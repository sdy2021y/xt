-- ============================================================================
-- SeasonManager.lua - 赛季管理器
-- 手动赛季制：由服务端 serverCloud 变量控制赛季更新
-- ============================================================================
---@diagnostic disable: return-type-mismatch

local EventBus = require("Infrastructure.EventBus")
local SeasonConfig = require("Config.SeasonConfig")
local PlayerDataManager = require("Data.PlayerDataManager")
local GameConfig = require("Config.GameConfig")

local SeasonManager = {}

-- 广告效果：金币翻倍
local goldDoubleActive_ = false

-- 订阅广告效果
EventBus.On("AdEffectActivated", function(effectType, effectData)
    if effectType == "goldDouble" then
        goldDoubleActive_ = effectData.active
    end
end)

-- ========== 内部状态 ==========

-- 当前赛季信息 { seasonId, seasonVersion, startTime, endTime, tierIndex, subTier, highestTierIndex }
local currentSeason_ = nil

-- 保段计数
local demotionProtection_ = 0
local MAX_DEMOTION_PROTECTION = 3

-- 服务端赛季结束时间（从 serverCloud 同步）
local serverSeasonEndTime_ = nil

-- 匹配保护相关
local totalBattlesThisSeason_ = 0  -- 本赛季总战斗数
local losingStreak_ = 0  -- 当前连败数
local IS_PROTECTION_ENABLED = true  -- 是否启用保护机制

-- ========== 初始化 ==========

function SeasonManager.Init()
    local data = PlayerDataManager.GetData()
    if data and data.seasonData then
        currentSeason_ = data.seasonData.currentSeason
        demotionProtection_ = data.seasonData.demotionProtection or 0
        totalBattlesThisSeason_ = data.seasonData.totalBattlesThisSeason or 0
        losingStreak_ = data.seasonData.losingStreak or 0
    end

    if SeasonConfig.MANUAL_SEASON then
        -- 手动赛季模式：从 serverCloud 获取赛季结束时间
        SeasonManager.SyncServerSeasonTime()
    else
        -- 自动赛季模式：检查本地时间
        if currentSeason_ then
            local now = os.time()
            if now >= currentSeason_.endTime then
                SeasonManager.EndSeason()
            end
        else
            SeasonManager.StartNewSeason()
        end
    end

    if not currentSeason_ then
        SeasonManager.StartNewSeason()
    end
end

--- 从服务端同步赛季时间（手动赛季模式）
function SeasonManager.SyncServerSeasonTime()
    if not clientCloud then return end

    -- 读取服务端设置的赛季结束时间和版本号
    clientCloud:Get("seasonEndTime", {
        ok = function(value)
            if value and type(value) == "number" and value > 0 then
                serverSeasonEndTime_ = value
                -- 检查赛季是否已过期
                if os.time() >= serverSeasonEndTime_ then
                    -- 赛季已结束，检查版本号是否已处理
                    SeasonManager.CheckSeasonVersion()
                else
                    -- 赛季进行中，更新本地结束时间
                    if currentSeason_ then
                        currentSeason_.endTime = serverSeasonEndTime_
                        SeasonManager.SaveData()
                    end
                end
            end
        end,
    })

    -- 同时获取赛季版本号
    clientCloud:Get("seasonVersion", {
        ok = function(value)
            if value and type(value) == "number" then
                local localVersion = currentSeason_ and currentSeason_.seasonVersion or 0
                if value > localVersion then
                    -- 服务端推送了新赛季版本，触发结算
                    SeasonManager.EndSeason()
                    if currentSeason_ then
                        currentSeason_.seasonVersion = value
                        SeasonManager.SaveData()
                    end
                end
            end
        end,
    })
end

--- 检查赛季版本（用于手动赛季判断是否需要结算）
function SeasonManager.CheckSeasonVersion()
    if not clientCloud then return end
    clientCloud:Get("seasonVersion", {
        ok = function(value)
            if not value then return end
            local localVersion = currentSeason_ and currentSeason_.seasonVersion or 0
            if value > localVersion then
                SeasonManager.EndSeason()
                if currentSeason_ then
                    currentSeason_.seasonVersion = value
                    SeasonManager.SaveData()
                end
            end
        end,
    })
end

-- ========== 赛季管理 ==========

--- 开始新赛季
function SeasonManager.StartNewSeason()
    local now = os.time()
    local endTime
    if SeasonConfig.MANUAL_SEASON then
        -- 手动赛季：结束时间由服务端控制，本地默认设为很远的未来
        endTime = serverSeasonEndTime_ or (now + 365 * 86400)
    else
        endTime = now + SeasonConfig.SEASON_DURATION
    end

    currentSeason_ = {
        seasonId = os.date("%Y%m%d", now),
        seasonVersion = SeasonConfig.SEASON_VERSION,
        startTime = now,
        endTime = endTime,
        tierIndex = 0,      -- 青铜
        subTier = 1,
        highestTierIndex = 0,
    }
    demotionProtection_ = 0
    totalBattlesThisSeason_ = 0  -- 重置本赛季战斗数
    losingStreak_ = 0  -- 重置连败
    SeasonManager.SaveData()
    EventBus.Emit("SeasonStarted", currentSeason_)
end

--- 结束赛季
function SeasonManager.EndSeason()
    if not currentSeason_ then return end

    -- 发放赛季结算奖励
    local rewards = SeasonConfig.SEASON_REWARDS[currentSeason_.highestTierIndex + 1]
    if rewards then
        PlayerDataManager.AddGold(rewards.gold)
        PlayerDataManager.AddXianyu(rewards.xianyu)
    end

    -- 重置到略低段位
    local now = os.time()
    local resetTierIndex = math.max(0, currentSeason_.tierIndex - 1)
    local endTime
    if SeasonConfig.MANUAL_SEASON then
        endTime = serverSeasonEndTime_ or (now + 365 * 86400)
    else
        endTime = now + SeasonConfig.SEASON_DURATION
    end

    local prevVersion = currentSeason_.seasonVersion or 0
    currentSeason_ = {
        seasonId = os.date("%Y%m%d", now),
        seasonVersion = prevVersion,
        startTime = now,
        endTime = endTime,
        tierIndex = resetTierIndex,
        subTier = 1,
        highestTierIndex = resetTierIndex,
    }
    demotionProtection_ = 0

    -- 重置段位奖励领取记录
    PlayerDataManager.Set("claimedTierRewards", {})

    SeasonManager.SaveData()
    EventBus.Emit("SeasonEnded", rewards)
end

-- ========== 段位管理 ==========

--- 更新奖杯（对战结束后调用）
---@param result string "victory"|"defeat"|"draw"
---@param mode? string 对战模式（"1v1"/"2v2"），默认"1v1"
---@return integer newTrophies, integer change, boolean tierChanged
function SeasonManager.UpdateTrophies(result, mode)
    if not currentSeason_ then return 0, 0, false end

    mode = mode or "1v1"
    local modeConfig = GameConfig.MODE_POINTS[mode] or GameConfig.MODE_POINTS["1v1"]

    local trophies = PlayerDataManager.Get("trophies") or 0
    local winBonus, lossPenalty = SeasonConfig.GetTrophyBonus(trophies)

    -- 用模式配置覆盖基础奖杯变化
    local change = 0
    if result == "victory" then
        change = modeConfig.win
        trophies = trophies + change
        losingStreak_ = 0
    elseif result == "draw" then
        -- 平局按失败处理（奖杯变化用 draw 值）
        change = modeConfig.draw
        trophies = math.max(0, trophies + change)
        losingStreak_ = losingStreak_ + 1
    else
        change = modeConfig.lose
        -- 保段机制
        if demotionProtection_ > 0 then
            demotionProtection_ = demotionProtection_ - 1
            change = 0
        else
            trophies = math.max(0, trophies + change)
        end
        losingStreak_ = losingStreak_ + 1
    end

    -- 增加本赛季战斗计数
    totalBattlesThisSeason_ = totalBattlesThisSeason_ + 1

    -- 更新玩家数据
    PlayerDataManager.UpdateTrophies(change)
    PlayerDataManager.RecordBattle(result)

    -- 检查段位变化
    local newTierIndex, newSubTier, _ = SeasonConfig.GetTierByTrophies(trophies)
    local tierChanged = false

    if newTierIndex > currentSeason_.tierIndex then
        -- 晋升
        tierChanged = true
        -- 发放晋升奖励
        SeasonManager.GrantPromotionReward(newTierIndex, newSubTier)
    elseif newTierIndex < currentSeason_.tierIndex then
        -- 掉段，给保护
        demotionProtection_ = MAX_DEMOTION_PROTECTION
    end

    currentSeason_.tierIndex = newTierIndex
    currentSeason_.subTier = newSubTier
    if newTierIndex > currentSeason_.highestTierIndex then
        currentSeason_.highestTierIndex = newTierIndex
    end

    SeasonManager.SaveData()

    if tierChanged then
        EventBus.Emit("TierChanged", newTierIndex, newSubTier)
    end

    return trophies, change, tierChanged
end

--- 发放晋升奖励
---@param tierIndex integer
---@param subTier integer
function SeasonManager.GrantPromotionReward(tierIndex, subTier)
    for _, reward in ipairs(SeasonConfig.TIER_PROMOTION_REWARDS) do
        if reward.tierIndex == tierIndex and reward.subTier == subTier then
            PlayerDataManager.AddGold(reward.gold)
            PlayerDataManager.AddXianyu(reward.xianyu)
            break
        end
    end
end

-- ========== 查询接口 ==========

--- 获取当前赛季信息
---@return table
function SeasonManager.GetCurrentSeason()
    return currentSeason_
end

--- 获取赛季剩余时间
---@return integer seconds
function SeasonManager.GetSeasonTimeRemaining()
    if not currentSeason_ then return 0 end
    return math.max(0, currentSeason_.endTime - os.time())
end

--- 获取当前段位
---@return string
function SeasonManager.GetCurrentTierName()
    if not currentSeason_ then return "青铜 I" end
    local trophies = PlayerDataManager.Get("trophies") or 0
    return SeasonConfig.GetTierDisplayName(currentSeason_.tierIndex, currentSeason_.subTier, trophies)
end

--- 获取最高段位
---@return string
function SeasonManager.GetHighestTierName()
    if not currentSeason_ then return "青铜 I" end
    local trophies = PlayerDataManager.Get("trophies") or 0
    return SeasonConfig.GetTierDisplayName(currentSeason_.highestTierIndex, 1, trophies)
end

--- 获取保段剩余次数
---@return integer
function SeasonManager.GetDemotionProtection()
    return demotionProtection_
end

-- ========== 持久化 ==========

function SeasonManager.SaveData()
    PlayerDataManager.Set("seasonData", {
        currentSeason = currentSeason_,
        demotionProtection = demotionProtection_,
        totalBattlesThisSeason = totalBattlesThisSeason_,
        losingStreak = losingStreak_,
    })
    PlayerDataManager.Save()
end

-- ========== 匹配保护公共接口 ==========

--- 检查是否应该匹配青铜级对手（前10局）
---@return boolean
function SeasonManager.ShouldMatchBronze()
    if not IS_PROTECTION_ENABLED then return false end
    return totalBattlesThisSeason_ < 10
end

--- 检查是否应该匹配AI（连败5局）
---@return boolean
function SeasonManager.ShouldMatchAI()
    if not IS_PROTECTION_ENABLED then return false end
    return losingStreak_ >= 5
end

--- 获取本赛季总战斗数
---@return integer
function SeasonManager.GetTotalBattlesThisSeason()
    return totalBattlesThisSeason_
end

--- 获取当前连败数
---@return integer
function SeasonManager.GetLosingStreak()
    return losingStreak_
end

return SeasonManager