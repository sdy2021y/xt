-- ============================================================================
-- OfflineRewardManager.lua - 离线奖励管理器
-- 据点产出：金币+铸材（按据点等级），3级起附加符文+星钻
-- ============================================================================

local PlayerDataManager = require("Data.PlayerDataManager")
local TerritoryConfig = require("Config.TerritoryConfig")
local EventBus = require("Infrastructure.EventBus")

local OfflineRewardManager = {}

-- ========== 内部状态 ==========

local accumulatedRewards_ = {
    gold = 0,
    materials = 0,
    runes = 0,
    xianyu = 0,
}

-- 广告效果：双倍离线奖励
local offlineDoubleActive_ = false

-- 订阅广告效果
EventBus.On("AdEffectActivated", function(effectType, effectData)
    if effectType == "doubleOffline" then
        offlineDoubleActive_ = effectData.active
    end
end)

-- ========== 初始化 ==========

function OfflineRewardManager.Init()
    local data = PlayerDataManager.GetData()
    if not data or not data.lastLoginAt then return end

    local now = os.time()
    local offlineSeconds = now - data.lastLoginAt
    local offlineHours = offlineSeconds / 3600

    if offlineHours <= 0.016 then return end  -- 不到1分钟不算离线

    -- 最多累积8小时
    offlineHours = math.min(offlineHours, 8)

    -- 据点等级
    local lordLevel = data.level or 1

    -- 基础产出：金币 + 铸材
    accumulatedRewards_.gold = math.floor(lordLevel * 15 * offlineHours)
    accumulatedRewards_.materials = math.floor(lordLevel * 10 * offlineHours)

    -- 据点3级开始附加：符文 + 星钻
    -- 24小时符文/星钻产出约10-20，即每小时约0.5-0.8
    if lordLevel >= 3 then
        local bonusLevel = lordLevel - 2  -- 3级开始算
        accumulatedRewards_.runes = math.floor(bonusLevel * 0.5 * offlineHours)
        accumulatedRewards_.xianyu = math.floor(bonusLevel * 0.5 * offlineHours)
    end

    if accumulatedRewards_.gold > 0 or accumulatedRewards_.materials > 0 then
        EventBus.Emit("OfflineRewardsReady", {
            hours = offlineHours,
            gold = accumulatedRewards_.gold,
            materials = accumulatedRewards_.materials,
            runes = accumulatedRewards_.runes,
            xianyu = accumulatedRewards_.xianyu,
        })
    end
end

-- ========== 领取奖励 ==========

--- 领取离线奖励
---@param isDoubled boolean 是否看广告双倍
---@return table rewards
function OfflineRewardManager.Claim(isDoubled)
    local multiplier = isDoubled and 2 or 1
    local rewards = {
        gold = accumulatedRewards_.gold * multiplier,
        materials = accumulatedRewards_.materials * multiplier,
        runes = accumulatedRewards_.runes * multiplier,
        xianyu = accumulatedRewards_.xianyu * multiplier,
    }

    if rewards.gold > 0 then
        PlayerDataManager.AddGold(rewards.gold)
    end
    if rewards.materials > 0 then
        PlayerDataManager.AddMaterials(rewards.materials)
    end
    if rewards.runes > 0 then
        PlayerDataManager.AddRunes(rewards.runes)
    end
    if rewards.xianyu > 0 then
        PlayerDataManager.AddXianyu(rewards.xianyu)
    end

    -- 清空累积
    accumulatedRewards_ = { gold = 0, materials = 0, runes = 0, xianyu = 0 }

    return rewards
end

--- 获取离线奖励（未领取）
---@return table
function OfflineRewardManager.GetAccumulated()
    return accumulatedRewards_
end

--- 是否有离线奖励
---@return boolean
function OfflineRewardManager.HasRewards()
    return accumulatedRewards_.gold > 0 or accumulatedRewards_.materials > 0
end

return OfflineRewardManager
