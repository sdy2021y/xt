-- ============================================================================
-- ChatManager.lua - 聊天系统
-- 局内精简快捷语 + 全服聊天 + 好友私聊
-- ============================================================================

local EventBus = require("Infrastructure.EventBus")
local PlayerDataManager = require("Data.PlayerDataManager")

local ChatManager = {}

-- ========== 快捷语列表（战斗中精简版） ==========

ChatManager.QUICK_CHATS = {
    "进攻！",
    "防守！",
    "干得漂亮！",
    "抱歉！",
    "GG！",
    "等我！",
}

-- ========== 表情快捷语 ==========

ChatManager.QUICK_EMOTES = {
    "😄",
    "😤",
    "👍",
    "😢",
}

-- ========== 内部状态 ==========

-- 最近聊天记录 { [channel] = { { sender, message, time } } }
local chatHistory_ = {}
local MAX_HISTORY = 50  -- 每个频道最多保留50条

-- ========== 初始化 ==========

function ChatManager.Init()
    chatHistory_ = {
        battle = {},   -- 局内频道
        friend = {},   -- 好友私聊
        world = {},    -- 全服频道
    }
end

-- ========== 发送消息 ==========

--- 发送局内快捷语
---@param playerId string 发送者ID
---@param playerName string 发送者名称
---@param quickChatIndex integer 快捷语索引
---@return string|nil message
function ChatManager.SendQuickChat(playerId, playerName, quickChatIndex)
    if quickChatIndex < 1 or quickChatIndex > #ChatManager.QUICK_CHATS then
        return nil
    end

    local message = ChatManager.QUICK_CHATS[quickChatIndex]
    local chatData = {
        sender = playerId,
        senderName = playerName,
        message = message,
        time = os.time(),
        type = "quick",
    }

    ChatManager.AddToHistory("battle", chatData)
    EventBus.Emit("ChatReceived", "battle", chatData)
    EventBus.Emit("ChatSent")  -- 成就系统
    return message
end

--- 发送局内表情
---@param playerId string 发送者ID
---@param playerName string 发送者名称
---@param emoteIndex integer 表情索引
---@return string|nil message
function ChatManager.SendEmote(playerId, playerName, emoteIndex)
    if emoteIndex < 1 or emoteIndex > #ChatManager.QUICK_EMOTES then
        return nil
    end

    local message = ChatManager.QUICK_EMOTES[emoteIndex]
    local chatData = {
        sender = playerId,
        senderName = playerName,
        message = message,
        time = os.time(),
        type = "emote",
    }

    ChatManager.AddToHistory("battle", chatData)
    EventBus.Emit("ChatReceived", "battle", chatData)
    EventBus.Emit("ChatSent")  -- 成就系统
    return message
end

--- 发送好友私聊
---@param friendId string
---@param message string
---@return boolean success
function ChatManager.SendFriendChat(friendId, message)
    if #message == 0 or #message > 200 then
        return false
    end

    local chatData = {
        sender = "self",
        senderName = PlayerDataManager.Get("name") or "浮空者",
        message = message,
        time = os.time(),
        type = "friend",
        targetId = friendId,
    }

    ChatManager.AddToHistory("friend", chatData)
    EventBus.Emit("ChatReceived", "friend", chatData)
    return true
end

--- 发送全服频道
---@param message string
---@return boolean success
function ChatManager.SendWorldChat(message)
    if #message == 0 or #message > 200 then
        return false
    end

    local chatData = {
        sender = "self",
        senderName = PlayerDataManager.Get("name") or "浮空者",
        message = message,
        time = os.time(),
        type = "world",
    }

    ChatManager.AddToHistory("world", chatData)
    EventBus.Emit("ChatReceived", "world", chatData)
    return true
end

-- ========== 消息管理 ==========

--- 添加到聊天记录
---@param channel string
---@param chatData table
function ChatManager.AddToHistory(channel, chatData)
    if not chatHistory_[channel] then
        chatHistory_[channel] = {}
    end

    table.insert(chatHistory_[channel], chatData)

    -- 限制历史记录数量
    while #chatHistory_[channel] > MAX_HISTORY do
        table.remove(chatHistory_[channel], 1)
    end
end

--- 获取聊天记录
---@param channel string
---@param count integer|nil 获取条数
---@return table[]
function ChatManager.GetHistory(channel, count)
    count = count or 20
    local history = chatHistory_[channel] or {}
    local start = math.max(1, #history - count + 1)
    local result = {}
    for i = start, #history do
        result[#result + 1] = history[i]
    end
    return result
end

--- 清空聊天记录
---@param channel string|nil nil=全部
function ChatManager.ClearHistory(channel)
    if channel then
        chatHistory_[channel] = {}
    else
        chatHistory_ = { battle = {}, friend = {}, tribe = {} }
    end
end

-- ========== 查询接口 ==========

--- 获取快捷语列表
---@return string[]
function ChatManager.GetQuickChats()
    return ChatManager.QUICK_CHATS
end

--- 获取未读消息数（好友私聊+部落）
---@return integer
function ChatManager.GetUnreadCount()
    -- 实际游戏中通过服务器追踪未读
    return 0
end

return ChatManager