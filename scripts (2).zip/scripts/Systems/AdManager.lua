-- ============================================================================
-- AdManager.lua - 广告系统
-- 6个广告位：免费宝箱加速/离线双倍/灵田加速/每日免费抽/金币翻倍/神器免费抽
-- ============================================================================

local PlayerDataManager = require("Data.PlayerDataManager")
local EventBus = require("Infrastructure.EventBus")

local AdManager = {}

-- ========== 广告位定义 ==========

AdManager.PLACEMENTS = {
    chestSpeed = {
        id = "chestSpeed",
        name = "宝箱加速",
        description = "减少宝箱解锁时间50%",
        maxDaily = 5,
        cooldown = 0,  -- 无冷却，每日限制
    },
    offlineDouble = {
        id = "offlineDouble",
        name = "离线双倍",
        description = "离线奖励翻倍",
        maxDaily = 1,
        cooldown = 0,
    },
    cropSpeed = {
        id = "cropSpeed",
        name = "灵田加速",
        description = "减少灵田种植时间30%",
        maxDaily = 3,
        cooldown = 0,
    },
    dailyFreePull = {
        id = "dailyFreePull",
        name = "每日免费抽",
        description = "免费抽卡1次",
        maxDaily = 1,
        cooldown = 0,
    },
    goldDouble = {
        id = "goldDouble",
        name = "金币翻倍",
        description = "对战金币奖励翻倍",
        maxDaily = 3,
        cooldown = 0,
    },
    freeArtifact = {
        id = "freeArtifact",
        name = "免费神器10连",
        description = "免费神器10连抽",
        cooldown = 6 * 3600,  -- 6小时冷却
        isCooldownBased = true,
    },
    shopRefresh = {
        id = "shopRefresh",
        name = "商店广告刷新",
        description = "看广告刷新商店商品",
        maxDaily = 3,
        cooldown = 0,
    },
}

-- ========== 内部状态 ==========

-- 每日使用计数 { [placementId] = count }
local dailyUsage_ = {}

-- 冷却时间记录 { [placementId] = lastUseTime }
local cooldowns_ = {}

-- 每日重置时间
local dailyResetTime_ = 0

-- 广告效果状态 { [effectType] = { active = boolean, expires = number, value = any } }
local effects_ = {}

-- 免费抽取次数
local freePullCount_ = 0

-- ========== 初始化 ==========

function AdManager.Init()
    local data = PlayerDataManager.GetData()
    if data and data.adData then
        dailyUsage_ = data.adData.dailyUsage or {}
        cooldowns_ = data.adData.cooldowns or {}
        dailyResetTime_ = data.adData.dailyResetTime or 0
        effects_ = data.adData.effects or {}
        freePullCount_ = data.adData.freePullCount or 0
    end

    AdManager.CheckDailyReset()
    AdManager.CheckEffectsExpiry()
end

-- ========== 每日重置 ==========

function AdManager.CheckDailyReset()
    local now = os.time()
    local todayStart = os.date("*t", now)
    todayStart.hour = 0
    todayStart.min = 0
    todayStart.sec = 0
    local todayReset = os.time(todayStart)

    if dailyResetTime_ < todayReset then
        dailyUsage_ = {}
        dailyResetTime_ = todayReset
        AdManager.SaveData()
    end
end

-- ========== 检查效果过期 ==========

function AdManager.CheckEffectsExpiry()
    local now = os.time()
    for effectType, effect in pairs(effects_) do
        if effect.expires and now >= effect.expires then
            effects_[effectType] = nil
            EventBus.Emit("AdEffectExpired", effectType)
        end
    end
end

-- ========== 广告播放 ==========

--- 检查是否可以播放广告
---@param placementId string
---@return boolean canPlay, string reason
function AdManager.CanPlayAd(placementId)
    local placement = AdManager.PLACEMENTS[placementId]
    if not placement then
        return false, "广告位不存在"
    end

    -- 检查冷却
    if placement.isCooldownBased then
        local lastUse = cooldowns_[placementId] or 0
        if os.time() - lastUse < placement.cooldown then
            local remaining = placement.cooldown - (os.time() - lastUse)
            return false, "冷却中，剩余" .. math.floor(remaining / 3600) .. "小时"
        end
    else
        -- 检查每日限制
        local used = dailyUsage_[placementId] or 0
        if used >= placement.maxDaily then
            return false, "今日次数已用完"
        end
    end

    return true, ""
end

--- 播放广告并领取奖励
---@param placementId string
---@return boolean success, string message, table|nil rewards
function AdManager.PlayAd(placementId)
    local canPlay, reason = AdManager.CanPlayAd(placementId)
    if not canPlay then
        return false, reason, nil
    end

    -- 更新使用计数
    if AdManager.PLACEMENTS[placementId].isCooldownBased then
        cooldowns_[placementId] = os.time()
    else
        dailyUsage_[placementId] = (dailyUsage_[placementId] or 0) + 1
    end

    -- 获取广告奖励和应用效果
    local rewards = AdManager.GetRewards(placementId)
    if rewards then
        -- 应用广告效果
        AdManager.ApplyEffect(placementId, rewards)
        
        if rewards.gold then PlayerDataManager.AddGold(rewards.gold) end
        if rewards.xianyu then PlayerDataManager.AddXianyu(rewards.xianyu) end
        if rewards.runes then PlayerDataManager.AddRunes(rewards.runes) end
        if rewards.materials then PlayerDataManager.AddMaterials(rewards.materials) end
        if rewards.freePull then 
            freePullCount_ = freePullCount_ + rewards.freePull
        end
    end

    AdManager.SaveData()
    EventBus.Emit("AdPlayed", placementId, rewards)
    return true, "广告播放完成", rewards
end

--- 应用广告效果
---@param placementId string
---@param rewards table
function AdManager.ApplyEffect(placementId, rewards)
    local now = os.time()
    if rewards.doubleSpeed then
        effects_["doubleSpeed"] = {
            active = true,
            expires = now + 3600,  -- 1小时效果
            value = 0.5  -- 50%加速
        }
        EventBus.Emit("AdEffectActivated", "doubleSpeed", effects_["doubleSpeed"])
    end
    if rewards.doubleOffline then
        effects_["doubleOffline"] = {
            active = true,
            expires = now + 86400,  -- 24小时效果
            value = 2  -- 双倍离线奖励
        }
        EventBus.Emit("AdEffectActivated", "doubleOffline", effects_["doubleOffline"])
    end
    if rewards.goldMultiplier then
        effects_["goldDouble"] = {
            active = true,
            expires = now + 3600,  -- 1小时效果
            value = rewards.goldMultiplier
        }
        EventBus.Emit("AdEffectActivated", "goldDouble", effects_["goldDouble"])
    end
    if rewards.freeArtifactPull then
        effects_["freeArtifact"] = {
            active = true,
            expires = now + 3600,  -- 1小时有效
            value = rewards.freeArtifactPull
        }
        EventBus.Emit("AdEffectActivated", "freeArtifact", effects_["freeArtifact"])
    end
end

--- 获取广告奖励
---@param placementId string
---@return table|nil
function AdManager.GetRewards(placementId)
    local rewards = {
        chestSpeed = { doubleSpeed = true },
        offlineDouble = { doubleOffline = true },
        cropSpeed = { speedUp = 0.30 },
        dailyFreePull = { freePull = 1 },
        goldDouble = { goldMultiplier = 2 },
        freeArtifact = { freeArtifactPull = 10 },
        shopRefresh = { shopRefresh = true },
    }
    return rewards[placementId]
end

-- ========== 效果查询接口 ==========

--- 检查某个效果是否激活
---@param effectType string
---@return boolean isActive
function AdManager.IsEffectActive(effectType)
    AdManager.CheckEffectsExpiry()
    local effect = effects_[effectType]
    return effect and effect.active and (not effect.expires or os.time() < effect.expires) or false
end

--- 获取效果值
---@param effectType string
---@return any value
function AdManager.GetEffectValue(effectType)
    AdManager.CheckEffectsExpiry()
    local effect = effects_[effectType]
    return effect and effect.value
end

--- 获取效果剩余时间
---@param effectType string
---@return number seconds
function AdManager.GetEffectRemaining(effectType)
    local effect = effects_[effectType]
    if not effect or not effect.expires then return 0 end
    return math.max(0, effect.expires - os.time())
end

--- 消耗免费抽取次数
---@param count number
---@return boolean success
function AdManager.UseFreePull(count)
    count = count or 1
    if freePullCount_ >= count then
        freePullCount_ = freePullCount_ - count
        AdManager.SaveData()
        return true
    end
    return false
end

--- 获取免费抽取剩余次数
---@return number
function AdManager.GetFreePullCount()
    return freePullCount_
end

-- ========== 查询接口 ==========

--- 获取广告位剩余次数
---@param placementId string
---@return integer
function AdManager.GetRemaining(placementId)
    local placement = AdManager.PLACEMENTS[placementId]
    if not placement then return 0 end

    if placement.isCooldownBased then
        local lastUse = cooldowns_[placementId] or 0
        local elapsed = os.time() - lastUse
        if elapsed >= placement.cooldown then
            return 1
        end
        return 0
    end

    local used = dailyUsage_[placementId] or 0
    return math.max(0, placement.maxDaily - used)
end

--- 获取冷却剩余时间（秒）
---@param placementId string
---@return integer
function AdManager.GetCooldownRemaining(placementId)
    local placement = AdManager.PLACEMENTS[placementId]
    if not placement or not placement.isCooldownBased then
        return 0
    end
    local lastUse = cooldowns_[placementId] or 0
    return math.max(0, placement.cooldown - (os.time() - lastUse))
end

-- ========== 持久化 ==========

function AdManager.SaveData()
    PlayerDataManager.Set("adData", {
        dailyUsage = dailyUsage_,
        cooldowns = cooldowns_,
        dailyResetTime = dailyResetTime_,
        effects = effects_,
        freePullCount = freePullCount_,
    })
    PlayerDataManager.Save()
end

return AdManager