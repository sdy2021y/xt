-- ============================================================================
-- FriendManager.lua - 好友系统
-- 添加好友、帮忙加速、赠送碎片、偷取资源
-- ============================================================================

local PlayerDataManager = require("Data.PlayerDataManager")
local EventBus = require("Infrastructure.EventBus")
local TerritoryConfig = require("Config.TerritoryConfig")

local FriendManager = {}

-- ========== 内部状态 ==========

-- 好友列表 { [friendId] = { name, avatar, lastOnline, tier, trophies } }
local friends_ = {}

-- 今日互动记录
local dailyInteractions_ = {
    helpCount = 0,      -- 今日帮忙次数
    stealCount = 0,     -- 今日偷取次数
    giftCount = 0,      -- 今日赠送次数
    maxHelp = 3,
    maxSteal = 3,
    maxGift = 1,
}

-- 重置时间
local dailyResetTime_ = 0

-- 被偷记录（防刷） { [playerId] = time }
local stolenRecords_ = {}

-- ========== 初始化 ==========

function FriendManager.Init()
    local data = PlayerDataManager.GetData()
    if data and data.friendData then
        friends_ = data.friendData.friends or {}
        dailyInteractions_ = data.friendData.dailyInteractions or {}
        dailyResetTime_ = data.friendData.dailyResetTime or 0
        stolenRecords_ = data.friendData.stolenRecords or {}
    end

    FriendManager.CheckDailyReset()
end

-- ========== 每日重置 ==========

function FriendManager.CheckDailyReset()
    local now = os.time()
    local todayStart = os.date("*t", now)
    todayStart.hour = 0
    todayStart.min = 0
    todayStart.sec = 0
    local todayReset = os.time(todayStart)

    if dailyResetTime_ < todayReset then
        dailyInteractions_ = {
            helpCount = 0,
            stealCount = 0,
            giftCount = 0,
            maxHelp = 3,
            maxSteal = 3,
            maxGift = 1,
        }
        dailyResetTime_ = todayReset
        FriendManager.SaveData()
    end
end

-- ========== 好友管理 ==========

--- 添加好友
---@param friendId string
---@param friendData table { name, avatar, tier, trophies }
---@return boolean success, string message
function FriendManager.AddFriend(friendId, friendData)
    if friends_[friendId] then
        return false, "已是好友"
    end

    friends_[friendId] = {
        name = friendData.name or "浮空者",
        avatar = friendData.avatar or "",
        tier = friendData.tier or 0,
        trophies = friendData.trophies or 0,
        lastOnline = os.time(),
    }

    FriendManager.SaveData()
    EventBus.Emit("FriendAdded", friendId)
    return true, "添加好友成功"
end

--- 删除好友
---@param friendId string
function FriendManager.RemoveFriend(friendId)
    friends_[friendId] = nil
    FriendManager.SaveData()
end

--- 获取好友列表
---@return table
function FriendManager.GetFriends()
    return friends_
end

--- 获取好友数量
---@return integer
function FriendManager.GetFriendCount()
    local count = 0
    for _ in pairs(friends_) do count = count + 1 end
    return count
end

-- ========== 帮忙加速 ==========

--- 帮忙好友加速灵田
---@param friendId string
---@param slotIndex integer
---@return boolean success, string message
function FriendManager.HelpFriend(friendId, slotIndex)
    if dailyInteractions_.helpCount >= dailyInteractions_.maxHelp then
        return false, "今日帮忙次数已用完"
    end

    if not friends_[friendId] then
        return false, "好友不存在"
    end

    -- 在实际游戏中，这里会通过服务器通知好友
    dailyInteractions_.helpCount = dailyInteractions_.helpCount + 1
    PlayerDataManager.AddRunes(TerritoryConfig.FRIEND_INTERACTION.helpReward)

    FriendManager.SaveData()
    EventBus.Emit("FriendHelp", friendId)
    return true, "帮忙成功，获得" .. TerritoryConfig.FRIEND_INTERACTION.helpReward .. "符文"
end

-- ========== 偷取资源 ==========

--- 偷取陌生人资源
---@param playerId string
---@return boolean success, string message, integer|nil stolenAmount
function FriendManager.StealFromPlayer(playerId)
    if dailyInteractions_.stealCount >= dailyInteractions_.maxSteal then
        return false, "今日偷取次数已用完", nil
    end

    -- 防刷：同一玩家每天只能被偷1次
    if stolenRecords_[playerId] then
        local todayStart = os.date("*t", os.time())
        todayStart.hour = 0
        todayStart.min = 0
        todayStart.sec = 0
        if stolenRecords_[playerId] > os.time(todayStart) then
            return false, "该玩家今日已被偷过", nil
        end
    end

    -- 防刷：1小时超10次偷取封禁
    local recentHour = os.time() - 3600
    local recentCount = 0
    for _, stealTime in pairs(stolenRecords_) do
        if stealTime > recentHour then
            recentCount = recentCount + 1
        end
    end
    if recentCount >= TerritoryConfig.FRIEND_INTERACTION.antiCheatMaxPerHour then
        return false, "操作过于频繁，请稍后再试", nil
    end

    -- 10%概率被抓
    if math.random() < TerritoryConfig.FRIEND_INTERACTION.stealCaughtRate then
        dailyInteractions_.stealCount = dailyInteractions_.stealCount + 1
        stolenRecords_[playerId] = os.time()
        PlayerDataManager.SpendRunes(TerritoryConfig.FRIEND_INTERACTION.stealPenalty)
        FriendManager.SaveData()
        return false, "偷取被抓！赔偿" .. TerritoryConfig.FRIEND_INTERACTION.stealPenalty .. "符文", nil
    end

    -- 偷取成功：偷取10%成熟星钻（模拟）
    -- 实际游戏中需要通过服务器获取目标玩家的星钻数据
    local stolenAmount = math.random(5, 20)
    dailyInteractions_.stealCount = dailyInteractions_.stealCount + 1
    stolenRecords_[playerId] = os.time()
    PlayerDataManager.AddXianyu(stolenAmount)

    FriendManager.SaveData()
    return true, "偷取成功！获得" .. stolenAmount .. "星钻", stolenAmount
end

-- ========== 赠送碎片 ==========

--- 赠送卡牌碎片给好友
---@param friendId string
---@param cardName string
---@return boolean success, string message
function FriendManager.GiftFragment(friendId, cardName)
    if dailyInteractions_.giftCount >= dailyInteractions_.maxGift then
        return false, "今日赠送次数已用完"
    end

    if not friends_[friendId] then
        return false, "好友不存在"
    end

    -- 检查是否拥有该卡（至少1张）
    if not PlayerDataManager.HasCard(cardName) then
        return false, "没有该卡牌"
    end

    dailyInteractions_.giftCount = dailyInteractions_.giftCount + 1
    FriendManager.SaveData()
    EventBus.Emit("FragmentGifted", friendId, cardName)
    return true, "赠送成功"
end

-- ========== 查询接口 ==========

--- 获取每日互动剩余次数
---@return table
function FriendManager.GetDailyRemaining()
    return {
        help = dailyInteractions_.maxHelp - dailyInteractions_.helpCount,
        steal = dailyInteractions_.maxSteal - dailyInteractions_.stealCount,
        gift = dailyInteractions_.maxGift - dailyInteractions_.giftCount,
    }
end

-- ========== 持久化 ==========

function FriendManager.SaveData()
    PlayerDataManager.Set("friendData", {
        friends = friends_,
        dailyInteractions = dailyInteractions_,
        dailyResetTime = dailyResetTime_,
        stolenRecords = stolenRecords_,
    })
    PlayerDataManager.Save()
end

return FriendManager