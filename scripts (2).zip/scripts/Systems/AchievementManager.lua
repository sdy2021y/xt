-- ============================================================================
-- AchievementManager.lua - 成就管理器
-- 25个成就，进度追踪，领取奖励
-- ============================================================================

local EventBus = require("Infrastructure.EventBus")
local AchievementConfig = require("Config.AchievementConfig")
local PlayerDataManager = require("Data.PlayerDataManager")

local AchievementManager = {}

-- ========== 内部状态 ==========

-- 成就进度 { [achievementId] = { progress, claimed } }
local progress_ = {}

-- 连胜计数器
local winStreak_ = 0
local maxWinStreak_ = 0  -- 记录最高连胜

-- ========== 初始化 ==========

function AchievementManager.Init()
    local data = PlayerDataManager.GetData()
    if data and data.achievementProgress then
        progress_ = data.achievementProgress
    else
        progress_ = {}
        for _, ach in ipairs(AchievementConfig.ACHIEVEMENTS) do
            progress_[ach.id] = { progress = 0, claimed = false }
        end
        AchievementManager.SaveData()
    end
    
    -- 加载连胜数据
    if data and data.winStreak ~= nil then
        winStreak_ = data.winStreak
    end
    if data and data.maxWinStreak ~= nil then
        maxWinStreak_ = data.maxWinStreak
    end

    -- 注册事件监听
    EventBus.On("BattleEnd", AchievementManager.OnBattleEnd)
    EventBus.On("CardCollected", AchievementManager.OnCardCollected)
    EventBus.On("CardUpgraded", AchievementManager.OnCardUpgraded)
    EventBus.On("ChestOpened", AchievementManager.OnChestOpened)
    EventBus.On("ArtifactCollected", AchievementManager.OnArtifactCollected)
    EventBus.On("ArtifactUsed", AchievementManager.OnArtifactUsed)
    EventBus.On("FriendAdded", AchievementManager.OnFriendAdded)
    EventBus.On("FriendHelp", AchievementManager.OnFriendHelp)
    EventBus.On("ChatSent", AchievementManager.OnChatSent)
    EventBus.On("TierChanged", AchievementManager.OnTierChanged)
    EventBus.On("LordLevelUp", AchievementManager.OnLordLevelUp)
end

-- ========== 事件处理 ==========

function AchievementManager.CheckWinStreakAchievements()
    -- 检查常见连胜阈值（可根据成就配置调整）
    local thresholds = { 3, 5, 10, 20, 50 }
    
    for _, threshold in ipairs(thresholds) do
        if winStreak_ >= threshold then
            -- 查找对应的成就
            for _, ach in ipairs(AchievementConfig.ACHIEVEMENTS) do
                if ach.target and ach.target.type == "winStreak" and ach.target.value == threshold then
                    local p = progress_[ach.id]
                    if p and not p.claimed then
                        p.progress = threshold
                        if p.progress >= ach.target.value then
                            EventBus.Emit("AchievementComplete", ach.id)
                        end
                    end
                end
            end
        end
    end
end

function AchievementManager.OnBattleEnd(result)
    AchievementManager.ReportProgress("totalBattles", 1)
    if result == "victory" then
        AchievementManager.ReportProgress("wins", 1)
        
        -- 胜利：连胜+1
        winStreak_ = winStreak_ + 1
        -- 更新最高连胜
        if winStreak_ > maxWinStreak_ then
            maxWinStreak_ = winStreak_
        end
        
        -- 检查连胜阈值成就
        AchievementManager.CheckWinStreakAchievements()
    else
        -- 失败：重置连胜
        winStreak_ = 0
    end
    
    -- 保存数据
    AchievementManager.SaveData()
end

function AchievementManager.OnCardCollected(cardName)
    local count = PlayerDataManager.GetCardCount()
    AchievementManager.SetProgress("cardsCollected", count)
end

function AchievementManager.OnCardUpgraded(times)
    AchievementManager.ReportProgress("cardUpgrades", times or 1)
end

function AchievementManager.OnChestOpened()
    AchievementManager.ReportProgress("chestsOpened", 1)
end

function AchievementManager.OnArtifactCollected(artifactName)
    -- 神器的收集数在神器管理器中计算
    local data = PlayerDataManager.GetData()
    if data and data.artifacts then
        local count = 0
        for _ in pairs(data.artifacts) do count = count + 1 end
        AchievementManager.SetProgress("artifactsCollected", count)
    end
end

function AchievementManager.OnArtifactUsed()
    AchievementManager.ReportProgress("artifactUse", 1)
end

function AchievementManager.OnFriendAdded()
    AchievementManager.ReportProgress("friendCount", 1)
end

function AchievementManager.OnFriendHelp()
    AchievementManager.ReportProgress("friendHelp", 1)
end

function AchievementManager.OnChatSent()
    AchievementManager.ReportProgress("chatMessages", 1)
end

function AchievementManager.OnTierChanged(tierIndex)
    AchievementManager.SetProgress("tier", tierIndex)
end

function AchievementManager.OnLordLevelUp(level)
    AchievementManager.SetProgress("lordLevel", level)
end

-- ========== 进度管理 ==========

--- 上报进度（增量）
---@param targetType string
---@param amount integer
function AchievementManager.ReportProgress(targetType, amount)
    for _, ach in ipairs(AchievementConfig.ACHIEVEMENTS) do
        if ach.target.type == targetType then
            local p = progress_[ach.id]
            if p and not p.claimed then
                p.progress = math.min((p.progress or 0) + amount, ach.target.value)
                if p.progress >= ach.target.value then
                    EventBus.Emit("AchievementComplete", ach.id)
                end
            end
        end
    end
    AchievementManager.SaveData()
end

--- 设置进度（绝对值）
---@param targetType string
---@param value integer
function AchievementManager.SetProgress(targetType, value)
    for _, ach in ipairs(AchievementConfig.ACHIEVEMENTS) do
        if ach.target.type == targetType then
            local p = progress_[ach.id]
            if p and not p.claimed then
                p.progress = math.min(value, ach.target.value)
                if p.progress >= ach.target.value then
                    EventBus.Emit("AchievementComplete", ach.id)
                end
            end
        end
    end
    AchievementManager.SaveData()
end

-- ========== 查询接口 ==========

--- 获取所有成就及进度
---@return table[]
function AchievementManager.GetAllAchievements()
    local result = {}
    for _, ach in ipairs(AchievementConfig.ACHIEVEMENTS) do
        local p = progress_[ach.id]
        result[#result + 1] = {
            id = ach.id,
            name = ach.name,
            desc = ach.desc,
            icon = ach.icon,
            category = ach.category,
            progress = p and p.progress or 0,
            target = ach.target.value,
            completed = (p and p.progress or 0) >= ach.target.value,
            claimed = p and p.claimed or false,
            rewards = ach.rewards,
        }
    end
    return result
end

--- 获取分类成就
---@param category string
---@return table[]
function AchievementManager.GetByCategory(category)
    local result = {}
    for _, item in ipairs(AchievementManager.GetAllAchievements()) do
        if item.category == category then
            result[#result + 1] = item
        end
    end
    return result
end

--- 领取成就奖励
---@param achievementId string
---@return boolean success, table|nil rewards
function AchievementManager.ClaimReward(achievementId)
    local p = progress_[achievementId]
    if not p then return false, nil end
    if p.claimed then return false, nil end

    -- 找到成就定义
    local achDef = nil
    for _, ach in ipairs(AchievementConfig.ACHIEVEMENTS) do
        if ach.id == achievementId then
            achDef = ach
            break
        end
    end
    if not achDef then return false, nil end

    -- 检查是否完成
    if p.progress < achDef.target.value then return false, nil end

    -- 发放奖励
    p.claimed = true
    if achDef.rewards then
        if achDef.rewards.runes then PlayerDataManager.AddRunes(achDef.rewards.runes) end
        if achDef.rewards.xianyu then PlayerDataManager.AddXianyu(achDef.rewards.xianyu) end
        if achDef.rewards.gold then PlayerDataManager.AddGold(achDef.rewards.gold) end
    end

    AchievementManager.SaveData()
    return true, achDef.rewards
end

--- 是否有可领取的成就
---@return boolean
function AchievementManager.HasClaimable()
    for _, item in ipairs(AchievementManager.GetAllAchievements()) do
        if item.completed and not item.claimed then
            return true
        end
    end
    return false
end

--- 获取完成进度统计
---@return integer completed, integer total
function AchievementManager.GetCompletionStats()
    local completed = 0
    for _, item in ipairs(AchievementManager.GetAllAchievements()) do
        if item.claimed then
            completed = completed + 1
        end
    end
    return completed, #AchievementConfig.ACHIEVEMENTS
end

-- ========== 持久化 ==========

function AchievementManager.SaveData()
    PlayerDataManager.Set("achievementProgress", progress_)
    PlayerDataManager.Set("winStreak", winStreak_)
    PlayerDataManager.Set("maxWinStreak", maxWinStreak_)
    PlayerDataManager.Save()
end

-- ========== 公共查询接口 ==========

--- 获取当前连胜次数
---@return integer
function AchievementManager.GetWinStreak()
    return winStreak_
end

--- 获取最高连胜次数
---@return integer
function AchievementManager.GetMaxWinStreak()
    return maxWinStreak_
end

return AchievementManager