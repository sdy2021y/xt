-- ══════════════════════════════════════════════
-- ============================================================================
-- PlayerDataManager.lua - 玩家数据持久化管理器
-- 管理奖杯、金币、符文、晶核、卡牌库存、等级等全局玩家数据
-- ============================================================================
---@diagnostic disable: missing-parameter
---@diagnostic disable: return-type-mismatch

local cjson = require("cjson")
local UnitConfig = require("Config.UnitConfig")

local PlayerDataManager = {}

-- ========== 常量 ==========
local SAVE_KEY = "player_data"

-- 默认新玩家数据
local DEFAULT_DATA = {
    name = "浮空者",
    level = 1,
    exp = 0,
    trophies = 0,
    trophyBest = 0,
    gold = 500,
    runes = 0,          -- 符文
    xianyu = 0,         -- 星钻（高级货币）
    spiritStones = 0,
    wins = 0,
    losses = 0,
    draws = 0,
    totalBattles = 0,
    -- 卡牌库存：cardName -> { count = int, level = int }
    -- 初始每张卡都有1张，等级1
    cards = {},
    -- 已解锁卡牌列表（用于标记哪些卡可用）
    unlockedCards = {},
    -- 统计
    chestsOpened = 0,
    cardsCollected = 0,
    -- 时间戳
    createdAt = 0,
    lastLoginAt = 0,
}

-- ========== 内部状态 ==========
---@type table
local data_ = nil
local dirty_ = false

-- ========== 云端存储（clientCloud） ==========

-- ========== 本地文件存档（兜底） ==========
local LOCAL_SAVE_FILE = "player_data.json"

local function saveToLocal()
    if not data_ then return end
    local ok, encoded = pcall(cjson.encode, data_)
    if not ok then
        print("[PlayerData] Local encode error: " .. tostring(encoded))
        return
    end
    local file = File:new(LOCAL_SAVE_FILE, FILE_WRITE)
    if file then
        file:WriteLine(encoded)
        file:Close()
        file:delete()
    end
end

local function loadFromLocal()
    if not fileSystem:FileExists(LOCAL_SAVE_FILE) then return nil end
    local file = File:new(LOCAL_SAVE_FILE, FILE_READ)
    if not file then return nil end
    local raw = file:ReadLine()
    file:Close()
    file:delete()
    if not raw or raw == "" then return nil end
    local ok, result = pcall(cjson.decode, raw)
    if ok and result then return result end
    return nil
end

local function saveToCloud()
    if not data_ then return end
    data_.lastSavedAt = os.time()
    -- 始终保存本地文件兜底
    saveToLocal()
    -- 云端可用时同步上云
    if not clientCloud then
        dirty_ = false
        return
    end
    clientCloud:Set(SAVE_KEY, cjson.encode(data_), {
        ok = function() end,
        error = function(err) print("[PlayerData] Cloud save error: " .. tostring(err)) end
    })
    dirty_ = false
end

local function loadFromCloud()
    -- 优先从云端加载
    if clientCloud then
        local raw = clientCloud:Get(SAVE_KEY)
        if raw and raw ~= "" then
            local ok, result = pcall(cjson.decode, raw)
            if ok and result then return result end
        end
    end
    -- 云端不可用或无数据时，从本地文件加载
    return loadFromLocal()
end

-- ========== 初始化 ==========

--- 初始化玩家数据（加载存档或创建新存档）
function PlayerDataManager.Init()
    local saved = loadFromCloud()
    if saved then
        -- 合并默认值（新增字段兼容）
        data_ = {}
        for k, v in pairs(DEFAULT_DATA) do
            data_[k] = saved[k] ~= nil and saved[k] or v
        end
        -- 确保 cards 和 unlockedCards 完整
        if type(data_.cards) ~= "table" then
            data_.cards = {}
        end
        if type(data_.unlockedCards) ~= "table" then
            data_.unlockedCards = {}
        end
    else
        -- 新玩家：初始化所有卡牌
        data_ = {}
        for k, v in pairs(DEFAULT_DATA) do
            if type(v) == "table" then
                data_[k] = {}
            else
                data_[k] = v
            end
        end
        data_.createdAt = os.time()
        data_.lastLoginAt = os.time()

        -- 初始解锁8张：联盟2绿2蓝1紫1金 + 矿脉 + 炮台 + 机械1绿卡
        local starterCards = {
            "矿脉", "炮台", "自爆机",
            "风帆新兵", "铁壁卫士", "破空剑士", "飞艇炮手", "联盟剑圣", "联盟元帅",
        }
        for _, cardName in ipairs(starterCards) do
            data_.cards[cardName] = { count = 0, level = 1 }
            data_.unlockedCards[#data_.unlockedCards + 1] = cardName
        end
        data_.cardsCollected = #starterCards

        saveToCloud()
    end

    -- 更新最后登录
    data_.lastLoginAt = os.time()
    dirty_ = true
end

-- ========== 读取 API ==========

--- 获取完整玩家数据表（只读引用）
---@return table
function PlayerDataManager.GetData()
    return data_
end

--- 获取单个字段
---@param key string
---@return any
function PlayerDataManager.Get(key)
    if data_ then return data_[key] end
    return nil
end

--- 获取卡牌信息
---@param cardName string
---@return table|nil { count, level }
function PlayerDataManager.GetCard(cardName)
    if data_ and data_.cards then
        return data_.cards[cardName]
    end
    return nil
end

--- 是否拥有某卡
---@param cardName string
---@return boolean
function PlayerDataManager.HasCard(cardName)
    if data_ and data_.cards then
        local card = data_.cards[cardName]
        return card ~= nil and card.count > 0
    end
    return false
end

--- 获取所有已解锁卡牌名
---@return string[]
function PlayerDataManager.GetUnlockedCards()
    if data_ and data_.unlockedCards then
        return data_.unlockedCards
    end
    return {}
end

--- 获取卡牌总收集数
---@return integer
function PlayerDataManager.GetCardCount()
    local count = 0
    if data_ and data_.cards then
        for _ in pairs(data_.cards) do
            count = count + 1
        end
    end
    return count
end

-- ========== 写入 API ==========

--- 设置单个字段
---@param key string
---@param value any
function PlayerDataManager.Set(key, value)
    if data_ then
        data_[key] = value
        dirty_ = true
    end
end

--- 增加金币
---@param amount integer
function PlayerDataManager.AddGold(amount)
    if data_ then
        data_.gold = (data_.gold or 0) + amount
        dirty_ = true
    end
end

--- 消耗金币
---@param amount integer
---@return boolean success
function PlayerDataManager.SpendGold(amount)
    if type(amount) ~= "number" or amount <= 0 then return false end
    if data_ and (data_.gold or 0) >= amount then
        data_.gold = data_.gold - amount
        dirty_ = true
        return true
    end
    return false
end

--- 增加符文
---@param amount integer
function PlayerDataManager.AddRunes(amount)
    if data_ then
        data_.runes = (data_.runes or 0) + amount
        dirty_ = true
    end
end

--- 消耗符文
---@param amount integer
---@return boolean success
function PlayerDataManager.SpendRunes(amount)
    if type(amount) ~= "number" or amount <= 0 then return false end
    if data_ and (data_.runes or 0) >= amount then
        data_.runes = data_.runes - amount
        dirty_ = true
        return true
    end
    return false
end

--- 更新奖杯（战斗后调用）
---@param change integer 正=赢得，负=失去
function PlayerDataManager.UpdateTrophies(change)
    if data_ then
        data_.trophies = math.max(0, (data_.trophies or 0) + change)
        if data_.trophies > (data_.trophyBest or 0) then
            data_.trophyBest = data_.trophies
        end
        dirty_ = true
    end
end

--- 记录战斗结果
---@param result string "victory"|"defeat"|"draw"
function PlayerDataManager.RecordBattle(result)
    if not data_ then return end
    data_.totalBattles = (data_.totalBattles or 0) + 1
    if result == "victory" then
        data_.wins = (data_.wins or 0) + 1
    elseif result == "defeat" then
        data_.losses = (data_.losses or 0) + 1
    else
        data_.draws = (data_.draws or 0) + 1
    end
    dirty_ = true
end

--- 添加卡牌到库存
---@param cardName string
---@param amount integer|nil 默认1
function PlayerDataManager.AddCard(cardName, amount)
    if not data_ then return end
    amount = amount or 1

    if not data_.cards[cardName] then
        -- 新卡：level=1 表示已拥有，count=amount-1 是重复卡数（第一张用于解锁，多余的算重复）
        data_.cards[cardName] = { count = math.max(0, amount - 1), level = 1 }
        -- 新解锁卡牌
        local found = false
        for _, name in ipairs(data_.unlockedCards) do
            if name == cardName then found = true; break end
        end
        if not found then
            data_.unlockedCards[#data_.unlockedCards + 1] = cardName
            data_.cardsCollected = (data_.cardsCollected or 0) + 1
        end
    else
        data_.cards[cardName].count = data_.cards[cardName].count + amount
    end
    dirty_ = true
end

--- 升级卡牌
---@param cardName string
---@return boolean success
function PlayerDataManager.UpgradeCard(cardName)
    if not data_ or not data_.cards[cardName] then return false end
    local card = data_.cards[cardName]
    local cardDef = UnitConfig.CARDS[cardName]
    if not cardDef then return false end

    -- 升级需求：等级张重复卡 + 金币
    local level = card.level or 1
    local cardsNeeded = level

    -- 金币消耗：绿卡100、蓝卡300、紫卡800、金卡2000
    local goldCosts = { green = 100, blue = 300, purple = 800, gold = 2000 }
    local goldNeeded = goldCosts[cardDef.quality] or 100

    if card.count < cardsNeeded then return false end
    if not PlayerDataManager.SpendGold(goldNeeded) then return false end

    -- 扣除资源
    card.count = card.count - cardsNeeded
    card.level = level + 1
    dirty_ = true

    -- 任务系统：报告卡牌升级事件
    local QuestManager = require("Data.QuestManager")
    QuestManager.ReportEvent("card_upgrade", 1)

    return true
end

--- 获取升级所需资源
---@param cardName string
---@return integer cardsNeeded, integer goldNeeded, integer currentLevel
function PlayerDataManager.GetUpgradeCost(cardName)
    if not data_ or not data_.cards[cardName] then
        ---@diagnostic disable-next-line: return-type-mismatch
        return 0, 0, 0
    end
    local card = data_.cards[cardName]
    local cardDef = UnitConfig.CARDS[cardName]
    local level = card.level or 1
    local goldCosts = { green = 100, blue = 300, purple = 800, gold = 2000 }
    local goldNeeded = goldCosts[(cardDef and cardDef.quality) or "green"] or 100
    return level, goldNeeded, level
end

-- ========== 星钻 API ==========

--- 增加星钻
---@param amount integer
function PlayerDataManager.AddXianyu(amount)
    if data_ then
        data_.xianyu = (data_.xianyu or 0) + amount
        dirty_ = true
    end
end

--- 消耗星钻
---@param amount integer
---@return boolean success
function PlayerDataManager.SpendXianyu(amount)
    if type(amount) ~= "number" or amount <= 0 then return false end
    if data_ and (data_.xianyu or 0) >= amount then
        data_.xianyu = data_.xianyu - amount
        dirty_ = true
        return true
    end
    return false
end

-- ========== 铸材/经验 API ==========

--- 增加铸材
---@param amount integer
function PlayerDataManager.AddMaterials(amount)
    if data_ then
        data_.spiritStones = (data_.spiritStones or 0) + amount
        dirty_ = true
    end
end

--- 消耗铸材
---@param amount integer
---@return boolean success
function PlayerDataManager.SpendMaterials(amount)
    if type(amount) ~= "number" or amount <= 0 then return false end
    if data_ and (data_.spiritStones or 0) >= amount then
        data_.spiritStones = data_.spiritStones - amount
        dirty_ = true
        return true
    end
    return false
end

--- 增加经验值（自动检测升级）
---@param amount integer
function PlayerDataManager.AddExp(amount)
    if data_ then
        data_.exp = (data_.exp or 0) + amount
        -- 简易升级公式：每级需要 level * 200 经验
        local level = data_.level or 1
        local needed = level * 200
        while data_.exp >= needed do
            data_.exp = data_.exp - needed
            data_.level = (data_.level or 1) + 1
            level = data_.level
            needed = level * 200
        end
        dirty_ = true
    end
end

-- ========== 保存控制 ==========

--- 手动保存（重要操作后调用）
function PlayerDataManager.Save()
    if dirty_ then
        saveToCloud()
    end
end

--- 自动保存（可在Update中定期调用）
local saveTimer_ = 0
function PlayerDataManager.AutoSave(dt)
    saveTimer_ = saveTimer_ + dt
    if saveTimer_ >= 30 and dirty_ then  -- 每30秒自动保存一次
        saveTimer_ = 0
        saveToCloud()
    end
end

return PlayerDataManager


-- ══════════════════════════════════════════════
