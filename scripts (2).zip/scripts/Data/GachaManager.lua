-- ============================================================================
-- GachaManager.lua - 抽卡保底系统
-- 50抽保底史诗，100抽保底传奇
-- ============================================================================
---@diagnostic disable: return-type-mismatch

local UnitConfig = require("Config.UnitConfig")
local PlayerDataManager = require("Data.PlayerDataManager")

local GachaManager = {}

-- ========== 常量 ==========

-- 保底计数
local PITY_EPIC = 50     -- 50抽保底史诗
local PITY_LEGENDARY = 100 -- 100抽保底传奇

-- 抽卡成本
GachaManager.COSTS = {
    single = 100,    -- 单抽100晶核
    tenPull = 1000,  -- 10连1000晶核
    xianyuSingle = 20,  -- 星钻单抽20
    xianyuTen = 180,    -- 星钻10连180
}

-- 基础概率
local BASE_PROB = {
    green = 50,      -- 50%
    blue = 35,       -- 35%
    purple = 12,     -- 12%
    gold = 3,        -- 3%
}

-- ========== 内部状态 ==========

-- 保底计数器
local pityCounter_ = {
    epic = 0,       -- 距上次史诗的抽数
    legendary = 0,  -- 距上次传说的抽数
    total = 0,      -- 总抽数
}

-- ========== 初始化 ==========

function GachaManager.Init()
    local data = PlayerDataManager.GetData()
    if data and data.gachaPity then
        pityCounter_ = data.gachaPity
    end
end

-- ========== 抽卡核心 ==========

--- 单抽
---@param currencyType string "gold"|"xianyu"
---@return table|nil cardInfo, string|nil error
function GachaManager.SinglePull(currencyType)
    -- 检查货币
    local cost = currencyType == "xianyu" and GachaManager.COSTS.xianyuSingle or GachaManager.COSTS.single
    if currencyType == "xianyu" then
        if not PlayerDataManager.SpendXianyu(cost) then
            return nil, "星钻不足"
        end
    else
        if not PlayerDataManager.SpendGold(cost) then
            return nil, "金币不足"
        end
    end

    return GachaManager.DoPull()
end

--- 10连抽
---@param currencyType string "gold"|"xianyu"
---@return table[] cards, string|nil error
function GachaManager.TenPull(currencyType)
    local cost = currencyType == "xianyu" and GachaManager.COSTS.xianyuTen or GachaManager.COSTS.tenPull
    if currencyType == "xianyu" then
        if not PlayerDataManager.SpendXianyu(cost) then
            return nil, "星钻不足"
        end
    else
        if not PlayerDataManager.SpendGold(cost) then
            return nil, "晶核不足"
        end
    end

    local cards = {}
    for i = 1, 10 do
        local card = GachaManager.DoPull()
        cards[#cards + 1] = card
    end
    return cards
end

--- 执行一次抽卡
---@return table cardInfo
function GachaManager.DoPull()
    -- 检查保底
    local quality = GachaManager.RollQuality()

    -- 根据品质筛选卡牌
    local candidates = {}
    for name, card in pairs(UnitConfig.CARDS) do
        if card.quality == quality then
            candidates[#candidates + 1] = { name = name, card = card }
        end
    end

    -- 随机选择一张
    local selected = candidates[math.random(1, #candidates)]
    local cardName = selected.name

    -- 添加到玩家库存
    PlayerDataManager.AddCard(cardName, 1)

    -- 更新保底计数
    pityCounter_.total = pityCounter_.total + 1
    if quality == "gold" then
        pityCounter_.legendary = 0
        pityCounter_.epic = pityCounter_.epic + 1
    elseif quality == "purple" then
        pityCounter_.epic = 0
        pityCounter_.legendary = pityCounter_.legendary + 1
    else
        pityCounter_.epic = pityCounter_.epic + 1
        pityCounter_.legendary = pityCounter_.legendary + 1
    end

    -- 保存保底计数
    PlayerDataManager.Set("gachaPity", pityCounter_)
    PlayerDataManager.Save()

    -- 任务系统上报
    local QuestManager = require("Data.QuestManager")
    QuestManager.ReportEvent("card_pull", 1)

    return {
        name = cardName,
        quality = quality,
        card = selected.card,
    }
end

--- 掷品质（含保底）
---@return string quality
function GachaManager.RollQuality()
    -- 保底检查
    if pityCounter_.legendary >= PITY_LEGENDARY then
        return "gold"
    end
    if pityCounter_.epic >= PITY_EPIC then
        return "purple"
    end

    -- 正常概率
    local roll = math.random(1, 100)
    if roll <= BASE_PROB.gold then
        return "gold"
    end
    local cumulative = BASE_PROB.gold
    if roll <= cumulative + BASE_PROB.purple then
        return "purple"
    end
    cumulative = cumulative + BASE_PROB.purple
    if roll <= cumulative + BASE_PROB.blue then
        return "blue"
    end
    return "green"
end

-- ========== 查询接口 ==========

--- 获取保底计数
---@return table
function GachaManager.GetPityCounter()
    return pityCounter_
end

--- 获取距保底剩余抽数
---@return integer epicRemaining, integer legendaryRemaining
function GachaManager.GetPityRemaining()
    return PITY_EPIC - pityCounter_.epic, PITY_LEGENDARY - pityCounter_.legendary
end

--- 获取总抽数
---@return integer
function GachaManager.GetTotalPulls()
    return pityCounter_.total
end

return GachaManager