-- ══════════════════════════════════════════════
---@diagnostic disable: assign-type-mismatch, missing-parameter
-- ============================================================================
-- QuestManager.lua - 每日/每周任务管理器
-- 进度追踪、重置判断、领取奖励
-- ============================================================================

local cjson = require("cjson")
local QuestConfig = require("Config.QuestConfig")

local QuestManager = {}

-- ========== 常量 ==========
local SAVE_KEY = "quest_data"

-- ========== 内部状态 ==========
---@type table|nil
local questData_ = nil
local dirty_ = false

-- ========== 时间工具 ==========

--- 获取今日0点时间戳
---@return integer
local function getTodayReset()
    local t = os.time()
    local d = os.date("*t", t)
    d.hour = 0
    d.min = 0
    d.sec = 0
    return os.time(d)
end

--- 获取本周一0点时间戳
---@return number
local function getWeeklyReset()
    local t = os.time()
    local d = os.date("*t", t)
    -- wday: 1=Sunday, 2=Monday, ..., 7=Saturday
    local daysSinceMonday = (d.wday - 2) % 7
    d.hour = 0
    d.min = 0
    d.sec = 0
    local todayMidnight = os.time(d)
    return todayMidnight - daysSinceMonday * 86400
end

-- ========== 云端存储（clientCloud） ==========

local function saveToCloud()
    if not questData_ then return end
    if not clientCloud then return end
    questData_.lastSavedAt = os.time()
    clientCloud:Set(SAVE_KEY, cjson.encode(questData_), {
        ok = function() end,
        error = function(err) print("[QuestData] Save error: " .. tostring(err)) end
    })
    dirty_ = false
end

local function loadFromCloud()
    if not clientCloud then return nil end
    local raw = clientCloud:Get(SAVE_KEY)
    if not raw or raw == "" then
        return nil
    end
    local ok, result = pcall(cjson.decode, raw)
    if ok and result then
        return result
    end
    return nil
end

-- ========== 初始化 ==========

--- 创建空的每日任务进度
---@return table
local function createDailyProgress()
    local progress = {}
    for _, quest in ipairs(QuestConfig.DAILY) do
        progress[quest.id] = {
            current = 0,
            claimed = false,
        }
    end
    progress._allClaimed = false
    return progress
end

--- 创建空的每周任务进度
---@return table
local function createWeeklyProgress()
    local progress = {}
    for _, quest in ipairs(QuestConfig.WEEKLY) do
        if quest.raceTarget then
            -- 特定种族任务需要记录各种族进度
            progress[quest.id] = {
                human = 0,
                demon = 0,
                dark = 0,
                spirit = 0,
                claimed = false,
            }
        else
            progress[quest.id] = {
                current = 0,
                claimed = false,
            }
        end
    end
    progress._allClaimed = false
    return progress
end

--- 初始化任务管理器
function QuestManager.Init()
    local saved = loadFromCloud()
    local now = os.time()
    local todayReset = getTodayReset()
    local weeklyReset = getWeeklyReset()

    if saved then
        questData_ = saved
        -- 检查每日重置
        if (questData_.dailyResetAt or 0) < todayReset then
            questData_.daily = createDailyProgress()
            questData_.dailyResetAt = todayReset
            dirty_ = true
        end
        -- 检查每周重置
        if (questData_.weeklyResetAt or 0) < weeklyReset then
            questData_.weekly = createWeeklyProgress()
            questData_.weeklyResetAt = weeklyReset
            dirty_ = true
        end
    else
        -- 新建
        questData_ = {
            daily = createDailyProgress(),
            weekly = createWeeklyProgress(),
            dailyResetAt = todayReset,
            weeklyResetAt = weeklyReset,
            -- 累计统计
            totalQuestsClaimed = 0,
            totalLingyuEarned = 0,
            totalXianyuEarned = 0,
        }
        dirty_ = true
    end

    if dirty_ then
        saveToCloud()
    end
end

-- ========== 事件上报 ==========

--- 上报事件（战斗中/战斗后调用）
---@param event string QuestConfig.EVENT 中的事件类型
---@param count integer|nil 增量（默认1）
---@param extra table|nil 额外数据，如 { race = "aether" }
function QuestManager.ReportEvent(event, count, extra)
    if not questData_ then return end
    count = count or 1
    extra = extra or {}

    -- 更新每日任务
    for _, quest in ipairs(QuestConfig.DAILY) do
        if quest.event == event then
            local p = questData_.daily[quest.id]
            if p and not p.claimed then
                p.current = (p.current or 0) + count
                dirty_ = true
            end
        end
    end

    -- 更新每周任务
    for _, quest in ipairs(QuestConfig.WEEKLY) do
        if quest.event == event then
            local p = questData_.weekly[quest.id]
            if p and not p.claimed then
                if quest.raceTarget and extra.race then
                    -- 种族特定任务
                    local race = extra.race
                    if p[race] ~= nil then
                        p[race] = (p[race] or 0) + count
                        dirty_ = true
                    end
                else
                    p.current = (p.current or 0) + count
                    dirty_ = true
                end
            end
        end
    end

    if dirty_ then
        saveToCloud()
    end
end

-- ========== 查询接口 ==========

--- 获取每日任务列表及进度
---@return table[] { id, name, desc, current, target, completed, claimed, rewards }
function QuestManager.GetDailyQuests()
    if not questData_ then return {} end
    local result = {}
    for _, quest in ipairs(QuestConfig.DAILY) do
        local p = questData_.daily[quest.id]
        if p then
            local current = math.min(p.current or 0, quest.target)
            result[#result + 1] = {
                id = quest.id,
                name = quest.name,
                desc = quest.desc,
                current = current,
                target = quest.target,
                completed = current >= quest.target,
                claimed = p.claimed or false,
                rewards = quest.rewards,
            }
        end
    end
    return result
end

--- 获取每周任务列表及进度
---@return table[] { id, name, desc, current, target, completed, claimed, rewards, raceProgress? }
function QuestManager.GetWeeklyQuests()
    if not questData_ then return {} end
    local result = {}
    for _, quest in ipairs(QuestConfig.WEEKLY) do
        local p = questData_.weekly[quest.id]
        if p then
            if quest.raceTarget then
                -- 种族任务：取最低值作为进度（4种族各需达标）
                local minRace = math.min(
                    math.min(p.human or 0, quest.target),
                    math.min(p.demon or 0, quest.target),
                    math.min(p.dark or 0, quest.target),
                    math.min(p.spirit or 0, quest.target)
                )
                local allDone = (p.human or 0) >= quest.target
                    and (p.demon or 0) >= quest.target
                    and (p.dark or 0) >= quest.target
                    and (p.spirit or 0) >= quest.target
                result[#result + 1] = {
                    id = quest.id,
                    name = quest.name,
                    desc = quest.desc,
                    current = minRace,
                    target = quest.target,
                    completed = allDone,
                    claimed = p.claimed or false,
                    rewards = quest.rewards,
                    raceProgress = {
                        human = math.min(p.human or 0, quest.target),
                        demon = math.min(p.demon or 0, quest.target),
                        dark = math.min(p.dark or 0, quest.target),
                        spirit = math.min(p.spirit or 0, quest.target),
                    },
                }
            else
                local current = math.min(p.current or 0, quest.target)
                result[#result + 1] = {
                    id = quest.id,
                    name = quest.name,
                    desc = quest.desc,
                    current = current,
                    target = quest.target,
                    completed = current >= quest.target,
                    claimed = p.claimed or false,
                    rewards = quest.rewards,
                }
            end
        end
    end
    return result
end

--- 是否有可领取的任务
---@return boolean hasDaily, boolean hasWeekly
function QuestManager.HasClaimable()
    local hasDaily = false
    local hasWeekly = false

    for _, q in ipairs(QuestManager.GetDailyQuests()) do
        if q.completed and not q.claimed then
            hasDaily = true
            break
        end
    end
    for _, q in ipairs(QuestManager.GetWeeklyQuests()) do
        if q.completed and not q.claimed then
            hasWeekly = true
            break
        end
    end

    return hasDaily, hasWeekly
end

--- 检查每日全部完成奖励是否可领
---@return boolean
function QuestManager.IsDailyAllClaimable()
    if not questData_ then return false end
    if questData_.daily._allClaimed then return false end
    for _, quest in ipairs(QuestConfig.DAILY) do
        local p = questData_.daily[quest.id]
        if not p or not p.claimed then
            return false
        end
    end
    return true
end

--- 检查每周全部完成奖励是否可领
---@return boolean
function QuestManager.IsWeeklyAllClaimable()
    if not questData_ then return false end
    if questData_.weekly._allClaimed then return false end
    for _, quest in ipairs(QuestConfig.WEEKLY) do
        local p = questData_.weekly[quest.id]
        if not p or not p.claimed then
            return false
        end
    end
    return true
end

-- ========== 领取奖励 ==========

--- 领取指定任务奖励
---@param questId string
---@param questType string "daily"|"weekly"
---@return table|nil rewards 领取成功返回奖励内容
function QuestManager.ClaimReward(questId, questType)
    if not questData_ then return nil end

    local questList = questType == "daily" and QuestConfig.DAILY or QuestConfig.WEEKLY
    local progressTable = questType == "daily" and questData_.daily or questData_.weekly

    -- 查找任务定义
    local questDef = nil
    for _, q in ipairs(questList) do
        if q.id == questId then
            questDef = q
            break
        end
    end
    if not questDef then return nil end

    -- 检查进度
    local p = progressTable[questId]
    if not p or p.claimed then return nil end

    -- 检查是否完成
    if questDef.raceTarget then
        local allDone = (p.human or 0) >= questDef.target
            and (p.demon or 0) >= questDef.target
            and (p.dark or 0) >= questDef.target
            and (p.spirit or 0) >= questDef.target
        if not allDone then return nil end
    else
        if (p.current or 0) < questDef.target then return nil end
    end

    -- 标记领取
    p.claimed = true
    dirty_ = true

    -- 统计
    questData_.totalQuestsClaimed = (questData_.totalQuestsClaimed or 0) + 1
    questData_.totalXianyuEarned = (questData_.totalXianyuEarned or 0) + (questDef.rewards.xianyu or 0)

    saveToCloud()
    return questDef.rewards
end

--- 领取全部完成额外奖励
---@param questType string "daily"|"weekly"
---@return table|nil rewards
function QuestManager.ClaimAllBonus(questType)
    if not questData_ then return nil end

    if questType == "daily" then
        if not QuestManager.IsDailyAllClaimable() then return nil end
        questData_.daily._allClaimed = true
        local bonus = QuestConfig.DAILY_ALL_COMPLETE_BONUS
        questData_.totalXianyuEarned = (questData_.totalXianyuEarned or 0) + (bonus.xianyu or 0)
        dirty_ = true
        saveToCloud()
        return bonus
    else
        if not QuestManager.IsWeeklyAllClaimable() then return nil end
        questData_.weekly._allClaimed = true
        local bonus = QuestConfig.WEEKLY_ALL_COMPLETE_BONUS
        questData_.totalXianyuEarned = (questData_.totalXianyuEarned or 0) + (bonus.xianyu or 0)
        dirty_ = true
        saveToCloud()
        return bonus
    end
end

-- ========== 辅助 ==========

--- 获取今日剩余重置时间（秒）
---@return integer
function QuestManager.GetDailyTimeRemaining()
    local nextReset = getTodayReset() + 86400
    return math.max(0, nextReset - os.time())
end

--- 获取本周剩余重置时间（秒）
---@return number
function QuestManager.GetWeeklyTimeRemaining()
    local nextReset = getWeeklyReset() + 7 * 86400
    return math.max(0, nextReset - os.time())
end

--- 格式化剩余时间
---@param seconds integer
---@return string
function QuestManager.FormatTimeRemaining(seconds)
    if seconds <= 0 then return "已重置" end
    local h = math.floor(seconds / 3600)
    local m = math.floor((seconds % 3600) / 60)
    if h >= 24 then
        local d = math.floor(h / 24)
        h = h % 24
        return string.format("%d天%d时", d, h)
    end
    return string.format("%d时%d分", h, m)
end

--- 获取已领取任务计数
---@param questType string "daily"|"weekly"
---@return integer claimed, integer total
function QuestManager.GetClaimedCount(questType)
    if not questData_ then return 0, 0 end
    local questList = questType == "daily" and QuestConfig.DAILY or QuestConfig.WEEKLY
    local progressTable = questType == "daily" and questData_.daily or questData_.weekly
    local claimed = 0
    local total = #questList
    for _, quest in ipairs(questList) do
        local p = progressTable[quest.id]
        if p and p.claimed then
            claimed = claimed + 1
        end
    end
    return claimed, total
end

return QuestManager


-- ══════════════════════════════════════════════
