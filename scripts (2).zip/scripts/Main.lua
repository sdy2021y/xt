-- ══════════════════════════════════════════════
-- ============================================================================
-- Main.lua - 仙途 游戏入口
-- 根据运行模式（Server/Client）加载对应模块
-- ============================================================================

---@type table
local Module = nil

function Start()
    math.randomseed(os.time())

    print("========================================")
    print("  仙途 (XianTu) v0.1.0")
    print("  Strategy Card Battle Game")
    print("========================================")

    if IsServerMode() then
        print("[Main] Running in SERVER mode")
        Module = require("Network.Server")
    else
        print("[Main] Running in CLIENT mode")
        Module = require("Network.Client")
    end

    Module.Start()
end

function Stop()
    if Module and Module.Stop then
        Module.Stop()
    end
    print("[Main] Game stopped")
end


-- ══════════════════════════════════════════════
