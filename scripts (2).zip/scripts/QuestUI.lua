-- ══════════════════════════════════════════════
---@diagnostic disable: param-type-mismatch
-- ============================================================================
-- QuestUI.lua - 每日/每周任务界面
-- 显示任务进度、领取奖励、倒计时重置
-- ============================================================================

local UI = require("urhox-libs/UI")
local QuestManager = require("Data.QuestManager")
local PlayerDataManager = require("Data.PlayerDataManager")

local QuestUI = {}

-- ========== 内部状态 ==========
local wrapper_ = nil
local activeTab_ = "daily"  -- "daily" | "weekly"
local onBack_ = nil

-- ========== 样式 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    bgPanel = "#12122A",
    bgCard = "#1A1A3A",
    bgCardCompleted = "#1A2A1A",
    bgCardClaimed = "#151520",
    headerBg = "#16162E",
    text = "#FFFFFF",
    textDim = "#8888AA",
    textGold = "#FFD700",
    textGreen = "#4CAF50",
    textCyan = "#64FFDA",
    progressBg = "#1A1A2E",
    progressFill = "#FFC107",
    progressFillDone = "#4CAF50",
    btnClaim = "#FF6D00",
    btnClaimed = "#333355",
    tabActive = "#FFD700",
    tabInactive = "#555577",
    border = "#2A2A4A",
    xianyu = "#FFD700",
    runes = "#AB47BC",
}

-- ========== 组件构建 ==========

--- 创建 Tab 切换栏
local function createTabBar()
    local dailyClaimed, dailyTotal = QuestManager.GetClaimedCount("daily")
    local weeklyClaimed, weeklyTotal = QuestManager.GetClaimedCount("weekly")

    local function tabBtn(id, label, claimed, total)
        local isActive = (id == activeTab_)
        return UI.Button {
            flexGrow = 1,
            height = 40,
            backgroundColor = isActive and "#1A1A3A" or { 0, 0, 0, 0 },
            borderBottomWidth = isActive and 2 or 0,
            borderColor = COLORS.tabActive,
            alignItems = "center",
            justifyContent = "center",
            onClick = function()
                if activeTab_ ~= id then
                    activeTab_ = id
                    QuestUI.Refresh()
                end
            end,
            children = {
                UI.Label {
                    text = label .. " (" .. claimed .. "/" .. total .. ")",
                    fontSize = 13,
                    fontColor = isActive and COLORS.tabActive or COLORS.tabInactive,
                },
            }
        }
    end

    return UI.Panel {
        width = "100%",
        height = 40,
        flexDirection = "row",
        backgroundColor = COLORS.bgPanel,
        children = {
            tabBtn("daily", "每日任务", dailyClaimed, dailyTotal),
            tabBtn("weekly", "每周任务", weeklyClaimed, weeklyTotal),
        }
    }
end

--- 创建进度条
---@param current integer
---@param target integer
---@param completed boolean
local function createProgressBar(current, target, completed)
    local ratio = math.min(1.0, current / math.max(1, target))
    return UI.Panel {
        width = "100%",
        height = 6,
        borderRadius = 3,
        backgroundColor = COLORS.progressBg,
        marginTop = 6,
        children = {
            UI.Panel {
                width = tostring(math.floor(ratio * 100)) .. "%",
                height = "100%",
                borderRadius = 3,
                backgroundColor = completed and COLORS.progressFillDone or COLORS.progressFill,
            },
        }
    }
end

--- 创建奖励显示
---@param rewards table { xianyu, gold, runes }
local function createRewardDisplay(rewards)
    local items = {}
    if rewards.gold and rewards.gold > 0 then
        items[#items + 1] = UI.Panel {
            flexDirection = "row",
            alignItems = "center",
            marginRight = 10,
            children = {
                UI.Label { text = "🪙", fontSize = 11 },
                UI.Label {
                    text = tostring(rewards.gold),
                    fontSize = 11,
                    fontColor = COLORS.gold,
                    marginLeft = 3,
                },
            }
        }
    end
    if rewards.runes and rewards.runes > 0 then
        items[#items + 1] = UI.Panel {
            flexDirection = "row",
            alignItems = "center",
            marginRight = 10,
            children = {
                UI.Label { text = "🔮", fontSize = 11 },
                UI.Label {
                    text = tostring(rewards.runes),
                    fontSize = 11,
                    fontColor = COLORS.runes,
                    marginLeft = 3,
                },
            }
        }
    end
    if rewards.xianyu and rewards.xianyu > 0 then
        items[#items + 1] = UI.Panel {
            flexDirection = "row",
            alignItems = "center",
            children = {
                UI.Label { text = "✨", fontSize = 11 },
                UI.Label {
                    text = tostring(rewards.xianyu),
                    fontSize = 11,
                    fontColor = COLORS.xianyu,
                    marginLeft = 3,
                },
            }
        }
    end
    return UI.Panel {
        flexDirection = "row",
        alignItems = "center",
        marginTop = 4,
        children = items,
    }
end

--- 创建单个任务卡片
---@param quest table { id, name, desc, current, target, completed, claimed, rewards, raceProgress? }
---@param questType string "daily"|"weekly"
local function createQuestCard(quest, questType)
    local bgColor = COLORS.bgCard
    if quest.claimed then
        bgColor = COLORS.bgCardClaimed
    elseif quest.completed then
        bgColor = COLORS.bgCardCompleted
    end

    -- 状态文字
    local statusText = quest.claimed and "已领取"
        or quest.completed and "可领取"
        or (quest.current .. "/" .. quest.target)

    local statusColor = quest.claimed and COLORS.textDim
        or quest.completed and COLORS.textGreen
        or COLORS.text

    -- 种族任务额外展示
    local raceDetail = nil
    if quest.raceProgress then
        local raceNames = { aether = "联盟", avian = "翼族", forge = "机械", astral = "元素" }
        local parts = {}
        for _, race in ipairs({"aether", "avian", "forge", "astral"}) do
            local v = quest.raceProgress[race] or 0
            local done = v >= quest.target
            parts[#parts + 1] = UI.Label {
                text = raceNames[race] .. v .. "/" .. quest.target,
                fontSize = 10,
                fontColor = done and COLORS.textGreen or COLORS.textDim,
                marginRight = 6,
            }
        end
        raceDetail = UI.Panel {
            flexDirection = "row",
            marginTop = 4,
            children = parts,
        }
    end

    -- 领取按钮
    local actionWidget = nil
    if quest.completed and not quest.claimed then
        actionWidget = UI.Button {
            width = 60, height = 28,
            borderRadius = 14,
            backgroundColor = COLORS.btnClaim,
            alignItems = "center",
            justifyContent = "center",
            onClick = function()
                local rewards = QuestManager.ClaimReward(quest.id, questType)
                if rewards then
                    -- 发放奖励到玩家数据
                    if rewards.gold then
                        PlayerDataManager.AddGold(rewards.gold)
                    end
                    if rewards.runes then
                        PlayerDataManager.AddRunes(rewards.runes)
                    end
                    if rewards.xianyu then
                        PlayerDataManager.AddXianyu(rewards.xianyu)
                    end
                    PlayerDataManager.Save()
                    QuestUI.Refresh()
                end
            end,
            children = {
                UI.Label { text = "领取", fontSize = 12, fontColor = "#FFF" },
            }
        }
    elseif quest.claimed then
        actionWidget = UI.Panel {
            width = 60, height = 28,
            borderRadius = 14,
            backgroundColor = COLORS.btnClaimed,
            alignItems = "center",
            justifyContent = "center",
            children = {
                UI.Label { text = "✓", fontSize = 14, fontColor = COLORS.textDim },
            }
        }
    else
        -- 进行中 - 显示进度数字
        actionWidget = UI.Label {
            text = statusText,
            fontSize = 12,
            fontColor = statusColor,
        }
    end

    -- 内容区域children
    local contentChildren = {
        UI.Label {
            text = quest.name,
            fontSize = 14,
            fontColor = quest.claimed and COLORS.textDim or COLORS.text,
            fontWeight = "bold",
        },
        UI.Label {
            text = quest.desc,
            fontSize = 11,
            fontColor = COLORS.textDim,
            marginTop = 2,
        },
        createRewardDisplay(quest.rewards),
    }
    if raceDetail then
        contentChildren[#contentChildren + 1] = raceDetail
    end
    contentChildren[#contentChildren + 1] = createProgressBar(quest.current, quest.target, quest.completed)

    return UI.Panel {
        width = "100%",
        paddingLeft = 12,
        paddingRight = 12,
        paddingTop = 10,
        paddingBottom = 10,
        marginBottom = 8,
        borderRadius = 8,
        backgroundColor = bgColor,
        flexDirection = "row",
        alignItems = "center",
        children = {
            -- 左侧内容
            UI.Panel {
                flexGrow = 1,
                flexShrink = 1,
                children = contentChildren,
            },
            -- 右侧按钮/状态
            UI.Panel {
                width = 70,
                alignItems = "center",
                justifyContent = "center",
                children = { actionWidget },
            },
        }
    }
end

--- 创建全部完成奖励卡
---@param questType string
local function createAllCompleteBonusCard(questType)
    local isClaimable = questType == "daily"
        and QuestManager.IsDailyAllClaimable()
        or QuestManager.IsWeeklyAllClaimable()

    local bonus = questType == "daily"
        and require("Config.QuestConfig").DAILY_ALL_COMPLETE_BONUS
        or require("Config.QuestConfig").WEEKLY_ALL_COMPLETE_BONUS

    local claimed, total = QuestManager.GetClaimedCount(questType)
    local allClaimed = claimed >= total

    -- 检查是否额外奖励已领
    local bonusClaimed = false
    if questType == "daily" then
        bonusClaimed = not QuestManager.IsDailyAllClaimable() and allClaimed
    else
        bonusClaimed = not QuestManager.IsWeeklyAllClaimable() and allClaimed
    end

    local actionWidget
    if isClaimable then
        actionWidget = UI.Button {
            width = 60, height = 28,
            borderRadius = 14,
            backgroundColor = "#E040FB",
            alignItems = "center",
            justifyContent = "center",
            onClick = function()
                local rewards = QuestManager.ClaimAllBonus(questType)
                if rewards then
                    if rewards.gold then
                        PlayerDataManager.AddGold(rewards.gold)
                    end
                    if rewards.runes then
                        PlayerDataManager.AddRunes(rewards.runes)
                    end
                    if rewards.xianyu then
                        PlayerDataManager.AddXianyu(rewards.xianyu)
                    end
                    PlayerDataManager.Save()
                    QuestUI.Refresh()
                end
            end,
            children = {
                UI.Label { text = "领取", fontSize = 12, fontColor = "#FFF" },
            }
        }
    elseif bonusClaimed then
        actionWidget = UI.Panel {
            width = 60, height = 28,
            borderRadius = 14,
            backgroundColor = COLORS.btnClaimed,
            alignItems = "center",
            justifyContent = "center",
            children = {
                UI.Label { text = "✓", fontSize = 14, fontColor = COLORS.textDim },
            }
        }
    else
        actionWidget = UI.Label {
            text = claimed .. "/" .. total,
            fontSize = 12,
            fontColor = COLORS.textDim,
        }
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12,
        paddingRight = 12,
        paddingTop = 10,
        paddingBottom = 10,
        marginBottom = 8,
        borderRadius = 8,
        backgroundColor = isClaimable and "#2A1A3A" or COLORS.bgCard,
        borderWidth = isClaimable and 1 or 0,
        borderColor = "#E040FB",
        flexDirection = "row",
        alignItems = "center",
        children = {
            UI.Panel {
                flexGrow = 1,
                flexShrink = 1,
                children = {
                    UI.Label {
                        text = "全部完成奖励",
                        fontSize = 14,
                        fontColor = isClaimable and "#E040FB" or COLORS.text,
                        fontWeight = "bold",
                    },
                    UI.Label {
                        text = "完成所有" .. (questType == "daily" and "每日" or "每周") .. "任务",
                        fontSize = 11,
                        fontColor = COLORS.textDim,
                        marginTop = 2,
                    },
                    createRewardDisplay(bonus),
                    createProgressBar(claimed, total, allClaimed),
                }
            },
            UI.Panel {
                width = 70,
                alignItems = "center",
                justifyContent = "center",
                children = { actionWidget },
            },
        }
    }
end

--- 创建任务列表内容
local function createQuestList()
    local quests = activeTab_ == "daily"
        and QuestManager.GetDailyQuests()
        or QuestManager.GetWeeklyQuests()
    local questType = activeTab_

    -- 排序：可领取的排最前，进行中其次，已领取的排最后
    table.sort(quests, function(a, b)
        local function priority(q)
            if q.completed and not q.claimed then return 1 end
            if not q.completed then return 2 end
            return 3
        end
        return priority(a) < priority(b)
    end)

    local cardWidgets = {}
    -- 全部完成奖励卡
    cardWidgets[#cardWidgets + 1] = createAllCompleteBonusCard(questType)
    -- 各任务卡
    for _, quest in ipairs(quests) do
        cardWidgets[#cardWidgets + 1] = createQuestCard(quest, questType)
    end

    return UI.ScrollView {
        width = "100%",
        flexGrow = 1,
        flexShrink = 1,
        paddingLeft = 10,
        paddingRight = 10,
        paddingTop = 10,
        paddingBottom = 10,
        children = cardWidgets,
    }
end

--- 创建底部货币总览
local function createFooter()
    local pd = PlayerDataManager.GetData()
    local runes = pd and pd.runes or 0
    local xianyu = pd and pd.xianyu or 0
    return UI.Panel {
        width = "100%",
        height = 36,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "center",
        backgroundColor = COLORS.headerBg,
        borderTopWidth = 1,
        borderColor = COLORS.border,
        children = {
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginRight = 24,
                children = {
                    UI.Label { text = "🔮", fontSize = 13 },
                    UI.Label {
                        text = " 符文: " .. tostring(runes),
                        fontSize = 12,
                        fontColor = COLORS.runes,
                    },
                }
            },
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                children = {
                    UI.Label { text = "✨", fontSize = 13 },
                    UI.Label {
                        text = " 星钻: " .. tostring(xianyu),
                        fontSize = 12,
                        fontColor = COLORS.xianyu,
                    },
                }
            },
        }
    }
end

-- ========== 公开 API ==========

--- 显示任务界面
---@param opts table|nil
---@return table wrapper
function QuestUI.Show(opts)
    opts = opts or {}
    onBack_ = opts.onBack
    QuestManager.Init()
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    QuestUI.Refresh()
    return wrapper_
end

--- 刷新界面
function QuestUI.Refresh()
    local content = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = COLORS.bgDark,
        paddingTop = 12,
        children = {
            createTabBar(),
            createQuestList(),
            createFooter(),
        }
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 隐藏界面
function QuestUI.Hide()
    wrapper_ = nil
end

--- 是否可见
---@return boolean
function QuestUI.IsVisible()
    return wrapper_ ~= nil
end

return QuestUI
