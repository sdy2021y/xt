-- ============================================================================
-- SoundManager.lua - 音效管理器
-- 统一管理游戏音效的加载和播放
-- ============================================================================

local SoundManager = {}

-- 音效缓存
local sounds_ = {}

-- 音效路径配置
local SOUND_PATHS = {
    flip       = "audio/sfx/flip_tile.ogg",
    build      = "audio/sfx/build_success.ogg",
    attack     = "audio/sfx/attack_hit.ogg",
    thunder    = "audio/sfx/skill_thunder.ogg",
    heal       = "audio/sfx/skill_heal.ogg",
    destroy    = "audio/sfx/building_destroy.ogg",
}

-- 播放节点（用于SoundSource组件）
---@type Node
local soundNode_ = nil

--- 初始化音效系统（在场景创建后调用）
---@param scene Scene
function SoundManager.Init(scene)
    -- 创建一个持久节点用于播放音效
    soundNode_ = scene:CreateChild("SoundManager")

    -- 预加载所有音效
    for name, path in pairs(SOUND_PATHS) do
        local sound = cache:GetResource("Sound", path)
        if sound then
            sounds_[name] = sound
        end
    end
end

--- 播放一个音效
---@param name string 音效名（flip/build/attack/thunder/heal/destroy）
---@param gain number|nil 音量（0~1，默认1.0）
function SoundManager.Play(name, gain)
    if not soundNode_ then return end

    local sound = sounds_[name]
    if not sound then return end

    -- 创建一个临时 SoundSource 组件（AUTO_REMOVE 播放完自动销毁）
    local source = soundNode_:CreateComponent("SoundSource")
    source.soundType = "Effect"
    source.gain = gain or 1.0
    source.autoRemoveMode = REMOVE_COMPONENT  -- 播放完成后自动移除组件
    source:Play(sound)
end

--- 获取已加载音效数量
---@return integer
function SoundManager.CountLoaded()
    local count = 0
    for _ in pairs(sounds_) do
        count = count + 1
    end
    return count
end

return SoundManager