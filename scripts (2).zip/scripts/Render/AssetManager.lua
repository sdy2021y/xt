-- ============================================================================
-- AssetManager.lua - 浮空岛美术资源管理器
-- 管理所有纹理、精灵、音效、字体的加载与缓存
-- ============================================================================

local GameConfig = require("Config.GameConfig")

local AssetManager = {}
AssetManager.__index = AssetManager

-- 资源状态枚举
AssetManager.STATUS = {
    UNLOADED = "unloaded",
    LOADING = "loading",
    LOADED = "loaded",
    ERROR = "error"
}

-- ============================================================================
-- 资源定义
-- ============================================================================

-- 建筑资源定义（对应 BuildingType）
AssetManager.BUILDING_ASSETS = {
    [GameConfig.BUILDING.MAIN_BASE] = {
        name = "核心",
        textures = {
            team1 = "assets/textures/buildings/main_base_team1.png",
            team2 = "assets/textures/buildings/main_base_team2.png"
        },
        width = 180,
        height = 180
    },
    [GameConfig.BUILDING.BARRACKS] = {
        name = "将营",
        textures = {
            team1 = "assets/textures/buildings/barracks_team1.png",
            team2 = "assets/textures/buildings/barracks_team2.png"
        },
        width = 140,
        height = 120
    },
    [GameConfig.BUILDING.TOWER] = {
        name = "炮台",
        textures = {
            team1 = "assets/textures/buildings/tower_team1.png",
            team2 = "assets/textures/buildings/tower_team2.png"
        },
        width = 100,
        height = 160
    },
    [GameConfig.BUILDING.SPIRIT_MINE] = {
        name = "矿脉",
        textures = {
            team1 = "assets/textures/buildings/spirit_mine_team1.png",
            team2 = "assets/textures/buildings/spirit_mine_team2.png"
        },
        width = 120,
        height = 140
    },
    [GameConfig.BUILDING.WALL] = {
        name = "护壁",
        textures = {
            team1 = "assets/textures/buildings/wall_team1.png",
            team2 = "assets/textures/buildings/wall_team2.png"
        },
        width = 80,
        height = 80
    }
}

-- 单位资源定义（对应 UnitType）
AssetManager.UNIT_ASSETS = {
    swordman = {
        name = "剑士",
        spritesheet = "assets/spritesheets/units/swordman.png",
        frameWidth = 64,
        frameHeight = 80,
        frames = { idle = 4, walk = 8, attack = 6, death = 4 }
    },
    archer = {
        name = "灵弓手",
        spritesheet = "assets/spritesheets/units/archer.png",
        frameWidth = 64,
        frameHeight = 80,
        frames = { idle = 4, walk = 8, attack = 6, death = 4 }
    },
    mage = {
        name = "法师",
        spritesheet = "assets/spritesheets/units/mage.png",
        frameWidth = 64,
        frameHeight = 80,
        frames = { idle = 4, walk = 8, attack = 8, death = 4 }
    },
    cavalry = {
        name = "骑兵",
        spritesheet = "assets/spritesheets/units/cavalry.png",
        frameWidth = 96,
        frameHeight = 96,
        frames = { idle = 4, walk = 8, attack = 6, death = 4 }
    },
    tank = {
        name = "重装卫士",
        spritesheet = "assets/spritesheets/units/tank.png",
        frameWidth = 80,
        frameHeight = 96,
        frames = { idle = 4, walk = 6, attack = 5, death = 4 }
    }
}

-- 格子资源定义
AssetManager.TILE_ASSETS = {
    hidden = "assets/textures/tiles/tile_hidden.png",
    revealed_team1 = "assets/textures/tiles/tile_revealed_team1.png",
    revealed_team2 = "assets/textures/tiles/tile_revealed_team2.png",
    fog_icon = "assets/textures/tiles/fog_icon.png"
}

-- UI 资源定义
AssetManager.UI_ASSETS = {
    buttons = {
        primary = "assets/textures/ui/button_primary.png",
        secondary = "assets/textures/ui/button_secondary.png",
        chat = "assets/textures/ui/button_chat.png",
        artifact = "assets/textures/ui/button_artifact.png"
    },
    panels = {
        info = "assets/textures/ui/panel_info.png",
        timer = "assets/textures/ui/panel_timer.png",
        chat = "assets/textures/ui/panel_chat.png"
    },
    icons = {
        spirit = "assets/textures/ui/icon_spirit.png",
        population = "assets/textures/ui/icon_population.png",
        territory = "assets/textures/ui/icon_territory.png"
    },
    frames = {
        card_green = "assets/textures/ui/card_frame_green.png",
        card_blue = "assets/textures/ui/card_frame_blue.png",
        card_purple = "assets/textures/ui/card_frame_purple.png",
        card_orange = "assets/textures/ui/card_frame_orange.png"
    }
}

-- 音效资源定义
AssetManager.AUDIO_ASSETS = {
    bgm = {
        battle = "assets/audio/bgm/battle.ogg",
        home = "assets/audio/bgm/home.ogg"
    },
    sfx = {
        flip = "assets/audio/sfx/flip.ogg",
        attack = "assets/audio/sfx/attack.ogg",
        build = "assets/audio/sfx/build.ogg",
        victory = "assets/audio/sfx/victory.ogg",
        defeat = "assets/audio/sfx/defeat.ogg",
        artifact = "assets/audio/sfx/artifact.ogg"
    }
}

-- ============================================================================
-- 实例创建
-- ============================================================================

function AssetManager.new()
    local self = setmetatable({}, AssetManager)
    self.textures = {}
    self.sprites = {}
    self.sounds = {}
    self.fonts = {}
    self.loadingCallbacks = {}
    return self
end

-- ============================================================================
-- 纹理加载
-- ============================================================================

function AssetManager:loadTexture(path, callback)
    if self.textures[path] then
        if self.textures[path].status == AssetManager.STATUS.LOADED then
            if callback then callback(self.textures[path].data, nil) end
        elseif self.textures[path].status == AssetManager.STATUS.LOADING then
            if callback then
                table.insert(self.loadingCallbacks[path], callback)
            end
        end
        return
    end

    self.textures[path] = {
        status = AssetManager.STATUS.LOADING,
        data = nil
    }
    self.loadingCallbacks[path] = callback and { callback } or {}

    -- 伪代码：实际加载纹理
    -- UrhoX 的纹理加载接口
    local texture = self:_loadTextureInternal(path)
    if texture then
        self.textures[path].status = AssetManager.STATUS.LOADED
        self.textures[path].data = texture
        for _, cb in ipairs(self.loadingCallbacks[path]) do
            cb(texture, nil)
        end
    else
        self.textures[path].status = AssetManager.STATUS.ERROR
        for _, cb in ipairs(self.loadingCallbacks[path]) do
            cb(nil, "Failed to load texture: " .. path)
        end
    end
    self.loadingCallbacks[path] = nil
end

function AssetManager:getTexture(path)
    local entry = self.textures[path]
    if entry and entry.status == AssetManager.STATUS.LOADED then
        return entry.data
    end
    return nil
end

-- 内部加载纹理（需要适配引擎）
function AssetManager:_loadTextureInternal(path)
    -- 这里需要根据你使用的游戏引擎实现
    -- 例如 UrhoX 的 texture:Load 方法
    return path -- 占位符
end

-- ============================================================================
-- 建筑纹理获取
-- ============================================================================

function AssetManager:getBuildingTexture(buildingType, team)
    local asset = AssetManager.BUILDING_ASSETS[buildingType]
    if not asset then return nil end
    local path = (team == 1) and asset.textures.team1 or asset.textures.team2
    return self:getTexture(path), asset
end

function AssetManager:loadBuildingTextures(buildingType, callback)
    local asset = AssetManager.BUILDING_ASSETS[buildingType]
    if not asset then
        if callback then callback(nil, "Unknown building type") end
        return
    end
    local loaded = 0
    local total = 2
    local textures = {}
    local error = nil

    local function checkDone()
        loaded = loaded + 1
        if loaded >= total then
            if callback then
                if error then
                    callback(nil, error)
                else
                    callback(textures, nil)
                end
            end
        end
    end

    self:loadTexture(asset.textures.team1, function(t, err)
        if err then error = err end
        textures.team1 = t
        checkDone()
    end)
    self:loadTexture(asset.textures.team2, function(t, err)
        if err then error = err end
        textures.team2 = t
        checkDone()
    end)
end

-- ============================================================================
-- 单位精灵加载
-- ============================================================================

function AssetManager:loadUnitSprites(unitType, callback)
    local asset = AssetManager.UNIT_ASSETS[unitType]
    if not asset then
        if callback then callback(nil, "Unknown unit type") end
        return
    end
    self:loadTexture(asset.spritesheet, function(texture, err)
        if err then
            if callback then callback(nil, err) end
            return
        end
        local sprites = {
            texture = texture,
            asset = asset,
            frames = {}
        }
        -- 解析精灵表
        for state, frameCount in pairs(asset.frames) do
            sprites.frames[state] = {}
            for i = 1, frameCount do
                sprites.frames[state][i] = {
                    x = (i - 1) * asset.frameWidth,
                    y = 0,
                    width = asset.frameWidth,
                    height = asset.frameHeight
                }
            end
        end
        if callback then callback(sprites, nil) end
    end)
end

-- ============================================================================
-- 批量预加载
-- ============================================================================

function AssetManager:preloadCriticalAssets(callback)
    local toLoad = {}
    local loadedCount = 0
    local errorCount = 0

    -- 收集关键资源
    for _, asset in pairs(AssetManager.BUILDING_ASSETS) do
        table.insert(toLoad, asset.textures.team1)
        table.insert(toLoad, asset.textures.team2)
    end
    table.insert(toLoad, AssetManager.TILE_ASSETS.revealed_team1)
    table.insert(toLoad, AssetManager.TILE_ASSETS.revealed_team2)
    table.insert(toLoad, AssetManager.TILE_ASSETS.fog_icon)

    local total = #toLoad

    local function onLoad(_, err)
        if err then errorCount = errorCount + 1 end
        loadedCount = loadedCount + 1
        if loadedCount >= total then
            if callback then
                callback(loadedCount, errorCount)
            end
        end
    end

    for _, path in ipairs(toLoad) do
        self:loadTexture(path, onLoad)
    end
end

-- ============================================================================
-- 获取加载进度
-- ============================================================================

function AssetManager:getLoadingProgress()
    local total = 0
    local loaded = 0
    for _, entry in pairs(self.textures) do
        total = total + 1
        if entry.status == AssetManager.STATUS.LOADED then
            loaded = loaded + 1
        end
    end
    return loaded, total
end

-- ============================================================================
-- 清除资源
-- ============================================================================

function AssetManager:clear()
    self.textures = {}
    self.sprites = {}
    -- 纹理资源需要引擎释放
end

return AssetManager
