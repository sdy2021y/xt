-- ══════════════════════════════════════════════
-- ============================================================================
-- HexRenderer.lua - 六边形格子 NanoVG 渲染器
-- 负责将格子状态绘制到屏幕上（含价格和类型图标）
-- ============================================================================

local HexGrid = require("Battle.HexGrid")
local GameConfig = require("Config.GameConfig")
local TileConfig = require("Config.TileConfig")
local Shared = require("Network.Shared")
local ViewTransform = require("Render.ViewTransform")

local HexRenderer = {}



-- 渲染配置
local hexRadius_ = GameConfig.HEX.RADIUS
local hexGap_ = GameConfig.HEX.GAP
local originX_ = 0
local localSlot_ = 1          -- 本地玩家slot（2v2区分盟友用）
local currentMode_ = "1v1"    -- 当前模式
local originY_ = 0
local mapWidth_ = 0   -- 地图总宽度(像素)，供 ViewTransform 使用
local mapHeight_ = 0  -- 地图总高度(像素)

-- 视口缩放/平移（战斗相机系统）
local viewScale_ = 1.5       -- 当前缩放级别（>1 表示放大/拉近）
local viewOffsetX_ = 0       -- 视口偏移X（逻辑像素，缩放前坐标系）
local viewOffsetY_ = 0       -- 视口偏移Y
local VIEW_SCALE_MIN = 1.2   -- 最小缩放（最远/最高视角）
local VIEW_SCALE_MAX = 3.2   -- 最大缩放（最近/最低视角）
local screenW_ = 0           -- 缓存屏幕尺寸
local screenH_ = 0

-- 翻牌动画状态
local flipAnimations_ = {}  -- { [hexKey] = { startTime, duration, tileData } }

-- 初始化翻牌动画
function HexRenderer.StartFlipAnimation(hexKey)
    flipAnimations_[hexKey] = {
        startTime = os.clock(),
        duration = 0.5,
    }
end

-- 更新动画（清理过期）
function HexRenderer.UpdateAnimations(dt)
    local now = os.clock()
    for key, anim in pairs(flipAnimations_) do
        if now - anim.startTime > anim.duration then
            flipAnimations_[key] = nil
        end
    end
end

-- ============================================================================
-- 初始化
-- ============================================================================

--- 计算并设置渲染原点（使格子居中）
---@param screenW number 屏幕宽度
---@param screenH number 屏幕高度
---@param cols integer 列数
---@param rows integer 行数
function HexRenderer.SetupLayout(screenW, screenH, cols, rows)
    local pY = HexGrid.PERSPECTIVE_Y
    local gridWidth = hexRadius_ * (3.0 / 2.0 * (cols - 1)) + hexRadius_ * 2
    local gridHeight = hexRadius_ * math.sqrt(3) * rows * pY  -- Y方向压缩

    mapWidth_ = gridWidth
    mapHeight_ = gridHeight

    -- origin 定义格子在地图空间中的位置（左上角偏移使格子居于地图空间中心）
    originX_ = hexRadius_
    originY_ = hexRadius_ * math.sqrt(3) * 0.5 * pY  -- Y方向压缩

    -- 缓存屏幕尺寸
    screenW_ = screenW
    screenH_ = screenH

    -- 初始视口：居中地图中央（后续 Client.ApplyMapData 会精确对准主城）
    viewOffsetX_ = 0
    viewOffsetY_ = 0
    HexRenderer.ClampViewOffset()
end



--- 获取当前渲染原点
---@return number, number
function HexRenderer.GetOrigin()
    return originX_, originY_
end

--- 获取当前 hex 半径
---@return number
function HexRenderer.GetRadius()
    return hexRadius_
end

--- 获取地图尺寸
---@return number width, number height
function HexRenderer.GetMapSize()
    return mapWidth_, mapHeight_
end

--- 设置本地玩家slot和模式（2v2模式下区分盟友格子用）
---@param slot integer
---@param mode string
function HexRenderer.SetLocalInfo(slot, mode)
    localSlot_ = slot or 1
    currentMode_ = mode or "1v1"
end

-- ============================================================================
-- 视口（缩放/平移）控制
-- ============================================================================

--- 限制视口偏移，不允许滑出地图边界
function HexRenderer.ClampViewOffset()
    if screenW_ == 0 or screenH_ == 0 then return end
    -- 视口焦点 = (mapWidth_/2 + viewOffsetX_, mapHeight_/2 + viewOffsetY_)
    -- 可视半宽/半高（地图空间）
    local halfVisW = screenW_ / (2 * viewScale_)
    local halfVisH = screenH_ / (2 * viewScale_)
    -- 焦点范围: [halfVisW, mapWidth_ - halfVisW]
    -- 即 mapWidth_/2 + offsetX ∈ [halfVisW, mapWidth_ - halfVisW]
    -- → offsetX ∈ [halfVisW - mapWidth_/2, mapWidth_/2 - halfVisW]
    local maxOffX = math.max(0, mapWidth_ / 2 - halfVisW)
    local maxOffY = math.max(0, mapHeight_ / 2 - halfVisH)
    viewOffsetX_ = math.max(-maxOffX, math.min(maxOffX, viewOffsetX_))
    viewOffsetY_ = math.max(-maxOffY, math.min(maxOffY, viewOffsetY_))
end

--- 设置缩放（带 clamp）
---@param newScale number
function HexRenderer.SetViewScale(newScale)
    viewScale_ = math.max(VIEW_SCALE_MIN, math.min(VIEW_SCALE_MAX, newScale))
    HexRenderer.ClampViewOffset()
end

--- 获取当前缩放
---@return number
function HexRenderer.GetViewScale()
    return viewScale_
end

--- 平移视口（delta 为屏幕像素单位）
---@param dx number 屏幕像素增量X
---@param dy number 屏幕像素增量Y
function HexRenderer.PanView(dx, dy)
    -- 屏幕像素 → 逻辑坐标（除以 scale）
    viewOffsetX_ = viewOffsetX_ - dx / viewScale_
    viewOffsetY_ = viewOffsetY_ - dy / viewScale_
    HexRenderer.ClampViewOffset()
end

--- 将视口中心对准指定地图空间坐标点
---@param mapX number 地图空间X
---@param mapY number 地图空间Y
function HexRenderer.CenterOnMapPoint(mapX, mapY)
    viewOffsetX_ = mapX - mapWidth_ / 2
    viewOffsetY_ = mapY - mapHeight_ / 2
    HexRenderer.ClampViewOffset()
end

--- 获取缩放范围
---@return number minScale
---@return number maxScale
function HexRenderer.GetScaleLimits()
    return VIEW_SCALE_MIN, VIEW_SCALE_MAX
end

--- 获取视口焦点（地图空间坐标，屏幕中心对准此点）
---@return number, number
function HexRenderer.GetViewFocus()
    return mapWidth_ / 2 + viewOffsetX_, mapHeight_ / 2 + viewOffsetY_
end

--- 将逻辑地图坐标转为视口屏幕坐标
--- NanoVG transform: T(scx,scy) * S(vs) * T(-fx,-fy) * point
--- screenX = (mapX - fx) * vs + scx
---@param mapX number
---@param mapY number
---@return number, number
function HexRenderer.MapToView(mapX, mapY)
    local fx, fy = HexRenderer.GetViewFocus()
    local rx = (mapX - fx) * viewScale_ + screenW_ / 2
    local ry = (mapY - fy) * viewScale_ + screenH_ / 2
    return rx, ry
end

--- 视口屏幕坐标转为逻辑地图坐标（逆变换）
--- mapX = (screenX - scx) / vs + fx
---@param viewX number
---@param viewY number
---@return number, number
function HexRenderer.ViewToMap(viewX, viewY)
    local fx, fy = HexRenderer.GetViewFocus()
    local mapX = (viewX - screenW_ / 2) / viewScale_ + fx
    local mapY = (viewY - screenH_ / 2) / viewScale_ + fy
    return mapX, mapY
end

-- ============================================================================
-- ViewTransform 坐标转换辅助
-- ============================================================================

--- 逻辑坐标转为屏幕坐标（应用 ViewTransform 翻转变换）— 返回地图空间坐标
---@param hex table {q, r}
---@return number, number
local function hexToScreen(hex)
    local sx, sy = HexGrid.ToPixel(hex, hexRadius_, originX_, originY_)
    return ViewTransform.Apply(sx, sy, mapWidth_, mapHeight_)
end

--- 屏幕坐标转为逻辑坐标（应用 ViewTransform 逆变换 + 视口逆变换）
---@param screenX number 视口屏幕坐标
---@param screenY number
---@return table|nil {q, r}
local function screenToLogical(screenX, screenY)
    -- 先从视口屏幕坐标 → 地图空间坐标
    local mapX, mapY = HexRenderer.ViewToMap(screenX, screenY)
    -- 再应用 ViewTransform 逆变换
    local lx, ly = ViewTransform.Invert(mapX, mapY, mapWidth_, mapHeight_)
    return HexGrid.FromPixel(lx, ly, hexRadius_, originX_, originY_)
end

-- ============================================================================
-- 渲染
-- ============================================================================

--- 绘制单个六边形
---@param vg userdata NanoVG 上下文
---@param cx number 中心X
---@param cy number 中心Y
---@param radius number 半径
---@param fillColor table {r,g,b,a}
---@param borderColor table|nil {r,g,b,a}
function HexRenderer.DrawHex(vg, cx, cy, radius, fillColor, borderColor)
    local r = radius - hexGap_
    local pY = HexGrid.PERSPECTIVE_Y
    nvgBeginPath(vg)

    for i = 0, 5 do
        local angleDeg = 60 * i
        local angleRad = math.rad(angleDeg)
        local px = cx + r * math.cos(angleRad)
        local py = cy + r * math.sin(angleRad) * pY
        if i == 0 then
            nvgMoveTo(vg, px, py)
        else
            nvgLineTo(vg, px, py)
        end
    end
    nvgClosePath(vg)

    nvgFillColor(vg, nvgRGBA(fillColor[1], fillColor[2], fillColor[3], fillColor[4]))
    nvgFill(vg)

    if borderColor then
        nvgStrokeColor(vg, nvgRGBA(borderColor[1], borderColor[2], borderColor[3], borderColor[4]))
        nvgStrokeWidth(vg, 1.5)
        nvgStroke(vg)
    end
end

--- 绘制带渐变质感的六边形瓦片（仿参考图平面3D效果）
---@param vg userdata NanoVG 上下文
---@param cx number 中心X
---@param cy number 中心Y
---@param baseColor table {r,g,b} 基础颜色
---@param radius number 六边形半径
function HexRenderer.DrawTileStyled(vg, cx, cy, baseColor, radius)
    local r = radius - hexGap_
    local br, bg, bb = baseColor[1], baseColor[2], baseColor[3]
    local pY = HexGrid.PERSPECTIVE_Y  -- 透视Y压缩因子

    -- 构建六边形路径（Y方向压缩模拟倾斜视角）
    nvgBeginPath(vg)
    for i = 0, 5 do
        local angleDeg = 60 * i
        local angleRad = math.rad(angleDeg)
        local vx = cx + r * math.cos(angleRad)
        local vy = cy + r * math.sin(angleRad) * pY
        if i == 0 then
            nvgMoveTo(vg, vx, vy)
        else
            nvgLineTo(vg, vx, vy)
        end
    end
    nvgClosePath(vg)

    -- 从上到下的线性渐变：顶部略亮，底部略暗（模拟微弱3D凸起）
    local lightR = math.min(255, br + 25)
    local lightG = math.min(255, bg + 25)
    local lightB = math.min(255, bb + 25)
    local darkR = math.max(0, br - 30)
    local darkG = math.max(0, bg - 30)
    local darkB = math.max(0, bb - 30)

    local halfH = r * 0.866 * pY  -- 压缩后的半高
    local gradient = nvgLinearGradient(vg, cx, cy - halfH, cx, cy + halfH,
        nvgRGBA(lightR, lightG, lightB, 255),
        nvgRGBA(darkR, darkG, darkB, 255))
    nvgFillPaint(vg, gradient)
    nvgFill(vg)
end

-- 瓦片质感颜色配置（参考 Top Heroes 风格）
local TILE_COLORS = {
    green = { 76, 190, 60 },      -- 玩家领地：翠绿
    yellow = { 240, 190, 50 },    -- 敌方领地：金黄
    neutral = { 140, 140, 140 },  -- 中立/未翻开：灰色
}

--- 根据 tile 状态获取瓦片质感颜色
---@param tile table|nil
---@return table|nil baseColor {r,g,b}
local function getTileStyledColor(tile)
    if not tile then return nil end
    if tile.ruins then return nil end  -- 残骸仍用纯色 fallback

    if tile.team == 1 then
        return TILE_COLORS.green
    elseif tile.team == 2 then
        return TILE_COLORS.yellow
    end
    return nil
end

--- 绘制地图背景（海洋/天空渐变 + 浮空岛阴影）
---@param vg userdata NanoVG 上下文
function HexRenderer.DrawBackground(vg)
    -- 背景渐变：深蓝海洋（从上到下由深到更深）
    local bgGrad = nvgLinearGradient(vg, 0, 0, 0, mapHeight_,
        nvgRGBA(25, 60, 120, 255),   -- 顶部：深蓝
        nvgRGBA(15, 35, 80, 255))    -- 底部：更深蓝
    nvgBeginPath(vg)
    nvgRect(vg, -mapWidth_ * 0.5, -mapHeight_ * 0.5, mapWidth_ * 2, mapHeight_ * 2)
    nvgFillPaint(vg, bgGrad)
    nvgFill(vg)

    -- 浮空岛底部阴影（地图整体偏移一个柔和的投影）
    local shadowOffY = 8
    local shadowBlur = 20
    local islandLeft = originX_ - hexRadius_
    local islandTop = originY_ - hexRadius_
    local islandW = mapWidth_
    local islandH = mapHeight_

    -- 椭圆形阴影（地图下方，营造悬浮感）
    nvgBeginPath(vg)
    nvgEllipse(vg, islandLeft + islandW / 2, islandTop + islandH + shadowOffY,
        islandW * 0.42, shadowBlur)
    nvgFillColor(vg, nvgRGBA(0, 0, 0, 60))
    nvgFill(vg)

    -- 地图底色（暗色底板，让六边形之间无缝隙时有一层微妙底色）
    nvgBeginPath(vg)
    nvgRoundedRect(vg, islandLeft - 4, islandTop - 4, islandW + 8, islandH + 8, 12)
    nvgFillColor(vg, nvgRGBA(20, 40, 60, 200))
    nvgFill(vg)

    -- 浮空岛边缘高光（顶部光线）
    nvgBeginPath(vg)
    nvgRoundedRect(vg, islandLeft - 4, islandTop - 4, islandW + 8, 6, 3)
    nvgFillColor(vg, nvgRGBA(100, 180, 255, 40))
    nvgFill(vg)
end

--- 绘制整个格子地图
---@param vg userdata NanoVG 上下文
---@param tiles table 格子数据
---@param hexes table[] 所有 hex 坐标
---@param highlightHex table|nil 当前高亮的格子
---@param buildings table|nil 建筑实例（用于显示产兵倒计时）
function HexRenderer.DrawGrid(vg, tiles, hexes, highlightHex, buildings)
    -- 视口裁剪：基于焦点计算地图空间可见范围（留 2 格余量避免边缘闪烁）
    local margin = hexRadius_ * 4
    local fx = mapWidth_ / 2 + viewOffsetX_
    local fy = mapHeight_ / 2 + viewOffsetY_
    local halfVisW = screenW_ / (2 * viewScale_)
    local halfVisH = screenH_ / (2 * viewScale_)
    local visLeft = fx - halfVisW - margin
    local visRight = fx + halfVisW + margin
    local visTop = fy - halfVisH - margin
    local visBottom = fy + halfVisH + margin

    for _, hex in ipairs(hexes) do
        local key = HexGrid.Key(hex.q, hex.r)
        local tile = tiles[key]
        -- 使用 hexToScreen 应用 ViewTransform 翻转变换
        local cx, cy = hexToScreen(hex)

        -- 视口裁剪：跳过屏幕外的格子
        if cx < visLeft or cx > visRight or cy < visTop or cy > visBottom then
            goto continue
        end

        -- 根据格子状态选择颜色
        local fillColor = GameConfig.COLORS.TILE_EMPTY
        local borderColor = { 60, 65, 75, 150 }

        if tile then
            if tile.ruins then
                -- 残骸：按归属队伍着色（暗色版），不用灰色
                if tile.team == 1 then
                    fillColor = { 35, 65, 120, 200 }
                    borderColor = { 60, 100, 160, 180 }
                elseif tile.team == 2 then
                    fillColor = { 120, 40, 40, 200 }
                    borderColor = { 160, 70, 70, 180 }
                else
                    fillColor = { 80, 80, 80, 200 }
                    borderColor = { 60, 60, 60, 180 }
                end
            elseif tile.team == 1 then
                if not tile.flipped and tile.tileType ~= TileConfig.TILE_TYPE.EMPTY then
                    fillColor = { 50, 100, 180, 220 }
                    borderColor = { 120, 180, 255, 255 }
                else
                    fillColor = { 50, 110, 190, 200 }
                    borderColor = { 100, 160, 230, 240 }
                end
            elseif tile.team == 2 then
                if not tile.flipped and tile.tileType ~= TileConfig.TILE_TYPE.EMPTY then
                    fillColor = { 180, 60, 60, 220 }
                    borderColor = { 255, 120, 120, 255 }
                else
                    fillColor = { 180, 60, 60, 200 }
                    borderColor = { 220, 100, 100, 240 }
                end
            end
        end

        -- 检查翻牌动画
        local flipAnim = flipAnimations_[key]
        local scale = 1.0
        if flipAnim then
            local progress = (os.clock() - flipAnim.startTime) / flipAnim.duration
            scale = 0.8 + 0.2 * math.abs(math.sin(progress * math.pi))
        end

        -- 绘制六边形（带缩放动画）
        if scale ~= 1.0 then
            nvgSave(vg)
            nvgTranslate(vg, cx, cy)
            nvgScale(vg, scale, scale)
            nvgTranslate(vg, -cx, -cy)
        end

        -- 优先使用带质感的六边形渲染，无颜色则 fallback 纯色
        local tileColor = getTileStyledColor(tile)
        if tileColor then
            HexRenderer.DrawTileStyled(vg, cx, cy, tileColor, hexRadius_)
        else
            HexRenderer.DrawHex(vg, cx, cy, hexRadius_, fillColor, borderColor)
        end

        if scale ~= 1.0 then
            nvgRestore(vg)
        end

        -- 高亮当前选中格子
        if highlightHex and highlightHex.q == hex.q and highlightHex.r == hex.r then
            HexRenderer.DrawHex(vg, cx, cy, hexRadius_ + 2,
                { 0, 0, 0, 0 }, GameConfig.COLORS.TILE_HIGHLIGHT)
        end

        -- 绘制内容
        if tile then
            if tile.flipped and tile.building and tile.building > 0 then
                -- 已翻有建筑：双方都可见
                HexRenderer.DrawBuildingIcon(vg, cx, cy, tile.building, tile.team)
                if buildings and buildings[key] then
                    local building = buildings[key]
                    if tile.building == GameConfig.BUILDING.SPIRIT_MINE or tile.building == GameConfig.BUILDING.MAIN_BASE then
                        local interval = building.spiritInterval or 5.0
                        local color = building.owner == 1 and { 100, 220, 255 } or { 255, 150, 100 }
                        HexRenderer.DrawCountdown(vg, cx, cy, building.spiritTimer, interval, color)
                    elseif tile.building == GameConfig.BUILDING.BARRACKS then
                        HexRenderer.DrawBarracksTimer(vg, cx, cy, building)
                    end
                end
            elseif not tile.flipped and not tile.ruins then
                -- 未翻开的格子：必须是我方领地 + 相邻我方已翻开格子才可翻
                local localTeam = ViewTransform.GetLocalTeam and ViewTransform.GetLocalTeam() or 1
                -- 领地检查：非我方领地不可翻
                if tile.team == localTeam then
                    -- 2v2模式：只显示自己slot相邻的格子
                    local slotForCheck = (currentMode_ == "2v2") and localSlot_ or nil
                    local isAdjacent = false
                    if slotForCheck then
                        isAdjacent = Shared.IsAdjacentToFlippedWithSlot(hex.q, hex.r, localTeam, slotForCheck, tiles)
                    else
                        isAdjacent = Shared.IsAdjacentToFlipped(hex.q, hex.r, localTeam, tiles)
                    end
                    if isAdjacent then
                        -- 相邻己方已翻开格子 + 我方领地：显示内容标签（可翻）
                        if tile.tileType ~= TileConfig.TILE_TYPE.EMPTY then
                            HexRenderer.DrawTileLabel(vg, cx, cy, tile)
                        end
                    end
                else
                    -- 非己方领地：显示迷雾
                    HexRenderer.DrawFogIcon(vg, cx, cy)
                end
            end
        end

        ::continue::
    end
end

--- 绘制兵营产兵倒计时
---@param vg userdata
---@param cx number
---@param cy number
---@param building table 建筑实例
function HexRenderer.DrawBarracksTimer(vg, cx, cy, building)
    local spawnRate = building.spawnRate
    if not spawnRate or spawnRate <= 0 then return end

    -- 应用羁绊加成后的实际产兵时间
    local produceBonus = 0  -- 这里暂时假设为0，实际游戏中从SynergyManager获取
    local effectiveRate = spawnRate * (1 - produceBonus)
    effectiveRate = math.max(1.0, effectiveRate)

    -- 倒计时颜色
    local color = building.owner == 1 and { 100, 200, 255 } or { 255, 120, 100 }
    HexRenderer.DrawCountdown(vg, cx, cy, building.spawnTimer, effectiveRate, color)
end

--- 绘制通用倒计时（带数字）
---@param vg userdata
---@param cx number
---@param cy number
---@param timer number 当前计时
---@param interval number 总间隔
---@param color table 颜色
function HexRenderer.DrawCountdown(vg, cx, cy, timer, interval, color)
    local progress = timer / interval
    progress = math.min(1.0, math.max(0.0, progress))

    -- 进度环半径
    local ringRadius = hexRadius_ * 0.7

    -- 绘制背景环（灰色）
    nvgBeginPath(vg)
    nvgCircle(vg, cx, cy, ringRadius)
    nvgStrokeColor(vg, nvgRGBA(60, 60, 80, 150))
    nvgStrokeWidth(vg, 3)
    nvgStroke(vg)

    -- 绘制进度弧
    if progress > 0 then
        local startAngle = -math.pi / 2
        local endAngle = startAngle + progress * math.pi * 2

        nvgBeginPath(vg)
        nvgArc(vg, cx, cy, ringRadius, startAngle, endAngle, NVG_CW)
        nvgStrokeColor(vg, nvgRGBA(color[1], color[2], color[3], 200))
        nvgStrokeWidth(vg, 4)
        nvgStroke(vg)
    end

    -- 绘制倒计时数字
    nvgFontFace(vg, "sans")
    nvgFontSize(vg, hexRadius_ * 0.35)
    nvgTextAlign(vg, NVG_ALIGN_CENTER + NVG_ALIGN_MIDDLE)
    nvgFillColor(vg, nvgRGBA(255, 255, 255, 220))
    local remaining = math.ceil(interval - timer)
    nvgText(vg, cx, cy, tostring(remaining))
end

--- 绘制敌方迷雾占位图标
---@param vg userdata
---@param cx number
---@param cy number
function HexRenderer.DrawFogIcon(vg, cx, cy)
    nvgFontFace(vg, "sans")
    nvgFontSize(vg, hexRadius_ * 0.8)
    nvgTextAlign(vg, NVG_ALIGN_CENTER + NVG_ALIGN_MIDDLE)
    nvgFillColor(vg, nvgRGBA(80, 80, 100, 150))
    nvgText(vg, cx, cy, "???")
end

--- 绘制未翻开格子的类型图标和价格
---@param vg userdata
---@param cx number
---@param cy number
---@param tile table
function HexRenderer.DrawTileLabel(vg, cx, cy, tile)
    local def = TileConfig.TILE_DEFS[tile.tileType]
    if not def then return end

    -- 绘制类型图标（上半部分）
    nvgFontFace(vg, "sans")
    nvgFontSize(vg, hexRadius_ * 0.7)
    nvgTextAlign(vg, NVG_ALIGN_CENTER + NVG_ALIGN_MIDDLE)

    -- 图标颜色根据类型不同
    local iconColor = { 255, 255, 255, 240 }
    if tile.tileType == TileConfig.TILE_TYPE.MYSTERY then
        iconColor = { 255, 220, 100, 255 }  -- 金色问号
    elseif tile.tileType == TileConfig.TILE_TYPE.SPIRIT_MINE then
        iconColor = { 100, 220, 255, 255 }  -- 蓝色矿脉
    elseif tile.tileType == TileConfig.TILE_TYPE.HIGH_BARRACKS then
        iconColor = { 255, 180, 50, 255 }   -- 金色高级
    end

    nvgFillColor(vg, nvgRGBA(iconColor[1], iconColor[2], iconColor[3], iconColor[4]))
    nvgText(vg, cx, cy - hexRadius_ * 0.15, def.icon)

    -- 绘制价格（下半部分，小字）
    nvgFontSize(vg, hexRadius_ * 0.45)
    nvgFillColor(vg, nvgRGBA(255, 240, 180, 220))
    nvgText(vg, cx, cy + hexRadius_ * 0.4, tostring(tile.price))
end

--- 绘制可爱仙侠版建筑图标
---@param vg userdata
---@param cx number
---@param cy number
---@param buildingType integer
---@param owner integer
function HexRenderer.DrawBuildingIcon(vg, cx, cy, buildingType, owner)
    local iconSize = hexRadius_ * 0.5
    local isPlayer1 = owner == 1
    
    -- 主城：可爱凌霄殿
    if buildingType == GameConfig.BUILDING.MAIN_BASE then
        local baseColor = isPlayer1 and { 255, 215, 0 } or { 180, 60, 60 }
        local roofColor = isPlayer1 and { 255, 100, 100 } or { 100, 40, 40 }
        
        -- 屋顶（三角形）
        nvgBeginPath(vg)
        nvgMoveTo(vg, cx, cy - iconSize * 1.1)
        nvgLineTo(vg, cx + iconSize * 0.9, cy - iconSize * 0.2)
        nvgLineTo(vg, cx - iconSize * 0.9, cy - iconSize * 0.2)
        nvgClosePath(vg)
        nvgFillColor(vg, nvgRGBA(roofColor[1], roofColor[2], roofColor[3], 255))
        nvgFill(vg)
        
        -- 屋顶装饰（小圆点）
        nvgBeginPath(vg)
        nvgCircle(vg, cx, cy - iconSize * 1.15, 3)
        nvgFillColor(vg, nvgRGBA(255, 255, 255, 255))
        nvgFill(vg)
        
        -- 房主体
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.7, cy - iconSize * 0.2, iconSize * 1.4, iconSize * 0.9)
        nvgFillColor(vg, nvgRGBA(baseColor[1], baseColor[2], baseColor[3], 255))
        nvgFill(vg)
        
        -- 门
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.25, cy + iconSize * 0.15, iconSize * 0.5, iconSize * 0.55)
        nvgFillColor(vg, nvgRGBA(80, 50, 30, 255))
        nvgFill(vg)
        
        -- 门的装饰
        nvgBeginPath(vg)
        nvgCircle(vg, cx + iconSize * 0.15, cy + iconSize * 0.45, 2)
        nvgFillColor(vg, nvgRGBA(255, 215, 0, 255))
        nvgFill(vg)
        
        -- 窗户
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.55, cy, iconSize * 0.25, iconSize * 0.3)
        nvgRect(vg, cx + iconSize * 0.3, cy, iconSize * 0.25, iconSize * 0.3)
        nvgFillColor(vg, nvgRGBA(255, 255, 200, 255))
        nvgFill(vg)

    -- 矿脉：聚能塔
    elseif buildingType == GameConfig.BUILDING.SPIRIT_MINE then
        local baseColor = isPlayer1 and { 100, 200, 255 } or { 150, 80, 150 }
        
        -- 塔基
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.5, cy, iconSize * 1, iconSize * 0.6)
        nvgFillColor(vg, nvgRGBA(80, 150, 100, 255))
        nvgFill(vg)
        
        -- 塔身
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.35, cy - iconSize * 0.6, iconSize * 0.7, iconSize * 0.8)
        nvgFillColor(vg, nvgRGBA(baseColor[1], baseColor[2], baseColor[3], 255))
        nvgFill(vg)
        
        -- 塔顶
        nvgBeginPath(vg)
        nvgMoveTo(vg, cx, cy - iconSize * 1.0)
        nvgLineTo(vg, cx + iconSize * 0.45, cy - iconSize * 0.5)
        nvgLineTo(vg, cx - iconSize * 0.45, cy - iconSize * 0.5)
        nvgClosePath(vg)
        nvgFillColor(vg, nvgRGBA(200, 220, 255, 255))
        nvgFill(vg)
        
        -- 发光晶核
        local pulse = 0.5 + 0.5 * math.sin(os.clock() * 3)
        nvgBeginPath(vg)
        nvgCircle(vg, cx, cy - iconSize * 0.2, 4 + pulse)
        nvgFillColor(vg, nvgRGBA(255, 255, 150, 255))
        nvgFill(vg)

    -- 兵营：可爱将营
    elseif buildingType == GameConfig.BUILDING.BARRACKS then
        local baseColor = isPlayer1 and { 150, 180, 255 } or { 200, 100, 100 }
        
        -- 帐篷主体
        nvgBeginPath(vg)
        nvgMoveTo(vg, cx, cy - iconSize * 1.0)
        nvgLineTo(vg, cx + iconSize * 0.8, cy + iconSize * 0.6)
        nvgLineTo(vg, cx - iconSize * 0.8, cy + iconSize * 0.6)
        nvgClosePath(vg)
        nvgFillColor(vg, nvgRGBA(baseColor[1], baseColor[2], baseColor[3], 255))
        nvgFill(vg)
        
        -- 帐篷条纹
        nvgBeginPath(vg)
        nvgMoveTo(vg, cx - iconSize * 0.4, cy + iconSize * 0.2)
        nvgLineTo(vg, cx - iconSize * 0.2, cy + iconSize * 0.6)
        nvgMoveTo(vg, cx + iconSize * 0.4, cy + iconSize * 0.2)
        nvgLineTo(vg, cx + iconSize * 0.2, cy + iconSize * 0.6)
        nvgStrokeColor(vg, nvgRGBA(255, 255, 255, 150))
        nvgStrokeWidth(vg, 2)
        nvgStroke(vg)
        
        -- 军旗
        nvgBeginPath(vg)
        nvgRect(vg, cx + iconSize * 0.6, cy - iconSize * 0.8, 2, iconSize * 1.2)
        nvgFillColor(vg, nvgRGBA(100, 80, 60, 255))
        nvgFill(vg)
        
        nvgBeginPath(vg)
        nvgMoveTo(vg, cx + iconSize * 0.62, cy - iconSize * 0.8)
        nvgLineTo(vg, cx + iconSize * 0.95, cy - iconSize * 0.6)
        nvgLineTo(vg, cx + iconSize * 0.62, cy - iconSize * 0.4)
        nvgClosePath(vg)
        nvgFillColor(vg, nvgRGBA(255, 80, 80, 255))
        nvgFill(vg)

    -- 防御塔：可爱望仙楼
    elseif buildingType == GameConfig.BUILDING.TOWER then
        local baseColor = isPlayer1 and { 120, 160, 200 } or { 160, 100, 100 }
        
        -- 塔基
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.45, cy + iconSize * 0.2, iconSize * 0.9, iconSize * 0.4)
        nvgFillColor(vg, nvgRGBA(100, 80, 60, 255))
        nvgFill(vg)
        
        -- 塔身
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.3, cy - iconSize * 0.6, iconSize * 0.6, iconSize * 1.0)
        nvgFillColor(vg, nvgRGBA(baseColor[1], baseColor[2], baseColor[3], 255))
        nvgFill(vg)
        
        -- 塔顶
        nvgBeginPath(vg)
        nvgMoveTo(vg, cx, cy - iconSize * 1.0)
        nvgLineTo(vg, cx + iconSize * 0.4, cy - iconSize * 0.55)
        nvgLineTo(vg, cx - iconSize * 0.4, cy - iconSize * 0.55)
        nvgClosePath(vg)
        nvgFillColor(vg, nvgRGBA(80, 60, 50, 255))
        nvgFill(vg)
        
        -- 箭孔
        nvgBeginPath(vg)
        nvgCircle(vg, cx, cy - iconSize * 0.2, 3)
        nvgFillColor(vg, nvgRGBA(40, 40, 40, 255))
        nvgFill(vg)

    -- 精锐防御塔：强化望仙楼（更大、发光）
    elseif buildingType == GameConfig.BUILDING.ELITE_TOWER then
        local baseColor = isPlayer1 and { 80, 120, 220 } or { 200, 60, 60 }

        -- 塔基（更宽）
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.55, cy + iconSize * 0.2, iconSize * 1.1, iconSize * 0.4)
        nvgFillColor(vg, nvgRGBA(80, 60, 50, 255))
        nvgFill(vg)

        -- 塔身（更宽更高）
        nvgBeginPath(vg)
        nvgRect(vg, cx - iconSize * 0.4, cy - iconSize * 0.7, iconSize * 0.8, iconSize * 1.1)
        nvgFillColor(vg, nvgRGBA(baseColor[1], baseColor[2], baseColor[3], 255))
        nvgFill(vg)

        -- 塔顶
        nvgBeginPath(vg)
        nvgMoveTo(vg, cx, cy - iconSize * 1.15)
        nvgLineTo(vg, cx + iconSize * 0.5, cy - iconSize * 0.6)
        nvgLineTo(vg, cx - iconSize * 0.5, cy - iconSize * 0.6)
        nvgClosePath(vg)
        nvgFillColor(vg, nvgRGBA(60, 40, 30, 255))
        nvgFill(vg)

        -- 双箭孔
        nvgBeginPath(vg)
        nvgCircle(vg, cx - iconSize * 0.15, cy - iconSize * 0.25, 3)
        nvgCircle(vg, cx + iconSize * 0.15, cy - iconSize * 0.25, 3)
        nvgFillColor(vg, nvgRGBA(255, 200, 100, 255))
        nvgFill(vg)

        -- 发光光环
        local pulse = 0.5 + 0.5 * math.sin(os.clock() * 2)
        nvgBeginPath(vg)
        nvgCircle(vg, cx, cy - iconSize * 0.3, iconSize * 0.3 + pulse * 2)
        nvgFillColor(vg, nvgRGBA(255, 200, 100, 30 + pulse * 20))
        nvgFill(vg)
    end
end

-- ============================================================================
-- 单位渲染
-- ============================================================================

--- 绘制所有单位
---@param vg userdata NanoVG 上下文
---@param units table[] 单位列表
function HexRenderer.DrawUnits(vg, units)
    for _, unit in ipairs(units) do
        if unit.state == "dead" then goto continueUnit end

        -- 使用 hexToScreen 应用 ViewTransform 翻转变换
        local cx, cy = hexToScreen({ q = unit.q, r = unit.r })
        HexRenderer.DrawUnit(vg, cx, cy, unit)

        ::continueUnit::
    end
end

--- 绘制简化版单位（性能优化：从15-20次draw call降至5-6次）
---@param vg userdata
---@param cx number
---@param cy number
---@param unit table
function HexRenderer.DrawUnit(vg, cx, cy, unit)
    local quality = unit.quality or "green"
    local isPlayer1 = unit.owner == 1

    -- 品质→大小映射
    local sizeScale = 1.0
    if quality == "green" then sizeScale = 0.80
    elseif quality == "blue" then sizeScale = 0.95
    elseif quality == "purple" then sizeScale = 1.10
    elseif quality == "gold" then sizeScale = 1.30
    end

    local radius = hexRadius_ * 0.22 * sizeScale
    local offsetX = ((unit.id % 3) - 1) * radius * 1.1
    local offsetY = (math.floor(unit.id / 3) % 2) * radius * 0.9
    cx = cx + offsetX
    cy = cy + offsetY

    -- 队伍颜色（玩家1绿色系，玩家2红色系）+ 品质亮度
    local bodyR, bodyG, bodyB
    if isPlayer1 then
        if quality == "gold" then bodyR, bodyG, bodyB = 200, 220, 60
        elseif quality == "purple" then bodyR, bodyG, bodyB = 100, 180, 160
        elseif quality == "blue" then bodyR, bodyG, bodyB = 80, 160, 200
        else bodyR, bodyG, bodyB = 100, 180, 90 end
    else
        if quality == "gold" then bodyR, bodyG, bodyB = 240, 180, 40
        elseif quality == "purple" then bodyR, bodyG, bodyB = 180, 80, 160
        elseif quality == "blue" then bodyR, bodyG, bodyB = 180, 100, 100
        else bodyR, bodyG, bodyB = 180, 70, 70 end
    end

    -- 1) 身体圆形（主色）
    nvgBeginPath(vg)
    nvgCircle(vg, cx, cy, radius)
    nvgFillColor(vg, nvgRGBA(bodyR, bodyG, bodyB, 230))
    nvgFill(vg)

    -- 2) 头部（肤色小圆）
    nvgBeginPath(vg)
    nvgCircle(vg, cx, cy - radius * 0.35, radius * 0.5)
    nvgFillColor(vg, nvgRGBA(255, 220, 185, 255))
    nvgFill(vg)

    -- 3) 品质环（金/紫卡专属，仅1次额外draw call）
    if quality == "gold" then
        nvgBeginPath(vg)
        nvgCircle(vg, cx, cy, radius * 1.2)
        nvgStrokeColor(vg, nvgRGBA(255, 215, 0, 180))
        nvgStrokeWidth(vg, 2)
        nvgStroke(vg)
    elseif quality == "purple" then
        nvgBeginPath(vg)
        nvgCircle(vg, cx, cy, radius * 1.15)
        nvgStrokeColor(vg, nvgRGBA(180, 100, 255, 150))
        nvgStrokeWidth(vg, 1.5)
        nvgStroke(vg)
    end

    -- 4) 血条（仅受伤时显示）
    local hpRatio = unit.hp / unit.maxHp
    if hpRatio < 1.0 then
        local barW = radius * 2.2
        local barH = 2.5
        local barX = cx - barW / 2
        local barY = cy - radius - 4

        nvgBeginPath(vg)
        nvgRect(vg, barX, barY, barW, barH)
        nvgFillColor(vg, nvgRGBA(0, 0, 0, 160))
        nvgFill(vg)

        local hr, hg, hb
        if hpRatio > 0.5 then hr, hg, hb = 80, 220, 80
        elseif hpRatio > 0.25 then hr, hg, hb = 240, 200, 50
        else hr, hg, hb = 240, 60, 60 end

        nvgBeginPath(vg)
        nvgRect(vg, barX, barY, barW * hpRatio, barH)
        nvgFillColor(vg, nvgRGBA(hr, hg, hb, 220))
        nvgFill(vg)
    end
end

-- ============================================================================
-- 建筑血条渲染
-- ============================================================================

--- 绘制所有建筑的血条
---@param vg userdata
---@param buildings table { [hexKey] = buildingInstance }
function HexRenderer.DrawBuildingHealthBars(vg, buildings)
    for hexKey, inst in pairs(buildings) do
        if inst.hp <= 0 then goto continueBldg end

        local hpRatio = inst.hp / inst.maxHp
        -- 满血不显示血条（减少视觉噪音）
        if hpRatio >= 1.0 then goto continueBldg end

        local bq, br = HexGrid.FromKey(hexKey)
        -- 使用 hexToScreen 应用 ViewTransform 翻转变换
        local cx, cy = hexToScreen({ q = bq, r = br })

        local barW = hexRadius_ * 1.2
        local barH = 3
        local barX = cx - barW / 2
        local barY = cy + hexRadius_ * 0.55

        -- 背景
        nvgBeginPath(vg)
        nvgRect(vg, barX, barY, barW, barH)
        nvgFillColor(vg, nvgRGBA(0, 0, 0, 180))
        nvgFill(vg)

        -- 血条颜色
        local hpColor
        if hpRatio > 0.5 then
            hpColor = { 80, 220, 80, 230 }
        elseif hpRatio > 0.25 then
            hpColor = { 240, 200, 50, 230 }
        else
            hpColor = { 240, 60, 60, 230 }
        end

        nvgBeginPath(vg)
        nvgRect(vg, barX, barY, barW * hpRatio, barH)
        nvgFillColor(vg, nvgRGBA(hpColor[1], hpColor[2], hpColor[3], hpColor[4]))
        nvgFill(vg)

        ::continueBldg::
    end
end

-- ============================================================================
-- 城墙渲染
-- ============================================================================

--- 绘制城墙段（两个相邻hex之间的边缘线段加厚显示）
---@param vg userdata
---@param segments table 城墙段表
function HexRenderer.DrawWalls(vg, segments)
    for _, seg in pairs(segments) do
        if seg.hp > 0 then
            -- 使用 hexToScreen 应用 ViewTransform 翻转变换
            local ax, ay = hexToScreen(seg.hexInside)
            local bx, by = hexToScreen(seg.hexOutside)

            -- 城墙绘制在两个hex中心连线的中点，垂直于连线方向
            local mx = (ax + bx) / 2
            local my = (ay + by) / 2

            -- 连线方向
            local dx = bx - ax
            local dy = by - ay
            local len = math.sqrt(dx * dx + dy * dy)
            if len < 0.01 then goto continueWall end

            -- 垂直方向（城墙线段方向）
            local nx = -dy / len
            local ny = dx / len

            -- 城墙长度 = hex半径 * 0.8
            local wallHalfLen = hexRadius_ * 0.45
            local x1 = mx + nx * wallHalfLen
            local y1 = my + ny * wallHalfLen
            local x2 = mx - nx * wallHalfLen
            local y2 = my - ny * wallHalfLen

            -- 颜色根据阵营和血量
            local hpRatio = seg.hp / seg.maxHp
            local alpha = math.floor(150 + hpRatio * 105)
            local color
            if seg.owner == 1 then
                color = { 80, 160, 255, alpha }
            else
                color = { 255, 100, 80, alpha }
            end

            -- 绘制城墙线段（粗线）
            local thickness = 2.5 + hpRatio * 1.5
            nvgBeginPath(vg)
            nvgMoveTo(vg, x1, y1)
            nvgLineTo(vg, x2, y2)
            nvgStrokeColor(vg, nvgRGBA(color[1], color[2], color[3], color[4]))
            nvgStrokeWidth(vg, thickness)
            nvgStroke(vg)

            ::continueWall::
        end
    end
end

--- 根据屏幕坐标获取对应的 hex（应用 ViewTransform 逆变换）
---@param screenX number
---@param screenY number
---@return table|nil hex坐标 {q, r}
function HexRenderer.ScreenToHex(screenX, screenY)
    return screenToLogical(screenX, screenY)
end

return HexRenderer


-- ══════════════════════════════════════════════
