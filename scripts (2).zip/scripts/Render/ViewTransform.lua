-- ============================================================================
-- ViewTransform.lua - 视图变换层
-- 将逻辑坐标转换为屏幕显示坐标，让本地玩家始终在屏幕底部
-- 纯渲染层处理，逻辑层完全不关心"谁在上面谁在下面"
-- ============================================================================

local ViewTransform = {}

local localTeam_ = 1  -- 本地玩家所在队伍

function ViewTransform.SetLocalTeam(team)
    localTeam_ = team
end

function ViewTransform.GetLocalTeam()
    return localTeam_
end

--- 逻辑坐标 → 屏幕坐标
--- 如果本地玩家在 team2（逻辑顶部），需要将整个地图翻转 180°
---@param screenX number 原始屏幕X
---@param screenY number 原始屏幕Y
---@param mapWidth number 地图总宽度(像素)
---@param mapHeight number 地图总高度(像素)
---@return number, number 变换后的 screenX, screenY
function ViewTransform.Apply(screenX, screenY, mapWidth, mapHeight)
    if localTeam_ == 2 then
        return mapWidth - screenX, mapHeight - screenY
    end
    return screenX, screenY
end

--- 屏幕点击坐标 → 逻辑坐标（反变换，用于输入）
---@param screenX number
---@param screenY number
---@param mapWidth number
---@param mapHeight number
---@return number, number
function ViewTransform.Invert(screenX, screenY, mapWidth, mapHeight)
    if localTeam_ == 2 then
        return mapWidth - screenX, mapHeight - screenY
    end
    return screenX, screenY
end

--- 判断一个 owner 是否是"我方"（用于颜色区分）
---@param ownerTeam integer
---@return boolean
function ViewTransform.IsAlly(ownerTeam)
    return ownerTeam == localTeam_
end

return ViewTransform