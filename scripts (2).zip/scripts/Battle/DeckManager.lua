-- ══════════════════════════════════════════════
-- ============================================================================
-- DeckManager.lua - 卡组管理器
-- 管理双方玩家的卡组（各8张），提供基于卡组的产兵抽卡逻辑
-- ============================================================================
---@diagnostic disable: missing-parameter

local cjson = require("cjson")
local UnitConfig = require("Config.UnitConfig")
local SynergyManager = require("Battle.SynergyManager")
local PlayerDataManager = require("Data.PlayerDataManager")

local DeckManager = {}

--- 卡组大小上限
DeckManager.DECK_SIZE = 8

-- 内部存储：decks_[owner] = { cardName1, cardName2, ... }
local decks_ = {}
-- 羁绊缓存：synergies_[owner] = SynergyManager 计算结果
local synergies_ = {}

-- 内存缓存：解决 clientCloud 异步延迟导致 Get 返回 nil 的问题
-- 保存时同步写入 memoryCache_，读取时优先从 memoryCache_ 取
local memoryCache_ = nil  -- table|nil { activeSlot, decks }

-- ============================================================================
-- 默认卡组（无玩家配置时使用）
-- ============================================================================

--- 默认玩家卡组：联盟2绿1蓝1紫1金 + 矿脉 + 炮台 + 机械1绿卡
DeckManager.DEFAULT_PLAYER_DECK = {
    "矿脉",        -- 矿脉
    "炮台",        -- 炮台
    "风帆新兵",    -- 联盟·近战·绿
    "铁壁卫士",    -- 联盟·近战·绿
    "破空剑士",    -- 联盟·近战·蓝
    "联盟剑圣",    -- 联盟·远程·紫
    "联盟元帅",    -- 联盟·远程·金
    "自爆机",      -- 机械·近战·绿
}

--- 默认AI卡组：包含矿脉 + 各品质单位卡
DeckManager.DEFAULT_AI_DECK = {
    "矿脉",        -- 矿脉·绿
    "自爆机",      -- 机械·近战·绿
    "侦察机",      -- 机械·远程·绿
    "蒸汽战犬",    -- 机械·近战·蓝
    "熔核巨兵",    -- 机械·近战·紫
    "机械总帅",    -- 机械·远程·金
    "光元素",      -- 元素·远程·绿
    "雷元素",      -- 元素·远程·蓝
}

-- ============================================================================
-- 核心 API
-- ============================================================================

--- 验证卡组合法性
---@param deck string[] 卡牌名数组
---@return boolean isValid
---@return string|nil errorMessage
function DeckManager.ValidateDeck(deck)
    if #deck < 8 then
        return false, "卡组需要正好8张卡"
    end
    if #deck > 8 then
        return false, "卡组不能超过8张卡"
    end

    local hasMine = false
    local hasGreen = false
    local hasBlue = false
    local hasPurple = false
    local hasGold = false
    local towerCount = 0

    for _, cardName in ipairs(deck) do
        local card = UnitConfig.CARDS[cardName]
        if not card then
            return false, "无效卡牌: " .. tostring(cardName)
        end

        local slotType = card.slotType or "unit"
        
        if slotType == "mine" then
            hasMine = true
        elseif slotType == "tower" then
            towerCount = towerCount + 1
        else -- unit
            if card.quality == "green" then hasGreen = true end
            if card.quality == "blue" then hasBlue = true end
            if card.quality == "purple" then hasPurple = true end
            if card.quality == "gold" then hasGold = true end
        end
    end

    if not hasMine then
        return false, "卡组需要至少1张矿脉卡"
    end
    if not hasGreen then
        return false, "卡组需要至少1张绿色品质单位卡"
    end
    if not hasBlue then
        return false, "卡组需要至少1张蓝色品质单位卡"
    end
    if not hasPurple then
        return false, "卡组需要至少1张紫色品质单位卡"
    end
    if not hasGold then
        return false, "卡组需要至少1张金色品质单位卡"
    end
    if towerCount > 2 then
        return false, "卡组中炮台卡不能超过2张"
    end

    return true, nil
end

--- 初始化/设置某玩家的卡组
---@param owner integer 1=玩家, 2=对手/AI
---@param deck string[] 卡牌名数组（最多8张）
function DeckManager.SetDeck(owner, deck)
    -- 校验卡组合法性
    local isValid, err = DeckManager.ValidateDeck(deck)
    if not isValid then
        print("[DeckManager] WARNING: " .. tostring(err) .. ", using default deck")
        deck = (owner == 1) and DeckManager.DEFAULT_PLAYER_DECK or DeckManager.DEFAULT_AI_DECK
    end

    local validDeck = {}
    for i = 1, math.min(#deck, DeckManager.DECK_SIZE) do
        local cardName = deck[i]
        if UnitConfig.CARDS[cardName] then
            validDeck[#validDeck + 1] = cardName
        else
            print("[DeckManager] WARNING: invalid card '" .. tostring(cardName) .. "' ignored")
        end
    end

    if #validDeck == 0 then
        print("[DeckManager] ERROR: empty deck for owner " .. owner .. ", using default")
        validDeck = (owner == 1) and DeckManager.DEFAULT_PLAYER_DECK or DeckManager.DEFAULT_AI_DECK
    end

    decks_[owner] = validDeck

    -- 重新计算羁绊
    SynergyManager.Calculate(owner, validDeck)
    synergies_[owner] = SynergyManager.GetActiveEffects(owner)
end

--- 从卡组中筛选指定类型和品质的卡牌
---@param owner integer
---@param slotType string "mine"|"unit"|"tower"
---@param quality string|nil "green"|"blue"|"purple"|"gold"，nil表示不限
---@return string[] 符合条件的卡牌名数组
function DeckManager.GetCardsBySlotAndQuality(owner, slotType, quality)
    local deck = decks_[owner]
    if not deck or #deck == 0 then return {} end

    local result = {}
    for _, cardName in ipairs(deck) do
        local card = UnitConfig.CARDS[cardName]
        if card then
            local cardSlotType = card.slotType or "unit"
            if cardSlotType == slotType then
                if quality == nil or card.quality == quality then
                    result[#result + 1] = cardName
                end
            end
        end
    end
    return result
end

--- 从卡组中随机选择一张符合条件的卡牌
---@param owner integer
---@param slotType string "mine"|"unit"|"tower"
---@param quality string|nil "green"|"blue"|"purple"|"gold"，nil表示不限
---@return string|nil cardName
---@return number cardLevel
function DeckManager.SelectRandomCard(owner, slotType, quality)
    local candidates = DeckManager.GetCardsBySlotAndQuality(owner, slotType, quality)
    if #candidates == 0 then return nil, 0 end

    local chosen = candidates[math.random(1, #candidates)]
    -- 从 PlayerDataManager 获取卡牌等级（仅 owner 1 本地玩家有数据）
    local cardLevel = 0
    if owner == 1 then
        local cardData = PlayerDataManager.GetCard(chosen)
        if cardData then
            cardLevel = (cardData.level or 1) - 1  -- level 1 对应 +0 倍成长
        end
    end
    return chosen, cardLevel
end

--- 从卡组中随机选择一张符合条件的卡牌，品质无匹配时自动降级
--- 用于翻格绑卡：先按 roll 出的品质选，卡组没该品质则降级查找
---@param owner integer
---@param slotType string "mine"|"unit"|"tower"
---@param quality string "green"|"blue"|"purple"|"gold"
---@return string|nil cardName
---@return number cardLevel
function DeckManager.SelectRandomCardWithFallback(owner, slotType, quality)
    local cardName, cardLevel = DeckManager.SelectRandomCard(owner, slotType, quality)
    if cardName then return cardName, cardLevel end

    -- 降级查找：按绿→蓝→紫→金顺序尝试
    local fallbackOrder = { "green", "blue", "purple", "gold" }
    for _, fq in ipairs(fallbackOrder) do
        if fq ~= quality then
            cardName, cardLevel = DeckManager.SelectRandomCard(owner, slotType, fq)
            if cardName then return cardName, cardLevel end
        end
    end
    return nil, 0
end

--- 根据建筑价格 roll 品质（所有建筑通用：兵营/矿脉/炮台）
---@param price integer 建筑价格（50/100/250）
---@return string quality "green"|"blue"|"purple"|"gold"
function DeckManager.RollQuality(price)
    local probTable = UnitConfig.QUALITY_PRODUCE[price]
    if not probTable then
        probTable = UnitConfig.QUALITY_PRODUCE[50]
    end

    local roll = math.random()
    local cumulative = 0
    -- 确保遍历顺序一致（从稀有到普通）
    local qualityOrder = { "gold", "purple", "blue", "green" }
    for _, quality in ipairs(qualityOrder) do
        local prob = probTable[quality] or 0
        cumulative = cumulative + prob
        if roll <= cumulative then
            return quality
        end
    end
    return "green"
end

--- 获取某玩家的卡组
---@param owner integer
---@return string[] deck
function DeckManager.GetDeck(owner)
    return decks_[owner] or {}
end

--- 获取某玩家的羁绊效果（缓存）
---@param owner integer
---@return table effects
function DeckManager.GetSynergies(owner)
    return synergies_[owner] or {}
end

--- 根据建筑价格从玩家卡组中随机抽取一张卡牌
--- 按照 UnitConfig.QUALITY_PRODUCE 的品质概率，从卡组中该品质的卡里随机选
--- 若指定 fixedQuality 则跳过概率roll，直接使用该品质
---@param owner integer
---@param barracksPrice integer 兵营价格（50/100/250）
---@param fixedQuality string|nil 固定品质（问号兵营专用）
---@return string|nil cardName
---@return number cardLevel
function DeckManager.RollCard(owner, barracksPrice, fixedQuality)
    local deck = decks_[owner]
    if not deck or #deck == 0 then return nil, 0 end

    local chosenQuality = "green"

    if fixedQuality then
        -- 问号兵营：直接使用固定品质
        chosenQuality = fixedQuality
    else
        -- 普通兵营：按概率表选品质
        local probTable = UnitConfig.QUALITY_PRODUCE[barracksPrice]
        if not probTable then
            probTable = UnitConfig.QUALITY_PRODUCE[50]
        end

        local roll = math.random()
        local cumulative = 0
        -- 确保遍历顺序一致（从稀有到普通）
        local qualityOrder = { "gold", "purple", "blue", "green" }
        for _, quality in ipairs(qualityOrder) do
            local prob = probTable[quality] or 0
            cumulative = cumulative + prob
            if roll <= cumulative then
                chosenQuality = quality
                break
            end
        end
    end

    -- 从卡组中筛选该品质的卡牌（只出单位卡，排除建筑卡）
    local candidates = {}
    for _, cardName in ipairs(deck) do
        local card = UnitConfig.CARDS[cardName]
        if card and card.quality == chosenQuality and (card.slotType or "unit") == "unit" then
            candidates[#candidates + 1] = cardName
        end
    end

    -- 如果卡组中没有该品质卡，逐级降级（同样只出单位卡）
    if #candidates == 0 then
        local fallbackOrder = { "green", "blue", "purple", "gold" }
        for _, fallbackQ in ipairs(fallbackOrder) do
            for _, cardName in ipairs(deck) do
                local card = UnitConfig.CARDS[cardName]
                if card and card.quality == fallbackQ and (card.slotType or "unit") == "unit" then
                    candidates[#candidates + 1] = cardName
                end
            end
            if #candidates > 0 then break end
        end
    end

    if #candidates == 0 then return nil, 0 end

    local chosen = candidates[math.random(1, #candidates)]
    -- 从 PlayerDataManager 获取卡牌等级（仅 owner 1 本地玩家有数据）
    local cardLevel = 0
    if owner == 1 then
        local cardData = PlayerDataManager.GetCard(chosen)
        if cardData then
            cardLevel = (cardData.level or 1) - 1  -- level 1 对应 +0 倍成长
        end
    end
    return chosen, cardLevel
end

--- 使用默认卡组初始化双方（无配置时的 fallback）
function DeckManager.InitDefaults()
    DeckManager.SetDeck(1, DeckManager.DEFAULT_PLAYER_DECK)
    DeckManager.SetDeck(2, DeckManager.DEFAULT_AI_DECK)
end

--- 重置
function DeckManager.Reset()
    decks_ = {}
    synergies_ = {}
end

-- ============================================================================
-- 本地存档（自动保存/加载玩家卡组）
-- ============================================================================

local SAVE_KEY = "player_decks"

--- 多卡组存档结构: { activeSlot = 1, decks = { [1]=deck, [2]=deck, ... } }
DeckManager.MAX_SLOTS = 5

--- 保存玩家卡组到本地存档（指定槽位）
---@param deck string[] 卡牌名数组
---@param slot integer|nil 槽位编号 1-5（默认当前活跃槽位）
function DeckManager.SavePlayerDeck(deck, slot)
    local allData = DeckManager.LoadAllDecks_()
    slot = slot or allData.activeSlot or 1
    allData.decks[slot] = deck
    allData.activeSlot = slot
    DeckManager.WriteDecksFile_(allData)
end

--- 从本地存档加载玩家当前活跃卡组
---@return string[]|nil deck 成功返回卡组数组，无存档返回nil
function DeckManager.LoadSavedDeck()
    local allData = DeckManager.LoadAllDecks_()
    local slot = allData.activeSlot or 1
    ---@type string[]|nil
    local deck = allData.decks[slot]
    if deck and #deck > 0 then
        return deck
    end
    return nil
end

--- 加载指定槽位卡组
---@param slot integer
---@return string[]|nil
function DeckManager.LoadDeckSlot(slot)
    local allData = DeckManager.LoadAllDecks_()
    local deck = allData.decks[slot]
    if deck and #deck > 0 then
        -- 校验
        local valid = {}
        for _, cardName in ipairs(deck) do
            if UnitConfig.CARDS[cardName] then
                valid[#valid + 1] = cardName
            end
        end
        if #valid > 0 then return valid end
    end
    return nil
end

--- 获取当前活跃槽位
---@return integer
function DeckManager.GetActiveSlot()
    local allData = DeckManager.LoadAllDecks_()
    return allData.activeSlot or 1
end

--- 设置活跃槽位
---@param slot integer
function DeckManager.SetActiveSlot(slot)
    local allData = DeckManager.LoadAllDecks_()
    allData.activeSlot = slot
    DeckManager.WriteDecksFile_(allData)
end

--- 获取玩家可用卡组（优先本地存档，fallback 默认卡组）
---@return string[] deck
function DeckManager.GetPlayerDeckOrDefault()
    local saved = DeckManager.LoadSavedDeck()
    if saved and #saved >= DeckManager.DECK_SIZE then
        return saved
    end
    return DeckManager.DEFAULT_PLAYER_DECK
end

--- 获取玩家已保存的卡组（不做默认回退，用于开战校验）
---@return string[]|nil deck 玩家真实保存的卡组，没保存则返回 nil
function DeckManager.GetSavedDeck()
    local saved = DeckManager.LoadSavedDeck()
    if saved and #saved >= DeckManager.DECK_SIZE then
        return saved
    end
    return nil
end

-- ========== 内部工具 ==========

--- 读取全部卡组存档（优先内存缓存 → clientCloud）
---@return table { activeSlot, decks }
function DeckManager.LoadAllDecks_()
    -- 1) 优先内存缓存（本次会话内保存过就一定有值）
    if memoryCache_ then
        return memoryCache_
    end
    -- 2) 尝试 clientCloud
    if not clientCloud then
        return { activeSlot = 1, decks = {} }
    end
    local raw = clientCloud:Get(SAVE_KEY)
    if not raw or raw == "" then
        return { activeSlot = 1, decks = {} }
    end
    local ok, data = pcall(cjson.decode, raw)
    if ok and data then
        local result
        -- 兼容旧格式（单卡组 { deck = {...} }）
        if data.deck and not data.decks then
            result = { activeSlot = 1, decks = { data.deck } }
        elseif data.decks then
            -- cjson 解码后 decks 可能是数组，需要转换 key 为 integer
            local fixedDecks = {}
            for k, v in pairs(data.decks) do
                fixedDecks[tonumber(k) or k] = v
            end
            result = { activeSlot = data.activeSlot or 1, decks = fixedDecks }
        end
        if result then
            memoryCache_ = result  -- 回填缓存
            return result
        end
    end
    return { activeSlot = 1, decks = {} }
end

--- 写入全部卡组存档（同步写内存 + 异步写云端）
---@param allData table
function DeckManager.WriteDecksFile_(allData)
    -- 立即写入内存缓存（保证同会话内读取一定成功）
    memoryCache_ = allData
    -- 异步写入云端持久化
    if not clientCloud then return end
    clientCloud:Set(SAVE_KEY, cjson.encode(allData), {
        ok = function() print("[DeckManager] Cloud save OK") end,
        error = function(err) print("[DeckManager] Cloud save error: " .. tostring(err)) end
    })
end

return DeckManager


-- ══════════════════════════════════════════════
