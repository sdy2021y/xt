-- ══════════════════════════════════════════════
-- ============================================================================
-- ChestManager.lua - 段位宝箱系统
-- 6个宝箱槽位，胜利掉落对应段位宝箱，解锁倒计时，星钻秒开
-- ============================================================================
---@diagnostic disable: missing-parameter

local cjson = require("cjson")
local UnitConfig = require("Config.UnitConfig")
local AdManager = require("Systems.AdManager")
local PlayerDataManager = require("Data.PlayerDataManager")

local ChestManager = {}

-- ========== 常量配置 ==========
ChestManager.MAX_SLOTS = 6

-- 段位宝箱定义（7种，对应青铜~王者）
-- cardDrops: { quality, count, guaranteed } — guaranteed=true为保底，false为概率触发
-- cardPreview: UI展示用，只显示可能获得的卡牌品质和数量，不显示概率
ChestManager.TYPES = {
    bronze = {
        name = "青铜宝箱",
        icon = "🟫",
        unlockSeconds = 20 * 60,          -- 20分钟
        color = "#CD7F32",
        gold = 25,                         -- 固定金币
        materials = 8,                     -- 固定铸材
        xianyu = 0,                        -- 星钻
        instantCost = 40,                  -- 星钻秒开
        cardPreview = { "精良×2", "稀有" },
        cardDrops = {
            { quality = "green",  count = 2, guaranteed = true },
            { quality = "blue",   count = 1, guaranteed = false, chance = 0.20 },
        },
    },
    silver = {
        name = "白银宝箱",
        icon = "⬜",
        unlockSeconds = 20 * 60,          -- 20分钟
        color = "#C0C0C0",
        gold = 50,
        materials = 15,
        xianyu = 0,
        instantCost = 40,
        cardPreview = { "精良×2", "稀有" },
        cardDrops = {
            { quality = "green",  count = 2, guaranteed = true },
            { quality = "blue",   count = 1, guaranteed = false, chance = 0.20 },
        },
    },
    gold = {
        name = "黄金宝箱",
        icon = "🟨",
        unlockSeconds = 40 * 60,          -- 40分钟
        color = "#FFD700",
        gold = 100,
        materials = 30,
        xianyu = 0,
        instantCost = 80,
        cardPreview = { "稀有×1", "精良×2", "史诗" },
        cardDrops = {
            { quality = "blue",   count = 1, guaranteed = true },
            { quality = "green",  count = 2, guaranteed = false, chance = 0.50 },
            { quality = "purple", count = 1, guaranteed = false, chance = 0.10 },
        },
    },
    platinum = {
        name = "铂金宝箱",
        icon = "🔷",
        unlockSeconds = 90 * 60,          -- 1小时30分钟
        color = "#E5E4E2",
        gold = 180,
        materials = 50,
        xianyu = 0,
        instantCost = 200,
        cardPreview = { "稀有×3", "精良×5", "史诗" },
        cardDrops = {
            { quality = "blue",   count = 3, guaranteed = true },
            { quality = "green",  count = 5, guaranteed = false, chance = 0.30 },
            { quality = "blue",   count = 3, guaranteed = false, chance = 0.30 },
            { quality = "purple", count = 1, guaranteed = false, chance = 0.20 },
        },
    },
    diamond = {
        name = "钻石宝箱",
        icon = "💎",
        unlockSeconds = 2 * 3600,           -- 2小时
        color = "#B9F2FF",
        gold = 260,
        materials = 70,
        xianyu = 3,                        -- 少量星钻
        instantCost = 200,
        cardPreview = { "稀有×3", "精良×5", "史诗" },
        cardDrops = {
            { quality = "blue",   count = 3, guaranteed = true },
            { quality = "green",  count = 5, guaranteed = false, chance = 0.30 },
            { quality = "blue",   count = 3, guaranteed = false, chance = 0.30 },
            { quality = "purple", count = 1, guaranteed = false, chance = 0.20 },
        },
    },
    starlight = {
        name = "星耀宝箱",
        icon = "🌟",
        unlockSeconds = 3 * 3600,         -- 3小时
        color = "#FFB6C1",
        gold = 400,
        materials = 100,
        xianyu = 8,                        -- 少量星钻
        instantCost = 300,
        cardPreview = { "史诗×1", "稀有×2", "精良×10", "传奇" },
        cardDrops = {
            { quality = "purple", count = 1, guaranteed = true },
            { quality = "blue",   count = 2, guaranteed = true },
            { quality = "green",  count = 10, guaranteed = false, chance = 0.20 },
            { quality = "blue",   count = 5, guaranteed = false, chance = 0.40 },
            { quality = "purple", count = 1, guaranteed = false, chance = 0.20 },
            { quality = "gold",   count = 1, guaranteed = false, chance = 0.05 },
        },
    },
    king = {
        name = "王者宝箱",
        icon = "👑",
        unlockSeconds = 8 * 3600,         -- 8小时
        color = "#FF6347",
        gold = 600,
        materials = 150,
        xianyu = 12,                       -- 少量星钻
        instantCost = 400,
        cardPreview = { "史诗×3", "精良", "稀有", "传奇" },
        cardDrops = {
            { quality = "purple", count = 3, guaranteed = true },
            { quality = "green",  count = 3, guaranteed = false, chance = 0.20 },
            { quality = "blue",   count = 3, guaranteed = false, chance = 0.20 },
            { quality = "purple", count = 2, guaranteed = false, chance = 0.20 },
            { quality = "gold",   count = 1, guaranteed = false, chance = 0.10 },
        },
    },
}

-- 段位索引 → 可掉落宝箱类型（胜利时：当前段位 或 低一段）
-- tierIndex: 0=青铜, 1=白银, 2=黄金, 3=铂金, 4=钻石, 5=星耀, 6=王者, 7=荣耀王者
local TIER_CHEST_MAP = {
    [0] = { "bronze" },                                    -- 青铜：只能青铜
    [1] = { "bronze", "silver" },                          -- 白银：青铜/白银
    [2] = { "silver", "gold" },                            -- 黄金：白银/黄金
    [3] = { "gold", "platinum" },                          -- 铂金：黄金/铂金
    [4] = { "platinum", "diamond" },                       -- 钻石：铂金/钻石
    [5] = { "diamond", "starlight" },                      -- 星耀：钻石/星耀
    [6] = { "starlight", "king" },                         -- 王者：星耀/王者
    [7] = { "starlight", "king" },                         -- 荣耀王者：星耀/王者
}

-- ========== 状态 ==========
-- 每个槽位: { state = "empty"|"locked"|"unlocking"|"ready", chestType = string, startTime = number }
---@type table[]
local slots_ = {}
local SAVE_KEY = "chest_data"
local lastUpdateTime_ = 0

-- ========== 云端存储（clientCloud） ==========

local function saveData()
    if not clientCloud then return end
    local data = {
        slots = slots_,
        savedAt = os.time(),
    }
    clientCloud:Set(SAVE_KEY, cjson.encode(data), {
        ok = function() end,
        error = function(err) print("[ChestData] Save error: " .. tostring(err)) end
    })
end

local function loadData()
    if not clientCloud then
        slots_ = {}
        for i = 1, ChestManager.MAX_SLOTS do
            slots_[i] = { state = "empty" }
        end
        return
    end
    local raw = clientCloud:Get(SAVE_KEY)
    if not raw or raw == "" then
        slots_ = {}
        for i = 1, ChestManager.MAX_SLOTS do
            slots_[i] = { state = "empty" }
        end
        return
    end

    local ok, data = pcall(cjson.decode, raw)
    if not ok or not data or not data.slots then
        slots_ = {}
        for i = 1, ChestManager.MAX_SLOTS do
            slots_[i] = { state = "empty" }
        end
        return
    end

    slots_ = data.slots
    for i = 1, ChestManager.MAX_SLOTS do
        if not slots_[i] then
            slots_[i] = { state = "empty" }
        end
    end

    -- 恢复后检查是否有解锁完成的宝箱
    local now = os.time()
    for i = 1, ChestManager.MAX_SLOTS do
        local slot = slots_[i]
        if slot.state == "unlocking" and slot.startTime then
            local chestDef = ChestManager.TYPES[slot.chestType]
            if chestDef then
                local elapsed = now - slot.startTime
                if elapsed >= chestDef.unlockSeconds then
                    slot.state = "ready"
                end
            end
        end
    end
end

-- ========== 内部工具 ==========

--- 从指定品质的卡牌中随机选一张
---@param quality string
---@return string|nil cardName
local function randomCardOfQuality(quality)
    local candidates = {}
    for cardName, cardDef in pairs(UnitConfig.CARDS) do
        if cardDef.quality == quality then
            candidates[#candidates + 1] = cardName
        end
    end
    if #candidates == 0 then return nil end
    return candidates[math.random(1, #candidates)]
end

--- 根据卡牌掉落配置生成卡牌奖励列表
---@param cardDrops table[]
---@return table[] cards {{ name, quality, race, icon }}
local function generateCardRewards(cardDrops)
    local cards = {}
    for _, drop in ipairs(cardDrops) do
        local shouldDrop = drop.guaranteed
        if not shouldDrop and drop.chance then
            shouldDrop = (math.random() < drop.chance)
        end
        if shouldDrop then
            for _ = 1, (drop.count or 1) do
                local cardName = randomCardOfQuality(drop.quality)
                if cardName then
                    local cardDef = UnitConfig.CARDS[cardName]
                    cards[#cards + 1] = {
                        name = cardName,
                        quality = drop.quality,
                        race = cardDef.race,
                        icon = cardDef.icon,
                    }
                end
            end
        end
    end
    return cards
end

-- ========== 公共 API ==========

--- 初始化宝箱系统
function ChestManager.Init()
    loadData()
    lastUpdateTime_ = os.time()
end

--- 每帧/每秒更新（检查解锁状态）
---@param dt number
function ChestManager.Update(dt)
    local now = os.time()
    if now == lastUpdateTime_ then return end
    lastUpdateTime_ = now

    local changed = false
    for i = 1, ChestManager.MAX_SLOTS do
        local slot = slots_[i]
        if slot.state == "unlocking" and slot.startTime then
            local chestDef = ChestManager.TYPES[slot.chestType]
            if chestDef then
                local elapsed = now - slot.startTime
                local totalTime = chestDef.unlockSeconds

                -- 检查是否有加速效果
                if AdManager and AdManager.IsEffectActive and AdManager.IsEffectActive("doubleSpeed") then
                    local speedMultiplier = AdManager.GetEffectValue("doubleSpeed") or 0.5
                    totalTime = math.floor(totalTime * (1 - speedMultiplier))
                end

                if elapsed >= totalTime then
                    slot.state = "ready"
                    changed = true
                end
            end
        end
    end

    if changed then
        saveData()
    end
end

--- 获取所有槽位状态
---@return table[] slots
function ChestManager.GetSlots()
    return slots_
end

--- 获取指定槽位
---@param index integer 1-6
---@return table|nil slot
function ChestManager.GetSlot(index)
    return slots_[index]
end

--- 战斗胜利后根据段位获得宝箱
--- 掉落当前段位 ±1 的宝箱，槽满则丢失
---@param tierIndex integer 段位索引 (0=青铜 ... 7=荣耀王者)
---@return string|nil chestType 获得的宝箱类型，nil表示没有空位
function ChestManager.AwardChestByTier(tierIndex)
    -- 找空槽位
    local emptySlot = nil
    for i = 1, ChestManager.MAX_SLOTS do
        if slots_[i].state == "empty" then
            emptySlot = i
            break
        end
    end

    if not emptySlot then
        return nil  -- 没有空槽位，宝箱丢失
    end

    -- 根据段位确定可掉落的宝箱类型（±1段位）
    local available = TIER_CHEST_MAP[tierIndex] or TIER_CHEST_MAP[0]
    local chosenType = available[math.random(1, #available)]

    slots_[emptySlot] = {
        state = "locked",
        chestType = chosenType,
    }
    saveData()

    return chosenType
end

--- 旧接口兼容（随机掉落，不再推荐使用）
---@return string|nil chestType
function ChestManager.AwardChest()
    -- 默认按青铜段位掉落
    return ChestManager.AwardChestByTier(0)
end

--- 手动放入宝箱到空槽位（指定类型）
---@param chestType string
---@return boolean success
function ChestManager.AddChest(chestType)
    for i = 1, ChestManager.MAX_SLOTS do
        if slots_[i].state == "empty" then
            slots_[i] = {
                state = "locked",
                chestType = chestType,
            }
            saveData()
            return true
        end
    end
    return false
end

--- 开始解锁宝箱（倒计时）
---@param slotIndex integer
---@return boolean success
function ChestManager.StartUnlock(slotIndex)
    local slot = slots_[slotIndex]
    if not slot or slot.state ~= "locked" then
        return false
    end

    slot.state = "unlocking"
    slot.startTime = os.time()
    saveData()
    return true
end

--- 星钻秒开宝箱（跳过倒计时直接开启）
---@param slotIndex integer
---@return table|nil rewards
---@return string|nil errorMessage
function ChestManager.InstantOpen(slotIndex)
    local slot = slots_[slotIndex]
    if not slot then
        return nil, "无效槽位"
    end
    if slot.state == "empty" then
        return nil, "槽位为空"
    end

    local chestDef = ChestManager.TYPES[slot.chestType]
    if not chestDef then return nil, "未知宝箱类型" end

    -- 扣除星钻
    local cost = chestDef.instantCost or 0
    if cost > 0 then
        if not PlayerDataManager.SpendXianyu(cost) then
            return nil, "星钻不足，需要 " .. cost .. " 星钻"
        end
    end

    -- 生成奖励
    local rewards = {
        chestType = slot.chestType,
        gold = chestDef.gold or 0,
        materials = chestDef.materials or 0,
        xianyu = chestDef.xianyu or 0,
        cards = generateCardRewards(chestDef.cardDrops or {}),
    }

    -- 发放奖励
    if rewards.gold > 0 then PlayerDataManager.AddGold(rewards.gold) end
    if rewards.materials > 0 then PlayerDataManager.AddMaterials(rewards.materials) end
    if rewards.xianyu > 0 then PlayerDataManager.AddXianyu(rewards.xianyu) end
    for _, card in ipairs(rewards.cards) do
        PlayerDataManager.AddCard(card.name, 1)
    end
    PlayerDataManager.Save()

    -- 清空槽位
    slots_[slotIndex] = { state = "empty" }
    saveData()

    return rewards, nil
end

--- 获取解锁剩余时间（秒）
---@param slotIndex integer
---@return number remainSeconds 剩余秒数，0表示已就绪
function ChestManager.GetRemainingTime(slotIndex)
    local slot = slots_[slotIndex]
    if not slot then return 0 end
    if slot.state == "ready" then return 0 end
    if slot.state == "locked" then
        local chestDef = ChestManager.TYPES[slot.chestType]
        return chestDef and chestDef.unlockSeconds or 0
    end
    if slot.state ~= "unlocking" or not slot.startTime then return -1 end

    local chestDef = ChestManager.TYPES[slot.chestType]
    if not chestDef then return 0 end

    local elapsed = os.time() - slot.startTime
    local totalTime = chestDef.unlockSeconds

    -- 检查是否有加速效果
    if AdManager and AdManager.IsEffectActive and AdManager.IsEffectActive("doubleSpeed") then
        local speedMultiplier = AdManager.GetEffectValue("doubleSpeed") or 0.5
        totalTime = math.floor(totalTime * (1 - speedMultiplier))
    end

    local remain = totalTime - elapsed
    return math.max(0, remain)
end

--- 格式化剩余时间
---@param seconds integer
---@return string
function ChestManager.FormatTime(seconds)
    if seconds <= 0 then return "就绪" end
    if seconds < 60 then return seconds .. "秒" end
    if seconds < 3600 then return math.ceil(seconds / 60) .. "分钟" end
    local hours = math.floor(seconds / 3600)
    local mins = math.ceil((seconds % 3600) / 60)
    if mins > 0 then
        return hours .. "时" .. mins .. "分"
    end
    return hours .. "小时"
end

--- 开启已就绪的宝箱，返回奖励（免费，倒计时结束后开启）
---@param slotIndex integer
---@return table|nil rewards { gold, materials, xianyu, cards = { { name, quality, race, icon } } }
---@return string|nil errorMessage 如果开启失败则返回错误信息
function ChestManager.OpenChest(slotIndex)
    local slot = slots_[slotIndex]
    if not slot or slot.state ~= "ready" then
        return nil, "宝箱未就绪"
    end

    local chestDef = ChestManager.TYPES[slot.chestType]
    if not chestDef then return nil, "未知宝箱类型" end

    -- 生成奖励
    local rewards = {
        chestType = slot.chestType,
        gold = chestDef.gold or 0,
        materials = chestDef.materials or 0,
        xianyu = chestDef.xianyu or 0,
        cards = generateCardRewards(chestDef.cardDrops or {}),
    }

    -- 发放奖励
    if rewards.gold > 0 then PlayerDataManager.AddGold(rewards.gold) end
    if rewards.materials > 0 then PlayerDataManager.AddMaterials(rewards.materials) end
    if rewards.xianyu > 0 then PlayerDataManager.AddXianyu(rewards.xianyu) end
    for _, card in ipairs(rewards.cards) do
        PlayerDataManager.AddCard(card.name, 1)
    end
    PlayerDataManager.Save()

    -- 清空槽位
    slots_[slotIndex] = { state = "empty" }
    saveData()

    return rewards, nil
end

--- 是否有正在解锁的宝箱
---@return boolean
function ChestManager.HasUnlocking()
    for i = 1, ChestManager.MAX_SLOTS do
        if slots_[i].state == "unlocking" then
            return true
        end
    end
    return false
end

--- 是否有空槽位
---@return boolean
function ChestManager.HasEmptySlot()
    for i = 1, ChestManager.MAX_SLOTS do
        if slots_[i].state == "empty" then
            return true
        end
    end
    return false
end

--- 获取各状态数量
---@return table { empty, locked, unlocking, ready }
function ChestManager.GetCounts()
    local counts = { empty = 0, locked = 0, unlocking = 0, ready = 0 }
    for i = 1, ChestManager.MAX_SLOTS do
        local state = slots_[i].state
        counts[state] = (counts[state] or 0) + 1
    end
    return counts
end

--- 获取宝箱的星钻秒开费用
---@param chestType string
---@return integer
function ChestManager.GetInstantCost(chestType)
    local def = ChestManager.TYPES[chestType]
    return def and (def.instantCost or 0) or 0
end

return ChestManager
