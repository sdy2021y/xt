-- ============================================================================
-- ArtifactManager.lua - 神器战斗管理器
-- 充能机制：翻格子第5/15/30次充能
-- 释放机制：主动释放神器技能
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local EventBus = require("Infrastructure.EventBus")
local ArtifactConfig = require("Config.ArtifactConfig")
local PlayerDataManager = require("Data.PlayerDataManager")

local ArtifactManager = {}

-- ========== 内部状态 ==========

-- 玩家装备的神器 { name, level, star, fragmentCount }
local equippedArtifact_ = nil

-- 战斗充能状态
local chargeProgress_ = 0      -- 当前充能次数
local chargeStages_ = {}        -- 充能阶段达标标记 { [5]=true, [15]=true, [30]=true }
local maxChargeStage_ = 0       -- 当前达到的最高充能阶段
local tilesFlipped_ = 0         -- 本局翻格子次数
local isReady_ = false          -- 是否可释放
local releaseCount_ = 0         -- 本局释放次数

-- 被动技能效果追踪
local passiveEffects_ = {}

-- 自动释放计时器
local autoReleaseTimer_ = 0

-- ========== 初始化 ==========

--- 初始化神器管理器（战斗开始时调用）
---@param playerArtifact table|nil 玩家装备的神器数据
function ArtifactManager.Init(playerArtifact)
    equippedArtifact_ = playerArtifact
    chargeProgress_ = 0
    chargeStages_ = {}
    maxChargeStage_ = 0
    tilesFlipped_ = 0
    isReady_ = false
    releaseCount_ = 0
    passiveEffects_ = {}
    autoReleaseTimer_ = 0

    if equippedArtifact_ then
        -- 读入充能阶段配置
        local artifactDef = ArtifactConfig.ARTIFACTS[equippedArtifact_.name]
        if artifactDef then
            for _, stage in ipairs(artifactDef.chargeStages) do
                chargeStages_[stage] = false
            end
        end
        EventBus.Emit("ArtifactCharged", 0, 0)
    end
end

--- 是否已装备神器
---@return boolean
function ArtifactManager.HasArtifact()
    return equippedArtifact_ ~= nil
end

--- 获取当前装备的神器数据
---@return table|nil
function ArtifactManager.GetEquipped()
    return equippedArtifact_
end

--- 获取神器定义数据
---@return table|nil
function ArtifactManager.GetArtifactDef()
    if not equippedArtifact_ then return nil end
    return ArtifactConfig.ARTIFACTS[equippedArtifact_.name]
end

-- ========== 充能机制 ==========

--- 翻格子事件处理（由Client.lua在翻格子时调用）
---@param tileIndex string|integer 翻开的格子Key或索引
function ArtifactManager.OnTileRevealed(tileIndex)
    if not equippedArtifact_ then return end

    tilesFlipped_ = tilesFlipped_ + 1
    local artifactDef = ArtifactConfig.ARTIFACTS[equippedArtifact_.name]
    if not artifactDef then return end

    -- 检查是否达到充能阶段
    for _, stage in ipairs(artifactDef.chargeStages) do
        if tilesFlipped_ >= stage and not chargeStages_[stage] then
            chargeStages_[stage] = true
            maxChargeStage_ = math.max(maxChargeStage_, stage)
            isReady_ = true
            EventBus.Emit("ArtifactCharged", stage, maxChargeStage_)
        end
    end

    -- 更新充能进度（用于UI进度条）
    local maxStage = artifactDef.chargeStages[#artifactDef.chargeStages]
    chargeProgress_ = math.min(tilesFlipped_ / maxStage, 1.0)
    EventBus.Emit("ArtifactChargeProgress", chargeProgress_, tilesFlipped_)
end

--- 获取充能进度 0~1
---@return number
function ArtifactManager.GetChargeProgress()
    return chargeProgress_
end

--- 获取已翻格子数
---@return integer
function ArtifactManager.GetTilesFlipped()
    return tilesFlipped_
end

--- 是否可释放
---@return boolean
function ArtifactManager.IsReady()
    return isReady_
end

--- 获取当前充能阶段（0/1/2/3）
---@return integer
function ArtifactManager.GetChargeStage()
    if maxChargeStage_ >= 30 then return 3
    elseif maxChargeStage_ >= 15 then return 2
    elseif maxChargeStage_ >= 5 then return 1
    end
    return 0
end

-- ========== 释放系统 ==========

--- 释放神器技能
---@return boolean success 是否成功释放
function ArtifactManager.Release()
    if not isReady_ or not equippedArtifact_ then
        return false
    end

    local artifactDef = ArtifactConfig.ARTIFACTS[equippedArtifact_.name]
    if not artifactDef then return false
    end

    isReady_ = false
    releaseCount_ = releaseCount_ + 1

    -- 发送释放事件，由Client.lua处理具体效果
    EventBus.Emit("ArtifactReleased", {
        artifactName = equippedArtifact_.name,
        artifactDef = artifactDef,
        level = equippedArtifact_.level or 0,
        star = equippedArtifact_.star or 0,
        releaseCount = releaseCount_,
        chargeStage = maxChargeStage_,
    })

    -- 30级被动：自动释放
    if equippedArtifact_.level >= 30 then
        local passive = artifactDef.passives[30]
        if passive and passive.effect == "auto_release" then
            autoReleaseTimer_ = passive.interval or 15
        end
    end

    -- 清除当前充能阶段（可重新充能）
    for stage, _ in pairs(chargeStages_) do
        chargeStages_[stage] = false
    end
    maxChargeStage_ = 0

    return true
end

-- ========== 被动技能 ==========

--- 获取当前生效的被动技能列表
---@return table[]
function ArtifactManager.GetActivePassives()
    if not equippedArtifact_ then return {} end
    local artifactDef = ArtifactConfig.ARTIFACTS[equippedArtifact_.name]
    if not artifactDef then return {} end

    local level = equippedArtifact_.level or 0
    local passives = {}
    for reqLevel, passive in pairs(artifactDef.passives) do
        if level >= reqLevel then
            passives[#passives + 1] = {
                reqLevel = reqLevel,
                name = passive.name,
                desc = passive.desc,
                effect = passive.effect,
                value = passive.value,
            }
        end
    end
    return passives
end

--- 获取被动效果加成值
---@param effectType string 效果类型
---@return number|nil
function ArtifactManager.GetPassiveBonus(effectType)
    if not equippedArtifact_ then return nil end
    local artifactDef = ArtifactConfig.ARTIFACTS[equippedArtifact_.name]
    if not artifactDef then return nil end

    local level = equippedArtifact_.level or 0
    local bonus = 0
    for reqLevel, passive in pairs(artifactDef.passives) do
        if level >= reqLevel and passive.effect == effectType then
            bonus = bonus + (passive.value or 0)
        end
    end
    return bonus
end

-- ========== 更新 ==========

--- 每帧更新（用于自动释放计时器）
---@param dt number 帧间隔
function ArtifactManager.Update(dt)
    if autoReleaseTimer_ > 0 then
        autoReleaseTimer_ = autoReleaseTimer_ - dt
        if autoReleaseTimer_ <= 0 then
            autoReleaseTimer_ = 0
            -- 自动释放
            if isReady_ then
                ArtifactManager.Release()
            end
        end
    end
end

-- ========== 持久化 ==========

--- 获取玩家神器数据（从PlayerDataManager中读取）
---@return table|nil
function ArtifactManager.LoadPlayerArtifact()
    local data = PlayerDataManager.GetData()
    if data and data.equippedArtifact then
        return data.equippedArtifact
    end
    return nil
end

--- 装备神器
---@param artifactName string
---@param artifactData table { level, star, fragmentCount }
function ArtifactManager.EquipArtifact(artifactName, artifactData)
    equippedArtifact_ = {
        name = artifactName,
        level = artifactData.level or 0,
        star = artifactData.star or 0,
        fragmentCount = artifactData.fragmentCount or 0,
    }
    PlayerDataManager.Set("equippedArtifact", equippedArtifact_)
    PlayerDataManager.Save()
end

--- 升星神器（0→1→2→3→4→5）
---@param artifactName string
---@return boolean success
function ArtifactManager.StarUpArtifact(artifactName)
    local data = PlayerDataManager.GetData()
    if not data or not data.artifacts then return false end
    local artifact = data.artifacts[artifactName]
    if not artifact then return false end

    local currentStar = artifact.star or 0
    if currentStar >= 5 then return false end  -- 满星

    local fragmentsNeeded = ArtifactConfig.GetStarUpFragments(currentStar)
    if (artifact.fragmentCount or 0) < fragmentsNeeded then return false end

    artifact.fragmentCount = artifact.fragmentCount - fragmentsNeeded
    artifact.star = currentStar + 1
    PlayerDataManager.Save()

    -- 如果当前装备的是这个神器，更新内存状态
    if equippedArtifact_ and equippedArtifact_.name == artifactName then
        equippedArtifact_.star = artifact.star
    end

    EventBus.Emit("ArtifactStarUp", artifactName, artifact.star)
    return true
end

--- 升级神器
---@param artifactName string
---@return boolean success
function ArtifactManager.UpgradeArtifact(artifactName)
    local data = PlayerDataManager.GetData()
    if not data or not data.artifacts then return false end
    local artifact = data.artifacts[artifactName]
    if not artifact then return false end

    local currentLevel = artifact.level or 0
    if currentLevel >= 30 then return false end  -- 满级

    local fragmentsNeeded = ArtifactConfig.GetLevelUpFragments(currentLevel)
    if (artifact.fragmentCount or 0) < fragmentsNeeded then return false end

    artifact.fragmentCount = artifact.fragmentCount - fragmentsNeeded
    artifact.level = currentLevel + 1
    PlayerDataManager.Save()

    -- 如果当前装备的是这个神器，更新
    if equippedArtifact_ and equippedArtifact_.name == artifactName then
        equippedArtifact_.level = artifact.level
    end

    return true
end

return ArtifactManager