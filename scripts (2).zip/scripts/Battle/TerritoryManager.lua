-- ============================================================================
-- TerritoryManager.lua - 据点管理器
-- 4建筑升级/产出收集 + 灵田种植 + 小偷入侵 + 领主等级 + 好友互动
-- ============================================================================
---@diagnostic disable: return-type-mismatch

local EventBus = require("Infrastructure.EventBus")
local TerritoryConfig = require("Config.TerritoryConfig")
local PlayerDataManager = require("Data.PlayerDataManager")
local OfflineRewardManager = require("Systems.OfflineRewardManager")

local TerritoryManager = {}

-- 防重复初始化守卫
local initialized_ = false

-- 广告效果：加速播种
local cropSpeedUpActive_ = false

-- 订阅广告效果
EventBus.On("AdEffectActivated", function(effectType, effectData)
    if effectType == "doubleSpeed" then
        cropSpeedUpActive_ = effectData.active
    end
end)

-- ========== 内部状态 ==========

-- 建筑数据 { [buildingId] = { level, lastCollectTime } }
local buildings_ = {}

-- 灵田种植数据 { [slotIndex] = { cropId, plantTime, growTime, reward, isBoosted, helpCount } }
local crops_ = {}

-- 小偷入侵状态
local thiefState_ = {
    dailyCount = 0,           -- 今日已触发次数
    lastThiefTime = 0,        -- 上次小偷时间
    nextThiefTime = 0,        -- 下次小偷时间
    isThiefActive = false,    -- 是否有小偷
    dailyResetTime = 0,       -- 每日重置时间
}

-- 在线计时器
local onlineTimer_ = 0

-- ========== 初始化 ==========

--- 初始化据点系统（幂等，重复调用安全）
function TerritoryManager.Init()
    if initialized_ then return end
    initialized_ = true

    -- 加载建筑数据
    local data = PlayerDataManager.GetData()
    if data and data.territory then
        buildings_ = data.territory.buildings or TerritoryManager.CreateDefaultBuildings()
        crops_ = data.territory.crops or {}
        thiefState_ = data.territory.thiefState or TerritoryManager.CreateDefaultThiefState()
    else
        buildings_ = TerritoryManager.CreateDefaultBuildings()
        crops_ = {}
        thiefState_ = TerritoryManager.CreateDefaultThiefState()
        TerritoryManager.SaveData()
    end

    -- 检查每日重置
    TerritoryManager.CheckDailyReset()

    -- 计算离线收益
    OfflineRewardManager.Init()

    -- 更新种植状态
    TerritoryManager.UpdateCropStatus()

    -- 检查小偷触发
    TerritoryManager.CheckThiefTrigger()
end

--- 创建默认建筑数据
---@return table
function TerritoryManager.CreateDefaultBuildings()
    local buildings = {}
    for buildingId, _ in pairs(TerritoryConfig.BUILDINGS) do
        buildings[buildingId] = {
            level = 1,
            lastCollectTime = os.time(),
        }
    end
    return buildings
end

--- 创建默认小偷状态
---@return table
function TerritoryManager.CreateDefaultThiefState()
    return {
        dailyCount = 0,
        lastThiefTime = 0,
        nextThiefTime = 0,
        isThiefActive = false,
        dailyResetTime = os.time(),
    }
end

-- ========== 建筑操作 ==========

--- 获取建筑数据
---@param buildingId string
---@return table|nil
function TerritoryManager.GetBuilding(buildingId)
    return buildings_[buildingId]
end

--- 获取所有建筑数据
---@return table
function TerritoryManager.GetAllBuildings()
    return buildings_
end

--- 升级建筑
---@param buildingId string
---@return boolean success, string message
function TerritoryManager.UpgradeBuilding(buildingId)
    local building = buildings_[buildingId]
    if not building then
        return false, "建筑不存在"
    end

    local buildingDef = TerritoryConfig.BUILDINGS[buildingId]
    if not buildingDef then
        return false, "建筑配置不存在"
    end

    if building.level >= buildingDef.maxLevel then
        return false, "已满级"
    end

    local cost = TerritoryConfig.GetUpgradeCost(buildingId, building.level)

    -- 扣除铸材
    if not PlayerDataManager.SpendMaterials(cost) then
        return false, "铸材不足"
    end
    building.level = building.level + 1
    TerritoryManager.SaveData()

    EventBus.Emit("TerritoryBuildingUpgraded", buildingId, building.level)
    return true, buildingDef.name .. "升级到" .. building.level .. "级"
end

--- 收集建筑产出
---@param buildingId string
---@return number collected, string resourceType
function TerritoryManager.CollectBuildingOutput(buildingId)
    local building = buildings_[buildingId]
    if not building then return 0, "" end

    local buildingDef = TerritoryConfig.BUILDINGS[buildingId]
    if not buildingDef then return 0, "" end

    local now = os.time()
    local elapsed = now - (building.lastCollectTime or now)
    local hours = elapsed / 3600

    -- 最大累积8小时
    hours = math.min(hours, 8)
    local output = math.floor(TerritoryConfig.GetBuildingOutput(buildingId, building.level) * hours)

    if output <= 0 then return 0, buildingDef.resourceName end

    building.lastCollectTime = now

    -- 添加到玩家资源
    local resourceKey = buildingDef.resource
    if resourceKey == "spiritStones" then
        -- 晶核在战斗中产出，这里用铸材替代
        PlayerDataManager.AddMaterials(output)
    elseif resourceKey == "runes" then
        PlayerDataManager.AddRunes(output)
    elseif resourceKey == "materials" then
        PlayerDataManager.AddMaterials(output)
    end

    TerritoryManager.SaveData()
    return output, buildingDef.resourceName
end

--- 获取建筑可收集的产出
---@param buildingId string
---@return number
function TerritoryManager.GetPendingOutput(buildingId)
    local building = buildings_[buildingId]
    if not building then return 0 end

    local buildingDef = TerritoryConfig.BUILDINGS[buildingId]
    if not buildingDef then return 0 end

    local now = os.time()
    local elapsed = now - (building.lastCollectTime or now)
    local hours = math.min(elapsed / 3600, 8)
    return math.floor(TerritoryConfig.GetBuildingOutput(buildingId, building.level) * hours)
end

-- ========== 灵田种植 ==========

--- 获取种植位数量
---@return integer
function TerritoryManager.GetCropSlots()
    local lingField = buildings_["lingField"]
    if not lingField then return 2 end
    local def = TerritoryConfig.BUILDINGS["lingField"]
    local baseSlots = def.baseSlots
    local bonusSlots = math.floor(lingField.level / def.slotsPerLevel)
    return math.min(baseSlots + bonusSlots, def.maxSlots)
end

--- 获取可种植的作物列表（根据段位解锁）
---@return table[]
function TerritoryManager.GetAvailableCrops()
    local tier = TerritoryManager.GetCurrentTier()
    local available = {}
    for _, crop in pairs(TerritoryConfig.CROPS) do
        if tier >= crop.unlockTier then
            available[#available + 1] = crop
        end
    end
    return available
end

--- 种植作物
---@param slotIndex integer 种植位（1-based）
---@param cropId string
---@return boolean success, string message
function TerritoryManager.PlantCrop(slotIndex, cropId)
    local maxSlots = TerritoryManager.GetCropSlots()
    if slotIndex < 1 or slotIndex > maxSlots then
        return false, "种植位不存在"
    end

    if crops_[slotIndex] and crops_[slotIndex].plantTime > 0 then
        return false, "该种植位已有作物"
    end

    local cropDef = TerritoryConfig.CROPS[cropId]
    if not cropDef then
        return false, "作物不存在"
    end

    -- 检查段位解锁
    local tier = TerritoryManager.GetCurrentTier()
    if tier < cropDef.unlockTier then
        return false, "段位不足，无法种植"
    end

    crops_[slotIndex] = {
        cropId = cropId,
        plantTime = os.time(),
        growTime = cropDef.growTime,
        reward = cropDef.reward,
        isBoosted = false,
        helpCount = 0,
    }
    TerritoryManager.SaveData()
    EventBus.Emit("CropPlanted", slotIndex, cropId)
    return true, "种植成功"
end

--- 收获作物
---@param slotIndex integer
---@return boolean success, integer reward
function TerritoryManager.HarvestCrop(slotIndex)
    local crop = crops_[slotIndex]
    if not crop or not crop.plantTime then
        return false, 0
    end

    local now = os.time()
    local elapsed = now - crop.plantTime
    if elapsed < crop.growTime then
        return false, 0
    end

    local reward = crop.reward
    PlayerDataManager.AddXianyu(reward)

    -- 清空种植位
    crops_[slotIndex] = nil
    TerritoryManager.SaveData()
    EventBus.Emit("CropHarvested", slotIndex, reward)
    return true, reward
end

--- 获取种植状态
---@param slotIndex integer
---@return table|nil { cropId, plantTime, growTime, progress, isReady, reward }
function TerritoryManager.GetCropStatus(slotIndex)
    local crop = crops_[slotIndex]
    if not crop or not crop.plantTime then
        return nil
    end

    local now = os.time()
    local elapsed = now - crop.plantTime
    local progress = math.min(elapsed / crop.growTime, 1.0)
    local isReady = elapsed >= crop.growTime

    return {
        cropId = crop.cropId,
        plantTime = crop.plantTime,
        growTime = crop.growTime,
        progress = progress,
        isReady = isReady,
        reward = crop.reward,
        helpCount = crop.helpCount or 0,
    }
end

--- 更新所有种植状态（检查是否成熟）
function TerritoryManager.UpdateCropStatus()
    local now = os.time()
    for slotIndex, crop in pairs(crops_) do
        if crop.plantTime then
            local elapsed = now - crop.plantTime
            if elapsed >= crop.growTime then
                EventBus.Emit("CropReady", slotIndex, crop.cropId)
            end
        end
    end
end

--- 好友帮忙加速
---@param slotIndex integer
---@return boolean success, string message
function TerritoryManager.FriendHelp(slotIndex)
    local crop = crops_[slotIndex]
    if not crop or not crop.plantTime then
        return false, "该种植位无作物"
    end

    local now = os.time()
    local elapsed = now - crop.plantTime
    if elapsed >= crop.growTime then
        return false, "作物已成熟"
    end

    if crop.helpCount and crop.helpCount >= 3 then
        return false, "该作物已被帮忙3次，无法再加速"
    end

    crop.helpCount = (crop.helpCount or 0) + 1
    -- 减少10%剩余时间
    local remaining = crop.growTime - elapsed
    local reduction = remaining * TerritoryConfig.FRIEND_INTERACTION.helpSpeedReduction
    crop.growTime = crop.growTime - reduction
    crop.isBoosted = true

    TerritoryManager.SaveData()
    EventBus.Emit("CropHelped", slotIndex, crop.helpCount)
    return true, "加速成功"
end

-- ========== 小偷入侵 ==========

--- 检查每日重置
function TerritoryManager.CheckDailyReset()
    local now = os.time()
    local todayStart = os.date("*t", now)
    todayStart.hour = 0
    todayStart.min = 0
    todayStart.sec = 0
    local todayReset = os.time(todayStart)

    if thiefState_.dailyResetTime < todayReset then
        thiefState_.dailyCount = 0
        thiefState_.dailyResetTime = todayReset
        thiefState_.nextThiefTime = now + math.random(
            TerritoryConfig.THIEF.firstTriggerMin * 60,
            TerritoryConfig.THIEF.firstTriggerMax * 60
        )
        TerritoryManager.SaveData()
    end
end

--- 检查小偷触发
function TerritoryManager.CheckThiefTrigger()
    if thiefState_.isThiefActive then return end
    if thiefState_.dailyCount >= TerritoryConfig.THIEF.maxDaily then return end

    local now = os.time()
    if thiefState_.nextThiefTime == 0 then
        thiefState_.nextThiefTime = now + math.random(
            TerritoryConfig.THIEF.firstTriggerMin * 60,
            TerritoryConfig.THIEF.firstTriggerMax * 60
        )
    end

    if now >= thiefState_.nextThiefTime then
        thiefState_.isThiefActive = true
        thiefState_.dailyCount = thiefState_.dailyCount + 1
        EventBus.Emit("ThiefInvasion", thiefState_.dailyCount)
    end
end

--- 击败小偷
---@return boolean victory, table rewards
function TerritoryManager.DefeatThief()
    if not thiefState_.isThiefActive then
        return false, nil
    end

    -- 获取奖励
    local rewardIndex = math.min(thiefState_.dailyCount, #TerritoryConfig.THIEF.rewards)
    local rewards = TerritoryConfig.THIEF.rewards[rewardIndex]

    -- 发放奖励
    PlayerDataManager.AddMaterials(rewards.materials or 0)
    PlayerDataManager.AddRunes(rewards.runes or 0)
    PlayerDataManager.AddXianyu(rewards.xianyu or 0)

    thiefState_.isThiefActive = false
    thiefState_.lastThiefTime = os.time()

    -- 设置下次小偷时间
    if thiefState_.dailyCount < TerritoryConfig.THIEF.maxDaily then
        thiefState_.nextThiefTime = os.time() + math.random(
            TerritoryConfig.THIEF.secondTriggerMin * 60,
            TerritoryConfig.THIEF.secondTriggerMax * 60
        )
    end

    TerritoryManager.SaveData()
    EventBus.Emit("ThiefDefeated", rewards)
    return true, rewards
end

--- 获取小偷状态
---@return table
function TerritoryManager.GetThiefState()
    return thiefState_
end

--- 计算防御值
---@return integer
function TerritoryManager.GetDefenseValue()
    local lordLevel = PlayerDataManager.Get("level") or 1
    local buildingLevelSum = 0
    for _, building in pairs(buildings_) do
        buildingLevelSum = buildingLevelSum + (building.level or 1)
    end
    return lordLevel * 5 + buildingLevelSum * 3
end

--- 计算小偷强度
---@return integer hp, integer atk
function TerritoryManager.GetThiefStrength()
    local lordLevel = PlayerDataManager.Get("level") or 1
    local buildingLevelSum = 0
    for _, building in pairs(buildings_) do
        buildingLevelSum = buildingLevelSum + (building.level or 1)
    end
    local diff = TerritoryConfig.GetThiefDifficulty(lordLevel)
    local strength = (lordLevel * 8 + buildingLevelSum * 2) * diff.coefficient
    return diff.hp, diff.atk
end

-- ========== 领主等级 ==========

--- 获取当前段位索引（0=青铜，1=白银，2=黄金，3=铂金，4=钻石，5=星耀，6=王者，7=荣耀王者）
---@return integer
function TerritoryManager.GetCurrentTier()
    local trophies = PlayerDataManager.Get("trophies") or 0
    if trophies >= 20000 then return 7
    elseif trophies >= 15000 then return 6
    elseif trophies >= 10000 then return 5
    elseif trophies >= 5000 then return 4
    elseif trophies >= 2500 then return 3
    elseif trophies >= 1000 then return 2
    elseif trophies >= 300 then return 1
    end
    return 0
end

--- 获取领主星阶信息
---@return table { title, atkPerLevel, hpPerLevel, spiritPerLevel }
function TerritoryManager.GetLordRealm()
    local level = PlayerDataManager.Get("level") or 1
    return TerritoryConfig.GetLordLevelInfo(level)
end

--- 获取领主加成（用于主城属性）
---@return integer atkBonus, integer hpBonus, number spiritPerSec
function TerritoryManager.GetLordBonus()
    local level = PlayerDataManager.Get("level") or 1
    local realm = TerritoryConfig.GetLordLevelInfo(level)

    local atk = 0
    local hp = 0
    local spirit = 0

    -- 遍历所有星阶累加
    for _, tier in ipairs(TerritoryConfig.LORD_LEVELS) do
        if level >= tier.minLevel then
            local levelsInTier = math.min(level, tier.maxLevel) - tier.minLevel + 1
            atk = atk + levelsInTier * tier.atkPerLevel
            hp = hp + levelsInTier * tier.hpPerLevel
            spirit = spirit + levelsInTier * tier.spiritPerLevel
        end
    end

    return atk, hp, spirit
end

-- ========== 离线奖励（委托给 OfflineRewardManager） ==========

--- 领取离线奖励
---@param isDoubled boolean 是否看广告双倍
---@return table
function TerritoryManager.ClaimOfflineRewards(isDoubled)
    return OfflineRewardManager.Claim(isDoubled)
end

--- 获取离线收益
---@return table
function TerritoryManager.GetOfflineRewards()
    return OfflineRewardManager.GetAccumulated()
end

-- ========== 更新 ==========

--- 每帧更新
---@param dt number
function TerritoryManager.Update(dt)
    onlineTimer_ = onlineTimer_ + dt
    -- 每10秒检查一次小偷触发
    if onlineTimer_ % 10 < dt then
        TerritoryManager.CheckThiefTrigger()
    end
end

-- ========== 持久化 ==========

--- 保存据点数据
function TerritoryManager.SaveData()
    PlayerDataManager.Set("territory", {
        buildings = buildings_,
        crops = crops_,
        thiefState = thiefState_,
    })
    PlayerDataManager.Save()
end

return TerritoryManager