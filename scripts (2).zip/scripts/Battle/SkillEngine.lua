-- ══════════════════════════════════════════════
-- ============================================================================
-- SkillEngine.lua - 技能效果执行引擎
-- 根据 UnitConfig 中的技能数据驱动所有技能逻辑
-- ============================================================================

local HexGrid = require("Battle.HexGrid")
local SoundManager = require("Audio.SoundManager")

local SkillEngine = {}

-- ========== 内部状态 ==========
-- 单位运行时技能状态: { [unitId] = { timers={}, stacks={}, buffs={}, dots={}, shield=0, ... } }
local unitSkillStates_ = {}

-- 全局效果事件队列（供渲染层消费）
local skillEvents_ = {}

local function BuildUnitLookup(units)
    local lookup = {}
    for _, unit in ipairs(units) do
        if unit.state ~= "dead" then
            local key = HexGrid.Key(unit.q, unit.r)
            local bucket = lookup[key]
            if not bucket then
                lookup[key] = { unit }
            else
                bucket[#bucket + 1] = unit
            end
        end
    end
    return lookup
end

local function MatchesOwnerFilter(unit, ownerFilter)
    if not ownerFilter then
        return true
    end
    if type(ownerFilter) == "function" then
        return ownerFilter(unit)
    end
    return unit.owner == ownerFilter
end

local function GetUnitsInRange(center, units, range, ownerFilter, excludeId, unitLookup)
    if not center or range == nil or range < 0 then
        return {}
    end

    local results = {}
    local useLookup = range <= 6
    if useLookup then
        unitLookup = unitLookup or BuildUnitLookup(units)
        for dq = -range, range do
            local drMin = math.max(-range, -dq - range)
            local drMax = math.min(range, -dq + range)
            for dr = drMin, drMax do
                local key = HexGrid.Key(center.q + dq, center.r + dr)
                local bucket = unitLookup[key]
                if bucket then
                    for _, other in ipairs(bucket) do
                        if other.id ~= excludeId and other.state ~= "dead" and MatchesOwnerFilter(other, ownerFilter) then
                            results[#results + 1] = other
                        end
                    end
                end
            end
        end

        return results
    end

    for _, other in ipairs(units) do
        if other.id ~= excludeId and other.state ~= "dead" and MatchesOwnerFilter(other, ownerFilter) then
            local dist = HexGrid.Distance(center, { q = other.q, r = other.r })
            if dist <= range then
                results[#results + 1] = other
            end
        end
    end
    return results
end

--- 获取并清空本帧技能事件
function SkillEngine.PopSkillEvents()
    local events = skillEvents_
    skillEvents_ = {}
    return events
end

--- 推送技能事件
local function pushEvent(eventType, data)
    data.eventType = eventType
    skillEvents_[#skillEvents_ + 1] = data
end

-- ========== 初始化/重置 ==========

--- 为一个单位初始化技能运行时状态
---@param unit table 单位对象（需要有 id, cardName, cardLevel 字段）
---@param unlockedSkills table[] 已解锁技能列表
function SkillEngine.InitUnit(unit, unlockedSkills)
    local state = {
        timers = {},        -- on_timer 冷却计时: { [skillName] = elapsed }
        cooldowns = {},     -- active 技能冷却: { [skillName] = remaining }
        stacks = {},        -- 叠加层数: { [skillName] = count }
        stackTargets = {},  -- 叠加目标跟踪: { [skillName] = targetId }
        buffs = {},         -- 临时 buff: { {stat, value, expireTime}, ... }
        dots = {},          -- 持续伤害: { {source, dmgPerTick, interval, remaining, timer}, ... }
        shield = 0,         -- 护盾值
        dodgeChance = 0,    -- 闪避率（累计）
        critRate = 0,       -- 暴击率
        critDamage = 0,     -- 暴击伤害加成
        lifesteal = 0,      -- 吸血比例
        damageReduce = 0,   -- 减伤比例
        extraRange = 0,     -- 额外射程
        spdPercent = 0,     -- 移速加成%
        atkPercent = 0,     -- 攻击加成%
        attackSpeedPercent = 0, -- 攻速加成%
        cooldownReduction = 0,  -- 冷却缩减%
        auraRange = 0,      -- 光环范围加成
        firstAttack = true, -- 是否首次攻击（猛扑用）
        reviveChance = 0,   -- 重生概率
        transformed = false,-- 变身状态
        transformExpire = 0,-- 变身结束时间
        
        -- 新增状态追踪字段
        lastPos = { q = 0, r = 0 },  -- 上一帧位置（用于 stationary/moving 判断）
        isStationary = true,          -- 是否保持静止
        isMoving = false,             -- 是否移动中
        stationaryTime = 0,           -- 保持静止的时间
        lastProduceCheck = 0,         -- 上次额外产兵检查时间
        extraProduceChance = 0,       -- 额外产兵概率（组装术）
        alliesDamageReduce = 0,       -- 友军减伤百分比（铜墙铁壁）
        nearbyAlliesDamageReduceRange = 0,     -- 友军减伤范围
        shareDamageRange = 0,         -- 伤害分担范围
        shareDamageRatio = 0,         -- 伤害分担比例
        enemiesDamageTakenIncrease = 0,         -- 光环内敌人受伤增加
        enemiesDamageTakenIncreaseRange = 0,    -- 敌人受伤增加范围
        enemiesAtkDebuff = 0,         -- 光环内敌人攻击削弱
        enemiesAtkDebuffRange = 0,    -- 光环内敌人攻击削弱范围
        after90sActive = false,       -- 90秒后效果是否激活
        healOnEnemyDeath = 0,         -- 附近敌人死亡时回血数值
        healOnEnemyDeathRange = 0,    -- 附近敌人死亡检测范围
    }

    -- 初始化 on_timer 冷却
    for _, skill in ipairs(unlockedSkills) do
        if skill.trigger == "on_timer" then
            state.timers[skill.name] = 0
        end
        if skill.trigger == "active" then
            state.cooldowns[skill.name] = 0
        end
    end

    -- 应用被动技能的常驻效果
    for _, skill in ipairs(unlockedSkills) do
        if skill.trigger == "passive" then
            SkillEngine.ApplyPassive(unit, skill, state)
        end
    end

    unitSkillStates_[unit.id] = state
end

--- 注入羁绊加成到技能运行时状态（在 InitUnit 之后调用）
---@param unitId integer
---@param synergies table { critRate, extraRange, attackSpeedPercent, cooldownReduction, reviveChance }
function SkillEngine.ApplySynergyBonuses(unitId, synergies)
    local state = unitSkillStates_[unitId]
    if not state then return end

    state.critRate = state.critRate + (synergies.critRate or 0)
    state.extraRange = state.extraRange + (synergies.extraRange or 0)
    state.attackSpeedPercent = state.attackSpeedPercent + (synergies.attackSpeedPercent or 0)
    state.cooldownReduction = state.cooldownReduction + (synergies.cooldownReduction or 0)
    state.reviveChance = state.reviveChance + (synergies.reviveChance or 0)
end

--- 清除单位技能状态
function SkillEngine.RemoveUnit(unitId)
    unitSkillStates_[unitId] = nil
end

--- 全部重置
function SkillEngine.Reset()
    unitSkillStates_ = {}
    skillEvents_ = {}
end

-- ========== 被动技能应用 ==========

--- 应用被动技能的常驻效果到运行时状态
---@param unit table
---@param skill table 技能定义
---@param state table 运行时状态
function SkillEngine.ApplyPassive(unit, skill, state)
    local p = skill.params
    if not p then return end

    local eff = skill.effect

    if eff == "stat_buff" then
        -- 对自身的常驻属性加成
        if not p.target and not p.perAlly and not p.condition then
            if p.stat == "atk" then
                state.atkPercent = state.atkPercent + (p.percent or 0)
            elseif p.stat == "spd" then
                state.spdPercent = state.spdPercent + (p.percent or 0)
            elseif p.stat == "attackSpeed" then
                state.attackSpeedPercent = state.attackSpeedPercent + (p.percent or 0)
            elseif p.stat == "range" then
                state.extraRange = state.extraRange + (p.flat or 0)
            elseif p.stat == "cooldownReduction" then
                state.cooldownReduction = state.cooldownReduction + (p.percent or 0)
            elseif p.stat == "dodgeChance" then
                state.dodgeChance = state.dodgeChance + (p.flat or 0)
            elseif p.stat == "lifesteal" then
                state.lifesteal = state.lifesteal + (p.flat or 0)
            elseif p.stat == "auraRange" then
                state.auraRange = state.auraRange + (p.flat or 0)
            elseif p.stat == "reviveChance" then
                state.reviveChance = state.reviveChance + (p.flat or 0)
            elseif p.stat == "chainTargets" then
                -- 连锁目标增加（存在 stacks 中）
                state.stacks["chainTargets"] = (state.stacks["chainTargets"] or 0) + (p.flat or 0)
            elseif p.stat == "focusStackMax" then
                state.stacks["focusStackMax"] = (state.stacks["focusStackMax"] or 0) + (p.flat or 0)
            elseif p.stat == "extraProduceChance" then
                state.stacks["extraProduceChance"] = (state.stacks["extraProduceChance"] or 0) + (p.flat or 0)
            elseif p.stat == "charmChance" then
                state.stacks["charmChance"] = (state.stacks["charmChance"] or 0) + (p.flat or 0)
            elseif p.stat == "dotDamage" then
                state.stacks["dotDamageBonus"] = (state.stacks["dotDamageBonus"] or 0) + (p.percent or 0)
            elseif p.stat == "fireDamage" then
                state.stacks["fireDamageBonus"] = (state.stacks["fireDamageBonus"] or 0) + (p.percent or 0)
            elseif p.stat == "slowPercent" then
                state.stacks["slowBonus"] = (state.stacks["slowBonus"] or 0) + (p.flat or 0)
            elseif p.stat == "elementDamage" then
                state.stacks["elementDamageBonus"] = (state.stacks["elementDamageBonus"] or 0) + (p.percent or 0)
            end
            -- 混沌之力的双属性
            if p.attackSpeed then
                state.attackSpeedPercent = state.attackSpeedPercent + p.attackSpeed
            end
        end
        -- #18 target="nearby_allies" — 铁壁卫士铜墙铁壁，3格内友军减伤15%
        if p.target == "nearby_allies" and p.stat == "damage_reduce" then
            state.alliesDamageReduce = p.percent or 0.15
            state.nearbyAlliesDamageReduceRange = p.aoeRange or p.range or 3
        end
    elseif eff == "stat_debuff" then
        if p.target == "enemies_in_aura" then
            if p.stat == "atk" then
                state.enemiesAtkDebuff = p.percent or 0.15
                state.enemiesAtkDebuffRange = p.range or 3
            end
        end
    elseif eff == "damage_reduce" then
        if p.target == "nearby_allies" then
            state.alliesDamageReduce = p.percent or 0.15
            state.nearbyAlliesDamageReduceRange = p.aoeRange or p.range or 3
        elseif not p.condition then
            state.damageReduce = state.damageReduce + (p.percent or 0)
        end
    elseif eff == "damage_taken_increase" then
        if p.target == "enemies_in_aura" then
            state.enemiesDamageTakenIncrease = p.percent or 0.2
            state.enemiesDamageTakenIncreaseRange = p.aoeRange or p.range or 3
        end
    elseif eff == "crit_buff" then
        state.critRate = state.critRate + (p.critRate or 0)
        state.critDamage = state.critDamage + (p.critDamage or 0)
    elseif eff == "dodge" then
        state.dodgeChance = state.dodgeChance + (p.chance or 0)
    elseif eff == "lifesteal" then
        if not p.source then
            state.lifesteal = state.lifesteal + (p.percent or 0)
        end
    elseif eff == "extra_produce" then
        -- #14 effect="extra_produce" — 维修机师组装术，10%额外产兵
        state.extraProduceChance = p.percent or 0.1
    elseif eff == "share_damage" then
        -- #13 effect="share_damage" — 铁壁卫士盾墙，分担3格内友军伤害
        state.shareDamageRange = p.range or 3
        state.shareDamageRatio = p.percent or 0.1
    elseif eff == "heal_on_enemy_death" then
        -- #17 condition="nearby_enemy_death" — 维修机师灵魂收割
        state.healOnEnemyDeath = p.flat or 10
        state.healOnEnemyDeathRange = p.range or 3
    end
end

-- ========== 运行时属性计算 ==========

--- 获取单位实际攻击力（含 buff/技能加成）
---@param unit table
---@param units table[]|nil 所有单位（用于 perAlly 计算）
---@return number
function SkillEngine.GetEffectiveAtk(unit, units)
    local state = unitSkillStates_[unit.id]
    if not state then return unit.baseAtk or unit.attack end
    local base = unit.baseAtk or unit.attack
    local finalAtk = base * (1 + state.atkPercent)
    
    -- 检查技能条件加成
    local skills = unit.unlockedSkills
    if skills then
        for _, skill in ipairs(skills) do
            if skill.trigger == "passive" and skill.effect == "stat_buff" then
                local p = skill.params
                if p and p.stat == "atk" then
                    -- #10 condition="moving" — 翼族王尊，移动中攻击+15%
                    if p.condition == "moving" and state.isMoving then
                        finalAtk = finalAtk * (1 + (p.percent or 0))
                    end
                    -- #11 perAlly=true — 自爆机，每友军攻击+2
                    if p.perAlly and units then
                        local allyCount = 0
                        for _, other in ipairs(units) do
                            if other.owner == unit.owner and other.id ~= unit.id and other.state ~= "dead" then
                                allyCount = allyCount + 1
                            end
                        end
                        finalAtk = finalAtk + allyCount * (p.flat or 2)
                    end
                    -- #12 condition="hp_scaling" — 熔核巨兵，生命越低攻击越高
                    if p.condition == "hp_scaling" then
                        local hpRatio = unit.hp / unit.maxHp
                        local bonusAtk = base * (1 - hpRatio) * (p.percent or 0)
                        finalAtk = finalAtk + bonusAtk
                    end
                    -- #16 condition="after_90s" — 侦察机夜行，90秒后攻击+15%
                    if p.condition == "after_90s" and state.after90sActive then
                        finalAtk = finalAtk * (1 + (p.percent or 0))
                    end
                end
            end
        end
    end

    if units then
        local nearbyAllies = GetUnitsInRange({ q = unit.q, r = unit.r }, units, 3, unit.owner, unit.id)
        for _, other in ipairs(nearbyAllies) do
            local otherSkills = other.unlockedSkills
            if otherSkills then
                for _, skill in ipairs(otherSkills) do
                    if skill.trigger == "passive" and skill.effect == "stat_buff" then
                        local p = skill.params
                        if p and p.target == "nearby_allies" and p.stat == "atk" then
                            local range = p.aoeRange or p.range or 1
                            local dist = HexGrid.Distance({ q = other.q, r = other.r }, { q = unit.q, r = unit.r })
                            if dist <= range then
                                finalAtk = finalAtk * (1 + (p.percent or 0))
                                finalAtk = finalAtk + (p.flat or 0)
                            end
                        end
                    end
                end
            end
        end

        local enemiesWithAura = GetUnitsInRange({ q = unit.q, r = unit.r }, units, 3, function(other)
            return other.owner ~= unit.owner
        end)
        for _, other in ipairs(enemiesWithAura) do
            local otherState = unitSkillStates_[other.id]
            if otherState and otherState.enemiesAtkDebuff > 0 then
                local dist = HexGrid.Distance({ q = other.q, r = other.r }, { q = unit.q, r = unit.r })
                if dist <= otherState.enemiesAtkDebuffRange then
                    finalAtk = finalAtk * (1 - otherState.enemiesAtkDebuff)
                end
            end
        end
    end
    
    return finalAtk
end

--- 获取单位实际防御
---@param unit table
---@param units table[]|nil 所有单位（用于敌人减防计算）
---@return number multiplier (1.0=正常)
function SkillEngine.GetSpeedMultiplier(unit)
    local state = unitSkillStates_[unit.id]
    if not state then return 1.0 end
    return 1.0 / (1.0 + state.spdPercent)  -- spdPercent 越高，移动间隔越短
end

--- 获取单位实际攻击间隔倍率
---@param unit table
---@return number multiplier (< 1.0 = 攻击更快)
function SkillEngine.GetAttackSpeedMultiplier(unit)
    local state = unitSkillStates_[unit.id]
    if not state then return 1.0 end
    return 1.0 / (1.0 + state.attackSpeedPercent)
end

--- 获取单位实际射程
---@param unit table
---@return number
function SkillEngine.GetEffectiveRange(unit)
    local state = unitSkillStates_[unit.id]
    if not state then return unit.range or 1 end
    return (unit.range or 1) + state.extraRange
end

-- ========== 触发型技能处理 ==========

--- 攻击时触发（on_attack）
---@param attacker table 攻击者
---@param target table 目标（可以是单位或建筑代理表）
---@param units table[] 全部单位
---@param battleTime number 当前战斗时间(秒)
---@return number extraDamage 额外伤害
function SkillEngine.OnAttack(attacker, target, units, battleTime)
    local state = unitSkillStates_[attacker.id]
    if not state then return 0 end

    local skills = attacker.unlockedSkills
    if not skills then return 0 end

    local extraDmg = 0
    local baseAtk = SkillEngine.GetEffectiveAtk(attacker, units)

    for _, skill in ipairs(skills) do
        if skill.trigger == "on_attack" then
            local p = skill.params
            local eff = skill.effect

            -- 概率判断
            local chance = p.chance or 1.0
            -- 魅惑概率加成
            if eff == "charm" then
                chance = chance + (state.stacks["charmChance"] or 0)
            end
            if math.random() > chance then goto continue end

            if eff == "damage" then
                -- 额外伤害
                if p.firstAttackBonus and state.firstAttack then
                    extraDmg = extraDmg + baseAtk * p.firstAttackBonus
                    state.firstAttack = false
                elseif p.flat then
                    extraDmg = extraDmg + p.flat
                elseif p.extraHits then
                    extraDmg = extraDmg + baseAtk * p.extraHits
                elseif p.bonusPercent and p.condition == "target_hp_below" then
                    if target.hp and target.maxHp and (target.hp / target.maxHp) < (p.threshold or 0.3) then
                        extraDmg = extraDmg + baseAtk * p.bonusPercent
                    end
                end

            elseif eff == "dot" then
                -- 施加 DOT
                local dotDmg = p.damage or (baseAtk * (p.percentAtk or 0))
                -- DOT 加成
                local dotBonus = state.stacks["dotDamageBonus"] or 0
                dotDmg = dotDmg * (1 + dotBonus)
                local fireBonus = state.stacks["fireDamageBonus"] or 0
                dotDmg = dotDmg * (1 + fireBonus)
                SkillEngine.ApplyDot(target, attacker.id, dotDmg, p.interval or 1, p.duration or 3)

            elseif eff == "slow" then
                -- 减速
                local slowPct = p.percent + (state.stacks["slowBonus"] or 0)
                SkillEngine.ApplySlow(target, slowPct, p.duration or 2)

            elseif eff == "stun" then
                SkillEngine.ApplyStun(target, p.duration or 1)
                pushEvent("stun", { q = target.q, r = target.r })

            elseif eff == "silence" then
                SkillEngine.ApplySilence(target, p.duration or 2)

            elseif eff == "fear" then
                SkillEngine.ApplyFear(target, p.duration or 1, p.range or 1, attacker, units)

            elseif eff == "charm" then
                SkillEngine.ApplyCharm(target, p.duration or 2)
                pushEvent("charm", { q = target.q, r = target.r })

            elseif eff == "lifesteal" then
                -- 吸血会在伤害结算后处理

            elseif eff == "chain" then
                -- 连锁攻击
                local chainTargets = (p.targets or 1) + (state.stacks["chainTargets"] or 0)
                local chainDmg = baseAtk * (p.percent or 0.5)
                SkillEngine.DoChainAttack(attacker, target, units, chainTargets, chainDmg)

            elseif eff == "damage_aoe" then
                -- 攻击附带范围伤害
                local aoeDmg = baseAtk * (p.percent or 0.5)
                SkillEngine.DoAoeDamage(attacker, target, units, p.range or 1, aoeDmg)
                pushEvent("aoe", { q = target.q, r = target.r, range = p.range })

            elseif eff == "stat_buff" then
                -- 攻击时叠加 buff（聚焦等）
                if p.condition == "same_target" then
                    local sn = skill.name
                    if state.stackTargets[sn] == (target.id or 0) then
                        local maxStack = p.stackMax or 99
                        state.stacks[sn] = math.min((state.stacks[sn] or 0) + 1, maxStack)
                    else
                        state.stackTargets[sn] = target.id or 0
                        state.stacks[sn] = 1
                    end
                    -- 聚焦加成当次伤害
                    local stackBonus = (state.stacks[sn] or 0) * (p.percent or 0.05)
                    extraDmg = extraDmg + baseAtk * stackBonus
                end
            end

            ::continue::
        end
    end

    -- #19 target="behind_enemy" — 破空剑士剑气，攻击目标身后敌人
    for _, skill in ipairs(skills) do
        if skill.trigger == "on_attack" and skill.effect == "damage_behind" then
            local p = skill.params
            -- 简化计算：目标后方一格内的敌人也受到伤害
            if target.q and target.r then
                for _, other in ipairs(units) do
                    if other.owner ~= attacker.owner and other.id ~= (target.id or -1) and other.state ~= "dead" then
                        -- 计算是否在目标后方（简化版：与攻击者-目标方向相反）
                        local distToTarget = HexGrid.Distance({ q = target.q, r = target.r }, { q = other.q, r = other.r })
                        if distToTarget <= 1 then
                            local behindDmg = baseAtk * (p.percent or 0.5)
                            other.hp = other.hp - behindDmg
                            if other.hp <= 0 then
                                other.state = "dead"
                            end
                            pushEvent("behind_damage", { q = other.q, r = other.r })
                        end
                    end
                end
            end
        end
    end
    
    -- 暴击判定
    if state.critRate > 0 and math.random() < state.critRate then
        local critMult = 1.5 + state.critDamage
        extraDmg = extraDmg + baseAtk * (critMult - 1)
        pushEvent("crit", { q = target.q, r = target.r })
    end

    return extraDmg
end

--- 被攻击时触发（on_hit）
---@param defender table
---@param attacker table
---@param rawDamage number 原始伤害
---@param units table[]|nil 全部单位
---@return number actualDamage 经过技能处理后的实际伤害
function SkillEngine.OnHit(defender, attacker, rawDamage, units)
    local state = unitSkillStates_[defender.id]
    if not state then return rawDamage end

    local dmg = rawDamage

    -- 护盾吸收
    if state.shield > 0 then
        if state.shield >= dmg then
            state.shield = state.shield - dmg
            return 0
        else
            dmg = dmg - state.shield
            state.shield = 0
        end
    end

    -- 闪避
    if state.dodgeChance > 0 and math.random() < state.dodgeChance then
        pushEvent("dodge", { q = defender.q, r = defender.r })
        return 0
    end

    -- #18 检查附近友军的减伤光环
    if units then
        local nearbyAllies = GetUnitsInRange({ q = defender.q, r = defender.r }, units, 3, defender.owner, defender.id)
        for _, other in ipairs(nearbyAllies) do
            local otherState = unitSkillStates_[other.id]
            if otherState and otherState.alliesDamageReduce > 0 then
                local dist = HexGrid.Distance({ q = other.q, r = other.r }, { q = defender.q, r = defender.r })
                if dist <= (otherState.nearbyAlliesDamageReduceRange or 3) then
                    dmg = dmg * (1 - otherState.alliesDamageReduce)
                end
            end
        end
    end
    
    -- 减伤
    if state.damageReduce > 0 then
        dmg = dmg * (1 - state.damageReduce)
    end

    local skills = defender.unlockedSkills
    if skills then
        for _, skill in ipairs(skills) do
            if (skill.trigger == "passive" or skill.trigger == "hp_below") and skill.effect == "damage_reduce" then
                local p = skill.params or {}
                local applies = false
                if skill.trigger == "hp_below" then
                    local threshold = skill.threshold or p.threshold or 0.3
                    applies = defender.maxHp and defender.maxHp > 0 and (defender.hp / defender.maxHp) < threshold
                elseif p.condition == "stationary" then
                    applies = state.isStationary
                elseif p.condition == "melee_damage" then
                    applies = attacker and ((attacker.class == "melee") or ((attacker.range or 1) <= 1))
                end
                if applies then
                    dmg = dmg * (1 - (p.percent or 0))
                end
            end
        end
    end

    -- on_hit 技能处理
    local skills = defender.unlockedSkills
    if skills then
        for _, skill in ipairs(skills) do
            if skill.trigger == "on_hit" then
                local p = skill.params

                if skill.effect == "survive" then
                    -- 免死判定：如果这次伤害会致死
                    if defender.hp - dmg <= 0 and math.random() < (p.chance or 0.1) then
                        dmg = defender.hp - 1  -- 保留1点血
                        pushEvent("survive", { q = defender.q, r = defender.r })
                    end

                elseif skill.effect == "reflect" then
                    -- 反伤
                    if math.random() < (p.chance or 0.15) then
                        local reflectDmg = rawDamage * (p.percent or 0.3)
                        if attacker and attacker.hp then
                            attacker.hp = attacker.hp - reflectDmg
                            pushEvent("reflect", { q = attacker.q, r = attacker.r, dmg = reflectDmg })
                        end
                    end
                end
            end
        end
    end
    
    -- #13 伤害分担：查找附近的友军，分担伤害
    if units then
        local potentialSharers = GetUnitsInRange({ q = defender.q, r = defender.r }, units, 3, defender.owner, defender.id)
        local shareTargets = {}
        for _, other in ipairs(potentialSharers) do
            local otherState = unitSkillStates_[other.id]
            if otherState and otherState.shareDamageRatio > 0 then
                local dist = HexGrid.Distance({ q = other.q, r = other.r }, { q = defender.q, r = defender.r })
                if dist <= otherState.shareDamageRange then
                    table.insert(shareTargets, { unit = other, state = otherState })
                end
            end
        end
        
        if #shareTargets > 0 then
            local sharePerTarget = dmg * (shareTargets[1].state.shareDamageRatio) / #shareTargets
            for _, t in ipairs(shareTargets) do
                t.unit.hp = t.unit.hp - sharePerTarget
                dmg = dmg - sharePerTarget
                pushEvent("damage_shared", { q = t.unit.q, r = t.unit.r, dmg = sharePerTarget })
            end
        end
    end

    return math.max(1, dmg)
end

--- 击杀时触发（on_kill）
---@param killer table
---@param victim table
---@param units table[]
---@param onSpiritGain function|nil 晶核获取回调
function SkillEngine.OnKill(killer, victim, units, onSpiritGain)
    local state = unitSkillStates_[killer.id]
    if not state then return end

    local skills = killer.unlockedSkills
    if not skills then return end

    for _, skill in ipairs(skills) do
        if skill.trigger == "on_kill" then
            local p = skill.params
            local eff = skill.effect

            if eff == "spirit_on_kill" then
                if onSpiritGain then
                    onSpiritGain(killer.owner, p.amount or 2)
                end

            elseif eff == "heal" then
                SoundManager.Play("heal", 0.5)
                local healAmt = killer.maxHp * (p.percent or 0.05)
                killer.hp = math.min(killer.hp + healAmt, killer.maxHp)

            elseif eff == "stat_buff" then
                -- 临时 buff
                if p.duration then
                    state.buffs[#state.buffs + 1] = {
                        stat = p.stat,
                        percent = p.percent or 0,
                        expireTime = p.duration, -- 倒计时
                    }
                    -- 立即应用
                    if p.stat == "attackSpeed" then
                        state.attackSpeedPercent = state.attackSpeedPercent + (p.percent or 0)
                    elseif p.stat == "atk" then
                        state.atkPercent = state.atkPercent + (p.percent or 0)
                    end
                end

            elseif eff == "explode_on_kill" then
                SoundManager.Play("thunder", 0.6)
                local aoeDmg = SkillEngine.GetEffectiveAtk(killer) * (p.percent or 0.3)
                SkillEngine.DoAoeDamageAtPos(killer, victim.q, victim.r, units, p.range or 1, aoeDmg)
                pushEvent("explode", { q = victim.q, r = victim.r })
            end
        end
    end
end

local function CopyParamsWithSlot(params, slot)
    local copied = {}
    for k, v in pairs(params or {}) do
        copied[k] = v
    end
    copied.slot = slot
    return copied
end

--- 死亡时触发（on_death）
---@param deadUnit table
---@param units table[]
---@param summonCallback function|nil 召唤单位回调
---@return boolean shouldRevive 是否应该复活
function SkillEngine.OnDeath(deadUnit, units, summonCallback)
    local state = unitSkillStates_[deadUnit.id]
    if not state then return false end

    -- 重生判定
    if state.reviveChance > 0 and math.random() < state.reviveChance then
        pushEvent("revive", { q = deadUnit.q, r = deadUnit.r })
        return true
    end
    
    -- #17 附近敌人死亡时，友军回血（灵魂收割）
    if units then
        local nearbyEnemies = GetUnitsInRange({ q = deadUnit.q, r = deadUnit.r }, units, 3, function(other)
            return other.owner ~= deadUnit.owner
        end)
        for _, other in ipairs(nearbyEnemies) do
            local otherState = unitSkillStates_[other.id]
            if otherState and otherState.healOnEnemyDeath > 0 then
                local dist = HexGrid.Distance({ q = deadUnit.q, r = deadUnit.r }, { q = other.q, r = other.r })
                if dist <= otherState.healOnEnemyDeathRange then
                    other.hp = math.min(other.hp + otherState.healOnEnemyDeath, other.maxHp)
                    pushEvent("heal_on_death", { q = other.q, r = other.r })
                end
            end
        end
    end

    local skills = deadUnit.unlockedSkills
    if not skills then return false end

    for _, skill in ipairs(skills) do
        if skill.trigger == "on_death" then
            local p = skill.params
            local eff = skill.effect

            if eff == "summon" then
                -- 死亡召唤
                if summonCallback then
                    summonCallback(deadUnit.owner, deadUnit.q, deadUnit.r, CopyParamsWithSlot(p, deadUnit.slot))
                end
                pushEvent("summon", { q = deadUnit.q, r = deadUnit.r, count = p.count })

            elseif eff == "heal" then
                -- 死亡时治疗友军
                SkillEngine.HealNearbyAllies(deadUnit, units, p.aoeRange or 3, p.percent or 0.2)
                pushEvent("heal_aoe", { q = deadUnit.q, r = deadUnit.r })

            elseif eff == "slow" then
                -- 死亡释放减速（毒雾）
                SkillEngine.SlowNearbyEnemies(deadUnit, units, p.range or 1, p.percent or 0.3, p.duration or 3)

            elseif eff == "revive" then
                local chance = p.chance
                if chance == nil or math.random() < chance then
                    pushEvent("revive", { q = deadUnit.q, r = deadUnit.r })
                    return true
                end
            end
        end
    end

    return false
end

-- ========== 定时器更新 ==========

--- 每帧更新所有单位的定时技能和 buff/dot
---@param units table[]
---@param dt number
---@param battleTime number
---@param summonCallback function|nil
function SkillEngine.Update(units, dt, battleTime, summonCallback)
    local unitLookup = BuildUnitLookup(units)
    -- 重置每个单位本帧的光环治疗接收量（用于叠加上限）
    for _, unit in ipairs(units) do
        unit._regenReceived = 0
    end
    for _, unit in ipairs(units) do
        if unit.state ~= "dead" then
            local state = unitSkillStates_[unit.id]
            if state then
                -- #9 #10 更新移动状态
                if state.lastPos.q ~= unit.q or state.lastPos.r ~= unit.r then
                    state.isMoving = true
                    state.isStationary = false
                    state.stationaryTime = 0
                else
                    state.isMoving = false
                    state.stationaryTime = state.stationaryTime + dt
                    -- 保持静止1秒后标记为 stationary
                    if state.stationaryTime >= 1 then
                        state.isStationary = true
                    end
                end
                state.lastPos.q = unit.q
                state.lastPos.r = unit.r
                
                -- #16 condition="after_90s" — 侦察机夜行
                if battleTime >= 90 and not state.after90sActive then
                    state.after90sActive = true
                end
                
                -- 更新定时技能
                SkillEngine.UpdateTimers(unit, state, units, dt, battleTime, summonCallback, unitLookup)
                -- 更新临时 buff 过期
                SkillEngine.UpdateBuffs(unit, state, dt)
                -- 更新 DOT
                SkillEngine.UpdateDots(unit, state, dt)
                -- 更新光环伤害
                SkillEngine.UpdateAura(unit, state, units, dt, unitLookup)
                -- 更新 HP 阈值技能
                SkillEngine.UpdateHpThreshold(unit, state)
                -- 更新变身状态
                SkillEngine.UpdateTransform(unit, state, battleTime)
            end
        end
    end
end

--- 更新 on_timer 技能
function SkillEngine.UpdateTimers(unit, state, units, dt, battleTime, summonCallback, unitLookup)
    local skills = unit.unlockedSkills
    if not skills then return end

    local cdr = state.cooldownReduction

    for _, skill in ipairs(skills) do
        if skill.trigger == "on_timer" then
            local interval = skill.interval or 10
            interval = interval * (1 - cdr)  -- 冷却缩减

            state.timers[skill.name] = (state.timers[skill.name] or 0) + dt
            if state.timers[skill.name] >= interval then
                state.timers[skill.name] = 0
                SkillEngine.ExecuteTimerSkill(unit, skill, units, battleTime, summonCallback, state, unitLookup)
            end
        end
    end
end

local function FindLastDeadAlly(unit, units)
    if not units then return nil end
    for i = #units, 1, -1 do
        local other = units[i]
        if other and other.owner == unit.owner and other.state == "dead" then
            return other
        end
    end
    return nil
end

--- 执行定时技能
function SkillEngine.ExecuteTimerSkill(unit, skill, units, battleTime, summonCallback, state, unitLookup)
    local p = skill.params
    local eff = skill.effect
    local baseAtk = SkillEngine.GetEffectiveAtk(unit)

    if eff == "damage_aoe" then
        SoundManager.Play("thunder", 0.5)
        local dmg = 0
        if p.percent then
            dmg = baseAtk * p.percent
        elseif p.percentAtk then
            dmg = baseAtk * p.percentAtk
        elseif p.percentMaxHp then
            -- 基于目标最大生命百分比 → 每个目标单独计算
        end
        local range = p.range or 2

        -- 找到目标区域中心（最近敌人或自身）
        local targetPos = SkillEngine.FindNearestEnemyPos(unit, units)
        if not targetPos then return end

        if p.percentMaxHp then
            -- 按最大生命比例伤害
            SkillEngine.DoPercentHpAoe(unit, targetPos, units, range, p.percentMaxHp)
        else
            SkillEngine.DoAoeDamageAtPos(unit, targetPos.q, targetPos.r, units, range, dmg)
        end

        -- 附带效果
        if p.stun then
            SkillEngine.StunInRange(targetPos, units, range, p.stun, unit.owner)
        end
        if p.slow then
            SkillEngine.SlowInRange(targetPos, units, range, p.slow, p.slowDur or 2, unit.owner)
        end
        if p.knockback then
            SkillEngine.KnockbackInRange(targetPos, units, range, p.knockback, unit)
        end
        if p.summon and summonCallback then
            summonCallback(unit.owner, targetPos.q, targetPos.r, { unitId = p.summon, count = p.summonCount or 1, slot = unit.slot })
        end

        pushEvent("timer_aoe", { q = targetPos.q, r = targetPos.r, range = range, name = skill.name })

    elseif eff == "damage_line" then
        SoundManager.Play("thunder", 0.4)
        local dmg = baseAtk * (p.percent or 2.0)
        SkillEngine.DoLineDamage(unit, units, dmg)
        pushEvent("line_attack", { q = unit.q, r = unit.r, name = skill.name })

    elseif eff == "summon" then
        SoundManager.Play("thunder", 0.3)
        if summonCallback then
            summonCallback(unit.owner, unit.q, unit.r, CopyParamsWithSlot(p, unit.slot))
        end
        pushEvent("summon", { q = unit.q, r = unit.r, count = p.count })

    elseif eff == "shield" then
        SoundManager.Play("heal", 0.4)
        local shieldAmt = unit.maxHp * (p.percentMaxHp or 0.2)
        state.shield = shieldAmt
        pushEvent("shield", { q = unit.q, r = unit.r })

    elseif eff == "heal" then
        SoundManager.Play("heal", 0.5)
        local healAmt = unit.maxHp * (p.percent or 0.1)
        unit.hp = math.min(unit.hp + healAmt, unit.maxHp)

    elseif eff == "suspend" then
        -- 龙卷风：悬浮一个敌人
        local target = SkillEngine.FindNearestEnemyUnit(unit, units)
        if target then
            SkillEngine.ApplySuspend(target, p.duration or 3)
            pushEvent("suspend", { q = target.q, r = target.r })
        end

    elseif eff == "convert" then
        -- 转化：转化一个敌人
        local target = SkillEngine.FindNearestEnemyUnit(unit, units)
        if target then
            SkillEngine.ApplyConvert(target, unit.owner, p.duration or 8, unit.slot)
            pushEvent("convert", { q = target.q, r = target.r })
        end

    elseif eff == "damage" then
        -- 暗影狂袭（对最远敌人）
        SoundManager.Play("thunder", 0.45)
        if p.target == "farthest_enemy" then
            local target = SkillEngine.FindFarthestEnemy(unit, units)
            if target then
                local dmg = baseAtk * (p.percent or 2.0)
                target.hp = target.hp - dmg
                if p.lifesteal then
                    local heal = dmg * p.lifesteal
                    unit.hp = math.min(unit.hp + heal, unit.maxHp)
                end
                pushEvent("dash_attack", { q = unit.q, r = unit.r, tq = target.q, tr = target.r })
            end
        end

    elseif eff == "revive" then
        -- 死灵复苏
        local targetQ, targetR = unit.q, unit.r
        local cardName = p.cardName
        local cardLevel = p.cardLevel or 0
        local reviveSlot = unit.slot
        if p.target == "last_dead_ally" then
            local deadAlly = FindLastDeadAlly(unit, units)
            if deadAlly then
                targetQ, targetR = deadAlly.q, deadAlly.r
                cardName = deadAlly.cardName
                cardLevel = deadAlly.cardLevel or 0
                reviveSlot = deadAlly.slot or reviveSlot
            end
        end
        if summonCallback then
            summonCallback(unit.owner, targetQ, targetR, {
                unitId = "_revived", count = 1,
                cardName = cardName,
                cardLevel = cardLevel,
                slot = reviveSlot,
                hpPercent = p.hpPercent or 0.5,
                duration = p.duration or 8
            })
        end

    elseif eff == "stat_buff" then
        -- 熔核领域等定时 buff
        if p.target == "nearby_allies" then
            SkillEngine.BuffNearbyAllies(unit, units, p.aoeRange or 3, p.stat, p.flat or 0, p.duration or 5)
        end
    end
end

--- 更新临时 buff 过期
function SkillEngine.UpdateBuffs(unit, state, dt)
    local i = 1
    while i <= #state.buffs do
        local buff = state.buffs[i]
        buff.expireTime = buff.expireTime - dt
        if buff.expireTime <= 0 then
            -- 移除 buff 效果
            if buff.stat == "attackSpeed" then
                state.attackSpeedPercent = state.attackSpeedPercent - (buff.percent or 0)
            elseif buff.stat == "atk" then
                state.atkPercent = state.atkPercent - (buff.percent or 0)
            elseif buff.stat == "_slow_restore" then
                state.spdPercent = state.spdPercent + (buff.percent or 0)
            elseif buff.stat == "_speed_buff" then
                state.spdPercent = state.spdPercent - (buff.percent or 0)
            end
            table.remove(state.buffs, i)
        else
            i = i + 1
        end
    end
end

--- 更新 DOT
function SkillEngine.UpdateDots(unit, state, dt)
    local i = 1
    while i <= #state.dots do
        local dot = state.dots[i]
        dot.timer = dot.timer + dt
        dot.remaining = dot.remaining - dt

        if dot.timer >= dot.interval then
            dot.timer = dot.timer - dot.interval
            unit.hp = unit.hp - dot.dmgPerTick
            if unit.hp <= 0 then
                unit.state = "dead"
            end
        end

        if dot.remaining <= 0 then
            table.remove(state.dots, i)
        else
            i = i + 1
        end
    end
end

--- 更新光环伤害
function SkillEngine.UpdateAura(unit, state, units, dt, unitLookup)
    local skills = unit.unlockedSkills
    if not skills then return end

    for _, skill in ipairs(skills) do
        if skill.trigger == "passive" and skill.effect == "aura_damage" then
            local p = skill.params
            local range = (p.range or 2) + state.auraRange
            -- 光环伤害由 interval 控制，此处简化为每秒执行
            state.timers["_aura"] = (state.timers["_aura"] or 0) + dt
            if state.timers["_aura"] >= (p.interval or 1) then
                state.timers["_aura"] = 0
                local enemies = GetUnitsInRange({ q = unit.q, r = unit.r }, units, range, function(other)
                    return other.owner ~= unit.owner
                end, nil, unitLookup)
                for _, other in ipairs(enemies) do
                    local dmg = other.maxHp * (p.percentMaxHp or 0.02)
                    other.hp = other.hp - dmg
                    -- 光环吸血
                    if state.lifesteal > 0 then
                        unit.hp = math.min(unit.hp + dmg * state.lifesteal, unit.maxHp)
                    end
                end
            end
        end

        -- 庇佑（持续回血光环）—— 叠加上限：每个单位每秒最多从所有regen光环获得3%maxHP治疗
        if skill.trigger == "passive" and skill.effect == "regen" and skill.params.target == "nearby_allies" then
            local p = skill.params
            state.timers["_regen_aura"] = (state.timers["_regen_aura"] or 0) + dt
            if state.timers["_regen_aura"] >= 1 then
                state.timers["_regen_aura"] = 0
                local range = p.aoeRange or 2
                local allies = GetUnitsInRange({ q = unit.q, r = unit.r }, units, range, unit.owner, unit.id, unitLookup)
                local REGEN_CAP = 0.03  -- 每秒最多回复3% maxHP（来自所有光环源）
                for _, other in ipairs(allies) do
                    local cap = other.maxHp * REGEN_CAP
                    local received = other._regenReceived or 0
                    if received < cap then
                        local healAmt = math.min(other.maxHp * (p.percent or 0.02), cap - received)
                        local hpBefore = other.hp
                        other.hp = math.min(other.hp + healAmt, other.maxHp)
                        other._regenReceived = received + healAmt
                        -- [DEBUG] 治疗日志（采样）
                        if not SkillEngine._healLogCount then SkillEngine._healLogCount = 0 end
                        SkillEngine._healLogCount = SkillEngine._healLogCount + 1
                        if SkillEngine._healLogCount % 30 == 1 then
                            print(string.format("[HEAL] %s(id=%d) heals %s(id=%d) +%.1f hp (%.0f->%.0f/%.0f) cap=%.1f recv=%.1f",
                                unit.cardName or "?", unit.id, other.cardName or "?", other.id,
                                healAmt, hpBefore, other.hp, other.maxHp, cap, other._regenReceived))
                        end
                    end
                end
            end
        end

        -- 自身再生
        if skill.trigger == "passive" and skill.effect == "regen" and not skill.params.target then
            state.timers["_self_regen"] = (state.timers["_self_regen"] or 0) + dt
            if state.timers["_self_regen"] >= 1 then
                state.timers["_self_regen"] = 0
                local healAmt = unit.maxHp * (skill.params.percent or 0.01)
                unit.hp = math.min(unit.hp + healAmt, unit.maxHp)
            end
        end
    end
end

--- 更新血量阈值技能
function SkillEngine.UpdateHpThreshold(unit, state)
    local skills = unit.unlockedSkills
    if not skills then return end

    for _, skill in ipairs(skills) do
        if skill.trigger == "hp_below" then
            local threshold = skill.threshold or 0.3
            local hpRatio = unit.hp / unit.maxHp
            local sn = "_hpbelow_" .. skill.name

            if hpRatio <= threshold and not state.stacks[sn] then
                -- 激活
                state.stacks[sn] = 1
                if skill.effect == "stat_buff" then
                    local p = skill.params
                    if p.stat == "atk" then
                        state.atkPercent = state.atkPercent + (p.percent or 0)
                    end
                end
            elseif hpRatio > threshold and state.stacks[sn] then
                -- 取消（回血超过阈值）
                state.stacks[sn] = nil
                if skill.effect == "stat_buff" then
                    local p = skill.params
                    if p.stat == "atk" then
                        state.atkPercent = state.atkPercent - (p.percent or 0)
                    end
                end
            end
        end
    end
end

--- 更新变身状态
function SkillEngine.UpdateTransform(unit, state, battleTime)
    if state.transformed and battleTime >= state.transformExpire then
        state.transformed = false
        -- 移除变身加成（简化：直接扣回）
        -- 实际由 buff 系统管理
    end
end

-- ========== 效果应用函数 ==========

function SkillEngine.ApplyDot(target, sourceId, dmgPerTick, interval, duration)
    local state = unitSkillStates_[target.id]
    if not state then return end
    state.dots[#state.dots + 1] = {
        source = sourceId,
        dmgPerTick = dmgPerTick,
        interval = interval,
        remaining = duration,
        timer = 0,
    }
end

function SkillEngine.ApplySlow(target, percent, duration)
    local state = unitSkillStates_[target.id]
    if not state then return end
    -- 简化：直接降低移速
    state.spdPercent = state.spdPercent - percent
    -- 注册恢复 buff
    state.buffs[#state.buffs + 1] = {
        stat = "_slow_restore",
        percent = percent,
        expireTime = duration,
    }
end

function SkillEngine.ApplyStun(target, duration)
    if not target then return end
    target._stunUntil = (target._stunUntil or 0)
    target._stunDuration = math.max(target._stunDuration or 0, duration)
end

function SkillEngine.ApplySilence(target, duration)
    if not target then return end
    target._silenceDuration = math.max(target._silenceDuration or 0, duration)
end

function SkillEngine.ApplyFear(target, duration, range, source, units)
    if not target then return end
    target._fearDuration = math.max(target._fearDuration or 0, duration)
end

function SkillEngine.ApplyCharm(target, duration)
    if not target then return end
    target._charmDuration = math.max(target._charmDuration or 0, duration)
end

function SkillEngine.ApplySuspend(target, duration)
    if not target then return end
    target._suspendDuration = math.max(target._suspendDuration or 0, duration)
end

function SkillEngine.ApplyConvert(target, newOwner, duration, newSlot)
    if not target then return end
    target._originalOwner = target.owner
    target._originalTeam = target.team
    target._originalSlot = target.slot
    target.owner = newOwner
    target.team = newOwner
    target.slot = newSlot or newOwner
    target._convertDuration = duration
end

-- ========== AOE / 范围效果 ==========

function SkillEngine.DoAoeDamage(attacker, center, units, range, damage)
    local enemies = GetUnitsInRange({ q = center.q, r = center.r }, units, range, function(other)
        return other.owner ~= attacker.owner and other.id ~= (center.id or -1)
    end)
    for _, other in ipairs(enemies) do
        other.hp = other.hp - damage
    end
end

-- DoAoeDamageAtPos: 见文件末尾统一定义（支持 sourceUnit 为 nil）

function SkillEngine.DoPercentHpAoe(attacker, center, units, range, percent)
    local enemies = GetUnitsInRange({ q = center.q, r = center.r }, units, range, function(other)
        return other.owner ~= attacker.owner
    end)
    for _, other in ipairs(enemies) do
        local dmg = other.maxHp * percent
        other.hp = other.hp - dmg
    end
end

function SkillEngine.DoLineDamage(attacker, units, damage)
    -- 直线伤害：从攻击者位置向最近敌人方向的所有敌人
    local target = SkillEngine.FindNearestEnemyUnit(attacker, units)
    if not target then return end

    -- 简化：对从自身到目标方向的一条线上所有敌人造成伤害
    local dirQ = target.q - attacker.q
    local dirR = target.r - attacker.r
    -- 归一化方向
    if dirQ ~= 0 then dirQ = dirQ > 0 and 1 or -1 end
    if dirR ~= 0 then dirR = dirR > 0 and 1 or -1 end

    for _, other in ipairs(units) do
        if other.owner ~= attacker.owner and other.state ~= "dead" then
            -- 判断是否在"同一方向线"上（六角格直线判定）
            local dq = other.q - attacker.q
            local dr = other.r - attacker.r
            -- dirQ==0时要求dq也为0（严格同列），dirR同理
            local onLineQ = (dirQ == 0 and dq == 0) or (dirQ ~= 0 and dq ~= 0 and (dq > 0) == (dirQ > 0))
            local onLineR = (dirR == 0 and dr == 0) or (dirR ~= 0 and dr ~= 0 and (dr > 0) == (dirR > 0))
            if onLineQ and onLineR then
                local dist = HexGrid.Distance({ q = attacker.q, r = attacker.r }, { q = other.q, r = other.r })
                if dist <= 5 then  -- 最大5格
                    other.hp = other.hp - damage
                end
            end
        end
    end
end

function SkillEngine.DoChainAttack(attacker, firstTarget, units, chainCount, damage)
    local hit = { [firstTarget.id or 0] = true }
    local lastPos = { q = firstTarget.q, r = firstTarget.r }
    local unitLookup = BuildUnitLookup(units)

    for _ = 1, chainCount do
        local bestDist = 999
        local bestTarget = nil
        local nearbyEnemies = GetUnitsInRange(lastPos, units, 3, function(other)
            return other.owner ~= attacker.owner and not hit[other.id]
        end, nil, unitLookup)
        for _, other in ipairs(nearbyEnemies) do
            local dist = HexGrid.Distance(lastPos, { q = other.q, r = other.r })
            if dist < bestDist then
                bestDist = dist
                bestTarget = other
            end
        end
        if bestTarget then
            bestTarget.hp = bestTarget.hp - damage
            hit[bestTarget.id] = true
            lastPos = { q = bestTarget.q, r = bestTarget.r }
            pushEvent("chain", { q = bestTarget.q, r = bestTarget.r })
        else
            break
        end
    end
end

function SkillEngine.StunInRange(pos, units, range, duration, excludeOwner)
    local targets = GetUnitsInRange(pos, units, range, function(other)
        return other.owner ~= excludeOwner
    end)
    for _, other in ipairs(targets) do
        SkillEngine.ApplyStun(other, duration)
    end
end

function SkillEngine.SlowInRange(pos, units, range, percent, duration, excludeOwner)
    local targets = GetUnitsInRange(pos, units, range, function(other)
        return other.owner ~= excludeOwner
    end)
    for _, other in ipairs(targets) do
        SkillEngine.ApplySlow(other, percent, duration)
    end
end

function SkillEngine.KnockbackInRange(pos, units, range, distance, source)
    local targets = GetUnitsInRange(pos, units, range, function(other)
        return other.owner ~= source.owner
    end)
    for _, other in ipairs(targets) do
        -- 简化击退：远离源头1格
        local dq = other.q - source.q
        local dr = other.r - source.r
        if dq ~= 0 then other.q = other.q + (dq > 0 and 1 or -1) end
        if dr ~= 0 then other.r = other.r + (dr > 0 and 1 or -1) end
    end
end

function SkillEngine.HealNearbyAllies(source, units, range, percent)
    local allies = GetUnitsInRange({ q = source.q, r = source.r }, units, range, source.owner, source.id)
    for _, other in ipairs(allies) do
        local heal = other.maxHp * percent
        other.hp = math.min(other.hp + heal, other.maxHp)
    end
end

function SkillEngine.SlowNearbyEnemies(source, units, range, percent, duration)
    local enemies = GetUnitsInRange({ q = source.q, r = source.r }, units, range, function(other)
        return other.owner ~= source.owner
    end)
    for _, other in ipairs(enemies) do
        SkillEngine.ApplySlow(other, percent, duration)
    end
end

function SkillEngine.BuffNearbyAllies(source, units, range, stat, value, duration)
    local allies = GetUnitsInRange({ q = source.q, r = source.r }, units, range, source.owner)
    for _, other in ipairs(allies) do
        local otherState = unitSkillStates_[other.id]
        if otherState and stat == "lifesteal" then
            otherState.lifesteal = otherState.lifesteal + value
            otherState.buffs[#otherState.buffs + 1] = {
                stat = "lifesteal", percent = value, expireTime = duration
            }
        end
    end
end

-- ========== 查找辅助函数 ==========

function SkillEngine.FindNearestEnemyPos(unit, units)
    local bestDist = 999
    local bestPos = nil
    for _, other in ipairs(units) do
        if other.owner ~= unit.owner and other.state ~= "dead" then
            local dist = HexGrid.Distance({ q = unit.q, r = unit.r }, { q = other.q, r = other.r })
            if dist < bestDist then
                bestDist = dist
                bestPos = { q = other.q, r = other.r }
            end
        end
    end
    return bestPos
end

function SkillEngine.FindNearestEnemyUnit(unit, units)
    local bestDist = 999
    local bestTarget = nil
    for _, other in ipairs(units) do
        if other.owner ~= unit.owner and other.state ~= "dead" then
            local dist = HexGrid.Distance({ q = unit.q, r = unit.r }, { q = other.q, r = other.r })
            if dist < bestDist then
                bestDist = dist
                bestTarget = other
            end
        end
    end
    return bestTarget
end

function SkillEngine.FindFarthestEnemy(unit, units)
    local bestDist = -1
    local bestTarget = nil
    for _, other in ipairs(units) do
        if other.owner ~= unit.owner and other.state ~= "dead" then
            local dist = HexGrid.Distance({ q = unit.q, r = unit.r }, { q = other.q, r = other.r })
            if dist > bestDist then
                bestDist = dist
                bestTarget = other
            end
        end
    end
    return bestTarget
end

-- ========== 主动技能接口 ==========

--- 使用主动技能（传奇卡牌专属）
---@param unit table
---@param skillName string
---@param units table[]
---@param battleTime number
---@return boolean success
function SkillEngine.UseActiveSkill(unit, skillName, units, battleTime)
    local state = unitSkillStates_[unit.id]
    if not state then return false end

    -- 检查冷却
    if (state.cooldowns[skillName] or 0) > 0 then return false end

    local skills = unit.unlockedSkills
    if not skills then return false end

    for _, skill in ipairs(skills) do
        if skill.name == skillName and skill.trigger == "active" then
            local p = skill.params

            -- 进入冷却
            state.cooldowns[skillName] = skill.cooldown or 15

            if skill.effect == "damage_aoe" then
                local baseAtk = SkillEngine.GetEffectiveAtk(unit)
                if p.percent then
                    local dmg = baseAtk * p.percent
                    SkillEngine.DoAoeDamageAtPos(unit, unit.q, unit.r, units, p.range or 999, dmg)
                elseif p.percentMaxHp then
                    SkillEngine.DoPercentHpAoe(unit, { q = unit.q, r = unit.r }, units, p.range or 999, p.percentMaxHp)
                end
                if p.stun then
                    SkillEngine.StunInRange({ q = unit.q, r = unit.r }, units, p.range or 999, p.stun, unit.owner)
                end

            elseif skill.effect == "stat_buff" then
                -- 虎王降临式自我强化
                if p.stat == "atk" then
                    state.atkPercent = state.atkPercent + (p.percent or 0)
                    state.buffs[#state.buffs + 1] = {
                        stat = "atk", percent = p.percent or 0, expireTime = p.duration or 8
                    }
                end
                if p.attackSpeed then
                    state.attackSpeedPercent = state.attackSpeedPercent + p.attackSpeed
                    state.buffs[#state.buffs + 1] = {
                        stat = "attackSpeed", percent = p.attackSpeed, expireTime = p.duration or 8
                    }
                end

            elseif skill.effect == "transform" then
                -- 混沌降临
                state.transformed = true
                state.transformExpire = battleTime + (p.duration or 8)
                state.atkPercent = state.atkPercent + (p.atkPercent or 0.5)
                state.extraRange = state.extraRange + (p.rangeBonus or 1)
                state.buffs[#state.buffs + 1] = {
                    stat = "atk", percent = p.atkPercent or 0.5, expireTime = p.duration or 8
                }
            end

            pushEvent("active_skill", { q = unit.q, r = unit.r, name = skillName })
            return true
        end
    end

    return false
end

--- 更新主动技能冷却
function SkillEngine.UpdateCooldowns(dt)
    for _, state in pairs(unitSkillStates_) do
        for name, cd in pairs(state.cooldowns) do
            if cd > 0 then
                state.cooldowns[name] = cd - dt
            end
        end
    end
end

-- ========== 伤害计算接口 ==========

--- 计算最终伤害（无防御力，减伤在 OnHit 处理）
---@param attacker table
---@param defender table
---@param baseDamage number
---@param units table[]|nil
---@return number finalDamage
function SkillEngine.CalculateDamage(attacker, defender, baseDamage, units)
    local dmg = baseDamage or 0

    if units and attacker and defender then
        local enemiesWithAura = GetUnitsInRange({ q = defender.q, r = defender.r }, units, 4, function(other)
            return other.owner == attacker.owner and other.state ~= "dead"
        end)
        for _, other in ipairs(enemiesWithAura) do
            local otherState = unitSkillStates_[other.id]
            if otherState and otherState.enemiesDamageTakenIncrease > 0 then
                local dist = HexGrid.Distance({ q = other.q, r = other.r }, { q = defender.q, r = defender.r })
                if dist <= (otherState.enemiesDamageTakenIncreaseRange or 3) then
                    dmg = dmg * (1 + otherState.enemiesDamageTakenIncrease)
                end
            end
        end
    end

    return math.max(1, dmg)
end

--- 处理吸血
function SkillEngine.ProcessLifesteal(attacker, damageDealt)
    local state = unitSkillStates_[attacker.id]
    if not state or state.lifesteal <= 0 then return end

    local heal = damageDealt * state.lifesteal
    attacker.hp = math.min(attacker.hp + heal, attacker.maxHp)
end

--- #14 检查额外产兵（维修机师组装术）
---@param unit table 产兵单位（通常是兵营）
---@param owner number 玩家 owner id
---@param units table[] 所有单位
---@return boolean 是否触发额外产兵
function SkillEngine.CheckExtraProduce(unit, owner, units)
    local extraCount = 0
    for _, u in ipairs(units) do
        if u.owner == owner and u.state ~= "dead" then
            local state = unitSkillStates_[u.id]
            if state and state.extraProduceChance > 0 then
                if math.random() < state.extraProduceChance then
                    extraCount = extraCount + 1
                end
            end
        end
    end
    return extraCount > 0, extraCount
end

-- ========== 神器效果接口 ==========

--- 给指定方所有单位添加移速buff
---@param units table[] 所有单位列表
---@param owner number 玩家ID
---@param speedPercent number 移速加成百分比
---@param duration number 持续时间(秒)
function SkillEngine.AddSpeedBuffToAllies(units, owner, speedPercent, duration)
    for _, unit in ipairs(units) do
        if unit.owner == owner and unit.state ~= "dead" then
            local state = unitSkillStates_[unit.id]
            if state then
                -- 应用移速加成
                state.spdPercent = state.spdPercent + speedPercent
                -- 添加到buffs列表，以便到期移除
                state.buffs[#state.buffs + 1] = {
                    stat = "_speed_buff",
                    percent = speedPercent,
                    expireTime = duration
                }
            end
        end
    end
end

--- 给指定单位添加移速buff
---@param unit table 目标单位
---@param speedPercent number 移速加成百分比
---@param duration number 持续时间(秒)
function SkillEngine.AddSpeedBuffToUnit(unit, speedPercent, duration)
    local state = unitSkillStates_[unit.id]
    if state then
        state.spdPercent = state.spdPercent + speedPercent
        state.buffs[#state.buffs + 1] = {
            stat = "_speed_buff",
            percent = speedPercent,
            expireTime = duration
        }
    end
end

--- 给指定单位添加攻速buff
---@param unit table 目标单位
---@param attackSpeedPercent number 攻速加成百分比
---@param duration number 持续时间(秒)
function SkillEngine.AddAttackSpeedBuffToUnit(unit, attackSpeedPercent, duration)
    local state = unitSkillStates_[unit.id]
    if state then
        state.attackSpeedPercent = state.attackSpeedPercent + attackSpeedPercent
        state.buffs[#state.buffs + 1] = {
            stat = "attackSpeed",
            percent = attackSpeedPercent,
            expireTime = duration
        }
    end
end

--- 对指定位置周围的敌人造成AOE伤害
---@param sourceUnit table|nil 来源单位
---@param q number 中心坐标q
---@param r number 中心坐标r
---@param units table[] 所有单位
---@param range number 范围(格子)
---@param damage number 伤害值
function SkillEngine.DoAoeDamageAtPos(sourceUnit, q, r, units, range, damage)
    local centerHex = { q = q, r = r }
    local targets = GetUnitsInRange(centerHex, units, range, function(unit)
        return not sourceUnit or unit.owner ~= sourceUnit.owner
    end)
    for _, unit in ipairs(targets) do
        unit.hp = unit.hp - damage
        pushEvent("artifact_damage", { q = unit.q, r = unit.r, damage = damage })
    end
end

--- 斩杀指定品质的敌方单位
---@param units table[] 所有单位
---@param excludeOwner number 不伤害的玩家
---@param qualities string[] 要斩杀的品质列表
---@return number 斩杀数量
function SkillEngine.ExecuteUnitsByQuality(units, excludeOwner, qualities)
    local count = 0
    local qualitySet = {}
    for _, q in ipairs(qualities) do
        qualitySet[q] = true
    end
    for _, unit in ipairs(units) do
        if unit.state ~= "dead" and unit.owner ~= excludeOwner then
            if qualitySet[unit.quality] then
                unit.hp = 0
                count = count + 1
                pushEvent("execute", { q = unit.q, r = unit.r, cardName = unit.cardName })
            end
        end
    end
    return count
end

return SkillEngine


-- ══════════════════════════════════════════════
