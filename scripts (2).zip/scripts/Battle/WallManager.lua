-- ══════════════════════════════════════════════
-- ============================================================================
-- WallManager.lua - 城墙系统
-- 规则：
--   - 2个或以上同阵营相邻建筑自动形成城墙
--   - 城墙覆盖建筑群的外围格子边缘
--   - 单位必须先破墙才能攻击墙内建筑
--   - 城墙只有 HP，无护甲概念
-- ============================================================================

local GameConfig = require("Config.GameConfig")
local HexGrid = require("Battle.HexGrid")

local WallManager = {}

-- 城墙配置
WallManager.CONFIG = {
    baseHp = 150,   -- 基础血量
}

-- 城墙数据：walls_[owner] = { segments = { [edgeKey] = {hp, maxHp, hexA, hexB} }, clusters = {...} }
local walls_ = { [1] = { segments = {} }, [2] = { segments = {} } }

--- 生成唯一边 key（两个相邻hex之间的边）
---@param hexA table {q, r}
---@param hexB table {q, r}
---@return string
local function EdgeKey(hexA, hexB)
    local kA = HexGrid.Key(hexA.q, hexA.r)
    local kB = HexGrid.Key(hexB.q, hexB.r)
    -- 确保顺序一致
    if kA < kB then
        return kA .. "|" .. kB
    else
        return kB .. "|" .. kA
    end
end

--- 重新计算某阵营的城墙
--- 逻辑：找到所有建筑群（connected components），2+建筑的群外围生成城墙
---@param owner integer 阵营
---@param buildings table 建筑实例表 { [hexKey] = inst }
---@param tileStates table 格子状态
function WallManager.Rebuild(owner, buildings, tileStates)
    -- 1. 收集该阵营所有建筑格子
    local buildingHexes = {} -- { hexKey = true }
    for hexKey, inst in pairs(buildings) do
        if inst.owner == owner and inst.hp > 0 then
            buildingHexes[hexKey] = true
        end
    end

    -- 2. 找连通分量（BFS）
    local visited = {}
    local clusters = {} -- { { hexKey1, hexKey2, ... }, ... }

    for hexKey, _ in pairs(buildingHexes) do
        if not visited[hexKey] then
            local cluster = {}
            local queue = { hexKey }
            visited[hexKey] = true

            while #queue > 0 do
                local current = table.remove(queue, 1)
                cluster[#cluster + 1] = current

                local cq, cr = HexGrid.FromKey(current)
                local neighbors = HexGrid.Neighbors({ q = cq, r = cr })
                for _, nh in ipairs(neighbors) do
                    local nKey = HexGrid.Key(nh.q, nh.r)
                    if buildingHexes[nKey] and not visited[nKey] then
                        visited[nKey] = true
                        queue[#queue + 1] = nKey
                    end
                end
            end

            clusters[#clusters + 1] = cluster
        end
    end

    -- 3. 对每个 2+ 建筑的群，计算外围墙段
    local oldSegments = walls_[owner].segments
    local newSegments = {}

    for _, cluster in ipairs(clusters) do
        if #cluster >= 2 then
            -- 建立快速查找集合
            local clusterSet = {}
            for _, hexKey in ipairs(cluster) do
                clusterSet[hexKey] = true
            end

            -- 对群内每个建筑，检查其每条边
            -- 城墙段 = 建筑格子的边界边（相邻格子不是同群建筑）
            for _, hexKey in ipairs(cluster) do
                local hq, hr = HexGrid.FromKey(hexKey)
                local hex = { q = hq, r = hr }
                local neighbors = HexGrid.Neighbors(hex)

                for _, nh in ipairs(neighbors) do
                    local nKey = HexGrid.Key(nh.q, nh.r)
                    -- 如果邻居不是同群建筑，则这条边是城墙
                    if not clusterSet[nKey] then
                        local eKey = EdgeKey(hex, nh)
                        if not newSegments[eKey] then
                            -- 保留旧城墙HP
                            if oldSegments[eKey] then
                                newSegments[eKey] = oldSegments[eKey]
                            else
                                newSegments[eKey] = {
                                    hp = WallManager.CONFIG.baseHp,
                                    maxHp = WallManager.CONFIG.baseHp,
                                    hexInside = hex,       -- 群内格子
                                    hexOutside = nh,       -- 群外格子
                                    owner = owner,
                                }
                            end
                        end
                    end
                end
            end
        end
    end

    walls_[owner].segments = newSegments
    walls_[owner].clusters = clusters
end

--- 全面重建双方城墙（建筑变化后调用）
---@param buildings table
---@param tileStates table
function WallManager.RebuildAll(buildings, tileStates)
    WallManager.Rebuild(1, buildings, tileStates)
    WallManager.Rebuild(2, buildings, tileStates)
end

--- 检查单位是否被城墙阻挡
--- 当单位试图进入一个被城墙保护的建筑格子时，返回需要攻击的城墙段
---@param unit table 单位
---@param targetHex table {q, r} 目标格子
---@return table|nil wallSegment 如果被阻挡返回墙段数据
function WallManager.GetBlockingWall(unit, targetHex)
    -- 城墙只阻挡敌方
    local enemyOwner = (unit.owner == 1) and 2 or 1
    local segments = walls_[enemyOwner].segments

    local unitHex = { q = unit.q, r = unit.r }
    local eKey = EdgeKey(unitHex, targetHex)

    local seg = segments[eKey]
    if seg and seg.hp > 0 then
        return seg
    end

    return nil
end

--- 对城墙段施加伤害
---@param segment table 墙段
---@param damage number 伤害值
---@return boolean destroyed 是否被摧毁
function WallManager.DamageWall(segment, damage)
    segment.hp = segment.hp - damage
    if segment.hp <= 0 then
        segment.hp = 0
        return true
    end
    return false
end

--- 获取指定阵营的所有城墙段（供渲染使用）
---@param owner integer
---@return table segments
function WallManager.GetSegments(owner)
    return walls_[owner].segments
end

--- 重置城墙数据
function WallManager.Reset()
    walls_ = { [1] = { segments = {} }, [2] = { segments = {} } }
end

return WallManager


-- ══════════════════════════════════════════════
