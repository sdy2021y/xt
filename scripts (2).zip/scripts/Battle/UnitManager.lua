-- ══════════════════════════════════════════════
-- ============================================================================
-- UnitManager.lua - 单位管理器（卡牌系统版）
-- 处理：单位生成、移动（向敌方行军）、战斗、死亡
-- 已接入 UnitConfig 卡牌数据 + SkillEngine 技能引擎
-- 攻击目标机制：
--   1. 射程内有敌方（单位或建筑）→ 趋前攻击
--   2. 我方建筑被攻击时，新刷出的兵优先打攻击我方建筑的敌人
--   3. 无感知目标时，向敌方核心行军
-- ============================================================================

local GameConfig = require("Config.GameConfig")
local UnitConfig = require("Config.UnitConfig")
local HexGrid = require("Battle.HexGrid")
local WallManager = require("Battle.WallManager")
local SkillEngine = require("Battle.SkillEngine")
local SynergyManager = require("Battle.SynergyManager")
local EventBus = require("Infrastructure.EventBus")

local UnitManager = {}

-- 单位通用配置
UnitManager.CONFIG = {
    detectionRange = 6,    -- 感知范围（格数）
}

-- 单位ID计数器
local nextUnitId_ = 1

-- 被攻击的己方建筑追踪: { [hexKey] = { owner, attackers = {unitId, ...} } }
local buildingsUnderAttack_ = {}

-- 攻击事件队列（每帧清空）: { {q, r, targetQ, targetR, damage}, ... }
local attackEvents_ = {}

-- 当前战斗时间（由外部 Update 传入累计）
local battleTime_ = 0

--- 获取并清空本帧攻击事件
---@return table[] events
function UnitManager.PopAttackEvents()
    local events = attackEvents_
    attackEvents_ = {}
    return events
end

--- 重置管理器状态（新一局开始时调用）
function UnitManager.Reset()
    nextUnitId_ = 1
    buildingsUnderAttack_ = {}
    attackEvents_ = {}
    battleTime_ = 0
    SkillEngine.Reset()
end

--- 构建单位空间索引（格子 → 单位列表）
---@param units table[]
---@return table { [hexKey] = {unit1, unit2, ...} }
local function BuildUnitLookup(units)
    local lookup = {}
    for _, unit in ipairs(units) do
        if unit.state ~= "dead" then
            local key = HexGrid.Key(unit.q, unit.r)
            local bucket = lookup[key]
            if not bucket then
                lookup[key] = { unit }
            else
                bucket[#bucket + 1] = unit
            end
        end
    end
    return lookup
end

--- 从 lookup 中查找范围内的敌方单位（小范围优化版）
---@param center table {q, r}
---@param units table[]
---@param range integer
---@param excludeOwner integer
---@param unitLookup table|nil
---@return table[] results
local function GetUnitsInRangeByOwner(center, units, range, excludeOwner, unitLookup)
    if not center or range == nil or range < 0 then
        return {}
    end

    local results = {}
    local useLookup = range <= 6
    if useLookup then
        unitLookup = unitLookup or BuildUnitLookup(units)
        for dq = -range, range do
            local drMin = math.max(-range, -dq - range)
            local drMax = math.min(range, -dq + range)
            for dr = drMin, drMax do
                local key = HexGrid.Key(center.q + dq, center.r + dr)
                local bucket = unitLookup[key]
                if bucket then
                    for _, other in ipairs(bucket) do
                        if other.owner ~= excludeOwner and other.hp > 0 then
                            local dist = HexGrid.Distance(center, { q = other.q, r = other.r })
                            results[#results + 1] = { unit = other, dist = dist }
                        end
                    end
                end
            end
        end
        return results
    end

    for _, other in ipairs(units) do
        if other.owner ~= excludeOwner and other.hp > 0 and other.state ~= "dead" then
            local dist = HexGrid.Distance(center, { q = other.q, r = other.r })
            if dist <= range then
                results[#results + 1] = { unit = other, dist = dist }
            end
        end
    end
    return results
end

--- 创建一个新单位（卡牌系统）
---@param owner integer 所属玩家 (1 or 2)
---@param q integer 出生格子 q
---@param r integer 出生格子 r
---@param cardName string 卡牌名（UnitConfig.CARDS 的 key）
---@param cardLevel integer 卡牌等级（影响属性和技能解锁）
---@return table|nil unit 创建失败返回 nil
function UnitManager.CreateUnit(owner, q, r, cardName, cardLevel, slot)
    local cardDef = UnitConfig.CARDS[cardName]
    if not cardDef then
        print("[UnitManager] 未知卡牌: " .. tostring(cardName))
        return nil
    end

    -- 拦截非单位卡（建筑卡等），防止崩溃
    if (cardDef.slotType or "unit") ~= "unit" then
        print("[UnitManager] 跳过非单位卡: " .. tostring(cardName))
        return nil
    end

    cardLevel = cardLevel or 0
    slot = slot or owner
    local synergyOwner = slot

    -- 计算等级加成后的属性
    local upg = cardDef.upgrade or {}
    local hp  = cardDef.hp + (upg.hp or 0) * cardLevel
    local atk = cardDef.atk + (upg.atk or 0) * cardLevel
    local spd = cardDef.spd + (upg.spd or 0) * cardLevel

    -- 应用羁绊加成
    local hpBonus = SynergyManager.GetUnitHpBonus(synergyOwner)       -- 近战羁绊：单位生命
    local dmgBonus = SynergyManager.GetUnitDamageBonus(synergyOwner)  -- 近战羁绊：单位攻击
    local spdBonus = SynergyManager.GetMoveSpeedBonus(synergyOwner)   -- 翼族羁绊：移动速度
    hp  = math.floor(hp * (1 + hpBonus))
    atk = math.floor(atk * (1 + dmgBonus))

    -- 移动间隔（spd 越高移动越快）: 基础 2.5s，最快 0.8s
    local moveSpeed = math.max(0.8, (2.5 - (spd - 50) * 0.01) * (1 - spdBonus))
    -- 攻击间隔: 基础 1.5s
    local attackInterval = 1.5

    local unit = {
        id = nextUnitId_,
        owner = owner,
        team = owner,       -- 队伍编号（1v1 时 team = owner）
        slot = slot,        -- 玩家槽位（2v2 时与 team 分离）
        q = q,
        r = r,
        -- 卡牌信息
        cardName = cardName,
        cardLevel = cardLevel,
        race = cardDef.race,
        class = cardDef.class,
        ---@diagnostic disable: assign-type-mismatch
        quality = cardDef.quality,
        pop = cardDef.pop or UnitConfig.QUALITY_POP[cardDef.quality] or 1,
        icon = cardDef.icon,
        color = cardDef.color,
        ---@diagnostic enable: assign-type-mismatch
        -- 像素位置（用于平滑移动渲染）
        px = 0,
        py = 0,
        targetPx = 0,
        targetPy = 0,
        -- 基础属性（含等级加成，供 SkillEngine 读取）
        baseAtk = atk,
        baseSpd = spd,
        range = cardDef.range,
        -- 运行时属性
        hp = hp,
        maxHp = hp,
        attack = atk,        -- 保留向后兼容（渲染层可能读这个）
        moveSpeed = moveSpeed,
        attackInterval = attackInterval,
        -- 计时器
        moveTimer = 0,
        attackTimer = 0,
        -- 出生位置（用于"刚产出"判定）
        spawnQ = q,
        spawnR = r,
        -- 状态标记
        state = "moving",  -- "moving" | "fighting" | "dead"
        targetUnit = nil,
        targetBuildingKey = nil,
        priorityTarget = nil,
        targetWall = nil,
        -- 战绩统计
        kills = 0,
        damageDealt = 0,
        -- CC 状态（由 SkillEngine 写入）
        _stunDuration = 0,
        _silenceDuration = 0,
        _fearDuration = 0,
        _charmDuration = 0,
        _suspendDuration = 0,
        _convertDuration = 0,
        _originalOwner = nil,
        -- 技能系统
        unlockedSkills = nil,  -- 由下方 InitUnit 填入
    }
    nextUnitId_ = nextUnitId_ + 1

    -- 解锁技能并初始化技能引擎状态
    local unlockedSkills = UnitConfig.GetUnlockedSkills(cardName, cardLevel)
    unit.unlockedSkills = unlockedSkills
    SkillEngine.InitUnit(unit, unlockedSkills)

    -- 注入羁绊加成到技能状态
    SkillEngine.ApplySynergyBonuses(unit.id, {
        critRate = SynergyManager.GetCritRateBonus(synergyOwner),
        extraRange = SynergyManager.GetAttackRangeBonus(synergyOwner),
        attackSpeedPercent = SynergyManager.GetAttackSpeedBonus(synergyOwner),
        cooldownReduction = SynergyManager.GetCooldownReductionBonus(synergyOwner),
        reviveChance = SynergyManager.GetReviveChance(synergyOwner),
    })

    -- 检查是否有己方建筑正在被攻击，赋予优先目标
    UnitManager.AssignDefensePriority(unit)

    return unit
end

--- 为新生成的单位分配防御优先目标
---@param unit table
function UnitManager.AssignDefensePriority(unit)
    local bestAttackerId = nil
    local bestDist = math.huge

    for hexKey, info in pairs(buildingsUnderAttack_) do
        if info.owner == unit.owner and #info.attackers > 0 then
            local bq, br = HexGrid.FromKey(hexKey)
            local dist = HexGrid.Distance(
                { q = unit.q, r = unit.r },
                { q = bq, r = br }
            )
            if dist < bestDist then
                bestDist = dist
                bestAttackerId = info.attackers[1]
            end
        end
    end

    if bestAttackerId then
        unit.priorityTarget = bestAttackerId
    end
end

--- 更新所有单位
---@param units table[] 单位列表
---@param tileStates table 格子状态
---@param buildings table 建筑实例
---@param dt number 时间步
---@param targetHexes table { [owner] = {q,r} } 各玩家目标（敌方核心位置）
---@param onTileCapture function(owner, hexKey) 格子占领回调
---@param onSpiritGain function|nil 晶核获取回调
---@param summonCallback function|nil 召唤单位回调
function UnitManager.Update(units, tileStates, buildings, dt, targetHexes, onTileCapture, onSpiritGain, summonCallback)
    battleTime_ = battleTime_ + dt

    -- 每帧构建一次单位空间索引（供 FindNearestEnemy / FindEnemyInRange 使用）
    local unitLookup = BuildUnitLookup(units)

    -- 更新"被攻击的建筑"追踪信息
    UnitManager.UpdateBuildingsUnderAttack(units, buildings)

    -- 技能引擎帧更新（DOT/buff/定时器/光环/阈值）
    SkillEngine.Update(units, dt, battleTime_, summonCallback)
    SkillEngine.UpdateCooldowns(dt)

    -- 更新 CC 计时器（减少持续时间）
    for _, unit in ipairs(units) do
        if unit.state ~= "dead" then
            UnitManager.UpdateCC(unit, dt)
        end
    end

    -- 主循环：状态机驱动
    for i = #units, 1, -1 do
        local unit = units[i]

        if unit._summonDuration and unit._summonDuration <= 0 and unit.state ~= "dead" then
            unit.hp = 0
            unit.state = "dead"
        end

        -- 集中兜底：任何来源导致 hp<=0 但未标记死亡的，统一标记
        if unit.hp <= 0 and unit.state ~= "dead" then
            unit.state = "dead"
        end

        if unit.state == "dead" then
            -- 死亡触发
            local shouldRevive = SkillEngine.OnDeath(unit, units, summonCallback)
            if shouldRevive then
                -- 复活：恢复部分生命
                unit.state = "moving"
                unit.hp = unit.maxHp * 0.3
                unit.attackTimer = 0
                unit.moveTimer = 0
                -- [DEBUG] 复活日志
                print(string.format("[REVIVE] %s(id=%d,o=%d) revived! hp=%.0f/%.0f",
                    unit.cardName or "?", unit.id, unit.owner, unit.hp, unit.maxHp))
            else
                -- [DEBUG] 死亡日志（采样）
                if not UnitManager._deathLogCount then UnitManager._deathLogCount = 0 end
                UnitManager._deathLogCount = UnitManager._deathLogCount + 1
                if UnitManager._deathLogCount % 5 == 1 then
                    print(string.format("[DEATH] %s(id=%d,o=%d) died. total deaths=%d",
                        unit.cardName or "?", unit.id, unit.owner, UnitManager._deathLogCount))
                end
                SkillEngine.RemoveUnit(unit.id)
                table.remove(units, i)
            end
        elseif unit._convertDuration and unit._convertDuration <= 0 and unit._originalOwner then
            unit.owner = unit._originalOwner
            unit.team = unit._originalTeam or unit.owner
            unit.slot = unit._originalSlot or unit.slot
            unit._originalOwner = nil
            unit._originalTeam = nil
            unit._originalSlot = nil
        elseif UnitManager.IsCC(unit) then
            -- 被控制中：不行动
        elseif unit.state == "fighting" then
            UnitManager.UpdateFighting(unit, units, buildings, dt, onSpiritGain, summonCallback, unitLookup)
        elseif unit.state == "moving" then
            UnitManager.UpdateMoving(unit, units, tileStates, buildings, dt, targetHexes, onTileCapture, unitLookup)
        end
    end
end

--- 更新 CC 倒计时
---@param unit table
---@param dt number
function UnitManager.UpdateCC(unit, dt)
    if unit._stunDuration and unit._stunDuration > 0 then
        unit._stunDuration = unit._stunDuration - dt
    end
    if unit._silenceDuration and unit._silenceDuration > 0 then
        unit._silenceDuration = unit._silenceDuration - dt
    end
    if unit._fearDuration and unit._fearDuration > 0 then
        unit._fearDuration = unit._fearDuration - dt
    end
    if unit._charmDuration and unit._charmDuration > 0 then
        unit._charmDuration = unit._charmDuration - dt
    end
    if unit._suspendDuration and unit._suspendDuration > 0 then
        unit._suspendDuration = unit._suspendDuration - dt
    end
    if unit._convertDuration and unit._convertDuration > 0 then
        unit._convertDuration = unit._convertDuration - dt
    end
    if unit._summonDuration and unit._summonDuration > 0 then
        unit._summonDuration = unit._summonDuration - dt
    end
end

--- 检查单位是否被 CC（无法行动）
---@param unit table
---@return boolean
function UnitManager.IsCC(unit)
    return (unit._stunDuration or 0) > 0
        or (unit._suspendDuration or 0) > 0
        or (unit._fearDuration or 0) > 0
        or (unit._charmDuration or 0) > 0
end

--- 追踪哪些己方建筑正在被攻击
function UnitManager.UpdateBuildingsUnderAttack(units, buildings)
    buildingsUnderAttack_ = {}

    for hexKey, bInst in pairs(buildings) do
        local attackers = {}
        for _, unit in ipairs(units) do
            if unit.state == "fighting"
                and unit.owner ~= bInst.owner
                and unit.targetBuildingKey == hexKey
                and unit.hp > 0 then
                attackers[#attackers + 1] = unit.id
            end
        end

        if #attackers > 0 then
            buildingsUnderAttack_[hexKey] = {
                owner = bInst.owner,
                attackers = attackers,
            }
        end
    end
end

--- 判断单位是否"刚产出"（离出生点不超过3格）
---@param unit table
---@return boolean
function UnitManager.IsJustSpawned(unit)
    local distFromSpawn = HexGrid.Distance(
        { q = unit.q, r = unit.r },
        { q = unit.spawnQ, r = unit.spawnR }
    )
    return distFromSpawn <= 3
end

--- 查找正在攻击我方建筑的最近敌方单位（用于回防决策）
--- 返回攻击者单位和被攻击建筑的距离
---@param unit table
---@param units table[]
---@return table|nil attacker 攻击我方建筑的敌方单位
---@return number distToMe 该攻击者与我的距离
function UnitManager.FindBuildingAttacker(unit, units)
    local bestAttacker = nil
    local bestDist = math.huge

    for _, info in pairs(buildingsUnderAttack_) do
        if info.owner == unit.owner then
            -- 找到攻击我方建筑的敌方单位
            for _, attackerId in ipairs(info.attackers) do
                local attacker = UnitManager.FindUnitById(units, attackerId)
                if attacker and attacker.hp > 0 and attacker.state ~= "dead" then
                    local dist = HexGrid.Distance(
                        { q = unit.q, r = unit.r },
                        { q = attacker.q, r = attacker.r }
                    )
                    if dist < bestDist then
                        bestDist = dist
                        bestAttacker = attacker
                    end
                end
            end
        end
    end

    return bestAttacker, bestDist
end

--- 移动逻辑：完整行为决策树
--- 优先级1: 我方建筑被攻击 → 在范围内或刚产出 → 回防
--- 优先级2: 行军途中6格内有敌方 → 停下攻击
--- 优先级3: 向敌方核心进军（核心摧毁则全歼剩余）
function UnitManager.UpdateMoving(unit, units, tileStates, buildings, dt, targetHexes, onTileCapture, unitLookup)
    -- 移速倍率（技能加成）
    local spdMult = SkillEngine.GetSpeedMultiplier(unit)
    local moveInterval = unit.moveSpeed * spdMult

    unit.moveTimer = unit.moveTimer + dt
    if unit.moveTimer < moveInterval then
        return
    end
    unit.moveTimer = unit.moveTimer - moveInterval

    local detectRange = UnitManager.CONFIG.detectionRange  -- 6格
    local attackRange = SkillEngine.GetEffectiveRange(unit)

    -- =========================================================
    -- 优先级1: 我方建筑正在被攻击 → 判断是否回防
    -- =========================================================
    local attacker, distToAttacker = UnitManager.FindBuildingAttacker(unit, units)
    if attacker then
        local shouldDefend = false

        if distToAttacker <= detectRange then
            -- 在6格范围内 → 立即回防
            shouldDefend = true
        elseif UnitManager.IsJustSpawned(unit) then
            -- 刚产出（还没走远） → 立即回防
            shouldDefend = true
        end
        -- 否则：已超出6格且不是刚产出 → 不回援，继续前进

        if shouldDefend then
            if distToAttacker <= attackRange then
                unit.state = "fighting"
                unit.targetUnit = attacker
                return
            else
                UnitManager.MoveToward(unit, { q = attacker.q, r = attacker.r }, tileStates, onTileCapture)
                return
            end
        end
    end

    -- =========================================================
    -- 优先级2: 行军途中6格内有敌方单位/建筑 → 停下来攻击
    -- =========================================================
    -- 2a: 敌方单位
    local nearestEnemy, enemyDist = UnitManager.FindNearestEnemy(unit, units, detectRange, unitLookup)
    if nearestEnemy then
        if enemyDist <= attackRange then
            unit.state = "fighting"
            unit.targetUnit = nearestEnemy
            return
        else
            UnitManager.MoveToward(unit, { q = nearestEnemy.q, r = nearestEnemy.r }, tileStates, onTileCapture)
            return
        end
    end

    -- 2b: 敌方建筑
    local nearestBuildingKey, buildingDist = UnitManager.FindNearestEnemyBuilding(unit, buildings, detectRange)
    if nearestBuildingKey then
        local bq, br = HexGrid.FromKey(nearestBuildingKey)
        if buildingDist <= attackRange then
            unit.state = "fighting"
            unit.targetBuildingKey = nearestBuildingKey
            unit.targetUnit = nil
            return
        else
            UnitManager.MoveToward(unit, { q = bq, r = br }, tileStates, onTileCapture)
            return
        end
    end

    -- =========================================================
    -- 优先级3: 向最近的敌方建筑进军（动态寻敌+优先级）
    -- =========================================================
    local anyBuildingKey, _ = UnitManager.FindNearestEnemyBuilding(unit, buildings, 999)
    if anyBuildingKey then
        local bq, br = HexGrid.FromKey(anyBuildingKey)
        UnitManager.MoveToward(unit, { q = bq, r = br }, tileStates, onTileCapture)
    else
        -- 无敌方建筑 → 找敌方单位
        local anyEnemy, _ = UnitManager.FindNearestEnemy(unit, units, 999, unitLookup)
        if anyEnemy then
            UnitManager.MoveToward(unit, { q = anyEnemy.q, r = anyEnemy.r }, tileStates, onTileCapture)
        end
        -- 全歼完毕，无目标
    end
end

--- 向目标方向移动一格（贪心 + BFS 后备寻路），遇城墙则停下攻击
---@param unit table
---@param target table {q, r}
---@param tileStates table
---@param onTileCapture function|nil
function UnitManager.MoveToward(unit, target, tileStates, onTileCapture)
    local start = { q = unit.q, r = unit.r }
    local neighbors = HexGrid.Neighbors(start)
    local bestDist = HexGrid.Distance(start, target)
    local candidates = {}

    -- 第一步：贪心尝试（选距离更近的邻居）
    for _, nh in ipairs(neighbors) do
        local key = HexGrid.Key(nh.q, nh.r)
        if tileStates[key] then
            local dist = HexGrid.Distance(nh, target)
            if dist < bestDist then
                if #candidates == 0 or dist < candidates[1].dist then
                    candidates = { { hex = nh, dist = dist } }
                elseif dist == candidates[1].dist then
                    candidates[#candidates + 1] = { hex = nh, dist = dist }
                end
            end
        end
    end

    local bestHex = nil
    if #candidates > 0 then
        local idx = (unit.id % #candidates) + 1
        bestHex = candidates[idx].hex
    end

    -- 第二步：贪心失败 → BFS 寻路绕行
    if not bestHex then
        bestHex = HexGrid.BFSNextStep(start, target, tileStates, 40)
    end

    if not bestHex then
        -- BFS 也找不到路 → 真正不可达
        unit.stuckCount = (unit.stuckCount or 0) + 1
        if unit.stuckCount >= 8 then
            unit.hp = 0
            unit.state = "dead"
        end
        return
    end

    -- 成功移动，重置卡住计数
    unit.stuckCount = 0

    -- 检查城墙阻挡
    local wall = WallManager.GetBlockingWall(unit, bestHex)
    if wall then
        unit.state = "fighting"
        unit.targetWall = wall
        unit.targetUnit = nil
        unit.targetBuildingKey = nil
        return
    end

    unit.q = bestHex.q
    unit.r = bestHex.r

    -- 途经格子领地染色
    local key = HexGrid.Key(unit.q, unit.r)
    local tile = tileStates[key]
    if tile then
        if tile.team ~= unit.owner then
            -- 敌方/中立格子：有敌方建筑的格子不染色（必须摧毁）
            local hasEnemyBuilding = tile.building
                and tile.building ~= GameConfig.BUILDING.NONE
                and tile.team ~= unit.owner
            if not hasEnemyBuilding then
                tile.team = unit.owner
                tile.ruins = false
                if onTileCapture then
                    onTileCapture(unit.owner, key, unit.slot)
                end
            end
        end
    end
end

--- 战斗逻辑：攻击目标（单位、建筑或城墙）
function UnitManager.UpdateFighting(unit, units, buildings, dt, onSpiritGain, summonCallback, unitLookup)
    -- 攻速倍率（技能加成）
    local atkSpdMult = SkillEngine.GetAttackSpeedMultiplier(unit)
    -- 翼族羁绊：低血量攻速加成
    local lowHpBonus = SynergyManager.GetLowHpAttackSpeedBonus(unit.slot or unit.owner)
    if lowHpBonus and unit.hp < unit.maxHp * lowHpBonus.hpThreshold then
        atkSpdMult = atkSpdMult * (1 - lowHpBonus.percent)
    end
    local atkInterval = unit.attackInterval * atkSpdMult

    unit.attackTimer = unit.attackTimer + dt
    if unit.attackTimer < atkInterval then
        return
    end
    unit.attackTimer = unit.attackTimer - atkInterval

    -- ======= 主动技能自动施放（传奇卡专属）=======
    if unit.quality == "gold" and unit.unlockedSkills then
        for _, skill in ipairs(unit.unlockedSkills) do
            if skill.trigger == "active" then
                local used = SkillEngine.UseActiveSkill(unit, skill.name, units, battleTime_)
                if used then return end  -- 本回合释放技能，不再普攻
                break  -- 每个金卡只有一个主动技能
            end
        end
    end

    local attackRange = SkillEngine.GetEffectiveRange(unit)

    -- ======= 攻击城墙 =======
    if unit.targetWall then
        if unit.targetWall.hp > 0 then
            local wallDmg = SkillEngine.GetEffectiveAtk(unit)
            WallManager.DamageWall(unit.targetWall, wallDmg)
            local wallHex = unit.targetWall.hexInside or { q = unit.q, r = unit.r }
            attackEvents_[#attackEvents_ + 1] = {
                q = unit.q, r = unit.r,
                targetQ = wallHex.q, targetR = wallHex.r,
                damage = wallDmg,
            }
            if unit.targetWall.hp <= 0 then
                unit.targetWall = nil
                unit.state = "moving"
                unit.attackTimer = 0
            end
            return
        else
            unit.targetWall = nil
            unit.state = "moving"
            unit.attackTimer = 0
            return
        end
    end

    -- ======= 攻击目标单位 =======
    if unit.targetUnit then
        local target = unit.targetUnit
        if target.hp > 0 and target.state ~= "dead" then
            local dist = HexGrid.Distance(
                { q = unit.q, r = unit.r },
                { q = target.q, r = target.r }
            )
            if dist <= attackRange then
                UnitManager.PerformAttack(unit, target, units, onSpiritGain, summonCallback)
                return
            else
                -- 目标超出射程，重新移动靠近
                unit.targetUnit = nil
                unit.state = "moving"
                unit.attackTimer = 0
                return
            end
        else
            unit.targetUnit = nil
        end
    end

    -- ======= 攻击建筑目标 =======
    if unit.targetBuildingKey then
        local bInst = buildings[unit.targetBuildingKey]
        if bInst and bInst.owner ~= unit.owner then
            local bq, br = HexGrid.FromKey(unit.targetBuildingKey)
            local dist = HexGrid.Distance(
                { q = unit.q, r = unit.r },
                { q = bq, r = br }
            )
            if dist <= attackRange then
                local atkVal = SkillEngine.GetEffectiveAtk(unit)
                bInst.hp = bInst.hp - atkVal
                bInst.lastAttackerTeam = unit.owner
                bInst.lastAttackerSlot = unit.slot
                attackEvents_[#attackEvents_ + 1] = {
                    q = unit.q, r = unit.r,
                    targetQ = bq, targetR = br,
                    damage = atkVal,
                }
                if bInst.hp <= 0 then
                    EventBus.Emit("BuildingDestroyed", unit.targetBuildingKey, bInst)
                    -- 不直接删除 buildings 条目，交给 CheckVictory 统一处理残骸/铸材/特效
                    unit.targetBuildingKey = nil
                    unit.state = "moving"
                    unit.attackTimer = 0
                end
                return
            else
                unit.targetBuildingKey = nil
                unit.state = "moving"
                unit.attackTimer = 0
                return
            end
        else
            unit.targetBuildingKey = nil
        end
    end

    -- ======= 无指定目标：扫描射程内敌人 =======
    local nearEnemy = UnitManager.FindEnemyInRange(unit, units, attackRange, unitLookup)
    if nearEnemy then
        unit.targetUnit = nearEnemy
        UnitManager.PerformAttack(unit, nearEnemy, units, onSpiritGain, summonCallback)
        return
    end

    -- 检查射程内建筑
    local bKey = UnitManager.FindNearestEnemyBuilding(unit, buildings, attackRange)
    if bKey then
        local bInst = buildings[bKey]
        if bInst and bInst.owner ~= unit.owner then
            unit.targetBuildingKey = bKey
            local atkVal = SkillEngine.GetEffectiveAtk(unit)
            bInst.hp = bInst.hp - atkVal
            bInst.lastAttackerTeam = unit.owner
            bInst.lastAttackerSlot = unit.slot
            local bkq, bkr = HexGrid.FromKey(bKey)
            attackEvents_[#attackEvents_ + 1] = {
                q = unit.q, r = unit.r,
                targetQ = bkq, targetR = bkr,
                damage = atkVal,
            }
            if bInst.hp <= 0 then
                EventBus.Emit("BuildingDestroyed", bKey, bInst)
                -- 不直接删除 buildings 条目，交给 CheckVictory 统一处理残骸/铸材/特效
                unit.targetBuildingKey = nil
                unit.state = "moving"
                unit.attackTimer = 0
            end
            return
        end
    end

    -- 完全没有目标，恢复行军
    unit.state = "moving"
    unit.attackTimer = 0
end

--- 执行一次攻击（含伤害计算+技能触发）
---@param attacker table
---@param target table
---@param units table[]
---@param onSpiritGain function|nil
---@param summonCallback function|nil
function UnitManager.PerformAttack(attacker, target, units, onSpiritGain, summonCallback)
    -- 1. 基础攻击力
    local baseAtk = SkillEngine.GetEffectiveAtk(attacker)

    -- 2. 攻击时技能触发（额外伤害、DOT、控制等）
    local extraDamage = SkillEngine.OnAttack(attacker, target, units, battleTime_)

    -- 3. 伤害计算（无防御力，直接增伤/减伤）
    local rawDamage = SkillEngine.CalculateDamage(attacker, target, baseAtk + extraDamage, units)

    -- 3.5 联盟羁绊：友军减伤（附近有友军时减少受到的伤害）
    local allyReduce = SynergyManager.GetNearbyAllyDamageReduce(target.slot or target.owner)
    if allyReduce then
        local hasNearbyAlly = false
        for _, u in ipairs(units) do
            if u.id ~= target.id and u.owner == target.owner and u.hp > 0 then
                local dist = HexGrid.Distance({ q = target.q, r = target.r }, { q = u.q, r = u.r })
                if dist <= 2 then
                    hasNearbyAlly = true
                    break
                end
            end
        end
        if hasNearbyAlly then
            rawDamage = rawDamage * (1 - allyReduce.percent)
        end
    end

    -- 4. 被攻击方技能触发（护盾吸收、闪避、反伤、免死）
    local actualDamage = SkillEngine.OnHit(target, attacker, rawDamage, units)

    -- 5. 扣血
    target.hp = target.hp - actualDamage

    -- [DEBUG] 战斗伤害日志（采样：每20次输出1次）
    UnitManager._atkLogCount = (UnitManager._atkLogCount or 0) + 1
    if UnitManager._atkLogCount % 20 == 1 then
        print(string.format("[COMBAT] %s(id=%d,o=%d,atk=%.1f) -> %s(id=%d,o=%d,hp=%.0f/%.0f) | base=%.1f raw=%.1f actual=%.1f remain=%.0f",
            attacker.cardName or "?", attacker.id, attacker.owner, baseAtk,
            target.cardName or "?", target.id, target.owner, target.hp, target.maxHp,
            baseAtk + extraDamage, rawDamage, actualDamage, target.hp))
    end

    -- 5.5 战绩统计
    attacker.damageDealt = (attacker.damageDealt or 0) + actualDamage

    -- 6. 吸血处理
    if actualDamage > 0 then
        SkillEngine.ProcessLifesteal(attacker, actualDamage)
    end

    -- 7. 攻击事件（供渲染层）
    attackEvents_[#attackEvents_ + 1] = {
        q = attacker.q, r = attacker.r,
        targetQ = target.q, targetR = target.r,
        damage = actualDamage,
    }

    -- 8. 判断击杀
    if target.hp <= 0 then
        target.state = "dead"
        attacker.kills = (attacker.kills or 0) + 1

        -- 击杀触发（晶核获取、击杀回血、爆炸等）
        SkillEngine.OnKill(attacker, target, units, onSpiritGain)

        -- 清除自身目标，恢复行军
        attacker.targetUnit = nil
        attacker.state = "moving"
        attacker.attackTimer = 0
    end
end

-- ========== 查找函数 ==========

--- 查找感知范围内最近的敌方单位
---@param unit table
---@param units table[]
---@param range integer
---@param unitLookup table|nil
---@return table|nil nearestEnemy
---@return integer distance
function UnitManager.FindNearestEnemy(unit, units, range, unitLookup)
    if range <= 6 and unitLookup then
        -- 使用空间索引加速小范围查询
        local candidates = GetUnitsInRangeByOwner({ q = unit.q, r = unit.r }, units, range, unit.owner, unitLookup)
        local bestDist = range + 1
        local bestTarget = nil
        for _, entry in ipairs(candidates) do
            if entry.dist < bestDist then
                bestDist = entry.dist
                bestTarget = entry.unit
            end
        end
        return bestTarget, bestDist
    end

    -- 范围 > 6 或未提供 lookup 时，回退到全表扫描
    local bestDist = range + 1
    local bestTarget = nil
    for _, other in ipairs(units) do
        if other.owner ~= unit.owner and other.hp > 0 and other.state ~= "dead" then
            local dist = HexGrid.Distance({ q = unit.q, r = unit.r }, { q = other.q, r = other.r })
            if dist <= range and dist < bestDist then
                bestDist = dist
                bestTarget = other
            end
        end
    end
    return bestTarget, bestDist
end

--- 查找范围内最近的敌方建筑（同距离按优先级排序）
---@param unit table
---@param buildings table
---@param range integer
---@return string|nil hexKey
---@return integer distance
function UnitManager.FindNearestEnemyBuilding(unit, buildings, range)
    local bestDist = range + 1
    local bestKey = nil
    local bestPriority = math.huge
    for hexKey, bInst in pairs(buildings) do
        if bInst.owner ~= unit.owner and bInst.hp > 0 then
            local bq, br = HexGrid.FromKey(hexKey)
            local dist = HexGrid.Distance({ q = unit.q, r = unit.r }, { q = bq, r = br })
            if dist <= range then
                local priority = GameConfig.ATTACK_PRIORITY[bInst.building] or 99
                if dist < bestDist or (dist == bestDist and priority < bestPriority) then
                    bestDist = dist
                    bestKey = hexKey
                    bestPriority = priority
                end
            end
        end
    end
    return bestKey, bestDist
end

--- 查找射程内的敌方单位
---@param unit table
---@param units table[]
---@param range integer
---@param unitLookup table|nil
---@return table|nil
function UnitManager.FindEnemyInRange(unit, units, range, unitLookup)
    if range <= 6 and unitLookup then
        -- 使用空间索引加速小范围查询
        local candidates = GetUnitsInRangeByOwner({ q = unit.q, r = unit.r }, units, range, unit.owner, unitLookup)
        local bestDist = range + 1
        local bestTarget = nil
        for _, entry in ipairs(candidates) do
            if entry.dist < bestDist then
                bestDist = entry.dist
                bestTarget = entry.unit
            end
        end
        return bestTarget
    end

    -- 范围 > 6 或未提供 lookup 时，回退到全表扫描
    local bestDist = range + 1
    local bestTarget = nil
    for _, other in ipairs(units) do
        if other.owner ~= unit.owner and other.hp > 0 and other.state ~= "dead" then
            local dist = HexGrid.Distance({ q = unit.q, r = unit.r }, { q = other.q, r = other.r })
            if dist <= range and dist < bestDist then
                bestDist = dist
                bestTarget = other
            end
        end
    end
    return bestTarget
end

--- 找到可能有额外参数的 FindBuildingAttacker 函数，使其与新的 UpdateMoving 签名兼容
--- 通过ID查找单位
---@param units table[]
---@param unitId integer
---@return table|nil
function UnitManager.FindUnitById(units, unitId)
    for _, u in ipairs(units) do
        if u.id == unitId then
            return u
        end
    end
    return nil
end

--- 获取某玩家的活跃单位数量（按人口计）
---@param units table[]
---@param owner integer
---@return integer totalPop
function UnitManager.CountPopulation(units, owner)
    local total = 0
    for _, unit in ipairs(units) do
        if unit.owner == owner and unit.state ~= "dead" then
            total = total + (unit.pop or 1)
        end
    end
    return total
end

--- 获取某 slot 的活跃人口
---@param units table[]
---@param slot integer
---@return integer totalPop
function UnitManager.CountPopulationBySlot(units, slot)
    local total = 0
    for _, unit in ipairs(units) do
        if unit.slot == slot and unit.state ~= "dead" then
            total = total + (unit.pop or 1)
        end
    end
    return total
end

--- 获取某玩家的活跃单位数量（按个数）
---@param units table[]
---@param owner integer
---@return integer
function UnitManager.CountUnits(units, owner)
    local count = 0
    for _, unit in ipairs(units) do
        if unit.owner == owner and unit.state ~= "dead" then
            count = count + 1
        end
    end
    return count
end

--- 获取某 slot 的活跃单位数量（按个数）
---@param units table[]
---@param slot integer
---@return integer
function UnitManager.CountUnitsBySlot(units, slot)
    local count = 0
    for _, unit in ipairs(units) do
        if unit.slot == slot and unit.state ~= "dead" then
            count = count + 1
        end
    end
    return count
end

--- 获取某玩家的 MVP 单位（伤害最高者）
---@param units table[]
---@param owner integer
---@return table|nil mvpInfo { cardName, icon, kills, damageDealt, quality, race }
function UnitManager.GetMVP(units, owner)
    local bestUnit = nil
    local bestDamage = 0
    -- 遍历所有单位（含已死亡的），取造成伤害最高者
    for _, unit in ipairs(units) do
        if unit.owner == owner then
            local dmg = unit.damageDealt or 0
            if dmg > bestDamage then
                bestDamage = dmg
                bestUnit = unit
            end
        end
    end
    if not bestUnit then return nil end
    return {
        cardName = bestUnit.cardName,
        icon = bestUnit.icon or "⚔️",
        kills = bestUnit.kills or 0,
        damageDealt = bestUnit.damageDealt or 0,
        quality = bestUnit.quality or "green",
        race = bestUnit.race or "未知",
    }
end

return UnitManager


-- ══════════════════════════════════════════════
