-- ══════════════════════════════════════════════
-- ============================================================================
-- BuildingManager.lua - 建筑管理器
-- 处理：矿脉产晶核、兵营产兵、炮台攻击
-- 数值基于 GDD 2.6.1 / 3.10 调整后
-- ============================================================================

local GameConfig = require("Config.GameConfig")
local UnitConfig = require("Config.UnitConfig")
local HexGrid = require("Battle.HexGrid")
local SynergyManager = require("Battle.SynergyManager")
local TerritoryManager = require("Battle.TerritoryManager")
local EventBus = require("Infrastructure.EventBus")

local BuildingManager = {}

-- 广告效果：建筑加速
local buildSpeedActive_ = false

-- 订阅广告效果
EventBus.On("AdEffectActivated", function(effectType, effectData)
    if effectType == "doubleSpeed" then
        buildSpeedActive_ = effectData.active
    end
end)

-- 建筑配置（基于 GDD 2.6.1 + 3.10 模拟调整后数值）
BuildingManager.CONFIG = {
    [GameConfig.BUILDING.MAIN_BASE] = {
        spiritRate = 10,       -- 核心每5秒产10晶核（相当于每秒2）
        spiritInterval = 5.0,  -- 5秒产出间隔
        spawnRate = 0,
        attackRange = 6,      -- 核心自动攻击6格范围内敌军
        attackDamage = 60,    -- 核心攻击伤害（秒绿卡）
        attackInterval = 1.5, -- 攻击间隔1.5秒
        hp = 2500,            -- GDD: 核心HP 2500
    },
    [GameConfig.BUILDING.SPIRIT_MINE] = {
        spiritRate = 10,       -- 每5秒产10晶核（相当于每秒2）
        spiritInterval = 5.0,  -- 5秒产出间隔
        spawnRate = 0,
        attackRange = 0,
        attackDamage = 0,
        hp = 400,             -- GDD: 矿脉HP 400
    },
    [GameConfig.BUILDING.BARRACKS] = {
        spiritRate = 0,
        spawnRate = 3.5,      -- 默认出兵间隔（绑定卡牌时使用卡牌 prodTime）
        attackRange = 0,
        attackDamage = 0,
        hp = 600,             -- GDD: 兵营HP 600
    },
    [GameConfig.BUILDING.TOWER] = {
        spiritRate = 0,
        spawnRate = 0,
        attackRange = 5,      -- 射程5格
        attackDamage = 45,    -- 伤害45（秒绿卡）
        attackInterval = 1.5, -- 攻击间隔1.5秒
        hp = 500,             -- 炮台HP 500
    },
    [GameConfig.BUILDING.ELITE_TOWER] = {
        spiritRate = 0,
        spawnRate = 0,
        attackRange = 5,      -- 射程5格
        attackDamage = 90,    -- 伤害90（秒蓝卡）
        attackInterval = 1.2, -- 攻击间隔1.2秒
        hp = 800,             -- 重炮HP 800
    },
}

--- 初始化建筑实例数据
---@param tile table 格子数据
---@return table|nil 建筑运行时数据
function BuildingManager.CreateInstance(tile)
    local cfg = BuildingManager.CONFIG[tile.building]
    if not cfg then return nil end

    -- 基础值从 CONFIG 取
    local hp = cfg.hp
    local spiritOutput = cfg.spiritRate
    local spiritInterval = cfg.spiritInterval or 5.0
    local atk = cfg.attackDamage or 0
    local attackInterval = cfg.attackInterval or 1.5
    local attackRange = cfg.attackRange or 0
    local spawnRate = cfg.spawnRate or 0

    -- 如果有绑定卡牌，用卡牌数据覆盖 CONFIG 静态值
    local boundCard = tile.boundCard
    if boundCard and boundCard.cardName then
        local card = UnitConfig.CARDS[boundCard.cardName]
        if card then
            local level = boundCard.cardLevel or 0
            local up = card.upgrade or {}
            ---@diagnostic disable: assign-type-mismatch
            -- HP：卡牌基础 + 等级加成
            local buildingHp = card.buildingHp or card.hp
            if buildingHp then hp = buildingHp + (up.buildingHp or up.hp or 0) * level end
            -- 矿脉产出：卡牌基础 + 等级加成
            if card.spiritOutput then spiritOutput = card.spiritOutput + (up.spiritOutput or 0) * level end
            -- 矿脉CD：卡牌基础 - 等级减少（每级减0.05秒，20级满级减1秒）
            if card.spiritInterval then
                spiritInterval = card.spiritInterval - (up.spiritIntervalReduction or 0) * level
                spiritInterval = math.max(1.0, spiritInterval)
            end
            -- 兵营产兵间隔：使用卡牌 prodTime（不同卡牌出兵速度不同）
            if card.prodTime then spawnRate = card.prodTime end
            -- 炮台攻击：卡牌基础 + 等级加成
            if card.atk then atk = card.atk + (up.atk or 0) * level end
            -- 炮台攻速/射程
            if card.attackInterval then attackInterval = card.attackInterval end
            if card.range then attackRange = card.range end
            ---@diagnostic enable: assign-type-mismatch
        end
    end

    -- 应用建筑血量羁绊加成
    local synergyOwner = tile.slot or tile.team or 0
    local hpBonus = SynergyManager.GetBuildingHpBonus(synergyOwner)
    hp = math.floor(hp * (1 + hpBonus))

    -- 获取领主加成（仅对玩家1我方建筑生效）
    local lordAtkBonus, lordHpBonus, lordSpiritBonus = 0, 0, 0
    if tile.team == 1 then
        lordAtkBonus, lordHpBonus, lordSpiritBonus = TerritoryManager.GetLordBonus()
        hp = hp + lordHpBonus
    end

    return {
        building = tile.building,
        owner = tile.team,
        team = tile.team,
        slot = tile.slot or tile.team,
        hp = hp,
        maxHp = hp,
        spawnTimer = 0,
        attackTimer = 0,
        spiritTimer = 0,
        barracksPrice = tile.barracksPrice or 0,
        fixedQuality = tile.fixedQuality or nil,
        boundCard = boundCard,
        -- 卡牌派生的属性（优先于 CONFIG）
        spiritOutput = spiritOutput,
        spiritInterval = spiritInterval,
        atk = atk,
        attackInterval = attackInterval,
        attackRange = attackRange,
        spawnRate = spawnRate,
        lordAtkBonus = lordAtkBonus,
        lordSpiritBonus = lordSpiritBonus,
    }
end

--- 每帧更新所有建筑
---@param buildings table { [hexKey] = buildingInstance }
---@param tileStates table 格子状态表
---@param dt number 时间步
---@param onSpiritProduced function(owner, amount) 晶核产出回调
---@param onUnitSpawn function(owner, hexKey) 单位生成回调
---@param units table[] 当前所有单位（供炮台目标查找）
function BuildingManager.Update(buildings, tileStates, dt, onSpiritProduced, onUnitSpawn, units)
    -- 广告双倍加速：加速时将 dt 翻倍
    local effectiveDt = buildSpeedActive_ and (dt * 2) or dt

    for hexKey, inst in pairs(buildings) do
        local cfg = BuildingManager.CONFIG[inst.building]
        if not cfg then goto continue end

        -- 建筑已被摧毁则跳过
        if inst.hp <= 0 then goto continue end

        -- 矿脉/核心产晶核
        if inst.spiritOutput and inst.spiritOutput > 0 then
            inst.spiritTimer = inst.spiritTimer + effectiveDt
            local interval = inst.spiritInterval or 5.0
            if inst.spiritTimer >= interval then
                inst.spiritTimer = inst.spiritTimer - interval
                local amount = inst.spiritOutput
                -- 应用领主晶核加成
                if inst.lordSpiritBonus and inst.lordSpiritBonus > 0 then
                    amount = amount + inst.lordSpiritBonus * interval
                end
                -- 建筑晶核额外产出（联盟6级羁绊）
                local spiritGen = SynergyManager.GetBuildingSpiritGen(inst.slot or inst.owner)
                if spiritGen and inst.building ~= GameConfig.BUILDING.MAIN_BASE then
                    amount = amount + spiritGen.amount
                end
                if onSpiritProduced then
                    onSpiritProduced(inst.owner, amount, inst.slot)
                end
            end
        end

        -- 兵营产兵
        if inst.spawnRate and inst.spawnRate > 0 then
            -- 产兵速度羁绊加成（降低间隔）
            local produceBonus = SynergyManager.GetProduceSpeedBonus(inst.slot or inst.owner)
            local effectiveRate = inst.spawnRate * (1 - produceBonus)
            effectiveRate = math.max(1.0, effectiveRate)

            inst.spawnTimer = inst.spawnTimer + effectiveDt
            if inst.spawnTimer >= effectiveRate then
                inst.spawnTimer = inst.spawnTimer - effectiveRate
                if onUnitSpawn then
                    onUnitSpawn(inst.owner, hexKey, inst.barracksPrice or 50, inst.fixedQuality)
                    -- 额外产兵羁绊（机械6级）
                    local extraCount = SynergyManager.GetExtraProduceCount(inst.slot or inst.owner)
                    for _ = 1, extraCount do
                        onUnitSpawn(inst.owner, hexKey, inst.barracksPrice or 50, inst.fixedQuality)
                    end
                end
            end
        end

        -- 建筑自动攻击（炮台 + 核心）
        if inst.attackRange and inst.attackRange > 0 then
            inst.attackTimer = inst.attackTimer + effectiveDt
            local atkInterval = inst.attackInterval or 1.2
            if inst.attackTimer >= atkInterval then
                inst.attackTimer = inst.attackTimer - atkInterval
                BuildingManager.BuildingAttack(inst, hexKey, units)
            end
        end

        ::continue::
    end
end

--- 建筑自动攻击逻辑（炮台 + 核心通用）
function BuildingManager.BuildingAttack(inst, hexKey, units)
    local tq, tr = HexGrid.FromKey(hexKey)
    local towerHex = { q = tq, r = tr }
    local range = inst.attackRange or 3
    local bestDist = range + 1
    local bestUnit = nil

    for _, unit in ipairs(units) do
        if unit.owner ~= inst.owner and unit.hp > 0 then
            local dist = HexGrid.Distance(towerHex, { q = unit.q, r = unit.r })
            if dist <= range and dist < bestDist then
                bestDist = dist
                bestUnit = unit
            end
        end
    end

    if bestUnit then
        -- 应用建筑伤害羁绊加成
        local dmgBonus = SynergyManager.GetBuildingDamageBonus(inst.slot or inst.owner)
        local damage = math.floor((inst.atk or 0) * (1 + dmgBonus))
        -- 应用领主攻击加成
        if inst.lordAtkBonus and inst.lordAtkBonus > 0 then
            damage = damage + inst.lordAtkBonus
        end
        bestUnit.hp = bestUnit.hp - damage
    end
end

return BuildingManager


-- ══════════════════════════════════════════════
