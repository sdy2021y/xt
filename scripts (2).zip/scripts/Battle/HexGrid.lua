-- ══════════════════════════════════════════════
-- ============================================================================
-- HexGrid.lua - 六边形格子数学库
-- 坐标系：轴向坐标（Axial Coordinates），平顶六边形（Flat-top）
-- 参考：https://www.redblobgames.com/grids/hexagons/
-- ============================================================================

local HexGrid = {}

-- 平顶六边形常量
local SQRT3 = math.sqrt(3)

-- 透视Y压缩因子（模拟约20°倾斜俯视角，参考 Top Heroes 风格）
HexGrid.PERSPECTIVE_Y = 0.78

-- 内部范围缓存，用于避免频繁创建中间表
local _rangeCache = {}

-- ============================================================================
-- 坐标系统
-- 使用 axial 坐标 (q, r)，q 为列，r 为行
-- 偏移坐标转换: odd-q（奇数列下移半格）
-- ============================================================================

--- 创建一个 hex 格子坐标
---@param q integer 列
---@param r integer 行
---@return table {q, r}
function HexGrid.New(q, r)
    return { q = q, r = r }
end

--- 将 axial 坐标转为 cube 坐标（用于距离计算）
---@param hex table {q, r}
---@return table {x, y, z}
function HexGrid.ToCube(hex)
    local x = hex.q
    local z = hex.r
    local y = -x - z
    return { x = x, y = y, z = z }
end

--- 计算两个 hex 之间的距离
---@param a table {q, r}
---@param b table {q, r}
---@return number
function HexGrid.Distance(a, b)
    local dx = a.q - b.q
    local dz = a.r - b.r
    local dy = -(a.q + a.r) + (b.q + b.r)
    return math.max(math.abs(dx), math.abs(dy), math.abs(dz))
end

--- 获取给定中心和半径范围内的所有 hex 坐标
---@param center table {q, r}
---@param radius integer
---@param out table|nil 可选输出表，以复用缓存表，避免频繁分配
---@return table[]
function HexGrid.Range(center, radius, out)
    out = out or _rangeCache
    for i = #out, 1, -1 do
        out[i] = nil
    end
    for dq = -radius, radius do
        local drMin = math.max(-radius, -dq - radius)
        local drMax = math.min(radius, -dq + radius)
        for dr = drMin, drMax do
            out[#out + 1] = { q = center.q + dq, r = center.r + dr }
        end
    end
    return out
end

--- 获取 hex 的6个邻居（平顶六边形）
---@param hex table {q, r}
---@return table[] 邻居列表
function HexGrid.Neighbors(hex)
    -- axial 方向向量（平顶）
    local directions = {
        { q = 1, r = 0 },   -- 右
        { q = 1, r = -1 },  -- 右上
        { q = 0, r = -1 },  -- 左上
        { q = -1, r = 0 },  -- 左
        { q = -1, r = 1 },  -- 左下
        { q = 0, r = 1 },   -- 右下
    }
    local result = {}
    for i = 1, 6 do
        result[i] = { q = hex.q + directions[i].q, r = hex.r + directions[i].r }
    end
    return result
end

--- Axial 坐标 → 像素坐标（平顶六边形中心点）
---@param hex table {q, r}
---@param radius number 六边形半径
---@param originX number 原点X偏移
---@param originY number 原点Y偏移
---@return number, number 像素坐标 px, py
function HexGrid.ToPixel(hex, radius, originX, originY)
    -- 平顶 (flat-top) 计算公式
    local px = radius * (3.0 / 2.0 * hex.q)
    local py = radius * (SQRT3 / 2.0 * hex.q + SQRT3 * hex.r)
    -- 透视Y压缩（模拟倾斜俯视角）
    py = py * HexGrid.PERSPECTIVE_Y
    return px + originX, py + originY
end

--- 像素坐标 → Axial 坐标（四舍五入到最近的格子）
---@param px number 像素X
---@param py number 像素Y
---@param radius number 六边形半径
---@param originX number 原点X偏移
---@param originY number 原点Y偏移
---@return table {q, r}
function HexGrid.FromPixel(px, py, radius, originX, originY)
    -- 减去原点偏移
    local x = px - originX
    local y = py - originY

    -- 逆透视Y压缩（还原真实逻辑坐标）
    y = y / HexGrid.PERSPECTIVE_Y

    -- 反向计算 fractional axial 坐标
    local q = (2.0 / 3.0 * x) / radius
    local r = (-1.0 / 3.0 * x + SQRT3 / 3.0 * y) / radius

    -- 四舍五入到最近的 hex（cube round）
    return HexGrid.Round(q, r)
end

--- 将 fractional axial 坐标四舍五入到最近的格子
---@param fq number fractional q
---@param fr number fractional r
---@return table {q, r}
function HexGrid.Round(fq, fr)
    local fs = -fq - fr

    local q = math.floor(fq + 0.5)
    local r = math.floor(fr + 0.5)
    local s = math.floor(fs + 0.5)

    local qDiff = math.abs(q - fq)
    local rDiff = math.abs(r - fr)
    local sDiff = math.abs(s - fs)

    if qDiff > rDiff and qDiff > sDiff then
        q = -r - s
    elseif rDiff > sDiff then
        r = -q - s
    end

    return { q = q, r = r }
end

--- 获取六边形的6个顶点坐标（平顶）
---@param cx number 中心X
---@param cy number 中心Y
---@param radius number 半径
---@return table[] 顶点列表 {{x,y}, ...}
function HexGrid.GetVertices(cx, cy, radius)
    local vertices = {}
    for i = 0, 5 do
        local angleDeg = 60 * i
        local angleRad = math.rad(angleDeg)
        vertices[i + 1] = {
            x = cx + radius * math.cos(angleRad),
            y = cy + radius * math.sin(angleRad),
        }
    end
    return vertices
end

--- 生成矩形区域的所有 hex 坐标
---@param cols integer 列数
---@param rows integer 行数
---@return table[] hex 坐标列表
function HexGrid.GenerateRectGrid(cols, rows)
    local hexes = {}
    for q = 0, cols - 1 do
        local rOffset = -math.floor(q / 2)
        for r = rOffset, rOffset + rows - 1 do
            hexes[#hexes + 1] = { q = q, r = r }
        end
    end
    return hexes
end

--- BFS 寻路：返回从 start 到 target 的下一步格子
--- 如果不可达返回 nil；如果已到达返回 nil
--- walkable 是一个包含所有可通行格子 key 的 table（tileStates）
---@param start table {q, r}
---@param target table {q, r}
---@param walkable table 以 HexGrid.Key 为键的 tileStates
---@param maxSearch number|nil 最大搜索步数（默认30，避免卡顿）
---@return table|nil nextHex 下一步应走的格子 {q, r}
function HexGrid.BFSNextStep(start, target, walkable, maxSearch)
    maxSearch = maxSearch or 30
    local startKey = HexGrid.Key(start.q, start.r)
    local targetKey = HexGrid.Key(target.q, target.r)
    if startKey == targetKey then return nil end

    -- BFS 队列
    local queue = { { q = target.q, r = target.r } }  -- 从目标反向搜索
    local visited = { [targetKey] = true }
    local cameFrom = {}  -- cameFrom[key] = 从哪个 key 过来的（反向）
    local head = 1
    local steps = 0

    while head <= #queue do
        local current = queue[head]
        head = head + 1
        steps = steps + 1
        if steps > maxSearch * 6 then break end  -- 防止搜索过多

        local neighbors = HexGrid.Neighbors(current)
        for _, nh in ipairs(neighbors) do
            local nKey = HexGrid.Key(nh.q, nh.r)
            if not visited[nKey] and walkable[nKey] then
                visited[nKey] = true
                cameFrom[nKey] = HexGrid.Key(current.q, current.r)

                if nKey == startKey then
                    -- 找到了！cameFrom[startKey] 指向 start 应该走向的那一格
                    -- 由于是反向搜索，cameFrom[startKey] 就是下一步
                    local nextKey = cameFrom[startKey]
                    local nq, nr = HexGrid.FromKey(nextKey)
                    return { q = nq, r = nr }
                end

                queue[#queue + 1] = nh
            end
        end
    end

    return nil  -- 不可达
end

--- 用字符串 key 表示格子坐标（用于 table 索引）
---@param q integer
---@param r integer
---@return string
function HexGrid.Key(q, r)
    return q .. "," .. r
end

--- 从 key 还原坐标
---@param key string "q,r"
---@return number, number
function HexGrid.FromKey(key)
    local q, r = key:match("([%-]?%d+),([%-]?%d+)")
    return tonumber(q) or 0, tonumber(r) or 0
end

return HexGrid


-- ══════════════════════════════════════════════
