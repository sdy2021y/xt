-- ══════════════════════════════════════════════
-- ============================================================================
-- SynergyManager.lua - 羁绊计算逻辑
-- 根据玩家卡组构成计算种族/职业羁绊激活状态，并应用全局加成
-- ============================================================================

local SynergyConfig = require("Config.SynergyConfig")
local UnitConfig = require("Config.UnitConfig")

local SynergyManager = {}

-- 每个玩家的羁绊状态: { [owner] = { race = {...}, class = {...}, activeEffects = {...} } }
local playerSynergies_ = {}

--- 重置所有羁绊状态
function SynergyManager.Reset()
    playerSynergies_ = {}
end

--- 计算玩家的羁绊状态（卡组变化时调用）
--- 卡组格式: { "风帆新兵", "铁壁卫士", "翼族斥候", ... } （8张卡牌名）
---@param owner integer 玩家编号
---@param deck table 卡组（卡牌名列表）
function SynergyManager.Calculate(owner, deck)
    -- 统计种族和职业数量
    local raceCounts = {}
    local classCounts = {}

    for _, cardName in ipairs(deck) do
        local card = UnitConfig.CARDS[cardName]
        if card and card.slotType == "unit" then  -- 只统计战斗单位，跳过建筑卡
            raceCounts[card.race] = (raceCounts[card.race] or 0) + 1
            classCounts[card.class] = (classCounts[card.class] or 0) + 1
        end
    end

    -- 计算激活的羁绊效果
    local activeEffects = {}

    -- 种族羁绊
    for race, count in pairs(raceCounts) do
        local tiers = SynergyConfig.GetActiveRaceTiers(race, count)
        for _, tier in ipairs(tiers) do
            activeEffects[#activeEffects + 1] = {
                source = "race",
                race = race,
                count = count,
                tierCount = tier.count,
                desc = tier.desc,
                effect = tier.effect,
                params = tier.params,
            }
        end
    end

    -- 职业羁绊
    for class, count in pairs(classCounts) do
        local tiers = SynergyConfig.GetActiveClassTiers(class, count)
        for _, tier in ipairs(tiers) do
            activeEffects[#activeEffects + 1] = {
                source = "class",
                class = class,
                count = count,
                tierCount = tier.count,
                desc = tier.desc,
                effect = tier.effect,
                params = tier.params,
            }
        end
    end

    playerSynergies_[owner] = {
        raceCounts = raceCounts,
        classCounts = classCounts,
        activeEffects = activeEffects,
    }
end

--- 获取玩家的所有激活羁绊效果
---@param owner integer
---@return table[] activeEffects
function SynergyManager.GetActiveEffects(owner)
    local synergy = playerSynergies_[owner]
    if not synergy then return {} end
    return synergy.activeEffects
end

--- 检查玩家是否有某个特定效果
---@param owner integer
---@param effectName string
---@return table|nil params 如果有返回参数，否则 nil
function SynergyManager.HasEffect(owner, effectName)
    local synergy = playerSynergies_[owner]
    if not synergy then return nil end

    for _, eff in ipairs(synergy.activeEffects) do
        if eff.effect == effectName then
            return eff.params
        end
    end
    return nil
end

--- 获取玩家的生产速度加成（百分比总和）
--- 影响兵营产兵间隔
---@param owner integer
---@return number totalPercent（0.0 = 无加成）
function SynergyManager.GetProduceSpeedBonus(owner)
    local total = 0
    local synergy = playerSynergies_[owner]
    if not synergy then return 0 end

    for _, eff in ipairs(synergy.activeEffects) do
        if eff.effect == "produce_speed" then
            total = total + (eff.params.percent or 0)
        end
    end
    return total
end

--- 获取玩家的建筑血量加成
---@param owner integer
---@return number percent
function SynergyManager.GetBuildingHpBonus(owner)
    local params = SynergyManager.HasEffect(owner, "building_hp")
    if params then return params.percent or 0 end
    return 0
end

--- 获取玩家的建筑伤害加成
---@param owner integer
---@return number percent
function SynergyManager.GetBuildingDamageBonus(owner)
    local params = SynergyManager.HasEffect(owner, "building_damage")
    if params then return params.percent or 0 end
    return 0
end

--- 获取玩家的额外产兵数量
---@param owner integer
---@return integer count
function SynergyManager.GetExtraProduceCount(owner)
    local params = SynergyManager.HasEffect(owner, "extra_produce")
    if params then return params.count or 0 end
    return 0
end

--- 获取玩家的移速加成
---@param owner integer
---@return number percent
function SynergyManager.GetMoveSpeedBonus(owner)
    local params = SynergyManager.HasEffect(owner, "move_speed")
    if params then return params.percent or 0 end
    return 0
end

--- 获取玩家的攻速加成
---@param owner integer
---@return number percent
function SynergyManager.GetAttackSpeedBonus(owner)
    local total = 0
    local synergy = playerSynergies_[owner]
    if not synergy then return 0 end

    for _, eff in ipairs(synergy.activeEffects) do
        if eff.effect == "attack_speed" then
            total = total + (eff.params.percent or 0)
        end
    end
    return total
end

--- 获取玩家的攻击距离加成
---@param owner integer
---@return integer flat
function SynergyManager.GetAttackRangeBonus(owner)
    local total = 0
    local synergy = playerSynergies_[owner]
    if not synergy then return 0 end

    for _, eff in ipairs(synergy.activeEffects) do
        if eff.effect == "attack_range" then
            total = total + (eff.params.flat or 0)
        end
    end
    return total
end

--- 获取玩家的冷却缩减加成
---@param owner integer
---@return number percent
function SynergyManager.GetCooldownReductionBonus(owner)
    local params = SynergyManager.HasEffect(owner, "cooldown_reduction")
    if params then return params.percent or 0 end
    return 0
end

--- 获取玩家的单位伤害加成（近战职业羁绊）
---@param owner integer
---@return number percent
function SynergyManager.GetUnitDamageBonus(owner)
    local params = SynergyManager.HasEffect(owner, "unit_damage")
    if params then return params.percent or 0 end
    return 0
end

--- 获取玩家的单位生命加成（近战职业羁绊）
---@param owner integer
---@return number percent
function SynergyManager.GetUnitHpBonus(owner)
    local params = SynergyManager.HasEffect(owner, "unit_hp")
    if params then return params.percent or 0 end
    return 0
end

--- 获取玩家的暴击率加成（远程职业羁绊）
---@param owner integer
---@return number percent
function SynergyManager.GetCritRateBonus(owner)
    local params = SynergyManager.HasEffect(owner, "crit_rate")
    if params then return params.percent or 0 end
    return 0
end

--- 获取低血量攻速加成参数（翼族）
---@param owner integer
---@return table|nil { hpThreshold, percent }
function SynergyManager.GetLowHpAttackSpeedBonus(owner)
    return SynergyManager.HasEffect(owner, "low_hp_attack_speed")
end

--- 获取重生概率（机械）
---@param owner integer
---@return number chance
function SynergyManager.GetReviveChance(owner)
    local params = SynergyManager.HasEffect(owner, "revive_chance")
    if params then return params.chance or 0 end
    return 0
end

--- 获取建筑晶核产出参数（联盟6级）
---@param owner integer
---@return table|nil { amount, interval }
function SynergyManager.GetBuildingSpiritGen(owner)
    return SynergyManager.HasEffect(owner, "building_spirit_gen")
end

--- 获取友军减伤参数（联盟4级）
---@param owner integer
---@return table|nil { percent }
function SynergyManager.GetNearbyAllyDamageReduce(owner)
    return SynergyManager.HasEffect(owner, "nearby_ally_damage_reduce")
end

--- 获取玩家种族统计
---@param owner integer
---@return table { [race] = count }
function SynergyManager.GetRaceCounts(owner)
    local synergy = playerSynergies_[owner]
    if not synergy then return {} end
    return synergy.raceCounts
end

--- 获取玩家职业统计
---@param owner integer
---@return table { [class] = count }
function SynergyManager.GetClassCounts(owner)
    local synergy = playerSynergies_[owner]
    if not synergy then return {} end
    return synergy.classCounts
end

return SynergyManager


-- ══════════════════════════════════════════════
