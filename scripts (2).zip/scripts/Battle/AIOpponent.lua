-- ══════════════════════════════════════════════
-- ============================================================================
-- AIOpponent.lua - AI 对手逻辑（多实例独立版）
-- 核心设计：
--   1. 每个 AI slot 拥有独立状态（晶核、冷却、策略参数）
--   2. AI 与玩家遵守完全相同的游戏规则
--   3. 晶核从建筑真实产出，AI 翻格需要晶核
--   4. AI 只能翻非迷雾、可翻开的格子
--   5. AI 强度由段位决定（卡牌等级/据点等级/矿脉加成）
--   6. 策略选格：前线兵营/炮台，后方矿脉
--   7. 2v2模式：slot 2(盟友)、3(敌方1)、4(敌方2) 各自独立
-- ============================================================================

local GameConfig = require("Config.GameConfig")
local TileConfig = require("Config.TileConfig")
local HexGrid = require("Battle.HexGrid")
local BuildingManager = require("Battle.BuildingManager")
local Shared = require("Network.Shared")
local PowerCalculator = require("Config.PowerCalculator")
local DeckManager = require("Battle.DeckManager")

local AIOpponent = {}

-- AI 配置（经济驱动，不再需要定时器间隔）
AIOpponent.CONFIG = {
    startDelay = 4.0,          -- 开场延迟（秒）
    actionCooldown = 0.8,      -- 每次翻格后冷却（秒），防止瞬间翻完
    focusProbability = 0.7,    -- 70% 概率选择集中方向建设
}

-- ============================================================================
-- 多实例 AI 状态管理
-- ============================================================================

-- AI 实例表：{ [slot] = instanceData }
-- 每个 instanceData 包含：
--   slot, team, spiritStones, actionTimer, startTimer, started,
--   focusColumn, barracksCount, mineCount, towerCount, startDelay
local aiInstances_ = {}

-- AI 强度（全局共享，由段位决定）
local aiStrength_ = {
    cardLevelBonus = 0,
    caveLevel = 1,
    spiritMineBonus = 0,
}

-- 地图尺寸缓存（从 tileStates 动态推断）
local mapCols_ = 15
local mapRows_ = 22

-- 当前模式
local currentMode_ = "1v1"

--- 创建一个新的 AI 实例
---@param slot integer AI 的槽位编号
---@param team integer AI 的队伍编号
---@param startDelay number 开场延迟（秒）
---@return table instance
local function CreateInstance(slot, team, startDelay)
    return {
        slot = slot,
        team = team,
        spiritStones = GameConfig.STARTING_SPIRIT_STONES,
        actionTimer = 0,
        startTimer = 0,
        started = false,
        startDelay = startDelay,
        focusColumn = -1,
        barracksCount = 0,
        mineCount = 0,
        towerCount = 0,
    }
end

-- ============================================================================
-- 公共 API
-- ============================================================================

--- 重置所有 AI 状态
function AIOpponent.Reset()
    aiInstances_ = {}
    aiStrength_ = {
        cardLevelBonus = 0,
        caveLevel = 1,
        spiritMineBonus = 0,
    }
    mapCols_ = 15
    mapRows_ = 22
    currentMode_ = "1v1"
end

--- 设置当前对战模式并初始化对应的 AI 实例
--- 1v1: slot 2 = 敌方 AI (team 2)
--- 2v2: slot 2 = 盟友 AI (team 1), slot 3 = 敌方 AI 1 (team 2), slot 4 = 敌方 AI 2 (team 2)
---@param mode string "1v1" 或 "2v2"
function AIOpponent.SetMode(mode)
    currentMode_ = mode
    aiInstances_ = {}

    if mode == "2v2" then
        -- 2v2模式：3个独立AI（盟友+2个敌方）
        aiInstances_[2] = CreateInstance(2, 1, AIOpponent.CONFIG.startDelay + 2)  -- 盟友延迟多2秒
        aiInstances_[3] = CreateInstance(3, 2, AIOpponent.CONFIG.startDelay)
        aiInstances_[4] = CreateInstance(4, 2, AIOpponent.CONFIG.startDelay + 1)  -- 敌方2号稍延迟
    else
        -- 1v1模式：1个敌方AI
        aiInstances_[2] = CreateInstance(2, 2, AIOpponent.CONFIG.startDelay)
    end
end

--- 启用盟友AI（2v2模式，兼容旧调用）
---@param enabled boolean
function AIOpponent.SetAllyEnabled(enabled)
    if enabled then
        if currentMode_ ~= "2v2" then
            currentMode_ = "2v2"
        end
        -- 确保 slot 2 是盟友
        if not aiInstances_[2] or aiInstances_[2].team ~= 1 then
            aiInstances_[2] = CreateInstance(2, 1, AIOpponent.CONFIG.startDelay + 2)
        end
        -- 确保 slot 3, 4 是敌方
        if not aiInstances_[3] then
            aiInstances_[3] = CreateInstance(3, 2, AIOpponent.CONFIG.startDelay)
        end
        if not aiInstances_[4] then
            aiInstances_[4] = CreateInstance(4, 2, AIOpponent.CONFIG.startDelay + 1)
        end
    else
        -- 禁用盟友AI时，移除 slot 2（如果它是盟友）
        if aiInstances_[2] and aiInstances_[2].team == 1 then
            aiInstances_[2] = nil
        end
    end
end

--- 查询盟友AI是否启用
---@return boolean
function AIOpponent.IsAllyEnabled()
    return aiInstances_[2] ~= nil and aiInstances_[2].team == 1
end

--- 设置 AI 强度（由段位决定，战斗开始前调用）
---@param tierIndex integer 段位索引
function AIOpponent.SetStrength(tierIndex)
    aiStrength_ = PowerCalculator.GetAIStrength(tierIndex)
end

--- 获取指定 slot 的 AI 晶核数量（兼容旧 API：无参数时返回主敌方 AI）
---@param slot? integer
---@return number
function AIOpponent.GetSpiritStones(slot)
    if not slot then
        -- 兼容旧 API：1v1 返回 slot 2，2v2 返回 slot 3（第一个敌方）
        if currentMode_ == "2v2" then
            local inst = aiInstances_[3]
            return inst and inst.spiritStones or 0
        else
            local inst = aiInstances_[2]
            return inst and inst.spiritStones or 0
        end
    end
    local inst = aiInstances_[slot]
    return inst and inst.spiritStones or 0
end

--- 添加晶核到指定队伍的所有 AI（建筑产出时调用）
--- 2v2模式：同一 team 的多个 AI slot 按比例分配
---@param amount number
---@param team? integer 目标队伍（默认2=敌方）
function AIOpponent.AddSpirit(amount, team)
    team = team or 2
    -- 应用矿脉加成（仅敌方AI有强度加成）
    local bonus = (team ~= 1) and (1 + aiStrength_.spiritMineBonus) or 1
    local adjusted = amount * bonus

    -- 分发给该队伍所有 AI 实例
    local slots = {}
    for slot, inst in pairs(aiInstances_) do
        if inst.team == team then
            slots[#slots + 1] = slot
        end
    end

    if #slots == 0 then return end

    -- 平均分配（每个 AI 独立经济）
    local share = adjusted / #slots
    for _, slot in ipairs(slots) do
        aiInstances_[slot].spiritStones = aiInstances_[slot].spiritStones + share
    end
end

--- 添加晶核到指定 slot 的 AI（精确控制）
---@param slot integer
---@param amount number
function AIOpponent.AddSpiritToSlot(slot, amount)
    local inst = aiInstances_[slot]
    if inst then
        local bonus = (inst.team ~= 1) and (1 + aiStrength_.spiritMineBonus) or 1
        inst.spiritStones = inst.spiritStones + amount * bonus
    end
end

--- 添加盟友晶核（兼容旧 API）
---@param amount number
function AIOpponent.AddAllySpirit(amount)
    local inst = aiInstances_[2]
    if inst and inst.team == 1 then
        inst.spiritStones = inst.spiritStones + amount
    end
end

--- 获取 AI 卡牌等级加成
---@return integer
function AIOpponent.GetCardLevelBonus()
    return aiStrength_.cardLevelBonus
end

--- 获取 AI 据点等级
---@return integer
function AIOpponent.GetCaveLevel()
    return aiStrength_.caveLevel
end

-- ============================================================================
-- CanFlip（与 Server.CanFlip 逻辑同步）
-- ============================================================================

--- 判断某格子是否可以被某队伍翻开
--- 规则：相邻己方已翻开的格子即可翻（空地也算扩展源）
--- 兵经过染色不算！只有已翻开的领地格才是扩展源
--- 2v2模式：slot 不为 nil 时，只能从自己 slot 的格子扩展
---@param hex table {q, r}
---@param team integer
---@param tileStates table
---@param slot integer|nil 2v2模式传入玩家slot
---@return boolean
function AIOpponent.CanFlip(hex, team, tileStates, slot)
    local neighbors = HexGrid.Neighbors(hex)
    for _, nh in ipairs(neighbors) do
        local key = HexGrid.Key(nh.q, nh.r)
        local tile = tileStates[key]
        -- 相邻格子必须：己方 + 已翻开（空地也可作为扩展源）
        if tile and tile.team == team and tile.flipped then
            if not slot then
                return true
            end
            -- 2v2模式：检查 slot 归属（tile.slot 必须精确匹配）
            if tile.slot == slot then
                return true
            end
        end
    end
    return false
end

-- ============================================================================
-- 核心更新循环
-- ============================================================================

--- 每帧更新所有 AI 实例（独立决策）
---@param tileStates table 格子状态
---@param gridHexes table[] 所有格子
---@param dt number 时间步
---@param units table[]|nil 单位列表
---@return string|nil enemyKey 兼容旧格式
---@return string|nil allyKey 兼容旧格式
---@return table flippedKeys { [slot] = hexKey } 本帧各 AI 翻开的格子
function AIOpponent.Update(tileStates, gridHexes, dt, units)
    local flippedKeys = {}

    for slot, inst in pairs(aiInstances_) do
        if not inst.started then
            inst.startTimer = inst.startTimer + dt
            if inst.startTimer >= inst.startDelay then
                inst.started = true
            end
        else
            inst.actionTimer = inst.actionTimer + dt
            if inst.actionTimer >= AIOpponent.CONFIG.actionCooldown then
                local result = AIOpponent.TryFlipTile(tileStates, gridHexes, units, inst)
                if result then
                    inst.actionTimer = 0
                    flippedKeys[slot] = result
                end
            end
        end
    end

    -- 兼容旧返回格式：return enemyKey, allyKey
    -- 新格式同时也通过 flippedKeys 表返回
    local enemyKey = nil
    local allyKey = nil
    for slot, key in pairs(flippedKeys) do
        local inst = aiInstances_[slot]
        if inst then
            if inst.team == 2 then
                -- 敌方 AI：合并为一个返回值（取第一个）
                if not enemyKey then enemyKey = key end
            elseif inst.team == 1 then
                allyKey = key
            end
        end
    end

    return enemyKey, allyKey, flippedKeys
end

-- ============================================================================
-- 策略逻辑
-- ============================================================================

--- 计算格子到前线的距离评分（越靠近前线值越高）
---@param hex table {q, r}
---@param tileStates table
---@return number frontScore 0~1，1 表示最前线
local function CalcFrontlineScore(hex, tileStates)
    local halfRows = math.floor(mapRows_ / 2)
    local rOffset = -math.floor(hex.q / 2)
    local rowIndex = hex.r - rOffset

    local frontline = halfRows - 1
    local normalizedPos = rowIndex / frontline
    return math.max(0, math.min(1, normalizedPos))
end

--- 分析当前 AI 实例的建筑分布，更新策略参数
---@param tileStates table
---@param gridHexes table[]
---@param inst table AI 实例
local function AnalyzeBuildings(tileStates, gridHexes, inst)
    inst.barracksCount = 0
    inst.mineCount = 0
    inst.towerCount = 0

    local colBarracks = {}
    for q = 0, mapCols_ - 1 do
        colBarracks[q] = 0
    end

    for _, hex in ipairs(gridHexes) do
        local key = HexGrid.Key(hex.q, hex.r)
        local tile = tileStates[key]
        -- 只统计属于本 AI slot 的建筑（2v2精确匹配）
        if tile and tile.team == inst.team and tile.slot == inst.slot and tile.building > 0 then
            if tile.building == GameConfig.BUILDING.BARRACKS then
                inst.barracksCount = inst.barracksCount + 1
                colBarracks[hex.q] = (colBarracks[hex.q] or 0) + 1
            elseif tile.building == GameConfig.BUILDING.SPIRIT_MINE then
                inst.mineCount = inst.mineCount + 1
            elseif tile.building == GameConfig.BUILDING.TOWER or tile.building == GameConfig.BUILDING.ELITE_TOWER then
                inst.towerCount = inst.towerCount + 1
            end
        end
    end

    if inst.focusColumn < 0 or inst.barracksCount == 0 then
        local bestCol = math.floor(mapCols_ / 2)
        local bestCount = -1
        for q = 0, mapCols_ - 1 do
            if colBarracks[q] > bestCount then
                bestCount = colBarracks[q]
                bestCol = q
            end
        end
        if bestCount > 0 then
            inst.focusColumn = bestCol
        else
            inst.focusColumn = math.random(2, mapCols_ - 3)
        end
    end
end

--- 评估一个可翻格子的策略价值
---@param entry table { key, tile, hex }
---@param tileStates table
---@param inst table AI 实例
---@return number score 分数越高越优先翻
local function ScoreTile(entry, tileStates, inst)
    local tile = entry.tile
    local hex = entry.hex
    local score = 0
    local spiritStones = inst.spiritStones

    local frontScore = CalcFrontlineScore(hex, tileStates)
    local tileType = tile.tileType

    -- 经济模式：晶核少时，矿脉高分，便宜格高分
    if spiritStones < 80 then
        if tileType == TileConfig.TILE_TYPE.SPIRIT_MINE then
            score = score + 80
        end
        score = score + (1 - tile.price / 250) * 30
        score = score + (1 - frontScore) * 20
        return score
    end

    -- 格子类型打分
    if tileType == TileConfig.TILE_TYPE.SPIRIT_MINE then
        if inst.mineCount < 2 then
            score = score + 60
        elseif inst.mineCount < 4 then
            score = score + 35
        else
            score = score + 15
        end
        score = score + (1 - frontScore) * 20

    elseif tileType == TileConfig.TILE_TYPE.BARRACKS_50
        or tileType == TileConfig.TILE_TYPE.BARRACKS_100
        or tileType == TileConfig.TILE_TYPE.HIGH_BARRACKS then
        score = score + 50
        score = score + frontScore * 30
        local colDist = math.abs(hex.q - inst.focusColumn)
        score = score + math.max(0, 20 - colDist * 8)
        if tileType == TileConfig.TILE_TYPE.HIGH_BARRACKS then
            score = score + 15
        end

    elseif tileType == TileConfig.TILE_TYPE.TOWER_50
        or tileType == TileConfig.TILE_TYPE.TOWER_100 then
        score = score + 40
        score = score + frontScore * 35
        if inst.towerCount < 2 then
            score = score + 20
        end

    elseif tileType == TileConfig.TILE_TYPE.MYSTERY then
        score = score + 25
        if spiritStones > 300 then
            score = score + 15
        end
    end

    -- 有钱时偏好贵格子
    if spiritStones > 300 then
        score = score + (tile.price / 250) * 15
    end

    -- 小随机扰动
    score = score + math.random() * 10

    return score
end

-- ============================================================================
-- 翻格执行
-- ============================================================================

--- AI 尝试翻格子（经济驱动：晶核够才翻）
---@param tileStates table
---@param gridHexes table[]
---@param units table[]|nil
---@param inst table AI 实例（包含 slot, team, spiritStones 等）
---@return string|nil 翻开的格子key
function AIOpponent.TryFlipTile(tileStates, gridHexes, units, inst)
    local team = inst.team
    local slot = inst.slot
    local spiritStones = inst.spiritStones

    -- 从 tileStates 推断地图尺寸
    local maxQ, maxR = 0, 0
    for key, tile in pairs(tileStates) do
        if tile.flipped or tile.team > 0 then
            local q, r = HexGrid.FromKey(key)
            if q > maxQ then maxQ = q end
            if r > maxR then maxR = r end
        end
    end
    mapCols_ = math.max(mapCols_, maxQ + 1)
    mapRows_ = math.max(mapRows_, maxR + 1)

    AnalyzeBuildings(tileStates, gridHexes, inst)

    -- 收集所有可翻的格子（和玩家规则一致：非迷雾 + 未翻 + 买得起）
    local flippable = {}

    for _, hex in ipairs(gridHexes) do
        local key = HexGrid.Key(hex.q, hex.r)
        local tile = tileStates[key]
        if tile
            and not tile.flipped
            and not tile.ruins
            and tile.tileType ~= TileConfig.TILE_TYPE.EMPTY
            and tile.building == GameConfig.BUILDING.NONE
            and tile.price <= spiritStones
            and AIOpponent.CanFlip(hex, team, tileStates, slot) then
            flippable[#flippable + 1] = { key = key, tile = tile, hex = hex }
        end
    end

    if #flippable == 0 then return nil end

    -- 打分选最优
    local scored = {}
    for _, entry in ipairs(flippable) do
        scored[#scored + 1] = {
            entry = entry,
            score = ScoreTile(entry, tileStates, inst),
        }
    end

    table.sort(scored, function(a, b) return a.score > b.score end)

    local chosen = nil
    if math.random() < AIOpponent.CONFIG.focusProbability then
        chosen = scored[1].entry
    else
        local topN = math.min(3, #scored)
        chosen = scored[math.random(1, topN)].entry
    end

    if not chosen then return nil end

    -- 执行翻格子（扣晶核、翻开、获得建筑）
    local tile = chosen.tile
    inst.spiritStones = inst.spiritStones - tile.price

    local buildingType, buildingName, barracksPrice, fixedQuality = TileConfig.GetFlipResult(tile.tileType)
    tile.flipped = true
    tile.team = team
    tile.slot = slot  -- 精确标记归属 slot

    if buildingType ~= GameConfig.BUILDING.NONE then
        tile.building = buildingType
        tile.barracksPrice = barracksPrice or 0
        tile.fixedQuality = fixedQuality

        -- 所有建筑统一流程：先 ROLL 品质，再从卡组匹配该品质的卡，绑定
        if buildingType == GameConfig.BUILDING.BARRACKS then
            local quality = fixedQuality or DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(slot, "unit", quality)
            if cardName then
                if team == 2 then
                    cardLevel = cardLevel + AIOpponent.GetCardLevelBonus()
                end
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        elseif buildingType == GameConfig.BUILDING.SPIRIT_MINE then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(slot, "mine", quality)
            if cardName then
                if team == 2 then
                    cardLevel = cardLevel + AIOpponent.GetCardLevelBonus()
                end
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        elseif buildingType == GameConfig.BUILDING.TOWER or buildingType == GameConfig.BUILDING.ELITE_TOWER then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(slot, "tower", quality)
            if cardName then
                if team == 2 then
                    cardLevel = cardLevel + AIOpponent.GetCardLevelBonus()
                end
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        end

        return chosen.key
    else
        tile.building = GameConfig.BUILDING.NONE
        tile.tileType = TileConfig.TILE_TYPE.EMPTY
        tile.revealedEmpty = true
        tile.barracksPrice = 0
        tile.fixedQuality = nil
        return chosen.key
    end
end

return AIOpponent
