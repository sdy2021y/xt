-- ============================================================================
-- TerritoryConfig.lua - 据点配置数据
-- 4功能建筑 + 灵田种植 + 小偷入侵 + 领主等级
-- ============================================================================

local TerritoryConfig = {}

-- ========== 资源产出配置 ==========

TerritoryConfig.RESOURCES = {
    materials = {
        name = "铸材",
        icon = "🔮",
        victory = 200,    -- 对战胜利
        defeat = 50,      -- 对战失败
        offlineHour = 10, -- 离线每小时 = 领主等级 × 此值
        maxOffline = 8,   -- 最大离线累积小时
    },
    spiritStones = {
        name = "晶核",
        icon = "💎",
    },
    runes = {
        name = "符文",
        icon = "🔮",
    },
    xianyu = {
        name = "星钻",
        icon = "✨",
    },
}

-- ========== 四大功能建筑 ==========

TerritoryConfig.BUILDINGS = {
    lingMine = {
        id = "lingMine",
        name = "矿脉",
        icon = "⛏️",
        desc = "产出晶核",
        resource = "spiritStones",
        resourceName = "晶核",
        baseOutput = 10,        -- 基础产出/小时
        outputPerLevel = 0.10,  -- 每级+10%
        maxLevel = 30,
        upgradeCostBase = 100,  -- 升级消耗铸材基数
        upgradeCostPerLevel = 50,
    },
    lingField = {
        id = "lingField",
        name = "灵田",
        icon = "🌱",
        desc = "种植星钻",
        resource = "xianyu",
        resourceName = "星钻",
        baseSlots = 2,          -- 初始种植位
        maxSlots = 6,           -- 最大种植位
        slotsPerLevel = 2,      -- 每多少级增加1个种植位
        maxLevel = 30,
        upgradeCostBase = 150,
        upgradeCostPerLevel = 80,
    },
    pillFurnace = {
        id = "pillFurnace",
        name = "丹炉",
        icon = "🏺",
        desc = "产出符文",
        resource = "runes",
        resourceName = "符文",
        baseOutput = 5,
        outputPerLevel = 0.10,
        maxLevel = 30,
        upgradeCostBase = 120,
        upgradeCostPerLevel = 60,
    },
    library = {
        id = "library",
        name = "藏经阁",
        icon = "📚",
        desc = "产出铸材",
        resource = "materials",
        resourceName = "铸材",
        baseOutput = 15,
        outputPerLevel = 0.10,
        maxLevel = 30,
        upgradeCostBase = 80,
        upgradeCostPerLevel = 40,
    },
}

-- ========== 灵田种植配置 ==========

TerritoryConfig.CROPS = {
    lingGrass = {
        id = "lingGrass",
        name = "灵草",
        icon = "🌿",
        growTime = 3600,      -- 1小时（秒）
        reward = 5,           -- 5星钻
        unlockTier = 0,       -- 初始解锁
    },
    xianLotus = {
        id = "xianLotus",
        name = "仙莲",
        icon = "🪷",
        growTime = 10800,     -- 3小时
        reward = 15,          -- 15星钻
        unlockTier = 1,       -- 白银解锁
    },
    nineTurnLingzhi = {
        id = "nineTurnLingzhi",
        name = "九转灵芝",
        icon = "🍄",
        growTime = 21600,     -- 6小时
        reward = 20,          -- 20星钻
        unlockTier = 2,       -- 黄金解锁
    },
    snowLotus = {
        id = "snowLotus",
        name = "天山雪莲",
        icon = "🌸",
        growTime = 43200,     -- 12小时
        reward = 30,          -- 30星钻
        unlockTier = 3,       -- 铂金解锁
    },
}

-- ========== 小偷入侵配置 ==========

TerritoryConfig.THIEF = {
    maxDaily = 2,          -- 每日最多2次
    firstTriggerMin = 30,  -- 第1次：在线30分钟后
    firstTriggerMax = 60,  -- 到60分钟随机
    secondTriggerMin = 120, -- 第2次：第1次击败后2小时
    secondTriggerMax = 240, -- 到4小时随机

    -- 难度分级
    difficultyByLevel = {
        { minLevel = 1,  maxLevel = 10, hp = 200,  atk = 15,  coefficient = 0.5 },
        { minLevel = 11, maxLevel = 30, hp = 500,  atk = 30,  coefficient = 0.7 },
        { minLevel = 31, maxLevel = 60, hp = 1200, atk = 60,  coefficient = 0.9 },
        { minLevel = 61, maxLevel = 999, hp = 2500, atk = 120, coefficient = 1.1 },
    },

    -- 奖励
    rewards = {
        { materials = 500, runes = 50,  xianyu = 10 },
        { materials = 800, runes = 80,  xianyu = 20 },
    },
}

-- ========== 领主等级配置 ==========
-- 9个境界，第一境界9级(1-9)，其余每境界10级，最高89级
-- 境界是永久的，不属于赛季

TerritoryConfig.LORD_LEVELS = {
    { minLevel = 1,  maxLevel = 9,   title = "浮空学徒", atkPerLevel = 8,   hpPerLevel = 40,  spiritPerLevel = 0.3 },
    { minLevel = 10, maxLevel = 19,  title = "云海行者", atkPerLevel = 12,  hpPerLevel = 60,  spiritPerLevel = 0.5 },
    { minLevel = 20, maxLevel = 29,  title = "星尘守卫", atkPerLevel = 16,  hpPerLevel = 80,  spiritPerLevel = 0.7 },
    { minLevel = 30, maxLevel = 39,  title = "风暴骑士", atkPerLevel = 20,  hpPerLevel = 100, spiritPerLevel = 0.9 },
    { minLevel = 40, maxLevel = 49,  title = "苍穹领主", atkPerLevel = 25,  hpPerLevel = 130, spiritPerLevel = 1.1 },
    { minLevel = 50, maxLevel = 59,  title = "天穹统帅", atkPerLevel = 30,  hpPerLevel = 160, spiritPerLevel = 1.3 },
    { minLevel = 60, maxLevel = 69,  title = "星域霸主", atkPerLevel = 38,  hpPerLevel = 200, spiritPerLevel = 1.6 },
    { minLevel = 70, maxLevel = 79,  title = "虚空君王", atkPerLevel = 48,  hpPerLevel = 260, spiritPerLevel = 2.0 },
    { minLevel = 80, maxLevel = 89,  title = "永恒浮空者", atkPerLevel = 60,  hpPerLevel = 340, spiritPerLevel = 2.5 },
}

--- 获取据点境界名称（如"浮空学徒 3级"）
---@param level integer 据点等级(1-89)
---@return string title, integer levelInRealm
function TerritoryConfig.GetLordTitle(level)
    for _, realm in ipairs(TerritoryConfig.LORD_LEVELS) do
        if level >= realm.minLevel and level <= realm.maxLevel then
            return realm.title, level - realm.minLevel + 1
        end
    end
    return "浮空学徒", 1
end

-- ========== 好友互动配置 ==========

TerritoryConfig.FRIEND_INTERACTION = {
    helpSpeedReduction = 0.10,   -- 帮忙加速减少10%时间
    helpReward = 10,             -- 帮忙者得10符文
    maxDailyHelp = 3,            -- 每日可帮3次
    stealRate = 0.10,            -- 偷取10%成熟星钻
    maxDailySteal = 3,           -- 每日可偷3次
    stealCaughtRate = 0.10,      -- 10%被抓概率
    stealPenalty = 20,           -- 被抓赔20符文
    maxStealPerPlayer = 1,       -- 同一玩家每天只能被偷1次
    antiCheatMaxPerHour = 10,    -- 1小时超10次偷取封禁
}

-- ========== 辅助函数 ==========

--- 获取据点离线收益（按据点等级）
--- 基础产出：金币+铸材，3级起附加符文+星钻
---@param lordLevel integer 据点等级
---@param offlineHours number 离线小时数
---@return table { gold, materials, runes, xianyu }
function TerritoryConfig.GetOfflineYield(lordLevel, offlineHours)
    local gold = math.floor(lordLevel * 15 * offlineHours)
    local materials = math.floor(lordLevel * 10 * offlineHours)
    local runes = 0
    local xianyu = 0

    -- 据点3级开始附加：符文+星钻
    -- 24小时符文/星钻产出约10-20，即每小时约0.5-0.8
    if lordLevel >= 3 then
        local bonusLevel = lordLevel - 2
        runes = math.floor(bonusLevel * 0.5 * offlineHours)
        xianyu = math.floor(bonusLevel * 0.5 * offlineHours)
    end

    return {
        gold = gold,
        materials = materials,
        runes = runes,
        xianyu = xianyu,
    }
end

--- 获取领主等级对应的星阶信息
---@param lordLevel integer
---@return table { title, atkPerLevel, hpPerLevel, spiritPerLevel }
function TerritoryConfig.GetLordLevelInfo(lordLevel)
    for _, tier in ipairs(TerritoryConfig.LORD_LEVELS) do
        if lordLevel >= tier.minLevel and lordLevel <= tier.maxLevel then
            return tier
        end
    end
    return TerritoryConfig.LORD_LEVELS[#TerritoryConfig.LORD_LEVELS]
end

--- 计算建筑升级所需铸材
---@param buildingId string
---@param currentLevel integer
---@return integer
function TerritoryConfig.GetUpgradeCost(buildingId, currentLevel)
    local building = TerritoryConfig.BUILDINGS[buildingId]
    if not building then return 0 end
    return building.upgradeCostBase + currentLevel * building.upgradeCostPerLevel
end

--- 计算建筑产出/小时
---@param buildingId string
---@param level integer
---@return number
function TerritoryConfig.GetBuildingOutput(buildingId, level)
    local building = TerritoryConfig.BUILDINGS[buildingId]
    if not building or not building.baseOutput or not building.outputPerLevel then return 0 end
    return building.baseOutput * (1 + level * building.outputPerLevel)
end

--- 获取小偷难度数据
---@param lordLevel integer
---@return table
function TerritoryConfig.GetThiefDifficulty(lordLevel)
    for _, diff in ipairs(TerritoryConfig.THIEF.difficultyByLevel) do
        if lordLevel >= diff.minLevel and lordLevel <= diff.maxLevel then
            return diff
        end
    end
    return TerritoryConfig.THIEF.difficultyByLevel[#TerritoryConfig.THIEF.difficultyByLevel]
end

return TerritoryConfig