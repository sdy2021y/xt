-- ============================================================================
-- AchievementConfig.lua - 成就配置
-- 25个成就，分4类：对战/收集/社交/段位
-- ============================================================================

local AchievementConfig = {}

-- ========== 成就定义 ==========

AchievementConfig.ACHIEVEMENTS = {

    -- ===== 对战类 =====
    {
        id = "battle_10",
        name = "初出茅庐",
        desc = "完成10场对战",
        icon = "⚔️",
        category = "battle",
        target = { type = "totalBattles", value = 10 },
        rewards = { gold = 100, runes = 50 },
    },
    {
        id = "battle_50",
        name = "身经百战",
        desc = "完成50场对战",
        icon = "⚔️",
        category = "battle",
        target = { type = "totalBattles", value = 50 },
        rewards = { gold = 200, runes = 100 },
    },
    {
        id = "battle_100",
        name = "百战不殆",
        desc = "完成100场对战",
        icon = "⚔️",
        category = "battle",
        target = { type = "totalBattles", value = 100 },
        rewards = { gold = 500, runes = 200 },
    },
    {
        id = "battle_500",
        name = "战场主宰",
        desc = "完成500场对战",
        icon = "⚔️",
        category = "battle",
        target = { type = "totalBattles", value = 500 },
        rewards = { gold = 1000, runes = 500 },
    },
    {
        id = "win_10",
        name = "初尝胜果",
        desc = "赢得10场对战",
        icon = "🏆",
        category = "battle",
        target = { type = "wins", value = 10 },
        rewards = { gold = 100, runes = 50 },
    },
    {
        id = "win_50",
        name = "常胜将军",
        desc = "赢得50场对战",
        icon = "🏆",
        category = "battle",
        target = { type = "wins", value = 50 },
        rewards = { gold = 300, runes = 150 },
    },
    {
        id = "win_100",
        name = "百胜之师",
        desc = "赢得100场对战",
        icon = "🏆",
        category = "battle",
        target = { type = "wins", value = 100 },
        rewards = { gold = 800, runes = 300 },
    },
    {
        id = "winStreak_5",
        name = "连胜之势",
        desc = "达成5连胜",
        icon = "🔥",
        category = "battle",
        target = { type = "winStreak", value = 5 },
        rewards = { gold = 200, runes = 100 },
    },
    {
        id = "winStreak_10",
        name = "势不可挡",
        desc = "达成10连胜",
        icon = "🔥",
        category = "battle",
        target = { type = "winStreak", value = 10 },
        rewards = { gold = 500, runes = 200 },
    },

    -- ===== 收集类 =====
    {
        id = "cards_10",
        name = "初入仙途",
        desc = "收集10张卡牌",
        icon = "🃏",
        category = "collect",
        target = { type = "cardsCollected", value = 10 },
        rewards = { gold = 100, runes = 50 },
    },
    {
        id = "cards_24",
        name = "万法归宗",
        desc = "收集全部24张卡牌",
        icon = "🃏",
        category = "collect",
        target = { type = "cardsCollected", value = 24 },
        rewards = { gold = 500, runes = 2000 },
    },
    {
        id = "upgrade_10",
        name = "精益求精",
        desc = "升级任意卡牌10次",
        icon = "⭐",
        category = "collect",
        target = { type = "cardUpgrades", value = 10 },
        rewards = { gold = 200, runes = 100 },
    },
    {
        id = "chests_20",
        name = "宝箱猎手",
        desc = "开启20个宝箱",
        icon = "📦",
        category = "collect",
        target = { type = "chestsOpened", value = 20 },
        rewards = { gold = 200, runes = 100 },
    },
    {
        id = "chests_100",
        name = "宝箱大师",
        desc = "开启100个宝箱",
        icon = "📦",
        category = "collect",
        target = { type = "chestsOpened", value = 100 },
        rewards = { gold = 500, runes = 200 },
    },
    {
        id = "artifact_3",
        name = "神器收集",
        desc = "收集全部3件神器",
        icon = "⚡",
        category = "collect",
        target = { type = "artifactsCollected", value = 3 },
        rewards = { gold = 500, runes = 200 },
    },

    -- ===== 社交类 =====
    {
        id = "friend_5",
        name = "广结仙缘",
        desc = "添加5个好友",
        icon = "👥",
        category = "social",
        target = { type = "friendCount", value = 5 },
        rewards = { gold = 100, runes = 50 },
    },
    {
        id = "help_10",
        name = "乐于助人",
        desc = "帮助好友10次",
        icon = "🤝",
        category = "social",
        target = { type = "friendHelp", value = 10 },
        rewards = { gold = 200, runes = 100 },
    },
    {
        id = "chat_50",
        name = "修炼交流",
        desc = "发送50条聊天消息",
        icon = "💬",
        category = "social",
        target = { type = "chatMessages", value = 50 },
        rewards = { gold = 100, runes = 50 },
    },

    -- ===== 段位类 =====
    {
        id = "tier_silver",
        name = "白银修士",
        desc = "达到白银段位",
        icon = "🥈",
        category = "rank",
        target = { type = "tier", value = 1 },
        rewards = { gold = 200, runes = 100 },
    },
    {
        id = "tier_gold",
        name = "黄金修士",
        desc = "达到黄金段位",
        icon = "🥇",
        category = "rank",
        target = { type = "tier", value = 2 },
        rewards = { gold = 500, runes = 200 },
    },
    {
        id = "tier_platinum",
        name = "铂金修士",
        desc = "达到铂金段位",
        icon = "💎",
        category = "rank",
        target = { type = "tier", value = 3 },
        rewards = { gold = 800, runes = 300 },
    },
    {
        id = "tier_diamond",
        name = "钻石修士",
        desc = "达到钻石段位",
        icon = "💎",
        category = "rank",
        target = { type = "tier", value = 4 },
        rewards = { gold = 1200, runes = 500 },
    },
    {
        id = "tier_king",
        name = "王者修士",
        desc = "达到王者段位",
        icon = "👑",
        category = "rank",
        target = { type = "tier", value = 6 },
        rewards = { gold = 2000, runes = 800 },
    },
    {
        id = "artifact_use",
        name = "神器使用者",
        desc = "使用神器10次",
        icon = "⚡",
        category = "battle",
        target = { type = "artifactUse", value = 10 },
        rewards = { gold = 200, runes = 40 },
    },
    {
        id = "lord_10",
        name = "领主初成",
        desc = "领主等级达到10级",
        icon = "🏰",
        category = "collect",
        target = { type = "lordLevel", value = 10 },
        rewards = { gold = 200, runes = 100 },
    },
}

-- 按分类归类
AchievementConfig.CATEGORIES = {
    battle = { name = "对战", icon = "⚔️" },
    collect = { name = "收集", icon = "🃏" },
    social = { name = "社交", icon = "👥" },
    rank = { name = "段位", icon = "👑" },
}

return AchievementConfig