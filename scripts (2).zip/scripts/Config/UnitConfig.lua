-- ══════════════════════════════════════════════
-- ============================================================================
-- UnitConfig.lua - 完整兵种配置（4种族×6卡=24张，含全部技能）
-- 严格按照设计文档 XianTu_Battle.md 第四章
-- ============================================================================

local UnitConfig = {}

-- ========== 品质定义 ==========
UnitConfig.QUALITY = {
    GREEN  = "green",   -- 普通 1人口
    BLUE   = "blue",    -- 稀有 2人口
    PURPLE = "purple",  -- 史诗 4人口
    GOLD   = "gold",    -- 传奇 8人口
}

-- 品质→人口映射
UnitConfig.QUALITY_POP = {
    green  = 1,
    blue   = 2,
    purple = 4,
    gold   = 8,
}

-- ========== 种族定义 ==========
UnitConfig.RACE = {
    HUMAN  = "aether",  -- 联盟
    DEMON  = "avian",   -- 翼族
    DARK   = "forge",   -- 机械
    SPIRIT = "astral",  -- 元素
}

-- ========== 职业定义 ==========
UnitConfig.CLASS = {
    MELEE  = "melee",   -- 近战
    RANGED = "ranged",  -- 远程
}

-- ========== 技能触发类型 ==========
UnitConfig.SKILL_TRIGGER = {
    PASSIVE    = "passive",    -- 被动（常驻）
    ON_ATTACK  = "on_attack",  -- 攻击时触发
    ON_HIT     = "on_hit",     -- 被攻击时触发
    ON_KILL    = "on_kill",    -- 击杀时触发
    ON_DEATH   = "on_death",   -- 死亡时触发
    ON_TIMER   = "on_timer",   -- 定时触发
    HP_BELOW   = "hp_below",   -- 血量低于阈值时触发
    ACTIVE     = "active",     -- 主动技能（传奇专属）
}

-- ========== 技能效果类型 ==========
UnitConfig.SKILL_EFFECT = {
    -- 属性修改
    STAT_BUFF        = "stat_buff",        -- 修改自身/友军属性
    STAT_DEBUFF      = "stat_debuff",      -- 削弱敌方属性
    -- 伤害
    DAMAGE           = "damage",           -- 造成伤害
    DAMAGE_AOE       = "damage_aoe",       -- 范围伤害
    DAMAGE_LINE      = "damage_line",      -- 直线伤害
    -- 持续伤害
    DOT              = "dot",              -- 持续掉血（中毒/灼烧）
    -- 生命
    HEAL             = "heal",             -- 治疗
    LIFESTEAL        = "lifesteal",        -- 吸血
    REGEN            = "regen",            -- 持续回血
    -- 控制
    SLOW             = "slow",             -- 减速
    STUN             = "stun",             -- 眩晕/冻结
    SILENCE          = "silence",          -- 沉默
    FEAR             = "fear",             -- 恐惧
    CHARM            = "charm",            -- 魅惑（停止攻击）
    KNOCKBACK        = "knockback",        -- 击退
    SUSPEND          = "suspend",          -- 悬浮（无法攻击移动）
    -- 特殊
    SUMMON           = "summon",           -- 召唤单位
    REVIVE           = "revive",           -- 复活
    SHIELD           = "shield",           -- 护盾
    DODGE            = "dodge",            -- 闪避
    REFLECT          = "reflect",          -- 反伤
    SURVIVE          = "survive",          -- 免死
    CHAIN            = "chain",            -- 连锁攻击
    CONVERT          = "convert",          -- 转化敌方单位
    CRIT_BUFF        = "crit_buff",        -- 暴击加成
    SPIRIT_ON_KILL   = "spirit_on_kill",   -- 击杀获得晶核
    EXTRA_PRODUCE    = "extra_produce",    -- 额外产兵
    EXPLODE_ON_DEATH = "explode_on_death", -- 死亡爆炸
    EXPLODE_ON_KILL  = "explode_on_kill",  -- 击杀爆炸
    DAMAGE_REDUCE    = "damage_reduce",    -- 减伤
    DAMAGE_TAKEN_INCREASE = "damage_taken_increase", -- enemies take more damage
    SHARE_DAMAGE     = "share_damage",     -- 分担伤害
    AURA_DAMAGE      = "aura_damage",      -- 光环持续伤害
    TRANSFORM        = "transform",        -- 变身
}

-- ============================================================================
-- 联盟（防御经济流）
-- ============================================================================

UnitConfig.CARDS = {}

-- 矿脉卡牌
UnitConfig.CARDS["矿脉"] = {
    slotType = "mine", quality = "green",
    icon = "矿", color = { 180, 160, 120 },
    -- 矿脉属性
    hp = 400, spiritOutput = 10, spiritInterval = 5.0,
    -- 升级加成：每级+1晶核产出，HP+20，CD-0.05秒（20级满级共减1秒）
    upgrade = { spiritOutput = 1, hp = 20, spiritIntervalReduction = 0.05 },
    desc = "每5秒产出10晶核"
}
UnitConfig.CARDS["精锐矿脉"] = {
    slotType = "mine", quality = "blue",
    icon = "矿", color = { 100, 200, 255 },
    hp = 600, spiritOutput = 15, spiritInterval = 5.0,
    upgrade = { spiritOutput = 1, hp = 30, spiritIntervalReduction = 0.05 },
    desc = "每5秒产出15晶核"
}

-- 炮台卡牌
UnitConfig.CARDS["炮台"] = {
    slotType = "tower", quality = "green",
    icon = "塔", color = { 100, 100, 120 },
    -- 炮台属性
    hp = 500, atk = 80, range = 5, attackInterval = 1.5,
    upgrade = { hp = 30, atk = 5 },
    desc = "攻击范围5格，攻击间隔1.5秒"
}
UnitConfig.CARDS["重炮"] = {
    slotType = "tower", quality = "blue",
    icon = "塔", color = { 80, 120, 180 },
    hp = 800, atk = 140, range = 5, attackInterval = 1.2,
    upgrade = { hp = 50, atk = 8 },
    desc = "攻击范围5格，攻击间隔1.2秒"
}

-- 1. 风帆新兵（绿，近战，肉盾）
UnitConfig.CARDS["风帆新兵"] = {
    race = "aether", class = "melee", quality = "green", slotType = "unit",
    buildingHp = 100, hp = 100, atk = 28, spd = 40, range = 1, pop = 1, prodTime = 5,
    icon = "兵", color = { 200, 220, 180 },
    upgrade = { hp = 8, atk = 0.5 },
    skills = {
        { name = "坚韧", unlock = 0, trigger = "passive",
          effect = "damage_reduce", params = { percent = 0.05 } },
        { name = "坚韧", unlock = 0, trigger = "hp_below", threshold = 0.3,
          effect = "damage_reduce", params = { percent = 0.30 } },
        { name = "鼓舞", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.15, target = "nearby_allies", aoeRange = 1 } },
        { name = "铁壁", unlock = 12, trigger = "on_hit",
          effect = "survive", params = { chance = 0.10 } },
        { name = "不屈意志", unlock = 18, trigger = "on_death",
          effect = "heal", params = { percent = 0.20, target = "nearby_allies", aoeRange = 3 } },
    },
}

-- 2. 铁壁卫士（绿，近战，防御）
UnitConfig.CARDS["铁壁卫士"] = {
    race = "aether", class = "melee", quality = "green", slotType = "unit",
    buildingHp = 90, hp = 90, atk = 30, spd = 44, range = 1, pop = 1, prodTime = 5.5,
    icon = "卫", color = { 180, 200, 220 },
    upgrade = { hp = 6, atk = 0.8 },
    skills = {
        { name = "盾墙", unlock = 0, trigger = "passive",
          effect = "share_damage", params = { percent = 0.10, target = "adjacent_allies" } },
        { name = "铁壁", unlock = 0, trigger = "passive",
          effect = "damage_reduce", params = { percent = 0.20, condition = "stationary" } },
        { name = "鼓舞", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", flat = 3, target = "nearby_allies", aoeRange = 1 } },
        { name = "反击", unlock = 12, trigger = "on_hit",
          effect = "reflect", params = { chance = 0.15, percent = 0.30 } },
        { name = "铜墙铁壁", unlock = 18, trigger = "passive",
          effect = "damage_reduce", params = { percent = 0.15, target = "nearby_allies", aoeRange = 3 } },
    },
}

-- 3. 破空剑士（蓝，近战，输出）
UnitConfig.CARDS["破空剑士"] = {
    race = "aether", class = "melee", quality = "blue", slotType = "unit",
    buildingHp = 110, hp = 110, atk = 55, spd = 48, range = 1, pop = 2, prodTime = 7.5,
    icon = "剑", color = { 100, 180, 255 },
    upgrade = { atk = 2, hp = 5, spd = 1 },
    skills = {
        { name = "锋芒", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.10 } },
        { name = "穿透", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.10 } },
        { name = "气刃", unlock = 6, trigger = "on_attack",
          effect = "damage", params = { chance = 0.20, percent = 0.50, target = "behind_enemy" } },
        { name = "连斩", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "attackSpeed", percent = 0.15 } },
        { name = "破空斩阵", unlock = 18, trigger = "on_timer", interval = 8,
          effect = "damage_aoe", params = { percent = 1.50, range = 3, direction = "front" } },
    },
}

-- 4. 飞艇炮手（蓝，远程，输出）
UnitConfig.CARDS["飞艇炮手"] = {
    race = "aether", class = "ranged", quality = "blue", slotType = "unit",
    buildingHp = 70, hp = 70, atk = 48, spd = 44, range = 2, pop = 2, prodTime = 6.5,
    icon = "炮", color = { 180, 140, 80 },
    upgrade = { atk = 2, hp = 3 },
    skills = {
        { name = "精准", unlock = 0, trigger = "passive",
          effect = "crit_buff", params = { critRate = 0.08 } },
        { name = "远射", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "range", flat = 0.5 } },
        { name = "穿甲弹", unlock = 6, trigger = "passive",
          effect = "crit_buff", params = { critDamage = 0.30 } },
        { name = "连射", unlock = 12, trigger = "on_attack",
          effect = "damage", params = { chance = 0.15, extraHits = 1 } },
        { name = "飞艇弹幕", unlock = 18, trigger = "on_timer", interval = 10,
          effect = "damage_aoe", params = { percent = 1.20, range = 2 } },
    },
}

-- 5. 联盟剑圣（紫，远程，输出）
UnitConfig.CARDS["联盟剑圣"] = {
    race = "aether", class = "ranged", quality = "purple", slotType = "unit",
    buildingHp = 160, hp = 160, atk = 95, spd = 40, range = 2, pop = 4, prodTime = 11,
    icon = "圣", color = { 100, 220, 200 },
    upgrade = { atk = 4, hp = 12 },
    skills = {
        { name = "锋心", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.15 } },
        { name = "护体气刃", unlock = 0, trigger = "passive",
          effect = "damage_reduce", params = { percent = 0.15, condition = "melee_damage" } },
        { name = "破空斩阵", unlock = 6, trigger = "on_attack",
          effect = "damage_aoe", params = { chance = 0.30, percent = 0.50, range = 1, target = "around_target" } },
        { name = "破甲", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.25 } },
        { name = "苍穹剑舞", unlock = 18, trigger = "on_timer", interval = 6,
          effect = "damage_aoe", params = { percent = 2.00, range = 3, direction = "front_cone" } },
    },
}

-- 6. 联盟元帅（金，远程，辅助）
UnitConfig.CARDS["联盟元帅"] = {
    race = "aether", class = "ranged", quality = "gold", slotType = "unit",
    buildingHp = 450, hp = 450, atk = 160, spd = 36, range = 3, pop = 8, prodTime = 16,
    icon = "帅", color = { 255, 215, 0 },
    upgrade = { atk = 6, hp = 25 },
    skills = {
        { name = "苍穹之光", unlock = 0, trigger = "on_attack",
          effect = "slow", params = { percent = 0.10, duration = 2 } },
        { name = "庇佑", unlock = 0, trigger = "passive",
          effect = "regen", params = { percent = 0.02, target = "nearby_allies", aoeRange = 2 } },
        { name = "天罚", unlock = 6, trigger = "on_attack",
          effect = "damage_aoe", params = { chance = 0.20, percent = 1.50, range = 1 } },
        { name = "统御", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "cooldownReduction", percent = 0.20 } },
        { name = "苍穹神雷", unlock = 18, trigger = "on_timer", interval = 5,
          effect = "damage_aoe", params = { percent = 2.50, range = 3 } },
        { name = "天罚降临", unlock = 0, trigger = "active", cooldown = 15,
          effect = "damage_aoe", params = { percent = 3.00, range = 999, stun = 2 } },
    },
}

-- ============================================================================
-- 翼族（快攻推塔流）
-- ============================================================================

-- 1. 翼族斥候（绿，近战，快攻）
UnitConfig.CARDS["翼族斥候"] = {
    race = "avian", class = "melee", quality = "green", slotType = "unit",
    buildingHp = 55, hp = 55, atk = 42, spd = 64, range = 1, pop = 1, prodTime = 4,
    icon = "翼", color = { 120, 200, 120 },
    upgrade = { spd = 0.8, atk = 1, hp = 3 },
    skills = {
        { name = "疾飞", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "spd", percent = 0.15 } },
        { name = "掠夺", unlock = 0, trigger = "on_kill",
          effect = "spirit_on_kill", params = { amount = 2 } },
        { name = "翼群", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", flat = 3, perAlly = true, aoeRange = 1 } },
        { name = "嗜血", unlock = 12, trigger = "on_kill",
          effect = "stat_buff", params = { stat = "attackSpeed", percent = 0.20, duration = 3 } },
        { name = "翼王之怒", unlock = 18, trigger = "on_death",
          effect = "summon", params = { unitId = "_幼翼", count = 2, hp = 50, atk = 8, duration = 8 } },
    },
}

-- 2. 羽弓猎手（绿，远程，骚扰）
UnitConfig.CARDS["羽弓猎手"] = {
    race = "avian", class = "ranged", quality = "green", slotType = "unit",
    buildingHp = 45, hp = 45, atk = 35, spd = 52, range = 2, pop = 1, prodTime = 5,
    icon = "羽", color = { 80, 200, 80 },
    upgrade = { atk = 1.5, hp = 2 },
    skills = {
        { name = "毒羽", unlock = 0, trigger = "on_attack",
          effect = "dot", params = { damage = 3, duration = 3, interval = 1 } },
        { name = "滑翔", unlock = 0, trigger = "passive",
          effect = "dodge", params = { chance = 0.15 } },
        { name = "剧毒", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "dotDamage", percent = 0.50 } },
        { name = "毒雾", unlock = 12, trigger = "on_death",
          effect = "slow", params = { percent = 0.30, duration = 3, range = 1 } },
        { name = "万毒侵蚀", unlock = 18, trigger = "on_attack",
          effect = "dot", params = { percentAtk = 0.20, duration = 5, interval = 1 } },
    },
}

-- 3. 猛禽勇士（蓝，近战，爆发）
UnitConfig.CARDS["猛禽勇士"] = {
    race = "avian", class = "melee", quality = "blue", slotType = "unit",
    buildingHp = 100, hp = 100, atk = 72, spd = 56, range = 1, pop = 2, prodTime = 7.5,
    icon = "猛", color = { 255, 160, 50 },
    upgrade = { atk = 3, hp = 6 },
    skills = {
        { name = "猛禽之威", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.12 } },
        { name = "俯冲", unlock = 0, trigger = "on_attack",
          effect = "damage", params = { firstAttackBonus = 0.50 } },
        { name = "撕裂", unlock = 6, trigger = "on_attack",
          effect = "dot", params = { damage = 5, duration = 3, interval = 1, chance = 1.0 } },
        { name = "鹰啸", unlock = 12, trigger = "on_attack",
          effect = "fear", params = { chance = 0.20, duration = 1, range = 1 } },
        { name = "翼族之王", unlock = 18, trigger = "on_timer", interval = 8,
          effect = "damage_aoe", params = { percent = 2.00, range = 2, slow = 0.50, slowDur = 2 } },
    },
}

-- 4. 风语祭司（蓝，远程，辅助）
UnitConfig.CARDS["风语祭司"] = {
    race = "avian", class = "ranged", quality = "blue", slotType = "unit",
    buildingHp = 75, hp = 75, atk = 44, spd = 48, range = 2, pop = 2, prodTime = 8,
    icon = "祭", color = { 255, 150, 200 },
    upgrade = { atk = 1.5, hp = 4, spd = 0.5 },
    skills = {
        { name = "魅惑", unlock = 0, trigger = "on_attack",
          effect = "charm", params = { chance = 0.10, duration = 2 } },
        { name = "灵巧", unlock = 0, trigger = "passive",
          effect = "dodge", params = { chance = 0.10 } },
        { name = "幻术", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "charmChance", flat = 0.05 } },
        { name = "分身", unlock = 12, trigger = "on_death",
          effect = "summon", params = { unitId = "_分身", count = 1, hpPercent = 0.50, atkPercent = 0.50, duration = 5 } },
        { name = "翼族魅惑", unlock = 18, trigger = "on_timer", interval = 10,
          effect = "convert", params = { count = 1, duration = 8 } },
    },
}

-- 5. 巨鹰领主（紫，近战，肉盾）
UnitConfig.CARDS["巨鹰领主"] = {
    race = "avian", class = "melee", quality = "purple", slotType = "unit",
    buildingHp = 280, hp = 280, atk = 85, spd = 36, range = 1, pop = 4, prodTime = 12,
    icon = "鹰", color = { 160, 100, 60 },
    upgrade = { hp = 20, atk = 2 },
    skills = {
        { name = "厚羽", unlock = 0, trigger = "passive",
          effect = "damage_reduce", params = { percent = 0.08 } },
        { name = "狂暴", unlock = 0, trigger = "hp_below", threshold = 0.5,
          effect = "stat_buff", params = { stat = "atk", percent = 0.30 } },
        { name = "震地", unlock = 6, trigger = "on_attack",
          effect = "stun", params = { chance = 0.15, duration = 1, range = 1 } },
        { name = "再生", unlock = 12, trigger = "passive",
          effect = "regen", params = { percent = 0.01 } },
        { name = "苍穹之怒", unlock = 18, trigger = "on_timer", interval = 10,
          effect = "damage_aoe", params = { percent = 1.80, range = 2, knockback = 1 } },
    },
}

-- 6. 翼族王尊（金，近战，爆发）
UnitConfig.CARDS["翼族王尊"] = {
    race = "avian", class = "melee", quality = "gold", slotType = "unit",
    buildingHp = 500, hp = 500, atk = 190, spd = 48, range = 1, pop = 8, prodTime = 16,
    icon = "尊", color = { 255, 255, 200 },
    upgrade = { atk = 7, hp = 20 },
    skills = {
        { name = "杀意", unlock = 0, trigger = "on_attack",
          effect = "damage", params = { bonusPercent = 0.50, condition = "target_hp_below", threshold = 0.3 } },
        { name = "翼步", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.15, condition = "moving" } },
        { name = "撕裂爪", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.20 } },
        { name = "嗜血狂攻", unlock = 12, trigger = "on_attack",
          effect = "stat_buff", params = { stat = "atk", percent = 0.10, stackMax = 5, condition = "same_target" } },
        { name = "翼族天杀", unlock = 18, trigger = "on_timer", interval = 6,
          effect = "damage_line", params = { percent = 2.50, range = 3 } },
        { name = "翼王降临", unlock = 0, trigger = "active", cooldown = 20,
          effect = "stat_buff", params = { stat = "atk", percent = 1.00, attackSpeed = 0.50, duration = 8 } },
    },
}

-- ============================================================================
-- 机械（人海消耗流）
-- ============================================================================

-- 1. 自爆机（绿，近战，人海）
UnitConfig.CARDS["自爆机"] = {
    race = "forge", class = "melee", quality = "green", slotType = "unit",
    buildingHp = 40, hp = 40, atk = 30, spd = 56, range = 1, pop = 1, prodTime = 3.5,
    icon = "爆", color = { 150, 80, 200 },
    upgrade = { hp = 3, atk = 0.8, spd = 1 },
    skills = {
        { name = "重启", unlock = 0, trigger = "on_death",
          effect = "revive", params = { chance = 0.08 } },
        { name = "集群", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", flat = 2, perAlly = true, aoeRange = 1 } },
        { name = "强化", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "reviveChance", flat = 0.04 } },
        { name = "吞噬", unlock = 12, trigger = "on_kill",
          effect = "heal", params = { percent = 0.05 } },
        { name = "自爆大军", unlock = 18, trigger = "on_death",
          effect = "summon", params = { unitId = "_自爆机", count = 2, hpPercent = 0.50, atkPercent = 0.50, duration = 6 } },
    },
}

-- 2. 侦察机（绿，远程，骚扰）
UnitConfig.CARDS["侦察机"] = {
    race = "forge", class = "ranged", quality = "green", slotType = "unit",
    buildingHp = 35, hp = 35, atk = 32, spd = 48, range = 2, pop = 1, prodTime = 4.5,
    icon = "侦", color = { 100, 50, 150 },
    upgrade = { atk = 1.2, hp = 2, spd = 1 },
    skills = {
        { name = "能量汲取", unlock = 0, trigger = "on_attack",
          effect = "lifesteal", params = { percent = 0.10 } },
        { name = "夜视", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.15, condition = "after_90s" } },
        { name = "声波", unlock = 6, trigger = "on_attack",
          effect = "silence", params = { chance = 0.15, duration = 2 } },
        { name = "过载", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "lifesteal", flat = 0.10 } },
        { name = "暗影狂袭", unlock = 18, trigger = "on_timer", interval = 8,
          effect = "damage", params = { percent = 2.00, target = "farthest_enemy", lifesteal = 0.50 } },
    },
}

-- 3. 蒸汽战犬（蓝，近战，输出）
UnitConfig.CARDS["蒸汽战犬"] = {
    race = "forge", class = "melee", quality = "blue", slotType = "unit",
    buildingHp = 95, hp = 95, atk = 60, spd = 52, range = 1, pop = 2, prodTime = 6.5,
    icon = "犬", color = { 255, 100, 50 },
    upgrade = { atk = 2.5, hp = 5 },
    skills = {
        { name = "蒸汽喷射", unlock = 0, trigger = "on_attack",
          effect = "damage", params = { flat = 5 } },
        { name = "灼烧", unlock = 0, trigger = "on_attack",
          effect = "dot", params = { chance = 0.20, percentAtk = 0.10, duration = 3, interval = 1 } },
        { name = "烈焰", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "fireDamage", percent = 0.50 } },
        { name = "炎爆", unlock = 12, trigger = "on_kill",
          effect = "explode_on_kill", params = { percent = 0.30, range = 1 } },
        { name = "熔核之火", unlock = 18, trigger = "on_timer", interval = 8,
          effect = "damage_aoe", params = { percent = 1.80, range = 2, dot = true, dotPercent = 0.10, dotDur = 3 } },
    },
}

-- 4. 维修机师（蓝，远程，召唤）
UnitConfig.CARDS["维修机师"] = {
    race = "forge", class = "ranged", quality = "blue", slotType = "unit",
    buildingHp = 65, hp = 65, atk = 40, spd = 40, range = 2, pop = 2, prodTime = 8,
    icon = "修", color = { 80, 150, 80 },
    upgrade = { atk = 1.5, hp = 4 },
    skills = {
        { name = "组装术", unlock = 0, trigger = "passive",
          effect = "extra_produce", params = { chance = 0.10, unitId = "_自爆机" } },
        { name = "零件回收", unlock = 0, trigger = "passive",
          effect = "heal", params = { percent = 0.03, condition = "nearby_enemy_death", aoeRange = 3 } },
        { name = "召唤", unlock = 6, trigger = "on_timer", interval = 15,
          effect = "summon", params = { unitId = "_机甲兵", count = 1, hp = 60, atk = 10 } },
        { name = "量产", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "extraProduceChance", flat = 0.10 } },
        { name = "重启复苏", unlock = 18, trigger = "on_timer", interval = 10,
          effect = "revive", params = { count = 1, hpPercent = 0.50, duration = 8, target = "last_dead_ally" } },
    },
}

-- 5. 熔核巨兵（紫，近战，吸血）
UnitConfig.CARDS["熔核巨兵"] = {
    race = "forge", class = "melee", quality = "purple", slotType = "unit",
    buildingHp = 200, hp = 200, atk = 105, spd = 44, range = 1, pop = 4, prodTime = 11,
    icon = "熔", color = { 200, 30, 30 },
    upgrade = { atk = 4, hp = 15 },
    skills = {
        { name = "能量汲取", unlock = 0, trigger = "on_attack",
          effect = "lifesteal", params = { percent = 0.15 } },
        { name = "杀戮", unlock = 0, trigger = "on_kill",
          effect = "stat_buff", params = { stat = "atk", percent = 0.10, duration = 5 } },
        { name = "熔核之力", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.50, condition = "hp_scaling" } },
        { name = "不死", unlock = 12, trigger = "on_hit",
          effect = "survive", params = { chance = 0.15 } },
        { name = "熔核领域", unlock = 18, trigger = "on_timer", interval = 8,
          effect = "stat_buff", params = { stat = "lifesteal", flat = 0.30, target = "nearby_allies", aoeRange = 3, duration = 5 } },
    },
}

-- 6. 机械总帅（金，远程，AOE）
UnitConfig.CARDS["机械总帅"] = {
    race = "forge", class = "ranged", quality = "gold", slotType = "unit",
    buildingHp = 420, hp = 420, atk = 175, spd = 36, range = 3, pop = 8, prodTime = 16,
    icon = "帅", color = { 80, 0, 120 },
    upgrade = { atk = 6, hp = 20 },
    skills = {
        { name = "死亡光环", unlock = 0, trigger = "passive",
          effect = "aura_damage", params = { percentMaxHp = 0.02, range = 2, interval = 1 } },
        { name = "灵魂汲取", unlock = 0, trigger = "passive",
          effect = "lifesteal", params = { percent = 0.30, source = "aura" } },
        { name = "瓦解", unlock = 6, trigger = "passive",
          effect = "damage_taken_increase", params = { percent = 0.20, target = "enemies_in_aura" } },
        { name = "死亡领域", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "auraRange", flat = 1 } },
        { name = "熔核之门", unlock = 18, trigger = "on_timer", interval = 8,
          effect = "damage_aoe", params = { percentAtk = 0.30, range = 2, duration = 3, interval = 1 } },
        { name = "灭世", unlock = 0, trigger = "active", cooldown = 20,
          effect = "damage_aoe", params = { percentMaxHp = 0.15, range = 999, summon = "_自爆机", summonCount = 3 } },
    },
}

-- ============================================================================
-- 元素（远程输出流）
-- ============================================================================

-- 1. 光元素（绿，远程，输出）
UnitConfig.CARDS["光元素"] = {
    race = "astral", class = "ranged", quality = "green", slotType = "unit",
    buildingHp = 50, hp = 50, atk = 44, spd = 48, range = 2, pop = 1, prodTime = 5,
    icon = "光", color = { 255, 255, 180 },
    upgrade = { atk = 1.5, hp = 2, spd = 0.5 },
    skills = {
        { name = "光耀", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "attackSpeed", percent = 0.10 } },
        { name = "聚焦", unlock = 0, trigger = "on_attack",
          effect = "stat_buff", params = { stat = "atk", percent = 0.05, stackMax = 4, condition = "same_target" } },
        { name = "闪光", unlock = 6, trigger = "on_attack",
          effect = "stun", params = { chance = 0.10, duration = 1 } },
        { name = "光束", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "focusStackMax", flat = 2 } },
        { name = "极光射线", unlock = 18, trigger = "on_timer", interval = 10,
          effect = "damage_line", params = { percent = 2.00 } },
    },
}

-- 2. 冰元素（绿，远程，控制）
UnitConfig.CARDS["冰元素"] = {
    race = "astral", class = "ranged", quality = "green", slotType = "unit",
    buildingHp = 50, hp = 50, atk = 38, spd = 44, range = 2, pop = 1, prodTime = 5,
    icon = "冰", color = { 150, 220, 255 },
    upgrade = { hp = 3, atk = 1 },
    skills = {
        { name = "寒冰", unlock = 0, trigger = "on_attack",
          effect = "slow", params = { percent = 0.15, duration = 2 } },
        { name = "冰甲", unlock = 0, trigger = "passive",
          effect = "damage_reduce", params = { percent = 0.10, condition = "melee_damage" } },
        { name = "冰冻", unlock = 6, trigger = "on_attack",
          effect = "stun", params = { chance = 0.08, duration = 1 } },
        { name = "霜冻", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "slowPercent", flat = 0.10 } },
        { name = "暴风雪", unlock = 18, trigger = "on_timer", interval = 10,
          effect = "damage_aoe", params = { percent = 1.50, range = 2, slow = 0.50, slowDur = 3 } },
    },
}

-- 3. 雷元素（蓝，远程，爆发）
UnitConfig.CARDS["雷元素"] = {
    race = "astral", class = "ranged", quality = "blue", slotType = "unit",
    buildingHp = 75, hp = 75, atk = 70, spd = 52, range = 2, pop = 2, prodTime = 7.5,
    icon = "雷", color = { 200, 180, 255 },
    upgrade = { atk = 3, hp = 4, spd = 0.5 },
    skills = {
        { name = "雷电", unlock = 0, trigger = "passive",
          effect = "crit_buff", params = { critRate = 0.12 } },
        { name = "连锁", unlock = 0, trigger = "on_attack",
          effect = "chain", params = { chance = 0.20, targets = 1, percent = 1.0 } },
        { name = "雷击", unlock = 6, trigger = "passive",
          effect = "crit_buff", params = { critDamage = 0.40 } },
        { name = "闪电链", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "chainTargets", flat = 1 } },
        { name = "雷霆万钧", unlock = 18, trigger = "on_timer", interval = 8,
          effect = "damage_aoe", params = { percent = 1.80, range = 3, targetCount = 3, random = true } },
    },
}

-- 4. 风元素（蓝，远程，辅助）
UnitConfig.CARDS["风元素"] = {
    race = "astral", class = "ranged", quality = "blue", slotType = "unit",
    buildingHp = 60, hp = 60, atk = 48, spd = 56, range = 2, pop = 2, prodTime = 6.5,
    icon = "风", color = { 180, 255, 200 },
    upgrade = { spd = 0.8, atk = 1.5, hp = 3 },
    skills = {
        { name = "疾风", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "spd", percent = 0.12 } },
        { name = "风盾", unlock = 0, trigger = "passive",
          effect = "dodge", params = { chance = 0.10 } },
        { name = "顺风", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "spd", percent = 0.08, target = "nearby_allies", aoeRange = 2 } },
        { name = "风之壁垒", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "dodgeChance", flat = 0.08 } },
        { name = "龙卷风", unlock = 18, trigger = "on_timer", interval = 10,
          effect = "suspend", params = { count = 1, duration = 3 } },
    },
}

-- 5. 火元素（紫，远程，AOE）
UnitConfig.CARDS["火元素"] = {
    race = "astral", class = "ranged", quality = "purple", slotType = "unit",
    buildingHp = 150, hp = 150, atk = 110, spd = 40, range = 3, pop = 4, prodTime = 11,
    icon = "火", color = { 255, 100, 30 },
    upgrade = { atk = 5, hp = 10 },
    skills = {
        { name = "灼烧", unlock = 0, trigger = "on_attack",
          effect = "dot", params = { percentAtk = 0.08, duration = 3, interval = 1 } },
        { name = "爆裂", unlock = 0, trigger = "on_kill",
          effect = "explode_on_kill", params = { percent = 0.30, range = 1 } },
        { name = "烈焰", unlock = 6, trigger = "passive",
          effect = "stat_buff", params = { stat = "dotDamage", percent = 0.50 } },
        { name = "火焰风暴", unlock = 12, trigger = "on_attack",
          effect = "damage_aoe", params = { chance = 0.20, percent = 0.80, range = 1 } },
        { name = "焚天烈焰", unlock = 18, trigger = "on_timer", interval = 7,
          effect = "damage_aoe", params = { percent = 2.00, range = 2, dot = true, dotPercent = 0.08, dotDur = 3 } },
    },
}

-- 6. 混沌元素（金，远程，全能）
UnitConfig.CARDS["混沌元素"] = {
    race = "astral", class = "ranged", quality = "gold", slotType = "unit",
    buildingHp = 380, hp = 380, atk = 170, spd = 40, range = 3, pop = 8, prodTime = 16,
    icon = "混", color = { 180, 100, 255 },
    upgrade = { atk = 5, hp = 20 },
    skills = {
        { name = "混沌之力", unlock = 0, trigger = "passive",
          effect = "stat_buff", params = { stat = "atk", percent = 0.15, attackSpeed = 0.10 } },
        { name = "元素护盾", unlock = 0, trigger = "on_timer", interval = 10,
          effect = "shield", params = { percentMaxHp = 0.20 } },
        { name = "混沌波动", unlock = 6, trigger = "on_attack",
          effect = "damage_aoe", params = { chance = 0.25, percent = 1.00, range = 1 } },
        { name = "元素亲和", unlock = 12, trigger = "passive",
          effect = "stat_buff", params = { stat = "elementDamage", percent = 0.25 } },
        { name = "混沌裂隙", unlock = 18, trigger = "on_timer", interval = 6,
          effect = "damage_aoe", params = { percentAtk = 0.25, range = 2, duration = 3, interval = 1 } },
        { name = "混沌降临", unlock = 0, trigger = "active", cooldown = 18,
          effect = "transform", params = { atkPercent = 0.50, rangeBonus = 1, aoe = true, duration = 8 } },
    },
}

-- ============================================================================
-- 兵营等级→卡牌产出概率映射
-- ============================================================================

-- 建筑价格→品质概率（所有建筑通用：兵营/矿脉/炮台）
UnitConfig.QUALITY_PRODUCE = {
    [50]  = { green = 0.74, blue = 0.20, purple = 0.05, gold = 0.01 },  -- 50晶核
    [100] = { green = 0.35, blue = 0.45, purple = 0.15, gold = 0.05 },  -- 100晶核
    [250] = { green = 0.00, blue = 0.00, purple = 0.85, gold = 0.15 },  -- 250晶核
}
-- 兼容旧引用
UnitConfig.BARRACKS_PRODUCE = UnitConfig.QUALITY_PRODUCE

-- ============================================================================
-- 辅助函数
-- ============================================================================

--- 获取指定种族的所有卡牌
---@param race string
---@return table[] cards { name, data }
function UnitConfig.GetCardsByRace(race)
    local result = {}
    for name, data in pairs(UnitConfig.CARDS) do
        if data.race == race then
            result[#result + 1] = { name = name, data = data }
        end
    end
    return result
end

--- 获取指定品质的所有卡牌
---@param quality string
---@return table[] cards { name, data }
function UnitConfig.GetCardsByQuality(quality)
    local result = {}
    for name, data in pairs(UnitConfig.CARDS) do
        if data.quality == quality then
            result[#result + 1] = { name = name, data = data }
        end
    end
    return result
end

--- 获取指定种族+品质的卡牌
---@param race string
---@param quality string
---@return table[] cards { name, data }
function UnitConfig.GetCardsByRaceAndQuality(race, quality)
    local result = {}
    for name, data in pairs(UnitConfig.CARDS) do
        if data.race == race and data.quality == quality then
            result[#result + 1] = { name = name, data = data }
        end
    end
    return result
end

--- 获取卡牌已解锁的技能列表（根据卡牌等级）
---@param cardName string
---@param cardLevel integer
---@return table[] skills
function UnitConfig.GetUnlockedSkills(cardName, cardLevel)
    local card = UnitConfig.CARDS[cardName]
    if not card then return {} end

    local result = {}
    ---@diagnostic disable-next-line: param-type-mismatch
    for _, skill in ipairs(card.skills) do
        if cardLevel >= skill.unlock then
            result[#result + 1] = skill
        end
    end
    return result
end

return UnitConfig


-- ══════════════════════════════════════════════
