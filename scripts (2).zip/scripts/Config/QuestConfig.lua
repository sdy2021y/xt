-- ══════════════════════════════════════════════
-- ============================================================================
-- QuestConfig.lua - 每日/每周任务配置
-- 定义所有任务的条件、奖励、重置周期
-- ============================================================================

local QuestConfig = {}

-- ========== 任务类型枚举 ==========
QuestConfig.TYPE = {
    DAILY = "daily",
    WEEKLY = "weekly",
}

-- ========== 追踪事件类型 ==========
QuestConfig.EVENT = {
    BATTLE_COMPLETE = "battle_complete",       -- 完成对战
    BATTLE_WIN = "battle_win",                 -- 获得胜利
    TILE_FLIP = "tile_flip",                   -- 翻格子
    SYNERGY_TRIGGER = "synergy_trigger",       -- 触发羁绊
    BUILDING_DESTROY = "building_destroy",     -- 拆除敌方建筑
    CARD_UPGRADE = "card_upgrade",             -- 升级卡牌
    ARTIFACT_USE = "artifact_use",             -- 使用神器
    WIN_WITH_RACE = "win_with_race",           -- 用特定种族胜利
}

-- ========== 每日任务定义 ==========
QuestConfig.DAILY = {
    {
        id = "daily_battle",
        name = "日常对战",
        desc = "完成3场对战",
        event = QuestConfig.EVENT.BATTLE_COMPLETE,
        target = 3,
        rewards = {
            gold = 200,
            xianyu = 20,
        },
    },
    {
        id = "daily_flip",
        name = "翻格子",
        desc = "在对战中翻15个格子",
        event = QuestConfig.EVENT.TILE_FLIP,
        target = 15,
        rewards = {
            gold = 200,
            xianyu = 20,
        },
    },
    {
        id = "daily_win",
        name = "胜利奖励",
        desc = "获得1场胜利",
        event = QuestConfig.EVENT.BATTLE_WIN,
        target = 1,
        rewards = {
            gold = 300,
            xianyu = 30,
        },
    },
    {
        id = "daily_synergy",
        name = "羁绊触发",
        desc = "在对战中触发任意1个羁绊效果",
        event = QuestConfig.EVENT.SYNERGY_TRIGGER,
        target = 1,
        rewards = {
            gold = 100,
            runes = 5,
        },
    },
    {
        id = "daily_destroy",
        name = "拆除建筑",
        desc = "在对战中拆除敌方3个建筑",
        event = QuestConfig.EVENT.BUILDING_DESTROY,
        target = 3,
        rewards = {
            gold = 100,
            runes = 5,
        },
    },
}

-- ========== 每周任务定义 ==========
QuestConfig.WEEKLY = {
    {
        id = "weekly_wins",
        name = "胜场大师",
        desc = "获得10场胜利",
        event = QuestConfig.EVENT.BATTLE_WIN,
        target = 10,
        rewards = {
            gold = 1000,
            xianyu = 100,
        },
    },
    {
        id = "weekly_race_wins",
        name = "特定种族",
        desc = "用联盟/翼族/机械/元素各胜利2场",
        event = QuestConfig.EVENT.WIN_WITH_RACE,
        target = 2,           -- 每种族2场
        raceTarget = true,    -- 标记需要4种族各自达标
        rewards = {
            gold = 800,
            xianyu = 80,
        },
    },
    {
        id = "weekly_battles",
        name = "累计对局",
        desc = "完成30场对战",
        event = QuestConfig.EVENT.BATTLE_COMPLETE,
        target = 30,
        rewards = {
            gold = 600,
            runes = 30,
        },
    },
    {
        id = "weekly_upgrade",
        name = "升级卡牌",
        desc = "升级任意卡牌5次",
        event = QuestConfig.EVENT.CARD_UPGRADE,
        target = 5,
        rewards = {
            gold = 600,
            runes = 30,
        },
    },
    {
        id = "weekly_artifact",
        name = "使用神器",
        desc = "在对战中使用神器累计10次",
        event = QuestConfig.EVENT.ARTIFACT_USE,
        target = 10,
        rewards = {
            gold = 400,
            runes = 20,
        },
    },
}

-- ========== 全部完成额外奖励 ==========
QuestConfig.DAILY_ALL_COMPLETE_BONUS = {
    gold = 400,
    xianyu = 50,
}

QuestConfig.WEEKLY_ALL_COMPLETE_BONUS = {
    gold = 1500,
    xianyu = 200,
}

return QuestConfig


-- ══════════════════════════════════════════════
