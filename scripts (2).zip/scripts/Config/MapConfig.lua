-- ============================================================================
-- MapConfig.lua - 地图模板系统
-- 每个模板是一个 generate(playerCount, teamCount) 函数
-- 返回 { hexes, spawns, bounds }，Server.InitGrid 直接消费
-- ============================================================================

local HexGrid = require("Battle.HexGrid")
local SpawnConfig = require("Config.SpawnConfig")
local GameConfig = require("Config.GameConfig")

local MapConfig = {}

--- @class MapTemplate
--- @field name string 模板名称
--- @field description string 模板描述
--- @field minPlayers integer 最少支持玩家数
--- @field maxPlayers integer 最多支持玩家数
--- @field generate fun(playerCount: integer, teamCount: integer): MapResult

--- @class MapResult
--- @field hexes table[] { {q, r}, ... } 所有格子坐标
--- @field spawns table[] { {slot, team, q, r}, ... } 主城坐标
--- @field bounds table { [team] = {startRow, endRow} } 领地划分

-- ============================================================================
-- 模板注册表
-- ============================================================================

MapConfig.TEMPLATES = {}

-- ────────────────────────────────────────────────────────────
-- 模板1: 矩形战场（经典）
-- 当前线上版本的标准地图
-- ────────────────────────────────────────────────────────────
MapConfig.TEMPLATES["rect_classic"] = {
    name = "矩形战场",
    description = "标准矩形对战地图",
    minPlayers = 2,
    maxPlayers = 8,
    generate = function(playerCount, teamCount)
        local cols = GameConfig.HEX.GRID_COLS
        local rows = GameConfig.HEX.GRID_ROWS

        local hexes = HexGrid.GenerateRectGrid(cols, rows)
        local spawns = SpawnConfig.Calculate(cols, rows, playerCount, teamCount)
        local bounds = SpawnConfig.GetTerritoryBounds(rows, teamCount)

        return { hexes = hexes, spawns = spawns, bounds = bounds }
    end,
}

-- ────────────────────────────────────────────────────────────
-- 模板2: 漏斗战场
-- 上下宽中间窄，战斗集中在中路瓶颈
-- ────────────────────────────────────────────────────────────
MapConfig.TEMPLATES["funnel"] = {
    name = "漏斗战场",
    description = "中路收窄，攻防焦点集中",
    minPlayers = 2,
    maxPlayers = 4,
    generate = function(playerCount, teamCount)
        local baseWidth = 15    -- 上下底最宽列数
        local neckWidth = 5     -- 中间瓶颈列数
        local rows = 22
        local neckRows = 3      -- 瓶颈持续行数

        local hexes = {}
        for q = 0, baseWidth - 1 do
            local rOffset = -math.floor(q / 2)
            for r = rOffset, rOffset + rows - 1 do
                local rowIndex = r - rOffset

                -- 计算该行允许的最大宽度（线性插值）
                local halfRows = rows / 2
                local neckStart = halfRows - neckRows / 2
                local neckEnd = halfRows + neckRows / 2

                local allowedWidth
                if rowIndex >= neckStart and rowIndex < neckEnd then
                    -- 瓶颈区：固定窄宽
                    allowedWidth = neckWidth
                else
                    -- 过渡区：线性插值
                    local distFromNeck
                    if rowIndex < neckStart then
                        distFromNeck = (neckStart - rowIndex) / neckStart
                    else
                        distFromNeck = (rowIndex - neckEnd + 1) / (rows - neckEnd)
                    end
                    distFromNeck = math.min(1.0, math.max(0.0, distFromNeck))
                    allowedWidth = math.floor(neckWidth + (baseWidth - neckWidth) * distFromNeck)
                    -- 保证奇数对称
                    if allowedWidth % 2 == 0 then
                        allowedWidth = math.min(baseWidth, allowedWidth + 1)
                    end
                end

                local margin = math.floor((baseWidth - allowedWidth) / 2)
                if q >= margin and q < baseWidth - margin then
                    hexes[#hexes + 1] = { q = q, r = r }
                end
            end
        end

        local spawns = SpawnConfig.Calculate(baseWidth, rows, playerCount, teamCount)
        local bounds = SpawnConfig.GetTerritoryBounds(rows, teamCount)

        return { hexes = hexes, spawns = spawns, bounds = bounds }
    end,
}

-- ────────────────────────────────────────────────────────────
-- 模板3: H型战场（双路）
-- 中间大段断开，形成左右两条进攻路线
-- ────────────────────────────────────────────────────────────
MapConfig.TEMPLATES["two_lane"] = {
    name = "双路战场",
    description = "中间阻隔，形成左右两路",
    minPlayers = 2,
    maxPlayers = 4,
    generate = function(playerCount, teamCount)
        local cols = 15
        local rows = 22
        local midCol = math.floor(cols / 2)  -- 7

        -- 断开区域：中间列在 row 6~15 之间挖空
        local gapStart = 6
        local gapEnd = 15

        local hexes = {}
        for q = 0, cols - 1 do
            local rOffset = -math.floor(q / 2)
            for r = rOffset, rOffset + rows - 1 do
                local rowIndex = r - rOffset

                -- 中间列在断开区域内不生成格子
                if q == midCol and rowIndex >= gapStart and rowIndex <= gapEnd then
                    -- 跳过：天然阻隔
                else
                    hexes[#hexes + 1] = { q = q, r = r }
                end
            end
        end

        local spawns = SpawnConfig.Calculate(cols, rows, playerCount, teamCount)
        -- 修正出生点避开挖空列
        for _, spawn in ipairs(spawns) do
            if spawn.q == midCol then
                spawn.q = midCol - 2  -- 移到左路
            end
        end
        local bounds = SpawnConfig.GetTerritoryBounds(rows, teamCount)

        return { hexes = hexes, spawns = spawns, bounds = bounds }
    end,
}

-- ────────────────────────────────────────────────────────────
-- 模板4: 菱形战场
-- 紧凑的菱形区域，格子更少但节奏更快
-- ────────────────────────────────────────────────────────────
MapConfig.TEMPLATES["diamond"] = {
    name = "菱形战场",
    description = "菱形区域，快节奏对战",
    minPlayers = 2,
    maxPlayers = 2,
    generate = function(playerCount, teamCount)
        local radius = 8  -- 菱形半径（hex distance 从中心算起）

        local hexes = {}
        for q = -radius, radius do
            for r = -radius, radius do
                local s = -q - r
                if math.abs(s) <= radius then
                    hexes[#hexes + 1] = { q = q, r = r }
                end
            end
        end

        -- 菱形地图的出生点：沿 r 轴两端
        local spawns = {
            { slot = 1, team = 1, q = 0, r = radius - 2 },
            { slot = 2, team = 2, q = 0, r = -(radius - 2) },
        }

        -- 领地按 r 划分：r > 0 → 队伍1, r < 0 → 队伍2
        local bounds = {
            [1] = { startRow = 1, endRow = radius },
            [2] = { startRow = -radius, endRow = -1 },
        }

        return { hexes = hexes, spawns = spawns, bounds = bounds }
    end,
}

-- ============================================================================
-- 2v2 地图模板（18列 × 26行）
-- ============================================================================

-- ────────────────────────────────────────────────────────────
-- 模板5: 宽矩形（2v2基础）
-- 18列全通，纯拼经济和操作
-- ────────────────────────────────────────────────────────────
MapConfig.TEMPLATES["2v2_rect"] = {
    name = "宽矩形战场",
    description = "2v2标准宽矩形地图",
    minPlayers = 4,
    maxPlayers = 4,
    generate = function(playerCount, teamCount)
        local cols = 18
        local rows = 26

        local hexes = HexGrid.GenerateRectGrid(cols, rows)
        local spawns = SpawnConfig.Calculate(cols, rows, playerCount, teamCount)
        local bounds = SpawnConfig.GetTerritoryBounds(rows, teamCount)

        return { hexes = hexes, spawns = spawns, bounds = bounds }
    end,
}

-- ────────────────────────────────────────────────────────────
-- 模板6: 蝴蝶双翼（2v2）
-- 左8右8中间断开，上下各有3行连通带
-- ────────────────────────────────────────────────────────────
MapConfig.TEMPLATES["2v2_butterfly"] = {
    name = "蝴蝶双翼",
    description = "各守一翼，支援需绕行",
    minPlayers = 4,
    maxPlayers = 4,
    generate = function(playerCount, teamCount)
        local cols = 18
        local rows = 26
        local midCol = 9  -- 中间列

        -- 连通带：row 9~11 和 row 15~17
        local bridgeRows = {}
        for r = 9, 11 do bridgeRows[r] = true end
        for r = 15, 17 do bridgeRows[r] = true end

        local hexes = {}
        for q = 0, cols - 1 do
            local rOffset = -math.floor(q / 2)
            for r = rOffset, rOffset + rows - 1 do
                local rowIndex = r - rOffset
                -- 中间列在非连通带区域断开
                if q == midCol and not bridgeRows[rowIndex] then
                    -- 跳过：天然阻隔
                else
                    hexes[#hexes + 1] = { q = q, r = r }
                end
            end
        end

        local spawns = SpawnConfig.Calculate(cols, rows, playerCount, teamCount)
        local bounds = SpawnConfig.GetTerritoryBounds(rows, teamCount)

        return { hexes = hexes, spawns = spawns, bounds = bounds }
    end,
}

-- ────────────────────────────────────────────────────────────
-- 模板7: 中央竞技场（2v2）
-- 左7右7，中间4列空，上下汇入中央开阔区
-- ────────────────────────────────────────────────────────────
MapConfig.TEMPLATES["2v2_arena"] = {
    name = "中央竞技场",
    description = "前期两翼发育，中后期中央混战",
    minPlayers = 4,
    maxPlayers = 4,
    generate = function(playerCount, teamCount)
        local cols = 18
        local rows = 26
        local midCols = { 7, 8, 9, 10 }  -- 中间4列

        -- 中央开阔区：row 9~18（10行）
        local arenaStart = 9
        local arenaEnd = 18

        local hexes = {}
        for q = 0, cols - 1 do
            local rOffset = -math.floor(q / 2)
            for r = rOffset, rOffset + rows - 1 do
                local rowIndex = r - rOffset
                local isMidCol = (q >= 7 and q <= 10)

                if isMidCol and (rowIndex < arenaStart or rowIndex > arenaEnd) then
                    -- 中间列在非中央区域不生成
                else
                    hexes[#hexes + 1] = { q = q, r = r }
                end
            end
        end

        local spawns = SpawnConfig.Calculate(cols, rows, playerCount, teamCount)
        local bounds = SpawnConfig.GetTerritoryBounds(rows, teamCount)

        return { hexes = hexes, spawns = spawns, bounds = bounds }
    end,
}

-- ============================================================================
-- 公共 API
-- ============================================================================

--- 获取所有模板 ID 列表
---@return string[]
function MapConfig.GetTemplateIds()
    local ids = {}
    for id, _ in pairs(MapConfig.TEMPLATES) do
        ids[#ids + 1] = id
    end
    return ids
end

--- 随机选择一个适配当前玩家数的模板
---@param playerCount? integer 玩家数（默认2）
---@return string templateId
function MapConfig.RandomTemplate(playerCount)
    playerCount = playerCount or 2
    local candidates = {}
    for id, tmpl in pairs(MapConfig.TEMPLATES) do
        if playerCount >= tmpl.minPlayers and playerCount <= tmpl.maxPlayers then
            candidates[#candidates + 1] = id
        end
    end
    if #candidates == 0 then
        return "rect_classic"  -- 兜底
    end
    return candidates[math.random(1, #candidates)]
end

--- 根据 ID 生成地图数据
---@param templateId string
---@param playerCount? integer
---@param teamCount? integer
---@return MapResult
function MapConfig.Generate(templateId, playerCount, teamCount)
    playerCount = playerCount or 2
    teamCount = teamCount or 2
    local tmpl = MapConfig.TEMPLATES[templateId]
    if not tmpl then
        print("[MapConfig] WARNING: unknown template '" .. tostring(templateId) .. "', fallback to rect_classic")
        tmpl = MapConfig.TEMPLATES["rect_classic"]
    end
    return tmpl.generate(playerCount, teamCount)
end

return MapConfig
