-- ══════════════════════════════════════════════
-- ============================================================================
-- ArenaConfig.lua - 竞技场（境界）配置
-- 类似皇室战争/占城大师的竞技场分段系统
-- ============================================================================

local ArenaConfig = {}

-- 境界（竞技场）列表，从低到高
ArenaConfig.ARENAS = {
    {
        id = 1,
        name = "练气境",
        subtitle = "修仙起步",
        trophyRequired = 0,       -- 进入所需奖杯
        trophyMax = 100,          -- 升入下一境界所需
        rewardGold = 50,
        rewardGems = 5,
        color = "#4CAF50",        -- 绿色系
        bgColor = "#1B5E20",
    },
    {
        id = 2,
        name = "筑基境",
        subtitle = "根基初成",
        trophyRequired = 100,
        trophyMax = 300,
        rewardGold = 100,
        rewardGems = 10,
        color = "#2196F3",        -- 蓝色系
        bgColor = "#0D47A1",
    },
    {
        id = 3,
        name = "金丹境",
        subtitle = "凝聚金丹",
        trophyRequired = 300,
        trophyMax = 600,
        rewardGold = 200,
        rewardGems = 20,
        color = "#9C27B0",        -- 紫色系
        bgColor = "#4A148C",
    },
    {
        id = 4,
        name = "元婴境",
        subtitle = "元婴出窍",
        trophyRequired = 600,
        trophyMax = 1000,
        rewardGold = 400,
        rewardGems = 35,
        color = "#FF9800",        -- 橙色系
        bgColor = "#E65100",
    },
    {
        id = 5,
        name = "化神境",
        subtitle = "神魂大成",
        trophyRequired = 1000,
        trophyMax = 1600,
        rewardGold = 600,
        rewardGems = 50,
        color = "#F44336",        -- 红色系
        bgColor = "#B71C1C",
    },
    {
        id = 6,
        name = "渡劫境",
        subtitle = "天劫降临",
        trophyRequired = 1600,
        trophyMax = 2500,
        rewardGold = 1000,
        rewardGems = 80,
        color = "#FFD700",        -- 金色系
        bgColor = "#5D4E37",
    },
}

-- 段位配置（每个境界内的小段位）
ArenaConfig.RANKS = {
    { id = 1, name = "青铜", icon = "★", color = "#CD7F32" },
    { id = 2, name = "白银", icon = "★★", color = "#C0C0C0" },
    { id = 3, name = "黄金", icon = "★★★", color = "#FFD700" },
}

-- 根据奖杯数获取当前境界
function ArenaConfig.GetArenaByTrophies(trophies)
    local result = ArenaConfig.ARENAS[1]
    for i = #ArenaConfig.ARENAS, 1, -1 do
        if trophies >= ArenaConfig.ARENAS[i].trophyRequired then
            result = ArenaConfig.ARENAS[i]
            break
        end
    end
    return result
end

-- 根据奖杯数获取当前段位
function ArenaConfig.GetRankByTrophies(trophies)
    local arena = ArenaConfig.GetArenaByTrophies(trophies)
    local trophyInArena = trophies - arena.trophyRequired
    local arenaRange = arena.trophyMax - arena.trophyRequired
    local rankCount = #ArenaConfig.RANKS

    local rankIndex = math.floor(trophyInArena / (arenaRange / rankCount)) + 1
    rankIndex = math.min(rankIndex, rankCount)
    return ArenaConfig.RANKS[rankIndex]
end

-- 获取晋级进度 (0.0 ~ 1.0)
function ArenaConfig.GetProgress(trophies)
    local arena = ArenaConfig.GetArenaByTrophies(trophies)
    local trophyInArena = trophies - arena.trophyRequired
    local arenaRange = arena.trophyMax - arena.trophyRequired
    return math.min(trophyInArena / arenaRange, 1.0)
end

return ArenaConfig


-- ══════════════════════════════════════════════
