-- ============================================================================
-- PowerCalculator.lua - 战力计算器
-- 战力 = 卡组战力 + 据点战力 + 收藏加成
-- 战力反映"硬实力"，是段位攀爬的基础
-- ============================================================================

local UnitConfig = require("Config.UnitConfig")
local PlayerDataManager = require("Data.PlayerDataManager")
local DeckManager = require("Battle.DeckManager")

local PowerCalculator = {}

-- 品质系数
local QUALITY_MULT = {
    green  = 1.0,
    blue   = 1.8,
    purple = 3.2,
    gold   = 6.0,
}

--- 计算单卡战力
---@param cardName string
---@param cardLevel integer 卡牌等级（1-based）
---@return number
function PowerCalculator.CardPower(cardName, cardLevel)
    local card = UnitConfig.CARDS[cardName]
    if not card then return 0 end

    -- 非单位卡（矿脉/炮台）贡献固定低战力
    local slotType = card.slotType or "unit"
    if slotType ~= "unit" then
        return 20
    end

    local qualityMult = QUALITY_MULT[card.quality] or 1.0
    local levelMult = 1 + (cardLevel - 1) * 0.25  -- Lv1=1.0, Lv2=1.25, Lv3=1.5...
    return (card.hp + card.atk * 5) * qualityMult * levelMult
end

--- 计算卡组战力（8张卡的总和）
---@param deck string[] 卡牌名数组
---@return number
function PowerCalculator.DeckPower(deck)
    if not deck then return 0 end
    local power = 0
    for _, cardName in ipairs(deck) do
        local cardData = PlayerDataManager.GetCard(cardName)
        local level = cardData and cardData.level or 1
        power = power + PowerCalculator.CardPower(cardName, level)
    end
    return power
end

--- 计算玩家总战力
--- 战力 = 卡组战力 + 据点战力 + 收藏加成
---@return integer power
function PowerCalculator.Calculate()
    local pd = PlayerDataManager.GetData()
    if not pd then return 0 end

    -- 1. 卡组战力：使用当前活跃卡组
    local deck = DeckManager.GetPlayerDeckOrDefault()
    local deckPower = PowerCalculator.DeckPower(deck)

    -- 2. 据点战力：据点等级 × 50
    local caveLevel = pd.caveLevel or 1
    local cavePower = caveLevel * 50

    -- 3. 收藏加成：每5张已解锁卡 +10
    local unlockedCount = 0
    if pd.unlockedCards then
        unlockedCount = #pd.unlockedCards
    end
    local collectionBonus = math.floor(unlockedCount / 5) * 10

    return math.floor(deckPower + cavePower + collectionBonus)
end

--- 计算 AI 战力（基于段位）
---@param tierIndex integer 段位索引（0=青铜, 1=白银, ...）
---@return integer power
function PowerCalculator.AIPower(tierIndex)
    -- AI 战力按段位线性增长
    -- 青铜~300, 白银~500, 黄金~800, 铂金~1100, 钻石~1500, 星耀~2000, 王者~2500
    local basePowers = { 300, 500, 800, 1100, 1500, 2000, 2500, 3000 }
    local idx = math.min(tierIndex + 1, #basePowers)
    return basePowers[idx] + math.random(-30, 30)
end

--- 获取 AI 强度配置（段位绑定）
---@param tierIndex integer 段位索引
---@return table { cardLevelBonus, caveLevel, spiritMineBonus }
function PowerCalculator.GetAIStrength(tierIndex)
    -- 段位越高，AI 卡牌等级/据点等级/矿脉加成越高
    local strengths = {
        { cardLevelBonus = 0,  caveLevel = 1, spiritMineBonus = 0 },    -- 青铜
        { cardLevelBonus = 0,  caveLevel = 1, spiritMineBonus = 0.05 }, -- 白银
        { cardLevelBonus = 0,  caveLevel = 2, spiritMineBonus = 0.08 }, -- 黄金（★从1改0）
        { cardLevelBonus = 1,  caveLevel = 2, spiritMineBonus = 0.10 }, -- 铂金
        { cardLevelBonus = 1,  caveLevel = 3, spiritMineBonus = 0.15 }, -- 钻石（★从2改1）
        { cardLevelBonus = 2,  caveLevel = 4, spiritMineBonus = 0.20 }, -- 星耀
        { cardLevelBonus = 2,  caveLevel = 5, spiritMineBonus = 0.25 }, -- 王者（★从3改2）
        { cardLevelBonus = 3,  caveLevel = 6, spiritMineBonus = 0.30 }, -- 荣耀王者
    }
    local idx = math.max(1, math.min(tierIndex + 1, #strengths))
    return strengths[idx] or strengths[1]
end

return PowerCalculator
