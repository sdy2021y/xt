-- ============================================================================
-- ArtifactConfig.lua - 神器配置数据
-- 3神器：雷鸣战鼓 / 虚空跃迁符 / 天陨长枪
-- ============================================================================

local ArtifactConfig = {}

-- ========== 神器定义 ==========

ArtifactConfig.ARTIFACTS = {
    ["雷鸣战鼓"] = {
        id = "artifact_thunder_drum",
        name = "雷鸣战鼓",
        quality = "rare",
        rarity = 3,  -- 稀有=3
        icon = "⚡",
        desc = "我方所有单位获得移速加成",
        -- 技能效果
        skill = {
            name = "雷霆战鼓",
            icon = "⚡",
            type = "buff_all",
            effect = "speed_buff",
            value = 100,        -- 100%移速加成
            duration = 5,       -- 持续5秒
            target = "all_allies",
        },
        -- 充能阶段
        chargeStages = { 5, 15, 30 },
        -- 被动技能（按等级解锁）
        passives = {
            [10] = {
                name = "雷霆余威",
                desc = "我方单位移速永久+10%",
                effect = "permanent_speed_buff",
                value = 10,
            },
            [20] = {
                name = "雷霆领域",
                desc = "每释放一次，额外造成1次雷击",
                effect = "thunder_strike",
                value = 50,  -- 伤害
            },
            [30] = {
                name = "天雷降世",
                desc = "首次释放后，每15秒自动释放一次",
                effect = "auto_release",
                interval = 15,
            },
        },
    },

    ["虚空跃迁符"] = {
        id = "artifact_void_talisman",
        name = "虚空跃迁符",
        quality = "epic",
        rarity = 4,  -- 史诗=4
        icon = "🌀",
        desc = "将我方单位传送至敌人后方",
        skill = {
            name = "虚空穿梭",
            icon = "🌀",
            type = "teleport",
            effect = "teleport_behind",
            count = 3,          -- 传送3个单位
            attackSpeedBuff = 10, -- 10%攻速加成
            duration = 5,
            target = "strongest_allies",
        },
        chargeStages = { 5, 15, 30 },
        passives = {
            [10] = {
                name = "虚空印记",
                desc = "传送的单位获得持续4秒的无敌",
                effect = "invincible",
                duration = 4,
            },
            [20] = {
                name = "虚空裂隙",
                desc = "传送后原地留下裂隙，持续伤害经过的敌人",
                effect = "void_rift",
                damage = 30,
                duration = 6,
            },
            [30] = {
                name = "虚空之主",
                desc = "传送数量+2，攻速加成提升至20%",
                effect = "teleport_enhance",
                extraCount = 2,
                attackSpeedBuff = 20,
            },
        },
    },

    ["天陨长枪"] = {
        id = "artifact_god_spear",
        name = "天陨长枪",
        quality = "legendary",
        rarity = 5,  -- 传说=5
        icon = "🗡️",
        desc = "立即斩杀敌方传说单位，并造成范围伤害",
        skill = {
            name = "天陨一击",
            icon = "🗡️",
            type = "targeted",
            effect = "execute_legendary",
            damage = 250,       -- 每秒250点伤害
            duration = 10,      -- 持续10秒
            radius = 3,         -- 范围伤害半径（格子）
            target = "enemy_legendary",
        },
        chargeStages = { 5, 15, 30 },
        passives = {
            [10] = {
                name = "天陨威压",
                desc = "敌方传说单位攻击力-20%",
                effect = "enemy_legendary_atk_debuff",
                value = 20,
            },
            [20] = {
                name = "天陨余波",
                desc = "斩杀后，对周围所有敌方单位造成额外伤害",
                effect = "execute_aoe",
                damage = 100,
                radius = 5,
            },
            [30] = {
                name = "星殒灭世",
                desc = "可斩杀史诗+传说单位，伤害提升至400/秒",
                effect = "execute_enhance",
                damage = 400,
                targetQuality = { "epic", "legendary" },
            },
        },
    },
}

-- ========== 升级消耗 ==========

--- 神器等级升级所需碎片
---@param currentLevel integer 当前等级 (0-29)
---@return integer 所需碎片数
function ArtifactConfig.GetLevelUpFragments(currentLevel)
    -- 1→2级: 2碎片, 递增: 每级+1
    return (currentLevel + 1) + 1
end

--- 神器等级升级所需符文
---@param currentLevel integer 当前等级 (0-29)
---@return integer 所需符文数
function ArtifactConfig.GetLevelUpRunes(currentLevel)
    -- 基础50符文，每级+20
    return 50 + currentLevel * 20
end

--- 神器星级升级所需碎片
---@param currentStar integer 当前星级 (0-4)
---@return integer 所需碎片数
function ArtifactConfig.GetStarUpFragments(currentStar)
    -- 0→1星: 10碎片, 递增
    local costs = { 10, 25, 50, 100, 200 }
    return costs[currentStar + 1] or 200
end

-- ========== 抽卡配置 ==========

-- 召唤等级概率表
ArtifactConfig.SUMMON_PROBABILITIES = {
    { level = 1,  crystal = 80,  common = 15, rare = 4,   epic = 0.9, legendary = 0.1 },
    { level = 10, crystal = 65,  common = 20, rare = 10,  epic = 4,   legendary = 1 },
    { level = 20, crystal = 55,  common = 21, rare = 14,  epic = 7,   legendary = 1.5 },
    { level = 30, crystal = 50,  common = 22, rare = 18,  epic = 8,   legendary = 2 },
    { level = 40, crystal = 42,  common = 22, rare = 24,  epic = 9.5, legendary = 2.5 },
    { level = 50, crystal = 37,  common = 21.25, rare = 28.5, epic = 10.7, legendary = 2.55 },
}

-- 升级所需抽数：从N级升到N+1级需要的抽数
ArtifactConfig.SUMMON_LEVEL_UP_COST = {
    [1] = 100,  -- 1级→2级: 100抽
    [2] = 110,  -- 2级→3级: 110抽
    [3] = 120,  -- 3级→4级: 120抽
    [4] = 130,  -- 4级→5级: 130抽
}
-- 通用公式：每级增加10抽，50级满级
for i = 5, 49 do
    ArtifactConfig.SUMMON_LEVEL_UP_COST[i] = 100 + (i - 1) * 10
end

-- 每抽消耗
ArtifactConfig.SUMMON_COST = {
    single = 50,  -- 星钻单抽
    ad_10 = 0,    -- 广告10连（免费）
}

-- 广告免费抽冷却时间（秒）
ArtifactConfig.FREE_SUMMON_COOLDOWN = 6 * 3600  -- 6小时

return ArtifactConfig