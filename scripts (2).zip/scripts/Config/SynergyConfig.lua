-- ══════════════════════════════════════════════
-- ============================================================================
-- SynergyConfig.lua - 种族/职业羁绊数据配置
-- 严格按照设计文档 XianTu_Battle.md 第五章
-- ============================================================================

local SynergyConfig = {}

-- ========== 种族羁绊 ==========
-- 卡组中放N张同族卡激活对应级效果（2/4/6 梯度）
SynergyConfig.RACE_SYNERGY = {
    aether = {
        name = "联盟",
        theme = "防御经济流",
        tiers = {
            {
                count = 2,
                desc = "建筑血量+50%",
                effect = "building_hp",
                params = { percent = 0.50 },
            },
            {
                count = 4,
                desc = "附近有友军时减伤20%",
                effect = "nearby_ally_damage_reduce",
                params = { percent = 0.20 },
            },
            {
                count = 6,
                desc = "建筑每5秒产1能量",
                effect = "building_spirit_gen",
                params = { amount = 1, interval = 5 },
            },
        },
    },
    avian = {
        name = "翼族",
        theme = "快攻推塔流",
        tiers = {
            {
                count = 2,
                desc = "移速+20%",
                effect = "move_speed",
                params = { percent = 0.20 },
            },
            {
                count = 4,
                desc = "血量<50%时攻速+50%",
                effect = "low_hp_attack_speed",
                params = { hpThreshold = 0.50, percent = 0.50 },
            },
            {
                count = 6,
                desc = "对建筑伤害+75%",
                effect = "building_damage",
                params = { percent = 0.75 },
            },
        },
    },
    forge = {
        name = "机械",
        theme = "人海消耗流",
        tiers = {
            {
                count = 2,
                desc = "产出速度+20%",
                effect = "produce_speed",
                params = { percent = 0.20 },
            },
            {
                count = 4,
                desc = "损毁后10%概率重构",
                effect = "revive_chance",
                params = { chance = 0.10 },
            },
            {
                count = 6,
                desc = "工厂每次额外产兵+1",
                effect = "extra_produce",
                params = { count = 1 },
            },
        },
    },
    astral = {
        name = "元素",
        theme = "远程输出流",
        tiers = {
            {
                count = 2,
                desc = "攻击速度+15%",
                effect = "attack_speed",
                params = { percent = 0.15 },
            },
            {
                count = 4,
                desc = "攻击距离+1",
                effect = "attack_range",
                params = { flat = 1 },
            },
            {
                count = 6,
                desc = "技能冷却-20%",
                effect = "cooldown_reduction",
                params = { percent = 0.20 },
            },
        },
    },
}

-- ========== 职业羁绊 ==========
SynergyConfig.CLASS_SYNERGY = {
    melee = {
        name = "近战",
        theme = "纯近战阵容",
        tiers = {
            {
                count = 2,
                desc = "生产效率+10%",
                effect = "produce_speed",
                params = { percent = 0.10 },
            },
            {
                count = 4,
                desc = "单位伤害+50%",
                effect = "unit_damage",
                params = { percent = 0.50 },
            },
            {
                count = 6,
                desc = "单位生命值+20%",
                effect = "unit_hp",
                params = { percent = 0.20 },
            },
        },
    },
    ranged = {
        name = "远程",
        theme = "纯远程阵容",
        tiers = {
            {
                count = 2,
                desc = "攻击距离+1",
                effect = "attack_range",
                params = { flat = 1 },
            },
            {
                count = 4,
                desc = "攻击速度+20%",
                effect = "attack_speed",
                params = { percent = 0.20 },
            },
            {
                count = 6,
                desc = "暴击率+10%",
                effect = "crit_rate",
                params = { percent = 0.10 },
            },
        },
    },
}

-- ========== 辅助函数 ==========

--- 获取指定种族当前激活的羁绊等级
---@param race string
---@param count integer 该种族在卡组中的张数
---@return table[] activeTiers 已激活的羁绊层列表
function SynergyConfig.GetActiveRaceTiers(race, count)
    local synergy = SynergyConfig.RACE_SYNERGY[race]
    if not synergy then return {} end

    local result = {}
    for _, tier in ipairs(synergy.tiers) do
        if count >= tier.count then
            result[#result + 1] = tier
        end
    end
    return result
end

--- 获取指定职业当前激活的羁绊等级
---@param class string
---@param count integer 该职业在卡组中的张数
---@return table[] activeTiers
function SynergyConfig.GetActiveClassTiers(class, count)
    local synergy = SynergyConfig.CLASS_SYNERGY[class]
    if not synergy then return {} end

    local result = {}
    for _, tier in ipairs(synergy.tiers) do
        if count >= tier.count then
            result[#result + 1] = tier
        end
    end
    return result
end

return SynergyConfig


-- ══════════════════════════════════════════════
