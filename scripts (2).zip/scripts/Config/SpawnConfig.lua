-- ============================================================================
-- SpawnConfig.lua - 配置驱动的出生点计算系统
-- 根据玩家数量和队伍数量，动态计算各玩家主城坐标
-- 不硬编码"P1在哪、P2在哪"，支持 1v1 / 2v2 / 3v3 / 4v4
-- ============================================================================

local HexGrid = require("Battle.HexGrid")

local SpawnConfig = {}

--- 根据玩家数量和网格尺寸，计算各玩家主城坐标
---@param cols integer 网格列数
---@param rows integer 网格行数
---@param playerCount integer 玩家总数(2/4/6/8)
---@param teamCount integer 队伍数(通常2)
---@return table[] spawns { {slot=1, team=1, q=, r=}, ... }
function SpawnConfig.Calculate(cols, rows, playerCount, teamCount)
    teamCount = teamCount or 2
    local playersPerTeam = playerCount / teamCount
    local spawns = {}

    local midCol = math.floor(cols / 2)
    local rOffset = -math.floor(midCol / 2)

    -- 队伍1（逻辑底部）: rowIndex = rows-1 附近
    -- 队伍2（逻辑顶部）: rowIndex = 0 附近

    if playersPerTeam == 1 then
        -- 1v1: 各方1个主城，正中间（向中心缩5格，缩短战线）
        spawns[#spawns + 1] = {
            slot = 1, team = 1,
            q = midCol, r = rOffset + rows - 6,  -- 底部，向中间挪5格
        }
        spawns[#spawns + 1] = {
            slot = 2, team = 2,
            q = midCol, r = rOffset + 5,          -- 顶部，向中间挪5格
        }
    elseif playersPerTeam == 2 then
        -- 2v2: 各方2个主城，左右分布
        local leftCol = math.floor(cols / 4)
        local rightCol = cols - 1 - leftCol
        local lOff = -math.floor(leftCol / 2)
        local rOff2 = -math.floor(rightCol / 2)

        spawns[#spawns + 1] = { slot = 1, team = 1, q = leftCol,  r = lOff + rows - 6 }
        spawns[#spawns + 1] = { slot = 2, team = 1, q = rightCol, r = rOff2 + rows - 6 }
        spawns[#spawns + 1] = { slot = 3, team = 2, q = leftCol,  r = lOff + 5 }
        spawns[#spawns + 1] = { slot = 4, team = 2, q = rightCol, r = rOff2 + 5 }
    elseif playersPerTeam == 3 then
        -- 3v3: 各方3个主城，均匀分布
        local positions = { math.floor(cols / 6), math.floor(cols / 2), cols - 1 - math.floor(cols / 6) }
        for i, col in ipairs(positions) do
            local off = -math.floor(col / 2)
            spawns[#spawns + 1] = { slot = i,     team = 1, q = col, r = off + rows - 6 }
            spawns[#spawns + 1] = { slot = i + 3, team = 2, q = col, r = off + 5 }
        end
    elseif playersPerTeam == 4 then
        -- 4v4: 各方4个主城
        local positions = {}
        for i = 1, 4 do
            positions[i] = math.floor((i - 0.5) * cols / 4)
        end
        for i, col in ipairs(positions) do
            local off = -math.floor(col / 2)
            spawns[#spawns + 1] = { slot = i,     team = 1, q = col, r = off + rows - 6 }
            spawns[#spawns + 1] = { slot = i + 4, team = 2, q = col, r = off + 5 }
        end
    end

    return spawns
end

--- 计算玩家领地划分（按行）
---@param rows integer
---@param teamCount integer
---@return table { [team] = { startRow, endRow } }
function SpawnConfig.GetTerritoryBounds(rows, teamCount)
    local halfRows = math.floor(rows / teamCount)
    local bounds = {}
    -- 队伍1: 底部半区; 队伍2: 顶部半区
    bounds[1] = { startRow = rows - halfRows, endRow = rows - 1 }
    bounds[2] = { startRow = 0, endRow = halfRows - 1 }
    return bounds
end

return SpawnConfig