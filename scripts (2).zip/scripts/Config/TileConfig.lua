-- ══════════════════════════════════════════════
-- ============================================================================
-- TileConfig.lua - 翻格子系统配置
-- 基于GDD 2.2/2.3：格子有可见类型和价格，点击翻开消耗晶核获得建筑
-- ============================================================================

local GameConfig = require("Config.GameConfig")
local UnitConfig = require("Config.UnitConfig")

local TileConfig = {}

-- 格子类型（翻开前可见的类型标识）
TileConfig.TILE_TYPE = {
    EMPTY = 0,          -- 空（无格子）
    MYSTERY = 1,        -- 问号（赌博机制）
    SPIRIT_MINE = 2,    -- 矿脉
    BARRACKS_50 = 3,    -- 兵营（50晶核）
    BARRACKS_100 = 4,   -- 兵营（100晶核）
    TOWER_50 = 5,       -- 炮台（50晶核）
    TOWER_100 = 6,      -- 炮台（100晶核）
    HIGH_BARRACKS = 7,  -- 高级兵营（250晶核）
}

-- 格子类型配置：价格、图标文字、翻开后获得的建筑
TileConfig.TILE_DEFS = {
    [TileConfig.TILE_TYPE.MYSTERY] = {
        price = 25,
        icon = "?",
        name = "问号",
        -- 翻开结果由概率决定（见 MYSTERY_OUTCOMES）
    },
    [TileConfig.TILE_TYPE.SPIRIT_MINE] = {
        price = 50,
        icon = "矿",
        name = "矿脉",
        building = GameConfig.BUILDING.SPIRIT_MINE,
    },
    [TileConfig.TILE_TYPE.BARRACKS_50] = {
        price = 50,
        icon = "兵",
        name = "兵营",
        building = GameConfig.BUILDING.BARRACKS,
    },
    [TileConfig.TILE_TYPE.BARRACKS_100] = {
        price = 100,
        icon = "兵",
        name = "精锐兵营",
        building = GameConfig.BUILDING.BARRACKS,
    },
    [TileConfig.TILE_TYPE.TOWER_50] = {
        price = 50,
        icon = "塔",
        name = "炮台",
        building = GameConfig.BUILDING.TOWER,
    },
    [TileConfig.TILE_TYPE.TOWER_100] = {
        price = 100,
        icon = "塔",
        name = "重炮",
        building = GameConfig.BUILDING.ELITE_TOWER,
    },
    [TileConfig.TILE_TYPE.HIGH_BARRACKS] = {
        price = 250,
        icon = "王",
        name = "高级兵营",
        building = GameConfig.BUILDING.BARRACKS,
    },
}

-- 问号格子翻开概率
-- 70%空 / 20%普通兵营 / 15%稀有兵营 / 10%史诗兵营 / 5%传奇兵营
TileConfig.MYSTERY_OUTCOMES = {
    { weight = 70, building = GameConfig.BUILDING.NONE, name = "空" },
    { weight = 20, building = GameConfig.BUILDING.BARRACKS, name = "普通兵营", fixedQuality = "green" },
    { weight = 15, building = GameConfig.BUILDING.BARRACKS, name = "稀有兵营", fixedQuality = "blue" },
    { weight = 10, building = GameConfig.BUILDING.BARRACKS, name = "史诗兵营", fixedQuality = "purple" },
    { weight = 5,  building = GameConfig.BUILDING.BARRACKS, name = "传奇兵营", fixedQuality = "gold" },
}

-- 基础格子生成权重（地图刷新时的概率）
-- 炮台概率调低一半；问号、50/100/250兵营 → 同等概率
TileConfig.BASE_SPAWN_WEIGHTS = {
    { tileType = TileConfig.TILE_TYPE.MYSTERY,       weight = 20 },  -- 同等
    { tileType = TileConfig.TILE_TYPE.BARRACKS_50,   weight = 20 },  -- 同等
    { tileType = TileConfig.TILE_TYPE.BARRACKS_100,  weight = 20 },  -- 同等
    { tileType = TileConfig.TILE_TYPE.HIGH_BARRACKS, weight = 20 },  -- 同等
    { tileType = TileConfig.TILE_TYPE.SPIRIT_MINE,   weight = 5 },   -- 低概率
    { tileType = TileConfig.TILE_TYPE.TOWER_50,      weight = 4 },   -- 减半
    { tileType = TileConfig.TILE_TYPE.TOWER_100,     weight = 3 },   -- 减半
}

--- 根据玩家卡组获取调整后的格子生成权重
---@param playerDeck string[] 玩家卡组
---@return table 调整后的权重表
function TileConfig.GetAdjustedSpawnWeights(playerDeck)
    local hasTower = false
    for _, cardName in ipairs(playerDeck) do
        local card = UnitConfig.CARDS[cardName]
        if card and card.slotType == "tower" then
            hasTower = true
            break
        end
    end

    local adjustedWeights = {}
    local totalWeight = 0
    for _, entry in ipairs(TileConfig.BASE_SPAWN_WEIGHTS) do
        local weight = entry.weight
        if not hasTower and (entry.tileType == TileConfig.TILE_TYPE.TOWER_50 or entry.tileType == TileConfig.TILE_TYPE.TOWER_100) then
            -- 如果没有塔卡，塔格子权重设为0
            weight = 0
        end
        adjustedWeights[#adjustedWeights + 1] = {
            tileType = entry.tileType,
            weight = weight
        }
        totalWeight = totalWeight + weight
    end

    return adjustedWeights, totalWeight
end

--- 随机生成一个格子类型（用于刷新相邻格子）
---@param playerDeck? string[] 玩家卡组（可选，用于调整权重）
---@return integer tileType
function TileConfig.RandomTileType(playerDeck)
    local weights, totalWeight
    if playerDeck then
        weights, totalWeight = TileConfig.GetAdjustedSpawnWeights(playerDeck)
    else
        weights = TileConfig.BASE_SPAWN_WEIGHTS
        totalWeight = 0
        for _, entry in ipairs(weights) do
            totalWeight = totalWeight + entry.weight
        end
    end

    local roll = math.random() * totalWeight
    local cumulative = 0
    for _, entry in ipairs(weights) do
        cumulative = cumulative + entry.weight
        if roll <= cumulative and entry.weight > 0 then
            return entry.tileType
        end
    end
    -- 兜底
    return TileConfig.TILE_TYPE.BARRACKS_50
end

-- Server 调用的别名（与 RandomTileType 相同，不需要 playerDeck 参数）
---@type fun(playerDeck?: string[]): integer
TileConfig.RandomTileTypeByWeight = TileConfig.RandomTileType

--- 翻开问号格子，返回获得的建筑类型和固定品质
---@return integer buildingType
---@return string name 建筑名称
---@return string|nil fixedQuality 固定品质（"green"/"blue"/"purple"/"gold"），nil表示空
function TileConfig.RollMystery()
    local totalWeight = 0
    for _, outcome in ipairs(TileConfig.MYSTERY_OUTCOMES) do
        totalWeight = totalWeight + outcome.weight
    end

    local roll = math.random() * totalWeight
    local cumulative = 0
    for _, outcome in ipairs(TileConfig.MYSTERY_OUTCOMES) do
        cumulative = cumulative + outcome.weight
        if roll <= cumulative then
            return outcome.building, outcome.name, outcome.fixedQuality
        end
    end
    return GameConfig.BUILDING.NONE, "空", nil
end

--- 获取格子的价格
---@param tileType integer
---@return integer price
function TileConfig.GetPrice(tileType)
    local def = TileConfig.TILE_DEFS[tileType]
    if def then return def.price end
    return 0
end

--- 获取翻开格子后获得的建筑（非问号格子直接返回固定建筑）
---@param tileType integer
---@return integer buildingType
---@return string name
---@return integer barracksPrice 兵营价格（50/100/250），非兵营返回0
---@return string|nil fixedQuality 问号翻出的兵营固定品质，非问号返回nil
function TileConfig.GetFlipResult(tileType)
    if tileType == TileConfig.TILE_TYPE.MYSTERY then
        local building, name, fixedQuality = TileConfig.RollMystery()
        -- 问号翻到兵营时默认50晶核兵营（价格仅影响建筑HP等，品质由fixedQuality决定）
        local barracksPrice = (building == GameConfig.BUILDING.BARRACKS) and 50 or 0
        return building, name, barracksPrice, fixedQuality
    end

    local def = TileConfig.TILE_DEFS[tileType]
    if def and def.building then
        return def.building, def.name, (def.price or 0), nil
    end
    return GameConfig.BUILDING.NONE, "空", 0, nil
end

-- 初始格子围绕主城的配置（GDD：主城周边必有一格矿脉）
TileConfig.INITIAL_FORCED = {
    MINE_COUNT = 1,  -- 强制至少1个矿脉
}

return TileConfig


-- ══════════════════════════════════════════════
