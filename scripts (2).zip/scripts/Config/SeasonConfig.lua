-- ============================================================================
-- SeasonConfig.lua - 赛季配置
-- 手动赛季制：由开发者通过服务端控制赛季更新
-- ============================================================================

local SeasonConfig = {}

-- ========== 赛季配置 ==========

-- 手动赛季模式：赛季不自动结束，由服务端 serverCloud 变量 "seasonEndTime" 控制
-- 当 MANUAL_SEASON = true 时，SeasonManager 从 serverCloud 读取赛季结束时间
-- 开发者通过更新服务端 "seasonEndTime" 变量触发新赛季
SeasonConfig.MANUAL_SEASON = true

-- 备用：自动赛季时长（仅 MANUAL_SEASON = false 时使用）
SeasonConfig.SEASON_DURATION = 15 * 86400  -- 15天（秒）

-- 当前赛季版本号（手动递增，用于判断是否需要结算）
-- 每次新赛季时递增此值，客户端检测到版本变化即触发结算
SeasonConfig.SEASON_VERSION = 1

-- ========== 段位定义 ==========

SeasonConfig.TIERS = {
    { name = "青铜", subTiers = 3, trophyMin = 0,    trophyMax = 299,   winBonus = 10,  lossPenalty = 5 },
    { name = "白银", subTiers = 3, trophyMin = 300,  trophyMax = 999,   winBonus = 15,  lossPenalty = 7 },
    { name = "黄金", subTiers = 3, trophyMin = 1000, trophyMax = 2499,  winBonus = 20,  lossPenalty = 10 },
    { name = "铂金", subTiers = 3, trophyMin = 2500, trophyMax = 4999,  winBonus = 25,  lossPenalty = 12 },
    { name = "钻石", subTiers = 5, trophyMin = 5000, trophyMax = 9999,  winBonus = 30,  lossPenalty = 15 },
    { name = "星耀", subTiers = 5, trophyMin = 10000, trophyMax = 14999, winBonus = 35, lossPenalty = 18 },
    { name = "王者", subTiers = 0, trophyMin = 15000, trophyMax = 19999, winBonus = 40, lossPenalty = 20 },
    { name = "荣耀王者", subTiers = 0, trophyMin = 20000, trophyMax = 99999, winBonus = 50, lossPenalty = 25 },
}

-- ========== 赛季结算奖励 ==========

SeasonConfig.SEASON_REWARDS = {
    { tierIndex = 0, gold = 200,  xianyu = 1000, bonus = "青铜头像框" },
    { tierIndex = 1, gold = 300,  xianyu = 1500, bonus = "白银头像框" },
    { tierIndex = 2, gold = 500,  xianyu = 2000, bonus = "黄金头像框" },
    { tierIndex = 3, gold = 800,  xianyu = 2500, bonus = "铂金头像框 + 稀有皮肤" },
    { tierIndex = 4, gold = 1200, xianyu = 3000, bonus = "钻石头像框 + 史诗皮肤" },
    { tierIndex = 5, gold = 1800, xianyu = 3500, bonus = "星耀头像框 + 史诗皮肤" },
    { tierIndex = 6, gold = 2500, xianyu = 4000, bonus = "王者头像框 + 传说皮肤" },
    { tierIndex = 7, gold = 3500, xianyu = 4500, bonus = "荣耀王者头像框 + 传说皮肤 + 专属称号" },
}

-- ========== 段位晋升奖励 ==========

SeasonConfig.TIER_PROMOTION_REWARDS = {
    { tierIndex = 0, subTier = 1, gold = 50,  xianyu = 100 },
    { tierIndex = 0, subTier = 2, gold = 50,  xianyu = 100 },
    { tierIndex = 0, subTier = 3, gold = 50,  xianyu = 100 },
    { tierIndex = 1, subTier = 1, gold = 100, xianyu = 200 },
    { tierIndex = 1, subTier = 2, gold = 100, xianyu = 200 },
    { tierIndex = 1, subTier = 3, gold = 100, xianyu = 200 },
    { tierIndex = 2, subTier = 1, gold = 200, xianyu = 400 },
    { tierIndex = 2, subTier = 2, gold = 200, xianyu = 400 },
    { tierIndex = 2, subTier = 3, gold = 200, xianyu = 400 },
    { tierIndex = 3, subTier = 1, gold = 400, xianyu = 800 },
    { tierIndex = 3, subTier = 2, gold = 400, xianyu = 800 },
    { tierIndex = 3, subTier = 3, gold = 400, xianyu = 800 },
    { tierIndex = 4, subTier = 1, gold = 800,  xianyu = 1600 },
    { tierIndex = 4, subTier = 2, gold = 800,  xianyu = 1600 },
    { tierIndex = 4, subTier = 3, gold = 800,  xianyu = 1600 },
    { tierIndex = 4, subTier = 4, gold = 800,  xianyu = 1600 },
    { tierIndex = 4, subTier = 5, gold = 800,  xianyu = 1600 },
    { tierIndex = 5, subTier = 1, gold = 1200, xianyu = 2400 },
    { tierIndex = 5, subTier = 2, gold = 1200, xianyu = 2400 },
    { tierIndex = 5, subTier = 3, gold = 1200, xianyu = 2400 },
    { tierIndex = 5, subTier = 4, gold = 1200, xianyu = 2400 },
    { tierIndex = 5, subTier = 5, gold = 1200, xianyu = 2400 },
}

-- ========== 辅助函数 ==========

--- 根据奖杯获取段位索引
---@param trophies integer
---@return integer tierIndex, integer subTier, string tierName
function SeasonConfig.GetTierByTrophies(trophies)
    for i, tier in ipairs(SeasonConfig.TIERS) do
        if trophies >= tier.trophyMin and trophies <= tier.trophyMax then
            local subTier = 1
            if tier.subTiers > 0 then
                local range = tier.trophyMax - tier.trophyMin
                local tierProgress = trophies - tier.trophyMin
                subTier = math.min(math.floor(tierProgress / (range / tier.subTiers)) + 1, tier.subTiers)
            end
            return i - 1, subTier, tier.name
        end
    end
    return 0, 1, "青铜"
end

--- 获取段位的奖杯加成
---@param trophies integer
---@return integer winBonus, integer lossPenalty
function SeasonConfig.GetTrophyBonus(trophies)
    local tierIndex, _, _ = SeasonConfig.GetTierByTrophies(trophies)
    local tier = SeasonConfig.TIERS[tierIndex + 1]
    if tier then
        return tier.winBonus, tier.lossPenalty
    end
    return 10, 5
end

--- 获取段位显示名称
---@param tierIndex integer
---@param subTier integer
---@param trophies integer|nil 奖杯数（荣耀王者需要计算星星）
---@return string
function SeasonConfig.GetTierDisplayName(tierIndex, subTier, trophies)
    local tier = SeasonConfig.TIERS[tierIndex + 1]
    if not tier then return "青铜III" end
    if tier.subTiers > 0 then
        local roman = { "I", "II", "III", "IV", "V" }
        return tier.name .. (roman[subTier] or "I")
    end
    -- 王者/荣耀王者
    if tier.name == "荣耀王者" and trophies then
        local stars = math.floor((trophies - tier.trophyMin) / 100)
        if stars > 0 then
            return "荣耀王者" .. stars .. "星"
        end
    end
    return tier.name
end

-- ========== 段位视觉配置 ==========

SeasonConfig.TIER_VISUALS = {
    { icon = "🥉", color = "#CD7F32", glow = "#8B4513", bgColor = "#1B5E20" },   -- 青铜
    { icon = "🥈", color = "#C0C0C0", glow = "#808080", bgColor = "#0D47A1" },   -- 白银
    { icon = "🥇", color = "#FFD700", glow = "#B8860B", bgColor = "#4A148C" },   -- 黄金
    { icon = "💎", color = "#00BCD4", glow = "#006064", bgColor = "#E65100" },   -- 铂金
    { icon = "💠", color = "#E040FB", glow = "#7B1FA2", bgColor = "#B71C1C" },   -- 钻石
    { icon = "⭐", color = "#FF9800", glow = "#E65100", bgColor = "#5D4E37" },   -- 星耀
    { icon = "👑", color = "#FFD700", glow = "#FF6F00", bgColor = "#5D4E37" },   -- 王者
    { icon = "🏆", color = "#FF1744", glow = "#B71C1C", bgColor = "#5D4E37" },   -- 荣耀王者
}

--- 获取段位视觉信息
---@param tierIndex integer
---@return table { icon, color, glow, bgColor }
function SeasonConfig.GetTierVisual(tierIndex)
    return SeasonConfig.TIER_VISUALS[tierIndex + 1] or SeasonConfig.TIER_VISUALS[1]
end

--- 获取当前段位在段位内的进度 (0.0 ~ 1.0)
---@param trophies integer
---@return number
function SeasonConfig.GetProgress(trophies)
    local tierIndex, _ = SeasonConfig.GetTierByTrophies(trophies)
    local tier = SeasonConfig.TIERS[tierIndex + 1]
    if not tier then return 0 end
    local range = tier.trophyMax - tier.trophyMin
    if range <= 0 then return 1 end
    return math.min((trophies - tier.trophyMin) / range, 1.0)
end

--- 获取段位显示名称（含图标）
---@param tierIndex integer
---@param subTier integer
---@param trophies integer|nil
---@return string iconAndName
function SeasonConfig.GetTierIconName(tierIndex, subTier, trophies)
    local visual = SeasonConfig.GetTierVisual(tierIndex)
    local name = SeasonConfig.GetTierDisplayName(tierIndex, subTier, trophies)
    return visual.icon .. " " .. name
end

--- 获取段位对应的奖励金币（用于战斗结算）
---@param tierIndex integer
---@return integer gold, integer runes
function SeasonConfig.GetTierRewards(tierIndex)
    local tier = SeasonConfig.TIERS[tierIndex + 1]
    if not tier then return 50, 5 end
    -- 基于段位的基础奖励
    local goldBase = { 50, 100, 200, 400, 600, 1000, 1500, 2000 }
    local runesBase = { 5, 10, 20, 35, 50, 80, 120, 200 }
    return goldBase[tierIndex + 1] or 50, runesBase[tierIndex + 1] or 5
end

return SeasonConfig