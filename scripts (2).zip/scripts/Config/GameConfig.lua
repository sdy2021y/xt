-- ══════════════════════════════════════════════
-- ============================================================================
-- GameConfig.lua - 全局游戏配置常量
-- ============================================================================

local GameConfig = {}

-- 游戏基础
GameConfig.TITLE = "仙途"
GameConfig.VERSION = "0.1.0"

-- 屏幕方向：竖屏
GameConfig.ORIENTATION = "portrait"

-- 战斗配置
GameConfig.STARTING_SPIRIT_STONES = 50   -- 初始晶核
GameConfig.MAX_POPULATION = 100          -- 最大人口
GameConfig.AI_MAX_POPULATION = 100       -- AI最大存活兵力（与玩家统一上限100）
GameConfig.MAIN_BASE_SPIRIT_RATE = 10    -- 主城每秒产晶核

-- 战斗时长（按模式区分）
GameConfig.BATTLE_DURATION = {
    ["1v1"] = 180,   -- 3分钟
    ["2v2"] = 240,   -- 4分钟
}
GameConfig.BATTLE_DURATION_DEFAULT = 180  -- 兜底

-- 对战模式
GameConfig.BATTLE_MODE = {
    RANKED_1V1 = "1v1",
    RANKED_2V2 = "2v2",
    CASUAL_3V3 = "3v3",
    CASUAL_BOSS = "boss",
}

-- 模式积分配置
GameConfig.MODE_POINTS = {
    ["1v1"] = { win = 30, lose = -15, draw = 5, rewardMultiplier = 1.0 },
    ["2v2"] = { win = 35, lose = -12, draw = 5, rewardMultiplier = 1.2 },
}

-- 2v2 灵力转赠
GameConfig.SPIRIT_TRANSFER_RATIO = 0.3       -- 转赠30%晶核
GameConfig.SPIRIT_TRANSFER_COOLDOWN = 30      -- 30秒冷却

-- 格子价格
GameConfig.TILE_PRICES = { 25, 50, 100, 250 }

-- 六边形格子配置
GameConfig.HEX = {
    RADIUS = 18,           -- 六边形半径（像素，逻辑坐标）
    GRID_COLS = 15,        -- 列数（横15格）
    GRID_ROWS = 22,        -- 行数（竖22格，总计330格）
    GAP = 0,               -- 格子间隙（0=无间隙，靠边框线分隔）
}

-- 建筑类型
GameConfig.BUILDING = {
    NONE = 0,
    MAIN_BASE = 1,         -- 主城
    SPIRIT_MINE = 2,       -- 矿脉
    BARRACKS = 3,          -- 兵营
    TOWER = 4,             -- 炮台
    ELITE_TOWER = 5,       -- 重炮
}

-- 建筑名称
GameConfig.BUILDING_NAMES = {
    [0] = "空地",
    [1] = "主城",
    [2] = "矿脉",
    [3] = "兵营",
    [4] = "炮台",
    [5] = "重炮",
}

-- 摧毁建筑获得铸材数量
GameConfig.BUILDING_MATERIAL_REWARD = {
    [1] = 50,   -- 主城
    [2] = 10,   -- 矿脉
    [3] = 10,   -- 兵营
    [4] = 10,   -- 炮台
    [5] = 15,   -- 重炮（奖励稍高）
}

-- 进攻目标优先级（同距离时）
GameConfig.ATTACK_PRIORITY = {
    [GameConfig.BUILDING.BARRACKS] = 1,
    [GameConfig.BUILDING.MAIN_BASE] = 2,
    [GameConfig.BUILDING.TOWER] = 3,
    [GameConfig.BUILDING.ELITE_TOWER] = 3,
    [GameConfig.BUILDING.SPIRIT_MINE] = 4,
}

-- 兵种配置已迁移至 Config/UnitConfig.lua（24张卡牌完整数据）
-- 旧的 UNIT_TYPE/UNIT_DEFS 已移除

-- 颜色配置（RGBA）
GameConfig.COLORS = {
    -- 玩家颜色
    PLAYER1 = { 66, 135, 245, 255 },     -- 蓝色系
    PLAYER2 = { 239, 83, 80, 255 },      -- 红色系

    -- 格子颜色
    TILE_NEUTRAL = { 80, 90, 70, 200 },   -- 中性格子
    TILE_EMPTY = { 40, 45, 55, 180 },     -- 未翻格子
    TILE_BORDER = { 120, 130, 110, 255 }, -- 格子边框
    TILE_HIGHLIGHT = { 255, 220, 100, 200 }, -- 高亮

    -- UI 颜色
    UI_BG = { 20, 22, 30, 240 },
    UI_TEXT = { 255, 255, 255, 255 },
    UI_GOLD = { 255, 200, 50, 255 },
    UI_TIMER = { 200, 220, 255, 255 },
}

-- 网络事件名称
GameConfig.EVENTS = {
    FLIP_TILE = "FlipTile",
    BATTLE_STATE = "BattleState",
    BATTLE_END = "BattleEnd",
    PLAYER_READY = "PlayerReady",
}

return GameConfig


-- ══════════════════════════════════════════════
