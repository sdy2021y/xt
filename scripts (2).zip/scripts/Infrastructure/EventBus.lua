-- ============================================================================
-- EventBus.lua - 全局事件总线
-- 解耦模块间通信：发布-订阅模式
-- ============================================================================

local EventBus = {}

-- ========== 内部状态 ==========

---@type table<string, table[]>
local listeners_ = {}

-- 调试模式：开发期设为 true，回调出错时直接抛出异常；发布期设为 false，仅打印日志
EventBus.DEBUG_MODE = false

-- ========== 注册监听 ==========

--- 注册事件监听
---@param event string 事件名称
---@param callback function 回调函数
---@param context table|nil 可选的上下文（用于 Off 时精确移除）
function EventBus.On(event, callback, context)
    if not listeners_[event] then
        listeners_[event] = {}
    end
    table.insert(listeners_[event], {
        callback = callback,
        context = context,
    })
end

--- 注册一次性事件监听
---@param event string
---@param callback function
---@param context table|nil
function EventBus.Once(event, callback, context)
    local wrapper
    wrapper = function(...)
        callback(...)
        EventBus.Off(event, wrapper)
    end
    EventBus.On(event, wrapper, context)
end

-- ========== 移除监听 ==========

--- 移除事件监听
---@param event string
---@param callback function|nil nil=移除该事件的全部监听
function EventBus.Off(event, callback)
    if not listeners_[event] then return end

    if callback == nil then
        listeners_[event] = nil
        return
    end

    for i, entry in ipairs(listeners_[event]) do
        if entry.callback == callback then
            table.remove(listeners_[event], i)
            break
        end
    end

    -- 清理空表
    if #listeners_[event] == 0 then
        listeners_[event] = nil
    end
end

-- ========== 触发事件 ==========

--- 发送事件
---@param event string 事件名称
---@param ... any 事件参数
function EventBus.Emit(event, ...)
    local entries = listeners_[event]
    if not entries then return end

    -- 复制一份再遍历，防止回调中修改表
    local copy = {}
    for i, entry in ipairs(entries) do
        copy[i] = entry
    end

    for _, entry in ipairs(copy) do
        if EventBus.DEBUG_MODE then
            -- 调试模式：直接调用，出错立即暴露
            entry.callback(...)
        else
            -- 发布模式：保护调用，一个监听器崩溃不影响其他
            local ok, err = pcall(entry.callback, ...)
            if not ok then
                print("[EventBus] Error in event '" .. event .. "': " .. tostring(err))
            end
        end
    end
end

--- 检查是否有监听器
---@param event string
---@return boolean
function EventBus.HasListeners(event)
    local entries = listeners_[event]
    return entries ~= nil and #entries > 0
end

--- 清空所有事件监听
function EventBus.Clear()
    listeners_ = {}
end

-- ========== 调试 ==========

--- 获取所有已注册的事件名
---@return string[]
function EventBus.GetEvents()
    local result = {}
    for event, _ in pairs(listeners_) do
        result[#result + 1] = event
    end
    return result
end

--- 获取某事件的监听器数量
---@param event string
---@return integer
function EventBus.GetListenerCount(event)
    local entries = listeners_[event]
    return entries and #entries or 0
end

return EventBus