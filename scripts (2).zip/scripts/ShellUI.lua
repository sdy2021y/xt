-- ============================================================================
-- ShellUI.lua - 常驻底部导航栏（调度者模式）
-- 子页面 Show() 只返回 panel，ShellUI 统一调 UpdateContent()
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")

local ShellUI = {}

-- ========== 内部状态 ==========
local rootPanel_ = nil
local activeTab_ = ""
local contentArea_ = nil  -- 内容区域容器
local bottomNav_ = nil  -- 底部导航栏
local storedCallbacks_ = {}  -- 缓存 Init 传入的回调

-- ========== 样式常量 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    navBg = "#0D0D22",
    border = "#2A2A4A",
    tabActive = "#FFD700",
    tabInactive = "#555577",
}

-- ========== 底部导航栏 ==========
local function createBottomNav()
    local tabs = {
        { id = "shop",   icon = "🏪", label = "商店" },
        { id = "cards",  icon = "🃏", label = "卡牌" },
        { id = "battle", icon = "⚔️", label = "斗法" },
        { id = "territory", icon = "🏯", label = "据点" },
        { id = "rank",   icon = "🏆", label = "排行" },
    }

    local tabWidgets = {}
    for _, tab in ipairs(tabs) do
        local isActive = (tab.id == activeTab_)
        local tabId = tab.id
        tabWidgets[#tabWidgets + 1] = UI.Button {
            flexGrow = 1,
            height = "100%",
            alignItems = "center",
            justifyContent = "center",
            backgroundColor = { 0, 0, 0, 0 },
            onClick = function()
                ShellUI.SwitchTab(tabId)
            end,
            children = {
                UI.Label {
                    text = tab.icon,
                    fontSize = isActive and 22 or 18,
                },
                UI.Label {
                    text = tab.label,
                    fontSize = 10,
                    fontColor = isActive and COLORS.tabActive or COLORS.tabInactive,
                    marginTop = 2,
                },
            }
        }
    end

    bottomNav_ = UI.Panel {
        width = "100%",
        height = 60,
        flexDirection = "row",
        alignItems = "center",
        backgroundColor = COLORS.navBg,
        borderTopWidth = 1,
        borderColor = COLORS.border,
        children = tabWidgets,
    }
    return bottomNav_
end

-- ========== 内容区域 ==========

local function createContentArea()
    contentArea_ = UI.Panel {
        width = "100%",
        flexGrow = 1,
        flexShrink = 1,
        backgroundColor = COLORS.bgDark,
    }
    return contentArea_
end

-- ========== 完整 Shell 结构 ==========

local function buildShell()
    return UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = COLORS.bgDark,
        flexDirection = "column",
        children = {
            createContentArea(),
            createBottomNav(),
        }
    }
end

-- ========== 公共 API ==========

--- 销毁 Shell UI（返回主界面前调用）
function ShellUI.Destroy()
    rootPanel_ = nil
    activeTab_ = nil
end

--- 初始化 Shell（首次加载调用）
---@param callbacks table { onBattle: function, onCards: function }
function ShellUI.Init(callbacks)
    storedCallbacks_ = callbacks or {}
    if not rootPanel_ then
        rootPanel_ = buildShell()
        UI.SetRoot(rootPanel_)
    end
    ShellUI.SwitchTab("battle")
end

--- 切换底部Tab —— 调度者：拿到子页面 panel，放进 contentArea
---@param tabId string
function ShellUI.SwitchTab(tabId)
    if tabId == activeTab_ then return end
    activeTab_ = tabId

    local panel = nil

    if tabId == "battle" then
        local HomeUI = require("UI.HomeUI")
        panel = HomeUI.Show({
            onBattle = storedCallbacks_.onBattle,
            onCards = storedCallbacks_.onCards,
            onNavigate = function(target) ShellUI.SwitchTab(target) end,
        })
    elseif tabId == "cards" then
        local DeckBuilderUI = require("UI.DeckBuilderUI")
        panel = DeckBuilderUI.Show({
            onConfirm = function(deck)
                local DeckManager = require("Battle.DeckManager")
                DeckManager.SavePlayerDeck(deck)
                ShellUI.SwitchTab("battle")
            end,
            onBack = function()
                ShellUI.SwitchTab("battle")
            end,
        })
    elseif tabId == "shop" then
        local ShopUI = require("UI.ShopUI")
        panel = ShopUI.Show()
    elseif tabId == "rank" then
        local RankUI = require("UI.RankUI")
        panel = RankUI.Show()
    elseif tabId == "territory" then
        local TerritoryUI = require("UI.TerritoryUI")
        panel = TerritoryUI.Show()
    elseif tabId == "quest" then
        local QuestUI = require("UI.QuestUI")
        panel = QuestUI.Show(nil)
    elseif tabId == "achievement" then
        local AchievementUI = require("UI.AchievementUI")
        panel = AchievementUI.Show()
    elseif tabId == "friend" then
        local FriendUI = require("UI.FriendUI")
        panel = FriendUI.Show()
    elseif tabId == "chat" then
        local ChatUI = require("UI.ChatUI")
        panel = ChatUI.Show()
    elseif tabId == "artifact" then
        local ArtifactUI = require("UI.ArtifactUI")
        panel = ArtifactUI.Show(nil)
    elseif tabId == "tierDetail" then
        local TierDetailUI = require("UI.TierDetailUI")
        panel = TierDetailUI.Show({ onNavigate = function(target) ShellUI.SwitchTab(target) end })
    end

    if panel then
        ShellUI.UpdateContent(panel)
    end

    -- 确保底部栏可见
    ShellUI.SetNavVisible(true)

    -- 刷新底部导航高亮
    ShellUI.RefreshBottomNav()
end

--- 清空内容区域
function ShellUI.ClearContent()
    if contentArea_ then
        contentArea_:RemoveAllChildren()
    end
end

--- 更新内容区域
---@param content Widget 子页面的 UI 组件
function ShellUI.UpdateContent(content)
    if contentArea_ then
        contentArea_:RemoveAllChildren()
        contentArea_:AddChild(content)
    end
end

--- 设置底部导航栏可见性
---@param visible boolean
function ShellUI.SetNavVisible(visible)
    if bottomNav_ then
        bottomNav_.visible = visible
        bottomNav_.height = visible and 60 or 0
    end
end

--- 刷新底部导航高亮（不重建树，避免破坏子页面事件绑定）
function ShellUI.RefreshBottomNav()
    -- 底部导航栏高亮在 createBottomNav() 初始化时已设置
    -- 不再重建整个 Shell 树，避免破坏子页面的事件绑定
    -- 后续可改为就地更新按钮颜色
end

--- 获取当前活跃Tab
---@return string
function ShellUI.GetActiveTab()
    return activeTab_
end

--- 隐藏整个 Shell（进入战斗前调用）
function ShellUI.Hide()
    UI.SetRoot(nil, true)
    rootPanel_ = nil
    contentArea_ = nil
    bottomNav_ = nil
end

--- 显示 Shell（战斗结束后调用）
---@param callbacks table|nil
function ShellUI.Show(callbacks)
    if callbacks then
        storedCallbacks_ = callbacks
    end
    if not rootPanel_ then
        ShellUI.Init(storedCallbacks_)
    end
end

-- ========== Overlay 弹窗层 ==========

local overlayPanel_ = nil  -- 弹窗遮罩层

--- 在 Shell 上叠加弹窗（半透明遮罩 + 弹窗内容）
---@param content Widget 弹窗 UI 组件
function ShellUI.ShowOverlay(content)
    if not rootPanel_ then return end
    -- 移除旧 overlay
    ShellUI.HideOverlay()
    -- 创建半透明遮罩层，覆盖整个 Shell
    overlayPanel_ = UI.Panel {
        width = "100%",
        height = "100%",
        position = "absolute",
        left = 0, top = 0,
        backgroundColor = { 0, 0, 0, 180 },
        alignItems = "center",
        justifyContent = "center",
        children = { content },
    }
    rootPanel_:AddChild(overlayPanel_)
end

--- 移除弹窗遮罩层
function ShellUI.HideOverlay()
    if overlayPanel_ then
        rootPanel_:RemoveChild(overlayPanel_)
        overlayPanel_ = nil
    end
end

return ShellUI
