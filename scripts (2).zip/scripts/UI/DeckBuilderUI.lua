-- ══════════════════════════════════════════════
-- ============================================================================
-- DeckBuilderUI.lua - 卡组配置页面（重设计版）
-- 功能：5个卡组标签页 + 4x2已选卡网格 + 战力/羁绊展示 + 全卡牌滚动选择
-- ============================================================================
---@diagnostic disable: param-type-mismatch
local UI = require("urhox-libs/UI")
local UnitConfig = require("Config.UnitConfig")
local DeckManager = require("Battle.DeckManager")
local SynergyConfig = require("Config.SynergyConfig")
local SynergyManager = require("Battle.SynergyManager")
local CardDetailPopup = require("UI.CardDetailPopup")
local PlayerDataManager = require("Data.PlayerDataManager")

local DeckBuilderUI = {}

-- ========== 常量 ==========
local DECK_SIZE = DeckManager.DECK_SIZE  -- 8
local MAX_SLOTS = DeckManager.MAX_SLOTS  -- 5

-- 品质颜色
local QUALITY_COLORS = {
    green  = "#4CAF50",
    blue   = "#2196F3",
    purple = "#9C27B0",
    gold   = "#FF9800",
}

local QUALITY_BG = {
    green  = "#1A3D1A",
    blue   = "#0D2B4D",
    purple = "#2D0D3D",
    gold   = "#3D2800",
}

-- 种族中文名
local RACE_NAMES = {
    human  = "联盟",
    demon  = "翼族",
    dark   = "机械",
    spirit = "元素",
}

-- 种族图标
local RACE_ICONS = {
    human  = "⚔️",
    demon  = "👹",
    dark   = "💀",
    spirit = "✨",
}

-- 种族颜色
local RACE_COLORS = {
    human  = "#FFD700",
    demon  = "#FF4444",
    dark   = "#8B00FF",
    spirit = "#00BFFF",
}

-- 职业中文名
local CLASS_NAMES = {
    melee  = "近战",
    ranged = "远程",
}

-- ========== 内部状态 ==========
local selectedCards_ = {}  -- 当前选中的卡牌名列表
local currentSlot_ = 1     -- 当前编辑的卡组槽位
local allCardNames_ = {}   -- 全部卡牌名（有序）
local wrapper_ = nil       -- 包装面板
local onConfirm_ = nil     -- 确认回调
local onBack_ = nil        -- 返回回调

-- ========== 工具函数 ==========

--- 获取全部卡牌名列表，已解锁的在前，未解锁的在后，品质从低到高排列
local function getAllCardsSorted()
    local unlockedCards = {}
    local lockedCards = {}
    local qualityOrder = { "green", "blue", "purple", "gold" }
    
    -- 获取已解锁卡牌列表
    local unlockedSet = {}
    for _, name in ipairs(PlayerDataManager.GetUnlockedCards()) do
        unlockedSet[name] = true
    end
    
    -- 按品质排序分组
    for _, quality in ipairs(qualityOrder) do
        for cardName, cardDef in pairs(UnitConfig.CARDS) do
            if cardDef.quality == quality then
                if unlockedSet[cardName] then
                    unlockedCards[#unlockedCards + 1] = cardName
                else
                    lockedCards[#lockedCards + 1] = cardName
                end
            end
        end
    end
    
    -- 合并：已解锁在前，未解锁在后
    for _, name in ipairs(lockedCards) do
        unlockedCards[#unlockedCards + 1] = name
    end
    
    return unlockedCards
end

--- 检查某卡是否已选中
local function isSelected(cardName)
    for _, name in ipairs(selectedCards_) do
        if name == cardName then return true end
    end
    return false
end

--- 添加卡牌到当前牌组
local function addCardToDeck(cardName)
    if isSelected(cardName) then return end
    if #selectedCards_ >= DECK_SIZE then return end
    selectedCards_[#selectedCards_ + 1] = cardName
    
    -- 尝试保存，验证后再保存
    local valid, err = DeckManager.ValidateDeck(selectedCards_)
    if valid then
        DeckManager.SavePlayerDeck(selectedCards_, currentSlot_)
        UI.Toast.Show("已添加卡牌，卡组已自动保存", { type = "success", duration = 1.5 })
    end
    DeckBuilderUI.Refresh()
end

--- 从当前牌组移除卡牌
local function removeCardFromDeck(cardName)
    for i, name in ipairs(selectedCards_) do
        if name == cardName then
            table.remove(selectedCards_, i)
            break
        end
    end
    
    -- 尝试保存，验证后再保存
    local valid, err = DeckManager.ValidateDeck(selectedCards_)
    if valid then
        DeckManager.SavePlayerDeck(selectedCards_, currentSlot_)
        UI.Toast.Show("已移除卡牌，卡组已自动保存", { type = "success", duration = 1.5 })
    else
        DeckManager.SavePlayerDeck(selectedCards_, currentSlot_) -- 即使不完整也保存
    end
    DeckBuilderUI.Refresh()
end

--- 打开卡牌详情弹窗（点击任何卡牌都走这里）
local function showCardDetail(cardName)
    -- 注入卡组操作回调
    CardDetailPopup.SetDeckCallbacks({
        isInDeck = function(name) return isSelected(name) end,
        addToDeck = function(name) addCardToDeck(name) end,
        removeFromDeck = function(name) removeCardFromDeck(name) end,
        isDeckFull = function() return #selectedCards_ >= DECK_SIZE end,
    })
    CardDetailPopup.Show(cardName, function()
        DeckBuilderUI.Refresh()
    end)
end

--- 计算战力（仅 unit 卡牌有效）
local function calculatePower()
    local power = 0
    for _, cardName in ipairs(selectedCards_) do
        local card = UnitConfig.CARDS[cardName]
        if card and card.slotType == "unit" then
            local qualityMult = { green = 1, blue = 2, purple = 4, gold = 8 }
            power = power + (card.hp + card.atk * 5) * (qualityMult[card.quality] or 1)
        end
    end
    return power
end

--- 验证卡组是否满足品质要求：至少1绿1蓝1紫1橙单位 + 1矿脉
local function validateDeck(cards)
    local hasGreen, hasBlue, hasPurple, hasGold, hasMine = false, false, false, false, false
    for _, cardName in ipairs(cards) do
        local card = UnitConfig.CARDS[cardName]
        if card then
            if card.slotType == "mine" then
                hasMine = true
            elseif card.slotType == "unit" then
                if card.quality == "green" then hasGreen = true
                elseif card.quality == "blue" then hasBlue = true
                elseif card.quality == "purple" then hasPurple = true
                elseif card.quality == "gold" then hasGold = true
                end
            end
        end
    end
    return hasGreen, hasBlue, hasPurple, hasGold, hasMine
end

-- ========== UI 构建 ==========

--- 创建卡组标签页切换栏
local function createSlotTabs(canConfirm)
    local tabs = {}
    for i = 1, MAX_SLOTS do
        local isActive = (i == currentSlot_)
        local hasDeck = DeckManager.LoadDeckSlot(i) ~= nil

        tabs[#tabs + 1] = UI.Button {
            width = 52, height = 32,
            marginRight = 6,
            backgroundColor = isActive and "#FF6D00" or (hasDeck and "#2A2A4A" or "#1A1A2E"),
            borderRadius = 8,
            borderWidth = isActive and 0 or 1,
            borderColor = hasDeck and "#555577" or "#333344",
            alignItems = "center",
            justifyContent = "center",
            onClick = function()
                -- 切换槽位
                currentSlot_ = i
                DeckManager.SetActiveSlot(i)
                local slotDeck = DeckManager.LoadDeckSlot(i)
                if slotDeck then
                    selectedCards_ = {}
                    for _, name in ipairs(slotDeck) do
                        selectedCards_[#selectedCards_ + 1] = name
                    end
                else
                    selectedCards_ = {}
                end
                DeckBuilderUI.Refresh()
            end,
            children = {
                UI.Label {
                    text = tostring(i),
                    fontSize = isActive and 15 or 13,
                    fontWeight = isActive and "bold" or "normal",
                    fontColor = isActive and "#FFFFFF" or (hasDeck and "#CCCCCC" or "#666688"),
                },
            }
        }
    end

    return UI.Panel {
        width = "100%",
        height = 44,
        flexDirection = "row",
        alignItems = "center",
        paddingLeft = 12, paddingRight = 12,
        backgroundColor = "#12122A",
        children = {
            UI.Label {
                text = "卡组",
                fontSize = 13,
                fontColor = "#8888AA",
                marginRight = 10,
            },
            table.unpack(tabs),
            UI.Panel { flexGrow = 1 },
            UI.Button {
                width = 56, height = 28,
                backgroundColor = canConfirm and "#2E7D32" or "#333344",
                borderRadius = 14,
                alignItems = "center",
                justifyContent = "center",
                disabled = not canConfirm,
                onClick = function()
                    if #selectedCards_ == DECK_SIZE then
                        local valid, err = DeckManager.ValidateDeck(selectedCards_)
                        if not valid then
                            UI.Toast.Show(err or "卡组不合法", { type = "warning", duration = 3 })
                            return
                        end
                        DeckManager.SavePlayerDeck(selectedCards_, currentSlot_)
                        UI.Toast.Show("卡组已保存！", { type = "success", duration = 1.5 })
                        if onConfirm_ then
                            onConfirm_(selectedCards_)
                        end
                    end
                end,
                children = {
                    UI.Label {
                        text = "💾",
                        fontSize = 14,
                        fontWeight = "bold",
                        fontColor = canConfirm and "#FFFFFF" or "#666666",
                    },
                }
            },
        }
    }
end

--- 创建已选卡组网格（4x2，大尺寸立绘风格）
local function createDeckGrid()
    local gridChildren = {}
    for i = 1, DECK_SIZE do
        local cardName = selectedCards_[i]
        local card = cardName and UnitConfig.CARDS[cardName]

        if card then
            local qualityColor = QUALITY_COLORS[card.quality] or "#888888"
            local bgColor = QUALITY_BG[card.quality] or "#1A1A2E"
            gridChildren[#gridChildren + 1] = UI.Button {
                width = "23%",
                height = 100,
                margin = 2,
                backgroundColor = bgColor,
                borderWidth = 2,
                borderColor = qualityColor,
                borderRadius = 10,
                flexDirection = "column",
                alignItems = "center",
                justifyContent = "center",
                onClick = function()
                    showCardDetail(cardName)
                end,
                children = {
                    -- 卡牌图标（立绘风格）
                    UI.Panel {
                        width = 48,
                        height = 48,
                        borderRadius = 24,
                        backgroundColor = "#0A0A1E",
                        borderWidth = 2,
                        borderColor = qualityColor,
                        alignItems = "center",
                        justifyContent = "center",
                        children = {
                            UI.Label {
                                text = card.icon or "?",
                                fontSize = 24,
                                fontColor = qualityColor,
                                fontWeight = "bold",
                            },
                        },
                    },
                    -- 卡牌名
                    UI.Label {
                        text = cardName,
                        fontSize = 11,
                        fontColor = "#FFFFFF",
                        fontWeight = "bold",
                        marginTop = 4,
                    },
                    -- 品质标签
                    UI.Label {
                        text = card.quality == "green" and "普通" or
                               card.quality == "blue" and "稀有" or
                               card.quality == "purple" and "史诗" or
                               card.quality == "gold" and "传奇" or "建筑",
                        fontSize = 9,
                        fontColor = qualityColor,
                        marginTop = 1,
                    },
                }
            }
        else
            -- 空槽
            gridChildren[#gridChildren + 1] = UI.Panel {
                width = "23%",
                height = 100,
                margin = 2,
                backgroundColor = "#0D0D1A",
                borderWidth = 1,
                borderColor = "#2A2A3A",
                borderRadius = 10,
                alignItems = "center",
                justifyContent = "center",
                children = {
                    UI.Label {
                        text = "+",
                        fontSize = 28,
                        fontColor = "#333355",
                    },
                }
            }
        end
    end

    return UI.Panel {
        width = "100%",
        flexDirection = "row",
        flexWrap = "wrap",
        paddingLeft = 8, paddingRight = 8,
        paddingTop = 4,
        justifyContent = "center",
        children = gridChildren,
    }
end

--- 创建战力和羁绊展示行
local function createPowerRow()
    local power = calculatePower()

    -- 计算羁绊
    SynergyManager.Calculate(1, selectedCards_)
    local effects = SynergyManager.GetActiveEffects(1)
    local raceCounts = SynergyManager.GetRaceCounts(1)

    -- 羁绊图标
    local synergyIcons = {}
    for race, count in pairs(raceCounts) do
        if count >= 2 then
            synergyIcons[#synergyIcons + 1] = UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginRight = 8,
                backgroundColor = "#1A1A3A",
                borderRadius = 10,
                paddingLeft = 6, paddingRight = 6,
                paddingTop = 2, paddingBottom = 2,
                children = {
                    UI.Label {
                        text = RACE_ICONS[race] or "?",
                        fontSize = 12,
                    },
                    UI.Label {
                        text = tostring(count),
                        fontSize = 11,
                        fontColor = RACE_COLORS[race] or "#FFFFFF",
                        marginLeft = 2,
                    },
                }
            }
        end
    end

    -- 激活羁绊数量
    local activeCount = #effects

    return UI.Panel {
        width = "100%",
        height = 36,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "space-between",
        paddingLeft = 12, paddingRight = 12,
        backgroundColor = "#0D0D20",
        borderTopWidth = 1,
        borderBottomWidth = 1,
        borderColor = "#222244",
        children = {
            -- 战力
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "⚡",
                        fontSize = 14,
                    },
                    UI.Label {
                        text = tostring(power),
                        fontSize = 15,
                        fontWeight = "bold",
                        fontColor = "#FFD700",
                        marginLeft = 4,
                    },
                }
            },
            -- 羁绊图标
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "羁绊" .. activeCount,
                        fontSize = 11,
                        fontColor = activeCount > 0 and "#00FF88" or "#666688",
                        marginRight = 6,
                    },
                    table.unpack(synergyIcons),
                }
            },
            -- 数量
            UI.Label {
                text = #selectedCards_ .. "/" .. DECK_SIZE,
                fontSize = 13,
                fontColor = #selectedCards_ == DECK_SIZE and "#00FF88" or "#FF8800",
            },
        }
    }
end

--- 创建单张卡牌选择按钮（全卡牌区域，立绘展示）
local function createCardItem(cardName)
    local card = UnitConfig.CARDS[cardName]
    if not card then return UI.Panel { width = 0, height = 0 } end

    local selected = isSelected(cardName)
    local qualityColor = QUALITY_COLORS[card.quality] or "#888888"
    local qualityBg = QUALITY_BG[card.quality] or "#1A1A2E"
    local bgColor = selected and "#2A3A5A" or qualityBg
    local borderColor = selected and "#4488FF" or qualityColor
    
    -- 检查是否已解锁
    local isUnlocked = false
    for _, name in ipairs(PlayerDataManager.GetUnlockedCards()) do
        if name == cardName then
            isUnlocked = true
            break
        end
    end

    return UI.Button {
        width = "31%",
        height = 110,
        margin = 3,
        backgroundColor = bgColor,
        borderWidth = selected and 2 or 1.5,
        borderColor = borderColor,
        borderRadius = 12,
        flexDirection = "column",
        alignItems = "center",
        justifyContent = "space-between",
        paddingTop = 4, paddingBottom = 4,
        onClick = function()
            showCardDetail(cardName)
        end,
        children = {
            -- 立绘展示区域（带光晕背景
            UI.Panel {
                width = "100%",
                height = 55,
                alignItems = "center",
                justifyContent = "center",
                children = {
                    -- 光晕背景
                    UI.Panel {
                        width = 44,
                        height = 44,
                        borderRadius = 22,
                        backgroundColor = isUnlocked and qualityColor or "#333344",
                        opacity = 0.2,
                    },
                    -- 卡牌图标
                    UI.Panel {
                        position = "absolute",
                        width = 48,
                        height = 48,
                        borderRadius = 24,
                        backgroundColor = isUnlocked and "#000000" or "#222233",
                        borderWidth = 2,
                        borderColor = isUnlocked and qualityColor or "#444466",
                        alignItems = "center",
                        justifyContent = "center",
                        children = {
                            UI.Label {
                                text = isUnlocked and (card.icon or "?") or "🔒",
                                fontSize = 26,
                                fontColor = isUnlocked and qualityColor or "#666688",
                            },
                        },
                    },
                },
            },
            -- 卡牌信息区域
            UI.Panel {
                width = "100%",
                flexDirection = "column",
                alignItems = "center",
                children = {
                    -- 卡名
                    UI.Label {
                        text = cardName,
                        fontSize = 10,
                        fontColor = isUnlocked and "#FFFFFF" or "#666688",
                        fontWeight = "bold",
                    },
                    -- 品质标签
                    UI.Panel {
                        flexDirection = "row",
                        alignItems = "center",
                        marginTop = 2,
                        children = {
                            UI.Panel {
                                width = 6, height = 6,
                                borderRadius = 3,
                                backgroundColor = qualityColor,
                            },
                            UI.Label {
                                text = " " .. (card.quality == "green" and "普通" or 
                                              card.quality == "blue" and "稀有" or 
                                              card.quality == "purple" and "史诗" or "传奇"),
                                fontSize = 8,
                                fontColor = qualityColor,
                            },
                        },
                    },
                },
            },
            -- 已上阵标记
            selected and UI.Panel {
                position = "absolute",
                top = 4, right = 4,
                width = 20, height = 20,
                borderRadius = 10,
                backgroundColor = "#4488FF",
                alignItems = "center",
                justifyContent = "center",
                borderWidth = 1.5,
                borderColor = "#FFFFFF",
                children = {
                    UI.Label { text = "✓", fontSize = 11, fontColor = "#FFFFFF", fontWeight = "bold" },
                }
            } or UI.Panel { width = 0, height = 0 },
        }
    }
end

--- 创建全卡牌选择区域（无种族分组，全部放一起）
local function createAllCardsSection()
    local allCards = {}
    for _, cardName in ipairs(allCardNames_) do
        allCards[#allCards + 1] = createCardItem(cardName)
    end

    return UI.Panel {
        width = "100%",
        flexDirection = "row",
        flexWrap = "wrap",
        children = allCards,
    }
end

-- ========== 公共 API ==========

function DeckBuilderUI.Show(opts)
    opts = opts or {}
    onConfirm_ = opts.onConfirm
    onBack_ = opts.onBack
    allCardNames_ = getAllCardsSorted()
    currentSlot_ = DeckManager.GetActiveSlot()
    local savedDeck = DeckManager.LoadDeckSlot(currentSlot_)
    if savedDeck and #savedDeck > 0 then
        selectedCards_ = {}
        for _, name in ipairs(savedDeck) do
            selectedCards_[#selectedCards_ + 1] = name
        end
    else
        selectedCards_ = {}
    end
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    DeckBuilderUI.Refresh()
    return wrapper_
end

--- 刷新整个 UI
function DeckBuilderUI.Refresh()
    local hasG, hasB, hasP, hasGold, hasMine = validateDeck(selectedCards_)
    local canConfirm = (#selectedCards_ == DECK_SIZE) and hasG and hasB and hasP and hasGold and hasMine
    local allCardsPanel = createAllCardsSection()

    local content = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = "#0A0A18",
        paddingTop = 12,
        children = {
            createSlotTabs(canConfirm),
            createDeckGrid(),
            createPowerRow(),
            UI.Panel {
                width = "100%",
                paddingLeft = 12, paddingTop = 8, paddingBottom = 4,
                children = {
                    UI.Label {
                        text = "全部卡牌",
                        fontSize = 14,
                        fontWeight = "bold",
                        fontColor = "#AAAACC",
                    },
                }
            },
            UI.ScrollView {
                width = "100%",
                flexGrow = 1,
                flexShrink = 1,
                paddingLeft = 4, paddingRight = 4,
                paddingBottom = 16,
                children = { allCardsPanel },
            },
        }
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 隐藏卡组配置页面
function DeckBuilderUI.Hide()
    wrapper_ = nil
end

--- 是否正在显示
function DeckBuilderUI.IsShowing()
    return wrapper_ ~= nil
end

return DeckBuilderUI


-- ══════════════════════════════════════════════
