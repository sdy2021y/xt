-- ============================================================================
-- ArtifactUI.lua - 神器管理界面（炼器阁）
-- 功能：召唤/升级/装备神器
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local PlayerDataManager = require("Data.PlayerDataManager")
local ArtifactConfig = require("Config.ArtifactConfig")
local EventBus = require("Infrastructure.EventBus")

local ArtifactUI = {}

-- ========== 颜色常量 ==========
local COLORS = {
    bgDark = "#0a0a1a",
    bgCard = "#1a1a3a",
    bgPanel = "#12122a",
    text = "#e8e0d4",
    textDim = "#8a7e72",
    gold = "#ffd700",
    purple = "#9b59b6",
    purpleLight = "#c39bd3",
    blue = "#5dade2",
    green = "#27ae60",
    red = "#e74c3c",
    orange = "#e67e22",
    legendary = "#ff8c00",
    epic = "#a855f7",
    rare = "#3b82f6",
    common = "#6b7280",
    border = "#2a2a4a",
}

-- 品质颜色映射
local QUALITY_COLORS = {
    common = COLORS.common,
    rare = COLORS.rare,
    epic = COLORS.epic,
    legendary = COLORS.legendary,
}

-- ========== 内部状态 ==========
local wrapper_ = nil
local onBack_ = nil
local activeTab_ = "list"  -- "list" | "summon" | "detail"
local selectedArtifact_ = nil

-- ========== 数据访问 ==========

--- 获取玩家所有神器数据
local function getPlayerArtifacts()
    local pd = PlayerDataManager.GetData() or {}
    return pd.artifacts or {}
end

--- 获取当前装备的神器名
local function getEquippedName()
    local pd = PlayerDataManager.GetData() or {}
    return pd.equippedArtifact and pd.equippedArtifact.name or nil
end

--- 获取召唤等级
local function getSummonLevel()
    local pd = PlayerDataManager.GetData() or {}
    return pd.artifactSummonLevel or 1
end

--- 获取累计抽数
local function getSummonCount()
    local pd = PlayerDataManager.GetData() or {}
    return pd.artifactSummonCount or 0
end

--- 获取星钻数量
local function getXianyu()
    local pd = PlayerDataManager.GetData() or {}
    return pd.xianyu or 0
end

-- ========== 召唤逻辑 ==========

--- 执行一次召唤
local function doSummon(count)
    local cost = ArtifactConfig.SUMMON_COST.single * count
    local xianyu = getXianyu()
    if xianyu < cost then
        UI.Toast.Show("星钻不足", "warning")
        return
    end

    -- 扣除星钻
    PlayerDataManager.AddXianyu(-cost)

    -- 根据召唤等级概率抽取
    local summonLevel = getSummonLevel()
    local probTable = nil
    for i = #ArtifactConfig.SUMMON_PROBABILITIES, 1, -1 do
        if summonLevel >= ArtifactConfig.SUMMON_PROBABILITIES[i].level then
            probTable = ArtifactConfig.SUMMON_PROBABILITIES[i]
            break
        end
    end
    if not probTable then
        probTable = ArtifactConfig.SUMMON_PROBABILITIES[1]
    end

    local results = {}
    local pd = PlayerDataManager.GetData() or {}
    local artifacts = pd.artifacts or {}

    for _ = 1, count do
        local roll = math.random() * 100
        local resultType = "crystal"  -- 默认：结晶（无用）

        if roll < probTable.legendary then
            resultType = "legendary"
        elseif roll < probTable.legendary + probTable.epic then
            resultType = "epic"
        elseif roll < probTable.legendary + probTable.epic + probTable.rare then
            resultType = "rare"
        elseif roll < probTable.legendary + probTable.epic + probTable.rare + probTable.common then
            resultType = "common"
        end

        -- 根据品质随机选择神器并增加碎片
        if resultType ~= "crystal" then
            local candidates = {}
            for name, def in pairs(ArtifactConfig.ARTIFACTS) do
                if def.quality == resultType then
                    candidates[#candidates + 1] = name
                end
            end
            if #candidates > 0 then
                local chosen = candidates[math.random(1, #candidates)]
                if not artifacts[chosen] then
                    artifacts[chosen] = { name = chosen, level = 1, star = 0, fragmentCount = 0, equipped = false }
                end
                artifacts[chosen].fragmentCount = (artifacts[chosen].fragmentCount or 0) + 1
                results[#results + 1] = { type = "fragment", name = chosen, quality = resultType }
            else
                results[#results + 1] = { type = "crystal", amount = 5 }
            end
        else
            results[#results + 1] = { type = "crystal", amount = 5 }
        end
    end

    -- 累计抽数+检查升级
    local totalCount = (pd.artifactSummonCount or 0) + count
    pd.artifactSummonCount = totalCount
    local nextLevelCost = ArtifactConfig.SUMMON_LEVEL_UP_COST[summonLevel] or 999999
    if totalCount >= nextLevelCost then
        pd.artifactSummonLevel = summonLevel + 1
        pd.artifactSummonCount = totalCount - nextLevelCost
        UI.Toast.Show("召唤等级提升至 " .. (summonLevel + 1) .. " 级！", "success")
    end

    pd.artifacts = artifacts
    PlayerDataManager.Set("artifacts", artifacts)
    PlayerDataManager.Set("artifactSummonCount", pd.artifactSummonCount)
    PlayerDataManager.Set("artifactSummonLevel", pd.artifactSummonLevel or summonLevel)
    PlayerDataManager.Save()

    -- 显示结果
    local fragCount = 0
    local crystalCount = 0
    for _, r in ipairs(results) do
        if r.type == "fragment" then fragCount = fragCount + 1
        else crystalCount = crystalCount + (r.amount or 0) end
    end
    UI.Toast.Show(
        string.format("获得 %d 个碎片, %d 结晶", fragCount, crystalCount),
        fragCount > 0 and "success" or "info"
    )

    -- 刷新界面
    ArtifactUI.Refresh()
end

-- ========== 升级逻辑 ==========

local function tryLevelUp(artifactName)
    local pd = PlayerDataManager.GetData() or {}
    local artifacts = pd.artifacts or {}
    local art = artifacts[artifactName]
    if not art then return end

    local fragCost = ArtifactConfig.GetLevelUpFragments(art.level)
    local runeCost = ArtifactConfig.GetLevelUpRunes(art.level)
    if art.fragmentCount < fragCost then
        UI.Toast.Show("碎片不足（需要 " .. fragCost .. "）", "warning")
        return
    end
    if not PlayerDataManager.SpendRunes(runeCost) then
        UI.Toast.Show("符文不足（需要 " .. runeCost .. "）", "warning")
        return
    end

    art.fragmentCount = art.fragmentCount - fragCost
    art.level = art.level + 1
    artifacts[artifactName] = art
    PlayerDataManager.Set("artifacts", artifacts)
    PlayerDataManager.Save()

    UI.Toast.Show(artifactName .. " 升至 " .. art.level .. " 级", "success")
    selectedArtifact_ = art
    ArtifactUI.Refresh()
end

-- ========== 升星逻辑 ==========

local function tryStarUp(artifactName)
    local ArtifactManager = require("Battle.ArtifactManager")
    local success = ArtifactManager.StarUpArtifact(artifactName)
    if not success then
        local pd = PlayerDataManager.GetData() or {}
        local art = (pd.artifacts or {})[artifactName]
        if art and (art.star or 0) >= 5 then
            UI.Toast.Show("已达满星（★5）", "warning")
        else
            local cost = ArtifactConfig.GetStarUpFragments((art and art.star) or 0)
            UI.Toast.Show("碎片不足（需要 " .. cost .. "）", "warning")
        end
        return
    end

    local pd = PlayerDataManager.GetData() or {}
    local art = (pd.artifacts or {})[artifactName]
    UI.Toast.Show(artifactName .. " 升至 ★" .. (art and art.star or "?"), "success")
    selectedArtifact_ = art
    ArtifactUI.Refresh()
end

-- ========== 装备逻辑 ==========

local function tryEquip(artifactName)
    local pd = PlayerDataManager.GetData() or {}
    local artifacts = pd.artifacts or {}

    -- 取消当前装备
    for name, art in pairs(artifacts) do
        art.equipped = false
    end

    -- 装备选中的
    if artifacts[artifactName] then
        artifacts[artifactName].equipped = true
    end

    PlayerDataManager.Set("artifacts", artifacts)
    PlayerDataManager.Set("equippedArtifact", artifacts[artifactName])
    PlayerDataManager.Save()

    UI.Toast.Show("已装备「" .. artifactName .. "」", "success")
    ArtifactUI.Refresh()
end

local function tryUnequip(artifactName)
    local pd = PlayerDataManager.GetData() or {}
    local artifacts = pd.artifacts or {}

    if artifacts[artifactName] then
        artifacts[artifactName].equipped = false
    end
    PlayerDataManager.Set("artifacts", artifacts)
    PlayerDataManager.Set("equippedArtifact", nil)
    PlayerDataManager.Save()

    UI.Toast.Show("已卸下「" .. artifactName .. "」", "info")
    ArtifactUI.Refresh()
end

-- ========== UI 构建 ==========

--- Tab 栏
local function createTabs()
    local tabs = {
        { id = "list", label = "神器列表" },
        { id = "summon", label = "召唤" },
    }

    local tabChildren = {}
    for _, tab in ipairs(tabs) do
        local isActive = (activeTab_ == tab.id)
        tabChildren[#tabChildren + 1] = UI.Button {
            flexGrow = 1,
            paddingTop = 8, paddingBottom = 8,
            backgroundColor = isActive and COLORS.purple or COLORS.bgDark,
            borderRadius = 6,
            onClick = function()
                activeTab_ = tab.id
                selectedArtifact_ = nil
                ArtifactUI.Refresh()
            end,
            children = {
                UI.Label {
                    text = tab.label,
                    fontSize = 12,
                    fontColor = isActive and "#ffffff" or COLORS.textDim,
                    textAlign = "center",
                    fontWeight = isActive and "bold" or "normal",
                },
            }
        }
    end

    return UI.Panel {
        width = "100%",
        flexDirection = "row",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 8, paddingBottom = 8,
        gap = 8,
        children = tabChildren,
    }
end

--- 神器卡片（列表中）
local function createArtifactCard(artifactName, artifactData)
    local def = ArtifactConfig.ARTIFACTS[artifactName]
    if not def then return UI.Panel { height = 0 } end

    local qualityColor = QUALITY_COLORS[def.quality] or COLORS.common
    local equippedName = getEquippedName()
    local isEquipped = (equippedName == artifactName)

    return UI.Button {
        width = "100%",
        flexDirection = "row",
        alignItems = "center",
        paddingLeft = 10, paddingRight = 10,
        paddingTop = 10, paddingBottom = 10,
        marginBottom = 8,
        borderRadius = 10,
        backgroundColor = COLORS.bgCard,
        borderWidth = isEquipped and 2 or 1,
        borderColor = isEquipped and COLORS.gold or COLORS.border,
        onClick = function()
            selectedArtifact_ = artifactData
            activeTab_ = "detail"
            ArtifactUI.Refresh()
        end,
        children = {
            -- 图标
            UI.Panel {
                width = 44, height = 44,
                borderRadius = 22,
                backgroundColor = qualityColor .. "33",
                justifyContent = "center",
                alignItems = "center",
                borderWidth = 2,
                borderColor = qualityColor,
                children = {
                    UI.Label { text = def.icon, fontSize = 22 },
                }
            },
            -- 信息
            UI.Panel {
                marginLeft = 10,
                flexGrow = 1,
                flexShrink = 1,
                children = {
                    UI.Panel {
                        flexDirection = "row", alignItems = "center",
                        children = {
                            UI.Label {
                                text = artifactName,
                                fontSize = 13,
                                fontColor = qualityColor,
                                fontWeight = "bold",
                            },
                            isEquipped and UI.Label {
                                text = " [装备中]",
                                fontSize = 10,
                                fontColor = COLORS.gold,
                            } or nil,
                        }
                    },
                    UI.Label {
                        text = string.format("Lv.%d  ★%d  碎片:%d", artifactData.level, artifactData.star, artifactData.fragmentCount or 0),
                        fontSize = 10,
                        fontColor = COLORS.textDim,
                        marginTop = 3,
                    },
                    UI.Label {
                        text = def.desc,
                        fontSize = 10,
                        fontColor = COLORS.textDim,
                        marginTop = 2,
                    },
                }
            },
            -- 箭头
            UI.Label { text = "›", fontSize = 18, fontColor = COLORS.textDim },
        }
    }
end

--- 神器列表页
local function createListContent()
    local artifacts = getPlayerArtifacts()
    local children = {}

    -- 列表内容
    local hasArtifact = false
    for name, data in pairs(artifacts) do
        hasArtifact = true
        children[#children + 1] = createArtifactCard(name, data)
    end

    if not hasArtifact then
        children[#children + 1] = UI.Panel {
            width = "100%",
            paddingTop = 40, paddingBottom = 40,
            alignItems = "center",
            children = {
                UI.Label { text = "🔮", fontSize = 40 },
                UI.Label {
                    text = "尚未拥有神器",
                    fontSize = 14,
                    fontColor = COLORS.textDim,
                    marginTop = 12,
                },
                UI.Label {
                    text = "前往「召唤」获取神器碎片",
                    fontSize = 11,
                    fontColor = COLORS.textDim,
                    marginTop = 6,
                },
            }
        }
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 8,
        children = children,
    }
end

--- 召唤页
local function createSummonContent()
    local summonLevel = getSummonLevel()
    local summonCount = getSummonCount()
    local nextCost = ArtifactConfig.SUMMON_LEVEL_UP_COST[summonLevel] or 999
    local progress = math.min(summonCount / nextCost, 1.0)
    local singleCost = ArtifactConfig.SUMMON_COST.single

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 12,
        children = {
            -- 召唤等级信息
            UI.Panel {
                width = "100%",
                backgroundColor = COLORS.bgCard,
                borderRadius = 10,
                paddingLeft = 14, paddingRight = 14,
                paddingTop = 12, paddingBottom = 12,
                marginBottom = 12,
                children = {
                    UI.Panel {
                        flexDirection = "row", justifyContent = "space-between",
                        children = {
                            UI.Label {
                                text = "召唤等级: " .. summonLevel,
                                fontSize = 13,
                                fontColor = COLORS.gold,
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = summonCount .. "/" .. nextCost,
                                fontSize = 11,
                                fontColor = COLORS.textDim,
                            },
                        }
                    },
                    -- 进度条
                    UI.Panel {
                        width = "100%", height = 6,
                        backgroundColor = COLORS.border,
                        borderRadius = 3,
                        marginTop = 8,
                        children = {
                            UI.Panel {
                                width = tostring(math.floor(progress * 100)) .. "%",
                                height = "100%",
                                backgroundColor = COLORS.purple,
                                borderRadius = 3,
                            },
                        }
                    },
                    UI.Label {
                        text = "等级越高，稀有神器概率越大",
                        fontSize = 10,
                        fontColor = COLORS.textDim,
                        marginTop = 6,
                    },
                }
            },

            -- 概率预览
            UI.Panel {
                width = "100%",
                backgroundColor = COLORS.bgCard,
                borderRadius = 10,
                paddingLeft = 14, paddingRight = 14,
                paddingTop = 10, paddingBottom = 10,
                marginBottom = 16,
                children = {
                    UI.Label { text = "当前概率", fontSize = 11, fontColor = COLORS.textDim, marginBottom = 6 },
                    UI.Panel {
                        flexDirection = "row", justifyContent = "space-between",
                        children = {
                            UI.Label { text = "传说", fontSize = 10, fontColor = COLORS.legendary },
                            UI.Label { text = "史诗", fontSize = 10, fontColor = COLORS.epic },
                            UI.Label { text = "稀有", fontSize = 10, fontColor = COLORS.rare },
                        }
                    },
                    UI.Panel {
                        flexDirection = "row", justifyContent = "space-between", marginTop = 2,
                        children = {
                            UI.Label { text = "0.1%", fontSize = 10, fontColor = COLORS.legendary },
                            UI.Label { text = "0.9%", fontSize = 10, fontColor = COLORS.epic },
                            UI.Label { text = "4%", fontSize = 10, fontColor = COLORS.rare },
                        }
                    },
                }
            },

            -- 召唤按钮
            UI.Panel {
                width = "100%",
                alignItems = "center",
                gap = 10,
                children = {
                    UI.Button {
                        width = "90%", height = 44,
                        backgroundColor = COLORS.purple,
                        borderRadius = 10,
                        justifyContent = "center",
                        alignItems = "center",
                        onClick = function() doSummon(1) end,
                        children = {
                            UI.Label {
                                text = "单抽 (💎" .. singleCost .. ")",
                                fontSize = 14,
                                fontColor = "#ffffff",
                                fontWeight = "bold",
                            },
                        }
                    },
                    UI.Button {
                        width = "90%", height = 44,
                        backgroundColor = COLORS.legendary,
                        borderRadius = 10,
                        justifyContent = "center",
                        alignItems = "center",
                        onClick = function() doSummon(10) end,
                        children = {
                            UI.Label {
                                text = "十连抽 (💎" .. (singleCost * 10) .. ")",
                                fontSize = 14,
                                fontColor = "#ffffff",
                                fontWeight = "bold",
                            },
                        }
                    },
                }
            },
        }
    }
end

--- 神器详情页
local function createDetailContent()
    if not selectedArtifact_ then
        activeTab_ = "list"
        return createListContent()
    end

    local artifactName = selectedArtifact_.name
    local def = ArtifactConfig.ARTIFACTS[artifactName]
    if not def then
        activeTab_ = "list"
        return createListContent()
    end

    local qualityColor = QUALITY_COLORS[def.quality] or COLORS.common
    local equippedName = getEquippedName()
    local isEquipped = (equippedName == artifactName)
    local levelUpCost = ArtifactConfig.GetLevelUpFragments(selectedArtifact_.level)
    local levelUpRuneCost = ArtifactConfig.GetLevelUpRunes(selectedArtifact_.level)
    local canLevelUp = (selectedArtifact_.fragmentCount or 0) >= levelUpCost and PlayerDataManager.Get("runes") >= levelUpRuneCost
    local currentStar = selectedArtifact_.star or 0
    local starUpCost = ArtifactConfig.GetStarUpFragments(currentStar)
    local canStarUp = currentStar < 5 and (selectedArtifact_.fragmentCount or 0) >= starUpCost

    -- 被动技能列表
    local passiveChildren = {}
    if def.passives then
        for lvl, passive in pairs(def.passives) do
            local unlocked = selectedArtifact_.level >= lvl
            passiveChildren[#passiveChildren + 1] = UI.Panel {
                width = "100%",
                flexDirection = "row",
                alignItems = "center",
                paddingTop = 6, paddingBottom = 6,
                opacity = unlocked and 1.0 or 0.5,
                children = {
                    UI.Label {
                        text = unlocked and "✓" or "🔒",
                        fontSize = 12,
                        width = 20,
                    },
                    UI.Panel {
                        flexGrow = 1, flexShrink = 1,
                        children = {
                            UI.Label {
                                text = string.format("Lv.%d %s", lvl, passive.name),
                                fontSize = 11,
                                fontColor = unlocked and COLORS.green or COLORS.textDim,
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = passive.desc,
                                fontSize = 10,
                                fontColor = COLORS.textDim,
                                marginTop = 2,
                            },
                        }
                    },
                }
            }
        end
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 12,
        children = {
            -- 头部：图标+名称
            UI.Panel {
                width = "100%",
                alignItems = "center",
                paddingBottom = 16,
                children = {
                    UI.Panel {
                        width = 64, height = 64,
                        borderRadius = 32,
                        backgroundColor = qualityColor .. "33",
                        justifyContent = "center",
                        alignItems = "center",
                        borderWidth = 3,
                        borderColor = qualityColor,
                        children = {
                            UI.Label { text = def.icon, fontSize = 32 },
                        }
                    },
                    UI.Label {
                        text = artifactName,
                        fontSize = 16,
                        fontColor = qualityColor,
                        fontWeight = "bold",
                        marginTop = 8,
                    },
                    UI.Label {
                        text = string.format("Lv.%d  ★%d  碎片: %d",
                            selectedArtifact_.level, selectedArtifact_.star, selectedArtifact_.fragmentCount or 0),
                        fontSize = 11,
                        fontColor = COLORS.textDim,
                        marginTop = 4,
                    },
                }
            },

            -- 技能信息
            UI.Panel {
                width = "100%",
                backgroundColor = COLORS.bgCard,
                borderRadius = 10,
                paddingLeft = 12, paddingRight = 12,
                paddingTop = 10, paddingBottom = 10,
                marginBottom = 10,
                children = {
                    UI.Label { text = "主动技能: " .. def.skill.name, fontSize = 12, fontColor = COLORS.gold, fontWeight = "bold" },
                    UI.Label { text = def.desc, fontSize = 11, fontColor = COLORS.text, marginTop = 4 },
                    UI.Label {
                        text = "充能: 翻格" .. table.concat(def.chargeStages, "/") .. "次",
                        fontSize = 10, fontColor = COLORS.textDim, marginTop = 4,
                    },
                }
            },

            -- 被动技能
            #passiveChildren > 0 and UI.Panel {
                width = "100%",
                backgroundColor = COLORS.bgCard,
                borderRadius = 10,
                paddingLeft = 12, paddingRight = 12,
                paddingTop = 10, paddingBottom = 10,
                marginBottom = 12,
                children = {
                    UI.Label { text = "被动技能", fontSize = 12, fontColor = COLORS.purple, fontWeight = "bold", marginBottom = 4 },
                    table.unpack(passiveChildren),
                }
            } or nil,

            -- 操作按钮（第一行：升级 + 升星）
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                gap = 10,
                marginTop = 8,
                children = {
                    -- 升级按钮
                    UI.Button {
                        flexGrow = 1, height = 40,
                        backgroundColor = canLevelUp and COLORS.green or COLORS.border,
                        borderRadius = 8,
                        justifyContent = "center",
                        alignItems = "center",
                        onClick = function()
                            tryLevelUp(artifactName)
                        end,
                        children = {
                            UI.Label {
                                text = "升级 (" .. levelUpCost .. "碎片+" .. levelUpRuneCost .. "符文)",
                                fontSize = 12,
                                fontColor = canLevelUp and "#ffffff" or COLORS.textDim,
                                fontWeight = "bold",
                            },
                        }
                    },
                    -- 升星按钮
                    UI.Button {
                        flexGrow = 1, height = 40,
                        backgroundColor = canStarUp and COLORS.orange or COLORS.border,
                        borderRadius = 8,
                        justifyContent = "center",
                        alignItems = "center",
                        onClick = function()
                            tryStarUp(artifactName)
                        end,
                        children = {
                            UI.Label {
                                text = currentStar >= 5 and "满星 ★5" or ("升星 (" .. starUpCost .. "碎片)"),
                                fontSize = 12,
                                fontColor = canStarUp and "#ffffff" or COLORS.textDim,
                                fontWeight = "bold",
                            },
                        }
                    },
                }
            },
            -- 操作按钮（第二行：装备/卸下）
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                gap = 10,
                marginTop = 8,
                children = {
                    -- 装备/卸下按钮
                    UI.Button {
                        flexGrow = 1, height = 40,
                        backgroundColor = isEquipped and COLORS.red or COLORS.blue,
                        borderRadius = 8,
                        justifyContent = "center",
                        alignItems = "center",
                        onClick = function()
                            if isEquipped then
                                tryUnequip(artifactName)
                            else
                                tryEquip(artifactName)
                            end
                        end,
                        children = {
                            UI.Label {
                                text = isEquipped and "卸下" or "装备",
                                fontSize = 12,
                                fontColor = "#ffffff",
                                fontWeight = "bold",
                            },
                        }
                    },
                }
            },
        }
    }
end

-- ========== 公共 API ==========

--- 创建标题
local function createTitle()
    return UI.Panel {
        width = "100%",
        height = 40,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "center",
        paddingTop = 8, paddingBottom = 4,
        children = {
            UI.Label {
                text = "神器",
                fontSize = 18,
                fontWeight = "bold",
                fontColor = COLORS.gold,
            },
        }
    }
end

--- 显示神器管理界面
---@param onBackCb? function 返回回调
function ArtifactUI.Show(onBackCb)
    onBack_ = onBackCb
    activeTab_ = "list"
    selectedArtifact_ = nil
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    ArtifactUI.Refresh()
    return wrapper_
end

--- 刷新界面
function ArtifactUI.Refresh()
    local content
    if activeTab_ == "list" then
        content = createListContent()
    elseif activeTab_ == "summon" then
        content = createSummonContent()
    elseif activeTab_ == "detail" then
        content = createDetailContent()
    end

    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(UI.Panel {
            width = "100%",
            height = "100%",
            backgroundColor = COLORS.bgDark,
            paddingTop = 12,
            children = {
                createTitle(),
                createTabs(),
                UI.ScrollView {
                    width = "100%",
                    flexGrow = 1, flexShrink = 1,
                    children = { content },
                },
            },
        })
    end
end

--- 隐藏
function ArtifactUI.Hide()
    wrapper_ = nil
end

return ArtifactUI
