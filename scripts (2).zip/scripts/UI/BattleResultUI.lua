-- ══════════════════════════════════════════════
-- ============================================================================
-- BattleResultUI.lua - 战斗结算界面
-- 胜利/失败/平局结算：MVP展示 + 奖杯变化 + 奖励明细 + 广告礼包
-- ============================================================================
---@diagnostic disable: param-type-mismatch, undefined-global

local UI = require("urhox-libs/UI")
local SeasonConfig = require("Config.SeasonConfig")
local PlayerDataManager = require("Data.PlayerDataManager")
local ChestManager = require("Battle.ChestManager")

local BattleResultUI = {}

local rootPanel_ = nil
local onReturn_ = nil

-- ========== 样式常量 ==========
local COLORS = {
    bgOverlay = "rgba(0,0,0,0.9)",
    panelBg = "#12122A",
    panelBorder = "#2A2A4A",
    victory = "#66BB6A",
    victoryGlow = "#A5D6A7",
    defeat = "#EF5350",
    defeatGlow = "#EF9A9A",
    draw = "#FFC107",
    text = "#FFFFFF",
    textDim = "#8888AA",
    gold = "#FFD700",
    trophy = "#FFC107",
    spiritStone = "#64FFDA",
    material = "#AB47BC",
    xianyu = "#E040FB",
    exp = "#42A5F5",
    btnPrimary = "#FF6D00",
    btnAd = "#4CAF50",
    btnAdBorder = "#66BB6A",
    qualityGreen = "#4CAF50",
    qualityBlue = "#42A5F5",
    qualityPurple = "#AB47BC",
    qualityGold = "#FFD700",
    separator = "#2A2A4A",
}

local QUALITY_COLORS = {
    green = COLORS.qualityGreen,
    blue = COLORS.qualityBlue,
    purple = COLORS.qualityPurple,
    gold = COLORS.qualityGold,
}

-- ========== 创建奖励行 ==========
local function createRewardRow(icon, label, value, color)
    return UI.Panel {
        width = "100%",
        flexDirection = "row",
        alignItems = "center",
        paddingLeft = 16,
        paddingRight = 16,
        marginTop = 4,
        children = {
            UI.Label { text = icon, fontSize = 16 },
            UI.Label {
                text = label,
                fontSize = 12,
                fontColor = COLORS.textDim,
                marginLeft = 6,
                flexGrow = 1,
            },
            UI.Label {
                text = value,
                fontSize = 14,
                fontWeight = "bold",
                fontColor = color or COLORS.gold,
            },
        }
    }
end

-- ========== 创建 MVP 区域 ==========
local function createMVPSection(mvp)
    if not mvp then return UI.Panel { height = 0 } end

    local qualityColor = QUALITY_COLORS[mvp.quality] or COLORS.qualityGreen
    return UI.Panel {
        width = "100%",
        alignItems = "center",
        marginTop = 12,
        marginBottom = 8,
        children = {
            UI.Label {
                text = "— MVP —",
                fontSize = 11,
                fontColor = COLORS.textDim,
            },
            UI.Panel {
                width = 220,
                height = 60,
                marginTop = 6,
                borderRadius = 12,
                backgroundColor = "#1A1A3A",
                borderWidth = 1,
                borderColor = qualityColor,
                flexDirection = "row",
                alignItems = "center",
                paddingLeft = 12,
                paddingRight = 12,
                children = {
                    -- 图标
                    UI.Panel {
                        width = 40,
                        height = 40,
                        borderRadius = 20,
                        backgroundColor = "#2A2A5A",
                        borderWidth = 1,
                        borderColor = qualityColor,
                        alignItems = "center",
                        justifyContent = "center",
                        children = {
                            UI.Label { text = mvp.icon, fontSize = 20 },
                        }
                    },
                    -- 名字和种族
                    UI.Panel {
                        marginLeft = 10,
                        flexGrow = 1,
                        children = {
                            UI.Label {
                                text = mvp.cardName,
                                fontSize = 13,
                                fontWeight = "bold",
                                fontColor = qualityColor,
                            },
                            UI.Label {
                                text = mvp.race,
                                fontSize = 10,
                                fontColor = COLORS.textDim,
                                marginTop = 2,
                            },
                        }
                    },
                    -- 战绩数据
                    UI.Panel {
                        alignItems = "flex-end",
                        children = {
                            UI.Label {
                                text = "击杀 " .. mvp.kills,
                                fontSize = 11,
                                fontColor = COLORS.victory,
                            },
                            UI.Label {
                                text = "伤害 " .. mvp.damageDealt,
                                fontSize = 10,
                                fontColor = COLORS.textDim,
                                marginTop = 2,
                            },
                        }
                    },
                }
            },
        }
    }
end

-- ========== 创建奖杯变化区域 ==========
local function createTrophySection(trophyBefore, trophyChange)
    local trophyAfter = math.max(0, trophyBefore + trophyChange)
    local trophyText = trophyChange >= 0 and ("+" .. trophyChange) or tostring(trophyChange)
    local trophyColor = trophyChange >= 0 and COLORS.victory or COLORS.defeat

    -- 检查是否晋级
    local tierIndexBefore, _ = SeasonConfig.GetTierByTrophies(trophyBefore)
    local tierIndexAfter, _ = SeasonConfig.GetTierByTrophies(trophyAfter)
    local promoted = tierIndexAfter > tierIndexBefore

    local children = {
        UI.Panel {
            flexDirection = "row",
            alignItems = "center",
            children = {
                UI.Label { text = "🏆", fontSize = 20 },
                UI.Label {
                    text = " " .. trophyBefore,
                    fontSize = 15,
                    fontColor = COLORS.textDim,
                },
                UI.Label {
                    text = "  →  ",
                    fontSize = 13,
                    fontColor = COLORS.textDim,
                },
                UI.Label {
                    text = tostring(trophyAfter),
                    fontSize = 18,
                    fontWeight = "bold",
                    fontColor = COLORS.trophy,
                },
                UI.Label {
                    text = " (" .. trophyText .. ")",
                    fontSize = 13,
                    fontColor = trophyColor,
                    marginLeft = 4,
                },
            }
        },
    }

    -- 晋级提示
    if promoted then
        children[#children + 1] = UI.Panel {
            marginTop = 6,
            paddingLeft = 12, paddingRight = 12,
            paddingTop = 4, paddingBottom = 4,
            borderRadius = 10,
            backgroundColor = SeasonConfig.GetTierVisual(tierIndexAfter).bgColor,
            borderWidth = 1,
            borderColor = SeasonConfig.GetTierVisual(tierIndexAfter).color,
            children = {
                UI.Label {
                    text = "🎉 晋升至 " .. SeasonConfig.GetTierDisplayName(tierIndexAfter, 1, trophyAfter) .. "!",
                    fontSize = 12,
                    fontWeight = "bold",
                    fontColor = SeasonConfig.GetTierVisual(tierIndexAfter).color,
                },
            }
        }
    end

    return UI.Panel {
        width = "100%",
        alignItems = "center",
        marginTop = 10,
        children = children,
    }
end

-- ========== 公共 API ==========

--- 显示战斗结算界面
---@param result string "victory"|"defeat"|"draw"
---@param stats table { territory1, territory2, spiritStones, trophiesBefore, trophyChange, goldReward, materialReward, expReward, chestReward, mvp, adBonusLeft }
---@param onReturnCallback function 返回主页回调
function BattleResultUI.Show(result, stats, onReturnCallback)
    onReturn_ = onReturnCallback

    -- 标题配置
    local titleText = "平局"
    local titleColor = COLORS.draw
    local titleIcon = "⚖️"
    local subtitleText = "旗鼓相当"
    if result == "victory" then
        titleText = "胜利！"
        titleColor = COLORS.victory
        titleIcon = "🏆"
        subtitleText = "修为精进"
    elseif result == "defeat" then
        titleText = "战败"
        titleColor = COLORS.defeat
        titleIcon = "💀"
        subtitleText = "来日再战"
    end

    local territory1 = stats.territory1 or 0
    local territory2 = stats.territory2 or 0
    local goldReward = stats.goldReward or 0
    local materialReward = stats.materialReward or 0
    local expReward = stats.expReward or 0
    local chestReward = stats.chestReward
    local adBonusLeft = stats.adBonusLeft or 0

    -- 构建奖励列表
    local rewardWidgets = {}
    -- 领地统计
    rewardWidgets[#rewardWidgets + 1] = createRewardRow(
        "🗺️", "领地", territory1 .. " : " .. territory2, COLORS.text
    )
    -- 晶核
    if goldReward > 0 then
        rewardWidgets[#rewardWidgets + 1] = createRewardRow(
            "💰", "晶核", "+" .. goldReward, COLORS.gold
        )
    end
    -- 铸材
    if materialReward > 0 then
        rewardWidgets[#rewardWidgets + 1] = createRewardRow(
            "💎", "铸材", "+" .. materialReward, COLORS.spiritStone
        )
    end
    -- 经验值
    if expReward > 0 then
        rewardWidgets[#rewardWidgets + 1] = createRewardRow(
            "⭐", "经验", "+" .. expReward, COLORS.exp
        )
    end
    -- 宝箱（仅胜利时获得）
    if result == "victory" then
        local trophies = PlayerDataManager.Get("trophies") or 0
        local tierIndex = SeasonConfig.GetTierByTrophies(trophies)
        local chestType = ChestManager.AwardChestByTier(tierIndex)
        if chestType then
            local chestDef = ChestManager.TYPES[chestType]
            local chestName = chestDef and chestDef.name or chestType
            rewardWidgets[#rewardWidgets + 1] = createRewardRow(
                "🎁", "宝箱", chestName, COLORS.victory
            )
        end
    end

    -- 广告礼包按钮（仅胜利时显示）
    local adBtn = nil
    if result == "victory" and adBonusLeft > 0 then
        adBtn = UI.Button {
            width = 220,
            height = 38,
            marginTop = 12,
            backgroundColor = "#1A3A1A",
            borderRadius = 19,
            borderWidth = 1,
            borderColor = COLORS.btnAdBorder,
            flexDirection = "row",
            alignItems = "center",
            justifyContent = "center",
            onClick = function()
                -- 调用广告 SDK
                sdk:ShowRewardVideoAd(function(adResult)
                    if adResult.success then
                        -- 广告观看成功，发放双倍奖励
                        local bonusGold = goldReward
                        local bonusMaterial = materialReward
                        if bonusGold > 0 then
                            PlayerDataManager.AddGold(bonusGold)
                        end
                        if bonusMaterial > 0 then
                            PlayerDataManager.AddMaterials(bonusMaterial)
                        end
                        -- 记录今日已用广告次数
                        local pd = PlayerDataManager.GetData()
                        local used = (pd and pd.adBonusUsedToday or 0) + 1
                        PlayerDataManager.Set("adBonusUsedToday", used)
                        PlayerDataManager.Save()
                        UI.Toast.Show("双倍奖励已领取! 晶核+" .. bonusGold, { type = "success", duration = 3 })
                    else
                        UI.Toast.Show("广告未完成，奖励取消", { type = "warning", duration = 2 })
                    end
                end)
            end,
            children = {
                UI.Label { text = "🎬", fontSize = 14 },
                UI.Label {
                    text = " 观看广告领双倍 (" .. adBonusLeft .. "/8)",
                    fontSize = 12,
                    fontColor = COLORS.btnAdBorder,
                    marginLeft = 4,
                },
            }
        }
    end

    rootPanel_ = UI.Panel {
        width = "100%", height = "100%",
        position = "absolute",
        top = 0, left = 0,
        backgroundColor = COLORS.bgOverlay,
        alignItems = "center",
        justifyContent = "center",
        children = {
            -- 结算面板（ScrollView 包裹以防内容过长）
            UI.Panel {
                width = 300,
                maxHeight = "85%",
                borderRadius = 16,
                backgroundColor = COLORS.panelBg,
                borderWidth = 1,
                borderColor = COLORS.panelBorder,
                alignItems = "center",
                paddingTop = 20,
                paddingBottom = 20,
                paddingLeft = 12,
                paddingRight = 12,
                children = {
                    -- 结果图标
                    UI.Label { text = titleIcon, fontSize = 44 },
                    -- 标题
                    UI.Label {
                        text = titleText,
                        fontSize = 28,
                        fontWeight = "bold",
                        fontColor = titleColor,
                        marginTop = 4,
                    },
                    -- 副标题
                    UI.Label {
                        text = subtitleText,
                        fontSize = 12,
                        fontColor = COLORS.textDim,
                        marginTop = 2,
                    },
                    -- MVP 展示
                    createMVPSection(stats.mvp),
                    -- 奖杯变化
                    createTrophySection(stats.trophiesBefore or 0, stats.trophyChange or 0),
                    -- 分隔线
                    UI.Panel {
                        width = "80%",
                        height = 1,
                        backgroundColor = COLORS.separator,
                        marginTop = 12,
                        marginBottom = 8,
                    },
                    -- 奖励标题
                    UI.Label {
                        text = "— 战斗奖励 —",
                        fontSize = 11,
                        fontColor = COLORS.textDim,
                    },
                    -- 奖励列表
                    UI.Panel {
                        width = "100%",
                        marginTop = 4,
                        children = rewardWidgets,
                    },
                    -- 广告礼包
                    adBtn or UI.Panel { height = 0 },
                    -- 返回按钮
                    UI.Button {
                        width = 200,
                        height = 44,
                        marginTop = 16,
                        backgroundColor = COLORS.btnPrimary,
                        borderRadius = 22,
                        alignItems = "center",
                        justifyContent = "center",
                        onClick = function()
                            BattleResultUI.Hide()
                            if onReturn_ then onReturn_() end
                        end,
                        children = {
                            UI.Label {
                                text = "继续",
                                fontSize = 16,
                                fontWeight = "bold",
                                fontColor = COLORS.text,
                            },
                        }
                    },
                }
            },
        }
    }

    UI.SetRoot(rootPanel_)
end

--- 隐藏
function BattleResultUI.Hide()
    if rootPanel_ then
        UI.SetRoot(nil, true)
        rootPanel_ = nil
    end
end

--- 是否正在显示
function BattleResultUI.IsShowing()
    return rootPanel_ ~= nil
end

return BattleResultUI


-- ══════════════════════════════════════════════
