-- ============================================================================
-- ChatUI.lua - 聊天面板
-- 局内精简快捷语、全服聊天、好友私聊
-- ============================================================================
---@diagnostic disable: param-type-mismatch, assign-type-mismatch

local UI = require("urhox-libs/UI")
local ChatManager = require("Systems.ChatManager")
local FriendManager = require("Systems.FriendManager")
local PlayerDataManager = require("Data.PlayerDataManager")

local ChatUI = {}

-- ========== 颜色常量 ==========
local COLORS = {
    bgDark = "#0a0a1a",
    bgCard = "#1a1a3a",
    bgPanel = "#12122a",
    bgMessage = "#1e1e3e",
    bgSelf = "#1a3a2a",
    text = "#e8e0d4",
    textDim = "#8a7e72",
    gold = "#ffd700",
    green = "#27ae60",
    blue = "#5dade2",
    orange = "#e67e22",
    red = "#e74c3c",
    purple = "#9b59b6",
    border = "#2a2a4a",
}

-- ========== 内部状态 ==========
local wrapper_ = nil
local activeChannel_ = "battle"  -- "battle" | "friend" | "world"

-- ========== 构建 UI ==========

--- 构建频道 Tab
local function buildChannelTabs()
    local channels = {
        { key = "battle", name = "快捷语", icon = "⚔️" },
        { key = "world", name = "全服", icon = "🌍" },
        { key = "friend", name = "好友", icon = "👥" },
    }

    local tabs = {}
    for _, ch in ipairs(channels) do
        local isActive = (activeChannel_ == ch.key)
        tabs[#tabs + 1] = UI.Button {
            text = ch.icon .. " " .. ch.name,
            fontSize = 12,
            backgroundColor = isActive and COLORS.blue or COLORS.bgDark,
            textColor = isActive and "#ffffff" or COLORS.textDim,
            borderRadius = 14, paddingLeft = 12, paddingRight = 12,
            height = 28, marginRight = 8,
            onClick = function()
                activeChannel_ = ch.key
                ChatUI.Refresh()
            end,
        }
    end

    return UI.Panel {
        width = "100%", height = 44, flexDirection = "row",
        alignItems = "center", paddingLeft = 12,
        backgroundColor = COLORS.bgDark,
        children = tabs,
    }
end

--- 构建聊天消息条目
local function buildMessageItem(msg)
    local isSelf = (msg.sender == "self")
    local timeStr = os.date("%H:%M", msg.time or os.time())

    -- 点击发送者名字弹出操作菜单（添加好友/查看信息）
    local function onSenderClick()
        if isSelf then return end
        local senderId = msg.sender
        local senderName = msg.senderName or "???"
        local friends = FriendManager.GetFriends()
        if friends[senderId] then
            UI.Toast.Show(senderName .. " 已是好友", "info")
            return
        end
        -- 弹出确认添加好友
        UI.Popup.Show({
            title = "添加好友",
            message = "是否添加 " .. senderName .. " 为好友？",
            confirmText = "添加",
            cancelText = "取消",
            onConfirm = function()
                local ok, result = FriendManager.AddFriend(senderId, {
                    name = senderName,
                    tier = msg.senderTier or 0,
                    trophies = msg.senderTrophies or 0,
                })
                UI.Toast.Show(result, ok and "success" or "warning")
            end,
        })
    end

    return UI.Panel {
        width = "100%", paddingLeft = 12, paddingRight = 12,
        paddingTop = 6, paddingBottom = 6,
        children = {
            -- 发送者 + 时间
            UI.Panel {
                flexDirection = "row", alignItems = "center", marginBottom = 2,
                children = {
                    UI.Button {
                        text = isSelf and "我" or (msg.senderName or "???"),
                        fontSize = 11,
                        backgroundColor = "transparent",
                        textColor = isSelf and COLORS.green or COLORS.blue,
                        paddingLeft = 0, paddingRight = 4,
                        height = 18,
                        onClick = onSenderClick,
                    },
                    UI.Label {
                        text = "  " .. timeStr,
                        fontSize = 10, color = COLORS.textDim,
                    },
                },
            },
            -- 消息气泡
            UI.Panel {
                backgroundColor = isSelf and COLORS.bgSelf or COLORS.bgMessage,
                borderRadius = 8, paddingLeft = 10, paddingRight = 10,
                paddingTop = 6, paddingBottom = 6,
                maxWidth = "80%",
                children = {
                    UI.Label {
                        text = msg.message or "",
                        fontSize = 13, color = COLORS.text,
                    },
                },
            },
        },
    }
end

--- 构建聊天历史区域
local function buildChatHistory(channel)
    local history = ChatManager.GetHistory(channel, 30)
    local items = {}

    if #history == 0 then
        items[#items + 1] = UI.Panel {
            width = "100%", alignItems = "center", paddingTop = 40,
            children = {
                UI.Label {
                    text = "暂无消息", fontSize = 14, color = COLORS.textDim,
                },
            },
        }
    else
        for _, msg in ipairs(history) do
            items[#items + 1] = buildMessageItem(msg)
        end
    end

    return UI.ScrollView {
        width = "100%", flexGrow = 1, flexShrink = 1,
        children = items,
    }
end

--- 构建快捷语面板（局内对战用 - 精简版）
local function buildQuickChatPanel()
    local quickChats = ChatManager.QUICK_CHATS
    local quickEmotes = ChatManager.QUICK_EMOTES
    local items = {
        UI.Label {
            text = "快捷语",
            fontSize = 12, color = COLORS.textDim,
            marginTop = 8, marginBottom = 8, marginLeft = 12,
        },
    }

    -- 快捷语 - 每行2个
    for i = 1, #quickChats, 2 do
        local row = UI.Panel {
            width = "100%", flexDirection = "row",
            paddingLeft = 12, paddingRight = 12, marginBottom = 6,
        }
        items[#items + 1] = row

        -- 左按钮
        row.children = {
            UI.Button {
                text = quickChats[i], fontSize = 13,
                backgroundColor = COLORS.bgCard, textColor = COLORS.text,
                borderRadius = 8, borderWidth = 1, borderColor = COLORS.border,
                height = 40, flexGrow = 1, marginRight = 6,
                onClick = function()
                    local pd = PlayerDataManager.GetData() or {}
                    ChatManager.SendQuickChat(
                        pd.playerId or "player",
                        pd.playerName or "浮空者",
                        i
                    )
                    UI.Toast.Show("已发送: " .. quickChats[i], "info")
                    ChatUI.Refresh()
                end,
            }
        }

        -- 右按钮（如果有）
        if quickChats[i + 1] then
            row.children[2] = UI.Button {
                text = quickChats[i + 1], fontSize = 13,
                backgroundColor = COLORS.bgCard, textColor = COLORS.text,
                borderRadius = 8, borderWidth = 1, borderColor = COLORS.border,
                height = 40, flexGrow = 1,
                onClick = function()
                    local pd = PlayerDataManager.GetData() or {}
                    ChatManager.SendQuickChat(
                        pd.playerId or "player",
                        pd.playerName or "浮空者",
                        i + 1
                    )
                    UI.Toast.Show("已发送: " .. quickChats[i + 1], "info")
                    ChatUI.Refresh()
                end,
            }
        end
    end

    -- 表情分隔
    items[#items + 1] = UI.Panel {
        width = "100%", height = 1, backgroundColor = COLORS.border,
        marginTop = 12, marginBottom = 8,
    }
    items[#items + 1] = UI.Label {
        text = "表情",
        fontSize = 12, color = COLORS.textDim,
        marginLeft = 12, marginBottom = 8,
    }

    -- 表情按钮 - 一行4个
    local emoteRow = UI.Panel {
        width = "100%", flexDirection = "row",
        paddingLeft = 12, paddingRight = 12, justifyContent = "space-around",
    }
    items[#items + 1] = emoteRow

    for i, emote in ipairs(quickEmotes) do
        emoteRow.children[#emoteRow.children + 1] = UI.Button {
            text = emote, fontSize = 24,
            backgroundColor = COLORS.bgCard,
            borderRadius = 12, borderWidth = 1, borderColor = COLORS.border,
            width = 50, height = 50,
            onClick = function()
                local pd = PlayerDataManager.GetData() or {}
                ChatManager.SendEmote(
                    pd.playerId or "player",
                    pd.playerName or "浮空者",
                    i
                )
                UI.Toast.Show("已发送: " .. emote, "info")
                ChatUI.Refresh()
            end,
        }
    end

    -- 下方显示历史
    items[#items + 1] = UI.Panel {
        width = "100%", height = 1, backgroundColor = COLORS.border,
        marginTop = 12, marginBottom = 8,
    }
    items[#items + 1] = UI.Label {
        text = "对局消息",
        fontSize = 12, color = COLORS.textDim,
        marginLeft = 12, marginBottom = 4,
    }

    local history = ChatManager.GetHistory("battle", 10)
    for _, msg in ipairs(history) do
        items[#items + 1] = buildMessageItem(msg)
    end

    return UI.ScrollView {
        width = "100%", flexGrow = 1, flexShrink = 1,
        children = items,
    }
end

--- 构建好友聊天面板
local function buildFriendChatPanel()
    local items = {}

    -- 好友聊天选择 + 历史
    items[#items + 1] = UI.Label {
        text = "选择好友发送消息",
        fontSize = 12, color = COLORS.textDim,
        marginTop = 8, marginBottom = 8, marginLeft = 12,
    }

    -- 简化版：显示好友列表 + 预设消息
    local friends = FriendManager.GetFriends()
    local friendCount = 0
    for friendId, friend in pairs(friends) do
        friendCount = friendCount + 1
        items[#items + 1] = UI.Panel {
            width = "100%", paddingLeft = 12, paddingRight = 12,
            paddingTop = 6, paddingBottom = 6, flexDirection = "row",
            alignItems = "center",
            backgroundColor = COLORS.bgCard, borderBottom = 1, borderColor = COLORS.border,
            children = {
                UI.Label {
                    text = friend.name or "浮空者",
                    fontSize = 13, color = COLORS.text, flexGrow = 1,
                },
                UI.Button {
                    text = "打招呼", fontSize = 11,
                    backgroundColor = COLORS.blue, textColor = "#ffffff",
                    borderRadius = 10, paddingLeft = 10, paddingRight = 10,
                    height = 24,
                    onClick = function()
                        local ok = ChatManager.SendFriendChat(friendId, "你好，一起修炼吗？")
                        if ok then
                            UI.Toast.Show("已向 " .. (friend.name or "好友") .. " 发送消息", "success")
                        else
                            UI.Toast.Show("发送失败", "error")
                        end
                        ChatUI.Refresh()
                    end,
                },
            },
        }
    end

    if friendCount == 0 then
        items[#items + 1] = UI.Panel {
            width = "100%", alignItems = "center", paddingTop = 40,
            children = {
                UI.Label {
                    text = "暂无好友，去好友面板添加吧",
                    fontSize = 13, color = COLORS.textDim,
                },
            },
        }
    end

    -- 好友聊天历史
    local history = ChatManager.GetHistory("friend", 20)
    if #history > 0 then
        items[#items + 1] = UI.Panel {
            width = "100%", height = 1, backgroundColor = COLORS.border,
            marginTop = 12, marginBottom = 8,
        }
        items[#items + 1] = UI.Label {
            text = "聊天记录", fontSize = 12, color = COLORS.textDim,
            marginLeft = 12, marginBottom = 4,
        }
        for _, msg in ipairs(history) do
            items[#items + 1] = buildMessageItem(msg)
        end
    end

    return UI.ScrollView {
        width = "100%", flexGrow = 1, flexShrink = 1,
        children = items,
    }
end

--- 构建全服聊天面板
local function buildWorldChatPanel()
    local presets = {
        "大家好！",
        "有人组队吗？",
        "帮忙看看我的卡组",
        "恭喜恭喜！",
        "谁有多余碎片交换？",
        "今天运气不错！",
    }

    local items = {
        UI.Label {
            text = "全服频道（点击发送）",
            fontSize = 12, color = COLORS.textDim,
            marginTop = 8, marginBottom = 8, marginLeft = 12,
        },
    }

    for _, msg in ipairs(presets) do
        items[#items + 1] = UI.Panel {
            width = "100%", paddingLeft = 12, paddingRight = 12, marginBottom = 4,
            children = {
                UI.Button {
                    text = msg, fontSize = 13,
                    backgroundColor = COLORS.bgCard, textColor = COLORS.text,
                    borderRadius = 8, borderWidth = 1, borderColor = COLORS.border,
                    width = "100%", height = 36, textAlign = "left", paddingLeft = 12,
                    onClick = function()
                        local ok = ChatManager.SendWorldChat(msg)
                        if ok then
                            UI.Toast.Show("已发送到全服", "success")
                        else
                            UI.Toast.Show("发送失败", "error")
                        end
                        ChatUI.Refresh()
                    end,
                },
            },
        }
    end

    -- 全服聊天历史
    items[#items + 1] = UI.Panel {
        width = "100%", height = 1, backgroundColor = COLORS.border,
        marginTop = 8, marginBottom = 8,
    }
    items[#items + 1] = UI.Label {
        text = "全服消息", fontSize = 12, color = COLORS.textDim,
        marginLeft = 12, marginBottom = 4,
    }

    local history = ChatManager.GetHistory("world", 20)
    if #history > 0 then
        for _, msg in ipairs(history) do
            items[#items + 1] = buildMessageItem(msg)
        end
    else
        items[#items + 1] = UI.Panel {
            width = "100%", alignItems = "center", paddingTop = 20,
            children = {
                UI.Label {
                    text = "快来和大家打招呼吧！", fontSize = 13, color = COLORS.textDim,
                },
            },
        }
    end

    return UI.ScrollView {
        width = "100%", flexGrow = 1, flexShrink = 1,
        children = items,
    }
end

-- ========== 公开接口 ==========

--- 显示聊天面板
---@param onBackCb function|nil
function ChatUI.Show(onBackCb)
    activeChannel_ = "battle"
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    ChatUI.Refresh()
    return wrapper_
end

--- 刷新界面
function ChatUI.Refresh()
    local channelContent
    if activeChannel_ == "battle" then
        channelContent = buildQuickChatPanel()
    elseif activeChannel_ == "friend" then
        channelContent = buildFriendChatPanel()
    else
        channelContent = buildWorldChatPanel()
    end

    local content = UI.Panel {
        width = "100%", height = "100%",
        backgroundColor = COLORS.bgDark,
        paddingTop = 12,
        children = {
            -- 标题
            UI.Panel {
                width = "100%",
                height = 40,
                flexDirection = "row",
                alignItems = "center",
                justifyContent = "center",
                paddingTop = 8, paddingBottom = 4,
                children = {
                    UI.Label {
                        text = "聊天",
                        fontSize = 18,
                        fontWeight = "bold",
                        fontColor = COLORS.gold,
                    },
                }
            },
            buildChannelTabs(),
            channelContent,
        },
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 隐藏面板
function ChatUI.Hide()
    wrapper_ = nil
end

return ChatUI
