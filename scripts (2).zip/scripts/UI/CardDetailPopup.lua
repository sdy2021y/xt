-- ══════════════════════════════════════════════
-- ============================================================================
-- CardDetailPopup.lua - 卡牌详情弹窗（重构版）
-- 参考设计稿：大立绘 + 职业/种族标签 + 双列属性 + 技能图标行（可点击看详情）+ 升级按钮
-- 橙色品质技能可升级
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local UnitConfig = require("Config.UnitConfig")
local PlayerDataManager = require("Data.PlayerDataManager")

local CardDetailPopup = {}

-- ========== 配置回调（由 DeckBuilderUI 注入） ==========
-- 这些回调让弹窗可以操作卡组上阵/下阵
local deckCallbacks_ = nil  -- { isInDeck(cardName), addToDeck(cardName), removeFromDeck(cardName), isDeckFull() }

--- 注入卡组操作回调
function CardDetailPopup.SetDeckCallbacks(callbacks)
    deckCallbacks_ = callbacks
end

-- ========== 常量 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    panelBg = "#121830",
    statsBg = "#0D1225",
    statRow = "#161C38",
    text = "#FFFFFF",
    textDim = "#8888AA",
    gold = "#FFD700",
    border = "#2A2A4A",
    bonusGreen = "#4CAF50",
    progressBg = "#1A1A2E",
    progressFill = "#42A5F5",
    upgradeBtn = "#3E7C2A",
    upgradeBorder = "#5CAF3A",
    disabledBtn = "#333355",
    skillPopupBg = "#0D1530",
}

-- 品质配置
local QUALITY_CONFIG = {
    green  = { label = "精良", color = "#4CAF50", bgGrad = "#1A3A1A" },
    blue   = { label = "稀有", color = "#42A5F5", bgGrad = "#1A2A3A" },
    purple = { label = "史诗", color = "#CE93D8", bgGrad = "#2A1A3A" },
    gold   = { label = "传奇", color = "#FFD700", bgGrad = "#3A2A1A" },
}

-- 种族配置（key 对应 UnitConfig.RACE 值）
local RACE_CONFIG = {
    aether = { icon = "👤", label = "联盟" },
    avian  = { icon = "🦅", label = "翼族" },
    forge  = { icon = "⚙️", label = "机械" },
    astral = { icon = "✨", label = "元素" },
}

-- 职业配置
local CLASS_CONFIG = {
    melee  = { icon = "⚔️", label = "近战" },
    ranged = { icon = "🏹", label = "远程" },
}

-- 技能图标颜色（按品质/类型）
local SKILL_COLORS = {
    "#4DD0E1", -- 青色（基础1）
    "#4DD0E1", -- 青色（基础2）
    "#AB47BC", -- 紫色
    "#AB47BC", -- 紫色
    "#FFD700", -- 金色
    "#FFD700", -- 金色（传奇专属第6技能）
}

-- 触发类型中文映射
local TRIGGER_NAMES = {
    passive = "被动",
    on_attack = "攻击时",
    on_hit = "受击时",
    on_kill = "击杀时",
    on_death = "死亡时",
    hp_below = "生命低于",
    on_spawn = "出场时",
    on_move = "移动时",
    on_tile_capture = "占格时",
    always = "常驻",
}

-- 效果类型中文映射
local EFFECT_NAMES = {
    damage_reduce = "减伤",
    damage_taken_increase = "易伤",
    stat_buff = "属性增益",
    survive = "免死",
    share_damage = "分摊伤害",
    reflect = "反弹伤害",
    damage = "额外伤害",
    heal = "治疗",
    poison = "中毒",
    summon = "召唤",
    extra_produce = "额外产兵",
    speed_buff = "加速",
    aoe = "范围伤害",
    knockback = "击退",
    stun = "眩晕",
    slow = "减速",
    lifesteal = "生命汲取",
    death_explosion = "死亡爆炸",
    death_summon = "死亡召唤",
    reconstruct = "重构",
    buff_atk_on_kill = "击杀增攻",
    crit = "暴击",
    dodge = "闪避",
    taunt = "嘲讽",
    shield = "护盾",
    convert = "转化",
}

-- ========== 内部状态 ==========
local popupRoot_ = nil
local onClose_ = nil
local skillPopupRoot_ = nil  -- 技能详情小弹窗

-- ========== 工具函数 ==========

--- 计算卡牌战力
local function calcPower(card, level)
    if not card then return 0 end
    local lv = level or 1
    local upg = card.upgrade or {}

    if card.slotType == "unit" then
        local baseAtk = (card.atk or 0) + (upg.atk or 0) * (lv - 1)
        local baseHp = (card.hp or 0) + (upg.hp or 0) * (lv - 1)
        return math.floor(baseAtk * 3 + baseHp * 0.5)
    elseif card.slotType == "mine" then
        local spiritOutput = (card.spiritOutput or 10) + (upg.spiritOutput or 0) * (lv - 1)
        return math.floor(spiritOutput * 20 + (card.hp or 0) * 0.5)
    elseif card.slotType == "tower" then
        local baseAtk = (card.atk or 0) + (upg.atk or 0) * (lv - 1)
        local baseHp = (card.hp or 0) + (upg.hp or 0) * (lv - 1)
        return math.floor(baseAtk * 3 + baseHp * 0.5)
    end
    return 0
end

--- 获取升级后属性加成
local function getBonus(card, level)
    if not card then return {} end
    local lv = level or 1
    local upg = card.upgrade or {}

    if card.slotType == "unit" then
        return {
            hp = math.floor((upg.hp or 0) * (lv - 1)),
            atk = math.floor((upg.atk or 0) * (lv - 1)),
        }
    elseif card.slotType == "mine" then
        return {
            hp = math.floor((upg.hp or 0) * (lv - 1)),
            spiritOutput = (upg.spiritOutput or 0) * (lv - 1),
        }
    elseif card.slotType == "tower" then
        return {
            hp = math.floor((upg.hp or 0) * (lv - 1)),
            atk = math.floor((upg.atk or 0) * (lv - 1)),
        }
    end
    return {}
end

--- 获取当前属性（含等级加成）
local function getStats(card, level)
    if not card then
        return { buildingHp = 0, hp = 0, atk = 0, spd = 0, range = 0, prodTime = 0, spiritOutput = 0 }
    end
    local lv = level or 1
    local upg = card.upgrade or {}

    if card.slotType == "unit" then
        return {
            buildingHp = math.floor((card.buildingHp or card.hp or 0) + (upg.buildingHp or upg.hp or 0) * (lv - 1)),
            hp = math.floor((card.hp or 0) + (upg.hp or 0) * (lv - 1)),
            atk = math.floor((card.atk or 0) + (upg.atk or 0) * (lv - 1)),
            spd = card.spd or 0,
            range = card.range or 0,
            prodTime = card.prodTime or 0,
            spiritOutput = 0,
        }
    elseif card.slotType == "mine" then
        return {
            hp = math.floor((card.hp or 0) + (upg.hp or 0) * (lv - 1)),
            atk = 0,
            spd = 0,
            range = 0,
            prodTime = 0,
            spiritOutput = (card.spiritOutput or 10) + (upg.spiritOutput or 0) * (lv - 1),
        }
    elseif card.slotType == "tower" then
        return {
            hp = math.floor((card.hp or 0) + (upg.hp or 0) * (lv - 1)),
            atk = math.floor((card.atk or 0) + (upg.atk or 0) * (lv - 1)),
            spd = 0,
            range = card.range or 5,
            attackInterval = card.attackInterval or 1.5,
            prodTime = 0,
            spiritOutput = 0,
        }
    end
    return { buildingHp = 0, hp = 0, atk = 0, spd = 0, range = 0, prodTime = 0, spiritOutput = 0 }
end

--- 生成技能效果描述文本
local function describeSkillEffect(skill)
    local p = skill.params or {}
    local parts = {}

    -- 效果类型名
    local eName = EFFECT_NAMES[skill.effect] or skill.effect
    parts[#parts + 1] = eName

    -- 百分比
    if p.percent then
        parts[#parts + 1] = string.format("%.0f%%", p.percent * 100)
    end
    -- 固定值
    if p.flat then
        parts[#parts + 1] = "+" .. p.flat
    end
    -- 概率
    if p.chance then
        parts[#parts + 1] = string.format("(%.0f%%概率)", p.chance * 100)
    end
    -- 目标
    if p.target == "adjacent_allies" then
        parts[#parts + 1] = "相邻友军"
    elseif p.target == "nearby_allies" then
        parts[#parts + 1] = string.format("周围%d格友军", p.aoeRange or 1)
    elseif p.target == "behind_enemy" then
        parts[#parts + 1] = "目标身后"
    elseif p.target == "self" then
        parts[#parts + 1] = "自身"
    end
    -- 属性
    if p.stat then
        local statNames = { atk = "攻击", hp = "生命", spd = "速度", attackSpeed = "攻速", damage_taken_increase = "易伤" }
        parts[#parts + 1] = statNames[p.stat] or p.stat
    end
    -- 条件
    if skill.condition == "stationary" then
        parts[#parts + 1] = "(驻守时)"
    end
    -- 范围
    if p.aoeRange and not p.target then
        parts[#parts + 1] = string.format("范围%d", p.aoeRange)
    end

    return table.concat(parts, " ")
end

-- ========== UI 组件 ==========

--- 创建职业/种族标签
local function createTag(icon, label)
    return UI.Panel {
        flexDirection = "column",
        alignItems = "center",
        marginRight = 12,
        children = {
            UI.Panel {
                width = 36,
                height = 36,
                borderRadius = 18,
                backgroundColor = "#1A1A3A",
                borderWidth = 2,
                borderColor = "#4A4A6A",
                alignItems = "center",
                justifyContent = "center",
                children = {
                    UI.Label { text = icon, fontSize = 16 },
                }
            },
            UI.Label {
                text = label,
                fontSize = 9,
                fontColor = COLORS.textDim,
                marginTop = 3,
            },
        }
    }
end

--- 创建单个属性格子（左列或右列）
local function createStatCell(icon, label, value, bonus)
    local children = {
        -- 图标+标签行
        UI.Panel {
            flexDirection = "row",
            alignItems = "center",
            children = {
                UI.Label { text = icon, fontSize = 13 },
                UI.Label {
                    text = label .. "：",
                    fontSize = 10,
                    fontColor = COLORS.textDim,
                    marginLeft = 4,
                },
            }
        },
        -- 数值行
        UI.Panel {
            flexDirection = "row",
            alignItems = "center",
            marginTop = 2,
            marginLeft = 20,
            children = {
                UI.Label {
                    text = tostring(value),
                    fontSize = 14,
                    fontColor = COLORS.text,
                    fontWeight = "bold",
                },
                bonus and bonus > 0 and UI.Label {
                    text = "  +" .. bonus,
                    fontSize = 11,
                    fontColor = COLORS.bonusGreen,
                    fontWeight = "bold",
                } or nil,
            }
        },
    }

    -- 过滤 nil
    local filtered = {}
    for _, c in ipairs(children) do
        if c then filtered[#filtered + 1] = c end
    end

    return UI.Panel {
        width = "48%",
        paddingTop = 8,
        paddingBottom = 8,
        paddingLeft = 6,
        borderBottomWidth = 1,
        borderColor = "#1A2040",
        children = filtered,
    }
end

--- 隐藏技能详情小弹窗
local function hideSkillPopup()
    if skillPopupRoot_ then
        local ShellUI = require("UI.ShellUI")
        ShellUI.HideOverlay()
        skillPopupRoot_ = nil
        -- 重新显示主弹窗
        if popupRoot_ then
            ShellUI.ShowOverlay(popupRoot_)
        end
    end
end

--- 显示技能详情小弹窗
local function showSkillPopup(skill, index, currentLevel, quality, cardName)
    local qc = QUALITY_CONFIG[quality] or QUALITY_CONFIG.green
    local unlockLevel = skill.unlock or 0
    local isUnlocked = (currentLevel >= unlockLevel)
    local isGold = (quality == "gold")
    local color = SKILL_COLORS[index] or "#888888"

    -- 技能等级（基于卡牌等级和技能解锁等级）
    local skillLevel = isUnlocked and math.max(1, currentLevel - unlockLevel + 1) or 0

    -- 升级所需
    local skillUpgradeCost = skillLevel * 800  -- 符文消耗：800×技能等级
    local canUpgradeSkill = isGold and isUnlocked and skillLevel < 5

    -- 效果描述
    local effectDesc = describeSkillEffect(skill)
    local triggerName = TRIGGER_NAMES[skill.trigger] or skill.trigger or "被动"

    -- 阈值描述
    local thresholdText = ""
    if skill.threshold then
        thresholdText = string.format(" (生命<%.0f%%时)", skill.threshold * 100)
    end

    -- 解锁等级描述
    local unlockText = ""
    if unlockLevel > 0 then
        unlockText = isUnlocked and (" (卡牌" .. unlockLevel .. "级解锁)") or (" (需卡牌" .. unlockLevel .. "级)")
    end

    skillPopupRoot_ = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = { 0, 0, 0, 180 },
        alignItems = "center",
        justifyContent = "center",
        onClick = function()
            hideSkillPopup()
        end,
        children = {
            UI.Panel {
                width = "80%",
                maxWidth = 320,
                borderRadius = 14,
                backgroundColor = COLORS.skillPopupBg,
                borderWidth = 2,
                borderColor = isUnlocked and color or "#333355",
                overflow = "hidden",
                children = {
                    -- 顶部：技能名 + 关闭
                    UI.Panel {
                        width = "100%",
                        flexDirection = "row",
                        alignItems = "center",
                        paddingLeft = 14,
                        paddingRight = 10,
                        paddingTop = 10,
                        paddingBottom = 6,
                        backgroundColor = isUnlocked and (qc.bgGrad) or "#0A0A1A",
                        children = {
                            UI.Label {
                                text = isUnlocked and string.sub(skill.name, 1, 3) or "🔒",
                                fontSize = 18,
                                fontColor = isUnlocked and color or "#555555",
                                fontWeight = "bold",
                                marginRight = 8,
                            },
                            UI.Label {
                                text = isUnlocked and skill.name or "未解锁",
                                fontSize = 16,
                                fontColor = isUnlocked and COLORS.text or "#555555",
                                fontWeight = "bold",
                                flexGrow = 1,
                            },
                            -- 关闭按钮
                            UI.Button {
                                width = 28,
                                height = 28,
                                borderRadius = 14,
                                backgroundColor = "#CC2222",
                                alignItems = "center",
                                justifyContent = "center",
                                onClick = function()
                                    hideSkillPopup()
                                end,
                                children = {
                                    UI.Label { text = "✕", fontSize = 12, fontColor = "#FFFFFF", fontWeight = "bold" },
                                }
                            },
                        }
                    },

                    -- 技能信息区
                    UI.Panel {
                        width = "100%",
                        paddingLeft = 14,
                        paddingRight = 14,
                        paddingTop = 10,
                        paddingBottom = 12,
                        children = {
                            -- 触发方式
                            UI.Panel {
                                flexDirection = "row",
                                alignItems = "center",
                                marginBottom = 6,
                                children = {
                                    UI.Label {
                                        text = "触发：",
                                        fontSize = 11,
                                        fontColor = COLORS.textDim,
                                    },
                                    UI.Label {
                                        text = triggerName .. thresholdText,
                                        fontSize = 11,
                                        fontColor = isUnlocked and color or "#555555",
                                        fontWeight = "bold",
                                    },
                                }
                            },
                            -- 效果描述
                            UI.Panel {
                                flexDirection = "row",
                                alignItems = "flex-start",
                                marginBottom = 6,
                                children = {
                                    UI.Label {
                                        text = "效果：",
                                        fontSize = 11,
                                        fontColor = COLORS.textDim,
                                    },
                                    UI.Label {
                                        text = isUnlocked and effectDesc or "???",
                                        fontSize = 11,
                                        fontColor = isUnlocked and COLORS.text or "#555555",
                                        flexGrow = 1,
                                    },
                                }
                            },
                            -- 解锁条件
                            unlockText ~= "" and UI.Panel {
                                flexDirection = "row",
                                alignItems = "center",
                                marginBottom = 6,
                                children = {
                                    UI.Label {
                                        text = "条件：",
                                        fontSize = 11,
                                        fontColor = COLORS.textDim,
                                    },
                                    UI.Label {
                                        text = unlockText,
                                        fontSize = 11,
                                        fontColor = isUnlocked and COLORS.bonusGreen or "#FF5252",
                                    },
                                }
                            } or nil,
                            -- 技能等级（橙色品质）
                            isGold and isUnlocked and UI.Panel {
                                flexDirection = "row",
                                alignItems = "center",
                                marginBottom = 6,
                                children = {
                                    UI.Label {
                                        text = "技能等级：",
                                        fontSize = 11,
                                        fontColor = COLORS.textDim,
                                    },
                                    UI.Label {
                                        text = "Lv." .. skillLevel .. "/5",
                                        fontSize = 12,
                                        fontColor = COLORS.gold,
                                        fontWeight = "bold",
                                    },
                                }
                            } or nil,
                            -- 橙色技能升级按钮
                            isGold and isUnlocked and canUpgradeSkill and UI.Button {
                                width = "100%",
                                height = 36,
                                marginTop = 8,
                                borderRadius = 10,
                                backgroundColor = COLORS.upgradeBtn,
                                borderWidth = 1,
                                borderColor = COLORS.upgradeBorder,
                                alignItems = "center",
                                justifyContent = "center",
                                onClick = function()
                                    -- 扣符文升级技能
                                    if PlayerDataManager.SpendRunes(skillUpgradeCost) then
                                        -- 升级卡牌（技能等级随卡牌等级走）
                                        local success = PlayerDataManager.UpgradeCard(cardName)
                                        if success then
                                            PlayerDataManager.Save()
                                            hideSkillPopup()
                                            CardDetailPopup.Show(cardName, onClose_)
                                        end
                                    else
                                        UI.Toast.Show("符文不足", { type = "warning", duration = 2.5 })
                                    end
                                end,
                                children = {
                                    UI.Label {
                                        text = "升级技能 (🔮" .. skillUpgradeCost .. ")",
                                        fontSize = 13,
                                        fontColor = "#FFFFFF",
                                        fontWeight = "bold",
                                    },
                                }
                            } or nil,
                            -- 已满级提示
                            isGold and isUnlocked and not canUpgradeSkill and UI.Panel {
                                marginTop = 8,
                                alignItems = "center",
                                children = {
                                    UI.Label {
                                        text = "已满级",
                                        fontSize = 12,
                                        fontColor = COLORS.gold,
                                        fontWeight = "bold",
                                    },
                                }
                            } or nil,
                        }
                    },
                }
            },
        }
    }

    -- 先隐藏主弹窗，再显示技能弹窗
    local ShellUI = require("UI.ShellUI")
    ShellUI.HideOverlay()
    ShellUI.ShowOverlay(skillPopupRoot_)
end

--- 创建技能图标（可点击）
local function createSkillIcon(skill, index, currentLevel, quality, cardName)
    local unlockLevel = skill.unlock or 0
    local isUnlocked = (currentLevel >= unlockLevel)
    local color = SKILL_COLORS[index] or "#888888"

    -- 未解锁用暗色 + 锁图标
    local bgColor = isUnlocked and "#1A2040" or "#0A0A1A"
    local borderColor = isUnlocked and color or "#333355"
    local iconText = isUnlocked and string.sub(skill.name, 1, 3) or "🔒"
    local iconSize = isUnlocked and 11 or 14

    return UI.Button {
        width = 42,
        height = 42,
        borderRadius = 21,
        backgroundColor = bgColor,
        borderWidth = 2,
        borderColor = borderColor,
        alignItems = "center",
        justifyContent = "center",
        marginRight = 6,
        onClick = function()
            showSkillPopup(skill, index, currentLevel, quality, cardName)
        end,
        children = {
            UI.Label {
                text = iconText,
                fontSize = iconSize,
                fontColor = isUnlocked and color or "#555555",
                fontWeight = isUnlocked and "bold" or "normal",
            },
        }
    }
end

--- 显示卡牌详情
---@param cardName string
---@param onClose function|nil
function CardDetailPopup.Show(cardName, onClose)
    local card = UnitConfig.CARDS[cardName]
    if not card then return end

    onClose_ = onClose

    local qc = QUALITY_CONFIG[card.quality] or QUALITY_CONFIG.green
    local raceInfo = RACE_CONFIG[card.race] or { icon = "❓", label = "未知" }
    local classInfo = CLASS_CONFIG[card.class] or { icon = "⚔️", label = "未知" }

    -- 玩家卡牌数据
    local cardInfo = PlayerDataManager.GetCard(cardName)
    local currentLevel = cardInfo and cardInfo.level or 0
    local cardCount = cardInfo and cardInfo.count or 0
    local isOwned = cardInfo ~= nil

    -- 升级所需数据
    local cardsNeeded, goldNeeded, _ = PlayerDataManager.GetUpgradeCost(cardName)
    local canUpgrade = isOwned and cardCount >= cardsNeeded and (goldNeeded == 0 or PlayerDataManager.Get("gold") >= goldNeeded)

    -- 属性计算
    local stats = getStats(card, math.max(1, currentLevel))
    local bonus = getBonus(card, math.max(1, currentLevel))
    local power = calcPower(card, math.max(1, currentLevel))

    -- 进度条（卡牌升级进度）
    local progressMax = cardsNeeded > 0 and cardsNeeded or 3
    local progressCurrent = math.min(cardCount, progressMax)
    local progressPercent = math.floor((progressCurrent / progressMax) * 100)

    -- ====== 技能图标行 ======
    local skillIcons = {}
    if card.skills then
        for i, skill in ipairs(card.skills) do
            skillIcons[#skillIcons + 1] = createSkillIcon(skill, i, currentLevel, card.quality, cardName)
        end
    end

    -- ====== 构建完整 UI ======
    popupRoot_ = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = { 0, 0, 0, 210 },
        alignItems = "center",
        justifyContent = "center",
        children = {
            UI.Panel {
                width = "92%",
                maxHeight = "95%",
                borderRadius = 16,
                backgroundColor = COLORS.panelBg,
                borderWidth = 2,
                borderColor = qc.color,
                overflow = "hidden",
                children = {
                    -- ====== 顶部立绘区 ======
                    UI.Panel {
                        width = "100%",
                        height = 180,
                        backgroundColor = qc.bgGrad,
                        alignItems = "center",
                        justifyContent = "center",
                        children = {
                            -- 光效背景
                            UI.Panel {
                                position = "absolute",
                                width = "100%",
                                height = "100%",
                                alignItems = "center",
                                justifyContent = "center",
                                children = {
                                    UI.Label {
                                        text = "✦",
                                        fontSize = 120,
                                        fontColor = qc.color .. "15",
                                    },
                                }
                            },
                            -- 大图标
                            UI.Panel {
                                width = 100,
                                height = 100,
                                borderRadius = 50,
                                backgroundColor = "#00000066",
                                borderWidth = 3,
                                borderColor = qc.color,
                                alignItems = "center",
                                justifyContent = "center",
                                children = {
                                    UI.Label {
                                        text = card.icon,
                                        fontSize = 48,
                                        fontColor = qc.color,
                                        fontWeight = "bold",
                                    },
                                }
                            },
                            -- 未拥有覆盖
                            not isOwned and UI.Panel {
                                position = "absolute",
                                width = "100%",
                                height = "100%",
                                backgroundColor = { 0, 0, 0, 140 },
                                alignItems = "center",
                                justifyContent = "center",
                                children = {
                                    UI.Label {
                                        text = "未解锁",
                                        fontSize = 22,
                                        fontColor = "#FF5252",
                                        fontWeight = "bold",
                                    },
                                }
                            } or nil,
                        }
                    },

                    -- ====== 职业/种族标签 + 关闭按钮行 ======
                    UI.Panel {
                        width = "100%",
                        flexDirection = "row",
                        alignItems = "center",
                        paddingLeft = 12,
                        paddingRight = 12,
                        paddingTop = 8,
                        paddingBottom = 4,
                        children = {
                            createTag(classInfo.icon, classInfo.label),
                            createTag(raceInfo.icon, raceInfo.label),
                            UI.Panel { flexGrow = 1 },
                            -- 关闭按钮
                            UI.Button {
                                width = 36,
                                height = 36,
                                borderRadius = 18,
                                backgroundColor = "#CC2222",
                                borderWidth = 2,
                                borderColor = "#FF4444",
                                alignItems = "center",
                                justifyContent = "center",
                                onClick = function()
                                    CardDetailPopup.Hide()
                                    if onClose_ then onClose_() end
                                end,
                                children = {
                                    UI.Label { text = "✕", fontSize = 16, fontColor = "#FFFFFF", fontWeight = "bold" },
                                }
                            },
                        }
                    },

                    -- ====== 卡牌内容区（可滚动） ======
                    UI.ScrollView {
                        width = "100%",
                        flexGrow = 1,
                        flexShrink = 1,
                        children = {
                            -- 名称 + 品质
                            UI.Panel {
                                width = "100%",
                                alignItems = "center",
                                paddingTop = 6,
                                children = {
                                    UI.Label {
                                        text = cardName,
                                        fontSize = 20,
                                        fontColor = COLORS.text,
                                        fontWeight = "bold",
                                    },
                                    UI.Label {
                                        text = qc.label .. " 卡牌",
                                        fontSize = 12,
                                        fontColor = qc.color,
                                        marginTop = 2,
                                    },
                                }
                            },

                            -- 等级 + 战力行
                            UI.Panel {
                                width = "100%",
                                flexDirection = "row",
                                alignItems = "center",
                                justifyContent = "center",
                                paddingTop = 10,
                                paddingLeft = 20,
                                paddingRight = 20,
                                children = {
                                    UI.Label {
                                        text = "等级  " .. currentLevel,
                                        fontSize = 14,
                                        fontColor = COLORS.text,
                                    },
                                    UI.Panel { flexGrow = 1 },
                                    UI.Label {
                                        text = "战力 ",
                                        fontSize = 13,
                                        fontColor = COLORS.textDim,
                                    },
                                    UI.Label {
                                        text = tostring(power),
                                        fontSize = 18,
                                        fontColor = COLORS.text,
                                        fontWeight = "bold",
                                    },
                                }
                            },

                            -- 进度条
                            UI.Panel {
                                width = "100%",
                                paddingLeft = 20,
                                paddingRight = 20,
                                paddingTop = 8,
                                paddingBottom = 4,
                                alignItems = "center",
                                children = {
                                    UI.Panel {
                                        width = "100%",
                                        height = 16,
                                        borderRadius = 8,
                                        backgroundColor = COLORS.progressBg,
                                        borderWidth = 1,
                                        borderColor = "#2A2A4A",
                                        overflow = "hidden",
                                        children = {
                                            UI.Panel {
                                                width = progressPercent .. "%",
                                                height = "100%",
                                                borderRadius = 8,
                                                backgroundColor = isOwned and COLORS.progressFill or "#555577",
                                            },
                                        }
                                    },
                                    UI.Label {
                                        text = progressCurrent .. "/" .. progressMax,
                                        fontSize = 10,
                                        fontColor = COLORS.textDim,
                                        marginTop = 3,
                                    },
                                }
                            },

                            -- ====== 属性面板（2列网格） ======
                            UI.Panel {
                                width = "100%",
                                paddingLeft = 12,
                                paddingRight = 12,
                                paddingTop = 10,
                                backgroundColor = COLORS.statsBg,
                                marginTop = 8,
                                children = (function()
                                    local rows = {}
                                    if card.slotType == "unit" then
                                        rows[#rows + 1] = UI.Panel {
                                            width = "100%",
                                            flexDirection = "row",
                                            children = {
                                                createStatCell("❤️", "生命值", stats.hp, bonus.hp),
                                                createStatCell("⏱️", "生产时间", stats.prodTime, nil),
                                            }
                                        }
                                        rows[#rows + 1] = UI.Panel {
                                            width = "100%",
                                            flexDirection = "row",
                                            children = {
                                                createStatCell("⚔️", "攻击力", stats.atk, bonus.atk),
                                                createStatCell("🏰", "建筑血量", stats.buildingHp, bonus.hp),
                                            }
                                        }
                                        rows[#rows + 1] = UI.Panel {
                                            width = "100%",
                                            flexDirection = "row",
                                            children = {
                                                createStatCell("💨", "速度", stats.spd, nil),
                                                createStatCell("🎯", "攻击范围", stats.range, nil),
                                            }
                                        }
                                    elseif card.slotType == "mine" then
                                        rows[#rows + 1] = UI.Panel {
                                            width = "100%",
                                            flexDirection = "row",
                                            children = {
                                                createStatCell("❤️", "生命值", stats.hp, bonus.hp),
                                                createStatCell("💎", "晶核产出", stats.spiritOutput, bonus.spiritOutput),
                                            }
                                        }
                                        if card.desc then
                                            rows[#rows + 1] = UI.Panel {
                                                width = "100%",
                                                paddingTop = 10,
                                                paddingBottom = 4,
                                                children = {
                                                    UI.Label {
                                                        text = card.desc,
                                                        fontSize = 12,
                                                        fontColor = "#8888AA",
                                                        align = "center",
                                                    }
                                                }
                                            }
                                        end
                                    elseif card.slotType == "tower" then
                                        rows[#rows + 1] = UI.Panel {
                                            width = "100%",
                                            flexDirection = "row",
                                            children = {
                                                createStatCell("❤️", "生命值", stats.hp, bonus.hp),
                                                createStatCell("⚔️", "攻击力", stats.atk, bonus.atk),
                                            }
                                        }
                                        rows[#rows + 1] = UI.Panel {
                                            width = "100%",
                                            flexDirection = "row",
                                            children = {
                                                createStatCell("🎯", "攻击范围", stats.range, nil),
                                                createStatCell("⏱️", "攻击间隔", stats.attackInterval, nil),
                                            }
                                        }
                                        if card.desc then
                                            rows[#rows + 1] = UI.Panel {
                                                width = "100%",
                                                paddingTop = 10,
                                                paddingBottom = 4,
                                                children = {
                                                    UI.Label {
                                                        text = card.desc,
                                                        fontSize = 12,
                                                        fontColor = "#8888AA",
                                                        align = "center",
                                                    }
                                                }
                                            }
                                        end
                                    end
                                    return rows
                                end)(),
                            },

                            -- ====== 技能区 ======
                            UI.Panel {
                                width = "100%",
                                alignItems = "center",
                                paddingTop = 12,
                                paddingBottom = 8,
                                children = {
                                    UI.Label {
                                        text = "技能",
                                        fontSize = 14,
                                        fontColor = COLORS.text,
                                        fontWeight = "bold",
                                        marginBottom = 4,
                                    },
                                    UI.Label {
                                        text = "点击图标查看详情",
                                        fontSize = 9,
                                        fontColor = COLORS.textDim,
                                        marginBottom = 8,
                                    },
                                    -- 技能图标行
                                    UI.Panel {
                                        flexDirection = "row",
                                        justifyContent = "center",
                                        flexWrap = "wrap",
                                        children = skillIcons,
                                    },
                                }
                            },

                            -- ====== 底部按钮区：升级 + 上阵/下阵 ======
                            isOwned and UI.Panel {
                                width = "100%",
                                flexDirection = "row",
                                justifyContent = "center",
                                alignItems = "center",
                                paddingTop = 8,
                                paddingBottom = 16,
                                children = {
                                    -- 升级按钮
                                    UI.Button {
                                        width = 140,
                                        height = 48,
                                        borderRadius = 12,
                                        backgroundColor = canUpgrade and COLORS.upgradeBtn or COLORS.disabledBtn,
                                        borderWidth = 2,
                                        borderColor = canUpgrade and COLORS.upgradeBorder or "#444466",
                                        alignItems = "center",
                                        justifyContent = "center",
                                        marginRight = 10,
                                        onClick = function()
                                            if canUpgrade then
                                                local success = PlayerDataManager.UpgradeCard(cardName)
                                                if success then
                                                    PlayerDataManager.Save()
                                                    CardDetailPopup.Show(cardName, onClose_)
                                                end
                                            end
                                        end,
                                        children = {
                                            UI.Label {
                                                text = "升级",
                                                fontSize = 16,
                                                fontColor = "#FFFFFF",
                                                fontWeight = "bold",
                                            },
                                            UI.Panel {
                                                flexDirection = "row",
                                                alignItems = "center",
                                                marginTop = 2,
                                                children = {
                                                    UI.Label { text = "×", fontSize = 12 },
                                                    UI.Label {
                                                        text = cardsNeeded,
                                                        fontSize = 12,
                                                        fontColor = canUpgrade and "#FFD700" or "#666688",
                                                        fontWeight = "bold",
                                                    },
                                                    UI.Label { text = " 🪙", fontSize = 10 },
                                                    UI.Label {
                                                        text = goldNeeded,
                                                        fontSize = 12,
                                                        fontColor = canUpgrade and "#FFD700" or "#666688",
                                                        fontWeight = "bold",
                                                    },
                                                }
                                            },
                                        }
                                    },
                                    -- 上阵/下阵按钮
                                    (function()
                                        if not deckCallbacks_ then return nil end
                                        local inDeck = deckCallbacks_.isInDeck(cardName)
                                        if inDeck then
                                            return UI.Button {
                                                width = 140,
                                                height = 48,
                                                borderRadius = 12,
                                                backgroundColor = "#8B0000",
                                                borderWidth = 2,
                                                borderColor = "#CC3333",
                                                alignItems = "center",
                                                justifyContent = "center",
                                                onClick = function()
                                                    deckCallbacks_.removeFromDeck(cardName)
                                                    CardDetailPopup.Hide()
                                                    if onClose_ then onClose_() end
                                                end,
                                                children = {
                                                    UI.Label {
                                                        text = "下阵",
                                                        fontSize = 16,
                                                        fontColor = "#FFFFFF",
                                                        fontWeight = "bold",
                                                    },
                                                }
                                            }
                                        else
                                            local deckFull = deckCallbacks_.isDeckFull()
                                            return UI.Button {
                                                width = 140,
                                                height = 48,
                                                borderRadius = 12,
                                                backgroundColor = deckFull and COLORS.disabledBtn or "#1565C0",
                                                borderWidth = 2,
                                                borderColor = deckFull and "#444466" or "#42A5F5",
                                                alignItems = "center",
                                                justifyContent = "center",
                                                onClick = function()
                                                    if not deckFull then
                                                        deckCallbacks_.addToDeck(cardName)
                                                        CardDetailPopup.Hide()
                                                        if onClose_ then onClose_() end
                                                    end
                                                end,
                                                children = {
                                                    UI.Label {
                                                        text = deckFull and "已满" or "上阵",
                                                        fontSize = 16,
                                                        fontColor = deckFull and "#666666" or "#FFFFFF",
                                                        fontWeight = "bold",
                                                    },
                                                }
                                            }
                                        end
                                    end)(),
                                }
                            } or nil,
                        }
                    },
                }
            },
        }
    }

    local ShellUI = require("UI.ShellUI")
    ShellUI.ShowOverlay(popupRoot_)
end

--- 隐藏弹窗
function CardDetailPopup.Hide()
    if popupRoot_ then
        local ShellUI = require("UI.ShellUI")
        ShellUI.HideOverlay()
        popupRoot_ = nil
    end
end

return CardDetailPopup
