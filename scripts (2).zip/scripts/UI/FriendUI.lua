-- ============================================================================
-- FriendUI.lua - 好友面板
-- 好友列表、帮忙加速、偷取资源、赠送碎片
-- ============================================================================
---@diagnostic disable: param-type-mismatch, assign-type-mismatch

local UI = require("urhox-libs/UI")
local FriendManager = require("Systems.FriendManager")
local PlayerDataManager = require("Data.PlayerDataManager")
local EventBus = require("Infrastructure.EventBus")

local FriendUI = {}

-- ========== 颜色常量 ==========
local COLORS = {
    bgDark = "#0a0a1a",
    bgCard = "#1a1a3a",
    bgPanel = "#12122a",
    text = "#e8e0d4",
    textDim = "#8a7e72",
    gold = "#ffd700",
    green = "#27ae60",
    blue = "#5dade2",
    orange = "#e67e22",
    red = "#e74c3c",
    purple = "#9b59b6",
    border = "#2a2a4a",
    online = "#27ae60",
    offline = "#6b7280",
}

-- ========== 内部状态 ==========
local wrapper_ = nil
local activeTab_ = "list"  -- "list" | "add"
local searchInput_ = ""    -- 搜索输入
local searchResult_ = nil  -- 搜索结果 { id, name, tier, trophies } 或 nil

-- ========== 段位名称映射 ==========
local TIER_NAMES = {
    [0] = "青铜", [1] = "白银", [2] = "黄金",
    [3] = "铂金", [4] = "钻石", [5] = "大师", [6] = "王者",
}

-- ========== 构建 UI ==========

--- 构建标题
local function buildTitle()
    return UI.Panel {
        width = "100%",
        height = 40,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "center",
        paddingTop = 8, paddingBottom = 4,
        children = {
            UI.Label {
                text = "好友",
                fontSize = 18,
                fontWeight = "bold",
                fontColor = COLORS.gold,
            },
        }
    }
end

--- 构建每日互动剩余次数提示
local function buildDailyInfo()
    local remaining = FriendManager.GetDailyRemaining()
    return UI.Panel {
        width = "100%", height = 32, flexDirection = "row",
        alignItems = "center", justifyContent = "center",
        backgroundColor = COLORS.bgPanel, paddingLeft = 12, paddingRight = 12,
        children = {
            UI.Label {
                text = "今日剩余：",
                fontSize = 11, color = COLORS.textDim,
            },
            UI.Label {
                text = "帮忙 " .. (remaining.help or 0),
                fontSize = 11, color = remaining.help > 0 and COLORS.green or COLORS.red,
                marginRight = 12,
            },
            UI.Label {
                text = "偷取 " .. (remaining.steal or 0),
                fontSize = 11, color = remaining.steal > 0 and COLORS.orange or COLORS.red,
                marginRight = 12,
            },
            UI.Label {
                text = "赠送 " .. (remaining.gift or 0),
                fontSize = 11, color = remaining.gift > 0 and COLORS.blue or COLORS.red,
            },
        },
    }
end

--- 构建 Tab 切换
local function buildTabs()
    local tabs = {
        { key = "list", name = "好友列表" },
        { key = "add", name = "添加好友" },
    }
    local tabChildren = {}
    for _, tab in ipairs(tabs) do
        local isActive = (activeTab_ == tab.key)
        tabChildren[#tabChildren + 1] = UI.Button {
            text = tab.name, fontSize = 13,
            backgroundColor = isActive and COLORS.blue or COLORS.bgDark,
            textColor = isActive and "#ffffff" or COLORS.textDim,
            borderRadius = 14, paddingLeft = 14, paddingRight = 14,
            height = 28, marginRight = 8,
            onClick = function()
                activeTab_ = tab.key
                FriendUI.Refresh()
            end,
        }
    end

    return UI.Panel {
        width = "100%", height = 40, flexDirection = "row",
        alignItems = "center", paddingLeft = 12,
        backgroundColor = COLORS.bgDark,
        children = tabChildren,
    }
end

--- 构建好友条目
local function buildFriendItem(friendId, friend)
    local tierName = TIER_NAMES[friend.tier or 0] or "青铜"
    local isOnline = (os.time() - (friend.lastOnline or 0)) < 300  -- 5分钟内算在线

    return UI.Panel {
        width = "100%", paddingLeft = 12, paddingRight = 12,
        paddingTop = 10, paddingBottom = 10,
        backgroundColor = COLORS.bgCard,
        borderBottom = 1, borderColor = COLORS.border,
        flexDirection = "row", alignItems = "center",
        children = {
            -- 在线状态点
            UI.Panel {
                width = 8, height = 8, borderRadius = 4,
                backgroundColor = isOnline and COLORS.online or COLORS.offline,
                marginRight = 8,
            },
            -- 好友信息
            UI.Panel {
                flexGrow = 1, flexShrink = 1,
                children = {
                    UI.Panel {
                        flexDirection = "row", alignItems = "center",
                        children = {
                            UI.Label {
                                text = friend.name or "浮空者",
                                fontSize = 14, color = COLORS.text,
                            },
                            UI.Label {
                                text = " [" .. tierName .. "]",
                                fontSize = 11, color = COLORS.purple,
                                marginLeft = 6,
                            },
                        },
                    },
                    UI.Label {
                        text = "奖杯: " .. (friend.trophies or 0),
                        fontSize = 11, color = COLORS.textDim, marginTop = 2,
                    },
                },
            },
            -- 操作按钮
            UI.Panel {
                flexDirection = "row", alignItems = "center",
                children = {
                    UI.Button {
                        text = "帮忙", fontSize = 11,
                        backgroundColor = COLORS.green, textColor = "#ffffff",
                        borderRadius = 10, paddingLeft = 8, paddingRight = 8,
                        height = 24, marginRight = 4,
                        onClick = function()
                            local ok, msg = FriendManager.HelpFriend(friendId, 1)
                            UI.Toast.Show(msg, ok and "success" or "warning")
                            FriendUI.Refresh()
                        end,
                    },
                    UI.Button {
                        text = "偷取", fontSize = 11,
                        backgroundColor = COLORS.orange, textColor = "#ffffff",
                        borderRadius = 10, paddingLeft = 8, paddingRight = 8,
                        height = 24, marginRight = 4,
                        onClick = function()
                            local ok, msg = FriendManager.StealFromPlayer(friendId)
                            UI.Toast.Show(msg, ok and "success" or "warning")
                            FriendUI.Refresh()
                        end,
                    },
                    UI.Button {
                        text = "删除", fontSize = 11,
                        backgroundColor = COLORS.red .. "66", textColor = COLORS.red,
                        borderRadius = 10, paddingLeft = 8, paddingRight = 8,
                        height = 24,
                        onClick = function()
                            FriendManager.RemoveFriend(friendId)
                            UI.Toast.Show("已删除好友", "info")
                            FriendUI.Refresh()
                        end,
                    },
                },
            },
        },
    }
end

--- 构建好友列表
local function buildFriendList()
    local friends = FriendManager.GetFriends()
    local items = {}

    for friendId, friend in pairs(friends) do
        items[#items + 1] = buildFriendItem(friendId, friend)
    end

    if #items == 0 then
        items[#items + 1] = UI.Panel {
            width = "100%", alignItems = "center", justifyContent = "center",
            paddingTop = 60,
            children = {
                UI.Label {
                    text = "暂无好友", fontSize = 16,
                    color = COLORS.textDim,
                },
                UI.Label {
                    text = "点击「添加好友」开始结交仙友",
                    fontSize = 12, color = COLORS.textDim, marginTop = 8,
                },
            },
        }
    end

    return UI.ScrollView {
        width = "100%", flexGrow = 1, flexShrink = 1,
        children = items,
    }
end

--- 构建添加好友界面（搜索名字 + 推荐列表）
local function buildAddFriendPanel()
    local items = {}

    -- 搜索栏
    items[#items + 1] = UI.Panel {
        width = "100%", paddingLeft = 12, paddingRight = 12,
        paddingTop = 12, paddingBottom = 8,
        flexDirection = "row", alignItems = "center",
        children = {
            UI.TextInput {
                placeholder = "输入玩家名字搜索...",
                fontSize = 13,
                backgroundColor = COLORS.bgCard, textColor = COLORS.text,
                borderRadius = 8, borderWidth = 1, borderColor = COLORS.border,
                height = 36, flexGrow = 1, marginRight = 8,
                value = searchInput_,
                onTextChanged = function(text)
                    searchInput_ = text
                end,
                onSubmit = function()
                    -- 执行搜索（实际游戏中通过服务器查询）
                    if searchInput_ == "" then
                        searchResult_ = nil
                        FriendUI.Refresh()
                        return
                    end
                    -- 模拟搜索结果
                    searchResult_ = {
                        id = "search_" .. searchInput_,
                        name = searchInput_,
                        tier = math.random(0, 4),
                        trophies = math.random(100, 900),
                    }
                    FriendUI.Refresh()
                end,
            },
            UI.Button {
                text = "搜索", fontSize = 13,
                backgroundColor = COLORS.blue, textColor = "#ffffff",
                borderRadius = 8, paddingLeft = 12, paddingRight = 12,
                height = 36,
                onClick = function()
                    if searchInput_ == "" then
                        UI.Toast.Show("请输入玩家名字", "warning")
                        return
                    end
                    -- 模拟搜索结果（实际游戏中通过服务器查询）
                    searchResult_ = {
                        id = "search_" .. searchInput_,
                        name = searchInput_,
                        tier = math.random(0, 4),
                        trophies = math.random(100, 900),
                    }
                    FriendUI.Refresh()
                end,
            },
        },
    }

    -- 搜索结果
    if searchResult_ then
        local s = searchResult_
        local tierName = TIER_NAMES[s.tier] or "青铜"
        local alreadyFriend = FriendManager.GetFriends()[s.id] ~= nil

        items[#items + 1] = UI.Panel {
            width = "100%", paddingLeft = 12, paddingRight = 12,
            paddingTop = 10, paddingBottom = 10,
            backgroundColor = COLORS.bgPanel,
            borderBottom = 1, borderColor = COLORS.blue,
            flexDirection = "row", alignItems = "center",
            children = {
                UI.Panel {
                    flexGrow = 1,
                    children = {
                        UI.Label {
                            text = "找到: " .. s.name .. "  [" .. tierName .. "]",
                            fontSize = 14, color = COLORS.text,
                        },
                        UI.Label {
                            text = "奖杯: " .. s.trophies,
                            fontSize = 11, color = COLORS.textDim, marginTop = 2,
                        },
                    },
                },
                alreadyFriend and UI.Label {
                    text = "已添加", fontSize = 11, color = COLORS.textDim,
                } or UI.Button {
                    text = "+ 添加好友", fontSize = 12,
                    backgroundColor = COLORS.blue, textColor = "#ffffff",
                    borderRadius = 10, paddingLeft = 12, paddingRight = 12,
                    height = 28,
                    onClick = function()
                        local ok, msg = FriendManager.AddFriend(s.id, {
                            name = s.name,
                            tier = s.tier,
                            trophies = s.trophies,
                        })
                        UI.Toast.Show(msg, ok and "success" or "warning")
                        searchResult_ = nil
                        searchInput_ = ""
                        FriendUI.Refresh()
                    end,
                },
            },
        }
    end

    -- 分隔线
    items[#items + 1] = UI.Panel {
        width = "100%", height = 1, backgroundColor = COLORS.border,
        marginTop = 8, marginBottom = 8,
    }

    -- 推荐列表
    items[#items + 1] = UI.Label {
        text = "推荐仙友", fontSize = 14,
        color = COLORS.text, marginBottom = 8, marginLeft = 12,
    }

    -- 模拟推荐列表（实际游戏中从服务器获取）
    local suggestions = {
        { id = "npc_1", name = "苍穹骑士", tier = 2, trophies = 450 },
        { id = "npc_2", name = "星辉贤者", tier = 3, trophies = 680 },
        { id = "npc_3", name = "熔核工匠", tier = 1, trophies = 230 },
        { id = "npc_4", name = "暗影机师", tier = 2, trophies = 510 },
        { id = "npc_5", name = "飞艇指挥", tier = 4, trophies = 920 },
    }

    for _, s in ipairs(suggestions) do
        local tierName = TIER_NAMES[s.tier] or "青铜"
        local alreadyFriend = FriendManager.GetFriends()[s.id] ~= nil

        items[#items + 1] = UI.Panel {
            width = "100%", paddingLeft = 12, paddingRight = 12,
            paddingTop = 8, paddingBottom = 8,
            backgroundColor = COLORS.bgCard,
            borderBottom = 1, borderColor = COLORS.border,
            flexDirection = "row", alignItems = "center",
            children = {
                UI.Panel {
                    flexGrow = 1,
                    children = {
                        UI.Label {
                            text = s.name .. "  [" .. tierName .. "]",
                            fontSize = 13, color = COLORS.text,
                        },
                        UI.Label {
                            text = "奖杯: " .. s.trophies,
                            fontSize = 11, color = COLORS.textDim, marginTop = 2,
                        },
                    },
                },
                alreadyFriend and UI.Label {
                    text = "已添加", fontSize = 11, color = COLORS.textDim,
                } or UI.Button {
                    text = "+ 添加", fontSize = 11,
                    backgroundColor = COLORS.blue, textColor = "#ffffff",
                    borderRadius = 10, paddingLeft = 10, paddingRight = 10,
                    height = 26,
                    onClick = function()
                        local ok, msg = FriendManager.AddFriend(s.id, {
                            name = s.name,
                            tier = s.tier,
                            trophies = s.trophies,
                        })
                        UI.Toast.Show(msg, ok and "success" or "warning")
                        FriendUI.Refresh()
                    end,
                },
            },
        }
    end

    return UI.ScrollView {
        width = "100%", flexGrow = 1, flexShrink = 1,
        children = items,
    }
end

-- ========== 公开接口 ==========

--- 显示好友面板
function FriendUI.Show()
    activeTab_ = "list"
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    FriendUI.Refresh()
    return wrapper_
end

--- 刷新界面
function FriendUI.Refresh()
    local tabContent
    if activeTab_ == "list" then
        tabContent = buildFriendList()
    else
        tabContent = buildAddFriendPanel()
    end

    local content = UI.Panel {
        width = "100%", height = "100%",
        backgroundColor = COLORS.bgDark,
        paddingTop = 12,
        children = {
            buildTitle(),
            buildDailyInfo(),
            buildTabs(),
            tabContent,
        },
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 隐藏面板
function FriendUI.Hide()
    wrapper_ = nil
end

return FriendUI
