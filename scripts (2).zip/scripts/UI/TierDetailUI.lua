-- ============================================================================
-- TierDetailUI.lua - 斗法段位详情页
-- 垂直可滑动段位列表 + 里程碑宝箱 + 当前段位定位
-- 参考"占城大师"竞技场页面设计
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local SeasonConfig = require("Config.SeasonConfig")
local PlayerDataManager = require("Data.PlayerDataManager")

local TierDetailUI = {}

-- ========== 内部状态 ==========
local rootPanel_ = nil
local onBack_ = nil

-- ========== 样式常量 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    headerBg = "#16162E",
    cardBg = "#1A1A3A",
    gold = "#FFD700",
    text = "#FFFFFF",
    textDim = "#8888AA",
    border = "#2A2A4A",
    green = "#4CAF50",
    blue = "#42A5F5",
    orange = "#FF8A65",
    purple = "#AB47BC",
    red = "#FF5252",
    locked = "#555577",
}

-- 段位对应的图标和颜色
local TIER_VISUALS = {
    { icon = "🥉", color = "#CD7F32", glow = "#8B4513" },   -- 青铜
    { icon = "🥈", color = "#C0C0C0", glow = "#808080" },   -- 白银
    { icon = "🥇", color = "#FFD700", glow = "#B8860B" },   -- 黄金
    { icon = "💎", color = "#00BCD4", glow = "#006064" },   -- 铂金
    { icon = "💠", color = "#E040FB", glow = "#7B1FA2" },   -- 钻石
    { icon = "⭐", color = "#FF9800", glow = "#E65100" },   -- 星耀
    { icon = "👑", color = "#FFD700", glow = "#FF6F00" },   -- 王者
    { icon = "🏆", color = "#FF1744", glow = "#B71C1C" },   -- 荣耀王者
}

-- ========== 辅助函数 ==========

--- 获取玩家已领取的段位奖励记录
local function getClaimedRewards()
    local pd = PlayerDataManager.GetData()
    if pd and pd.claimedTierRewards then
        return pd.claimedTierRewards
    end
    return {}
end

--- 领取段位奖励
local function claimTierReward(tierIndex, subTier)
    local key = tierIndex .. "_" .. subTier
    local pd = PlayerDataManager.GetData()
    if not pd then return end

    local claimed = pd.claimedTierRewards or {}
    if claimed[key] then return end -- 已领取

    -- 查找奖励
    for _, reward in ipairs(SeasonConfig.TIER_PROMOTION_REWARDS) do
        if reward.tierIndex == tierIndex and reward.subTier == subTier then
            PlayerDataManager.AddGold(reward.gold)
            PlayerDataManager.AddXianyu(reward.xianyu)
            break
        end
    end

    -- 标记已领取
    claimed[key] = true
    PlayerDataManager.Set("claimedTierRewards", claimed)
    PlayerDataManager.Save()

    UI.Toast.Show("段位奖励已领取!", { type = "success", duration = 2 })
    TierDetailUI.Refresh()
end

-- ========== UI 构建 ==========

local function createHeader()
    return UI.Panel {
        width = "100%",
        height = 48,
        flexDirection = "row",
        alignItems = "center",
        backgroundColor = COLORS.headerBg,
        paddingLeft = 12,
        paddingRight = 12,
        children = {
            UI.Button {
                width = 36, height = 36,
                borderRadius = 18,
                backgroundColor = "#2A2A4A",
                alignItems = "center",
                justifyContent = "center",
                onClick = function()
                    if onBack_ then onBack_("battle") end
                end,
                children = {
                    UI.Label { text = "←", fontSize = 18, fontColor = "#FFFFFF" },
                }
            },
            UI.Label {
                text = "⚔ 斗法段位",
                fontSize = 18,
                fontColor = COLORS.text,
                fontWeight = "bold",
                marginLeft = 12,
            },
            UI.Panel { flexGrow = 1 },
            -- 赛季信息
            UI.Label {
                text = "赛季进行中",
                fontSize = 10,
                fontColor = COLORS.green,
            },
        }
    }
end

--- 创建单个段位节点（含子段位）
local function createTierNode(tierIndex, tier, currentTierIndex, currentSubTier, playerTrophies)
    local visual = TIER_VISUALS[tierIndex + 1] or TIER_VISUALS[1]
    local isCurrentTier = (tierIndex == currentTierIndex)
    local isUnlocked = (playerTrophies >= tier.trophyMin)
    local isPassed = (tierIndex < currentTierIndex)

    local claimed = getClaimedRewards()

    -- 大段位节点
    local nodeColor = isUnlocked and visual.color or COLORS.locked
    local nodeBg = isCurrentTier and "#2A3A5A" or (isPassed and "#1A2A1A" or "#1A1A2A")
    local nodeBorder = isCurrentTier and visual.color or (isPassed and COLORS.green or COLORS.border)

    -- 子段位奖励行
    local subTierWidgets = {}
    if tier.subTiers > 0 then
        for sub = 1, tier.subTiers do
            local subKey = tierIndex .. "_" .. sub
            local isClaimed = claimed[subKey] == true

            -- 判断是否可领取（已经过了这个子段位）
            local subTrophyThreshold = tier.trophyMin + math.floor((tier.trophyMax - tier.trophyMin) / tier.subTiers * sub)
            local canClaim = playerTrophies >= subTrophyThreshold and not isClaimed
            local isReached = playerTrophies >= subTrophyThreshold

            -- 查找奖励数据
            local rewardGold = 0
            local rewardXianyu = 0
            for _, r in ipairs(SeasonConfig.TIER_PROMOTION_REWARDS) do
                if r.tierIndex == tierIndex and r.subTier == sub then
                    rewardGold = r.gold
                    rewardXianyu = r.xianyu
                    break
                end
            end

            local roman = { "I", "II", "III", "IV", "V" }
            local subName = tier.name .. (roman[sub] or tostring(sub))

            -- 状态显示
            local statusIcon, statusColor, statusBg
            if isClaimed then
                statusIcon = "✓"
                statusColor = COLORS.green
                statusBg = "#1A2E1A"
            elseif canClaim then
                statusIcon = "🎁"
                statusColor = COLORS.gold
                statusBg = "#2A2A1A"
            elseif isReached then
                statusIcon = "○"
                statusColor = COLORS.textDim
                statusBg = "#1A1A2A"
            else
                statusIcon = "🔒"
                statusColor = COLORS.locked
                statusBg = "#12121E"
            end

            local thisTierIndex = tierIndex
            local thisSubTier = sub
            subTierWidgets[#subTierWidgets + 1] = UI.Panel {
                width = "100%",
                flexDirection = "row",
                alignItems = "center",
                paddingLeft = 32,
                paddingRight = 12,
                paddingTop = 6,
                paddingBottom = 6,
                backgroundColor = statusBg,
                children = {
                    -- 连接线指示
                    UI.Panel {
                        width = 2,
                        height = 24,
                        backgroundColor = isReached and visual.color or "#333344",
                        marginRight = 10,
                    },
                    -- 状态图标
                    UI.Label {
                        text = statusIcon,
                        fontSize = 14,
                        fontColor = statusColor,
                    },
                    -- 子段位名
                    UI.Label {
                        text = "  " .. subName,
                        fontSize = 12,
                        fontColor = isReached and COLORS.text or COLORS.locked,
                        marginLeft = 4,
                    },
                    UI.Panel { flexGrow = 1 },
                    -- 奖励信息
                    UI.Label {
                        text = "🪙" .. rewardGold .. " ✨" .. rewardXianyu,
                        fontSize = 10,
                        fontColor = isReached and COLORS.textDim or "#333344",
                        marginRight = 8,
                    },
                    -- 领取按钮（仅可领取状态显示）
                    canClaim and UI.Button {
                        height = 24,
                        paddingLeft = 10, paddingRight = 10,
                        borderRadius = 12,
                        backgroundColor = COLORS.gold,
                        alignItems = "center",
                        justifyContent = "center",
                        onClick = function()
                            claimTierReward(thisTierIndex, thisSubTier)
                        end,
                        children = {
                            UI.Label { text = "领取", fontSize = 9, fontColor = "#000000", fontWeight = "bold" },
                        }
                    } or nil,
                }
            }
        end
    end

    -- 组装大段位卡片
    local headerChildren = {
        -- 段位图标
        UI.Panel {
            width = 44, height = 44,
            borderRadius = 22,
            backgroundColor = visual.glow,
            borderWidth = 2,
            borderColor = nodeColor,
            alignItems = "center",
            justifyContent = "center",
            children = {
                UI.Label { text = visual.icon, fontSize = 20 },
            }
        },
        -- 段位信息
        UI.Panel {
            marginLeft = 12,
            flexGrow = 1,
            children = {
                UI.Panel {
                    flexDirection = "row",
                    alignItems = "center",
                    children = {
                        UI.Label {
                            text = tier.name,
                            fontSize = 16,
                            fontColor = nodeColor,
                            fontWeight = "bold",
                        },
                        isCurrentTier and UI.Panel {
                            marginLeft = 8,
                            paddingLeft = 6, paddingRight = 6,
                            paddingTop = 2, paddingBottom = 2,
                            borderRadius = 8,
                            backgroundColor = visual.color,
                            children = {
                                UI.Label { text = "当前", fontSize = 8, fontColor = "#000000", fontWeight = "bold" },
                            }
                        } or nil,
                        isPassed and UI.Label {
                            text = " ✓ 已通过",
                            fontSize = 10,
                            fontColor = COLORS.green,
                            marginLeft = 6,
                        } or nil,
                    }
                },
                UI.Label {
                    text = "🏆 " .. tier.trophyMin .. " - " .. tier.trophyMax,
                    fontSize = 10,
                    fontColor = COLORS.textDim,
                    marginTop = 2,
                },
            }
        },
        -- 赛季结算奖励预览
        UI.Panel {
            alignItems = "flex-end",
            children = {
                UI.Label {
                    text = "赛季奖励",
                    fontSize = 8,
                    fontColor = COLORS.textDim,
                },
                UI.Label {
                    text = "🪙" .. (SeasonConfig.SEASON_REWARDS[tierIndex + 1] and SeasonConfig.SEASON_REWARDS[tierIndex + 1].gold or 0),
                    fontSize = 10,
                    fontColor = isUnlocked and COLORS.gold or COLORS.locked,
                    marginTop = 2,
                },
            }
        },
    }

    -- 完整节点
    local nodeChildren = {
        -- 头部行
        UI.Panel {
            width = "100%",
            flexDirection = "row",
            alignItems = "center",
            paddingLeft = 12, paddingRight = 12,
            paddingTop = 12, paddingBottom = 8,
            children = headerChildren,
        },
    }

    -- 加入子段位
    for _, sw in ipairs(subTierWidgets) do
        nodeChildren[#nodeChildren + 1] = sw
    end

    -- 底部分隔
    nodeChildren[#nodeChildren + 1] = UI.Panel {
        width = "100%", height = 1,
        backgroundColor = COLORS.border,
        marginTop = 8,
    }

    return UI.Panel {
        width = "100%",
        backgroundColor = nodeBg,
        borderWidth = isCurrentTier and 1 or 0,
        borderColor = nodeBorder,
        borderRadius = isCurrentTier and 8 or 0,
        marginBottom = isCurrentTier and 4 or 0,
        children = nodeChildren,
    }
end

--- 创建赛季结算预览卡
local function createSeasonSummaryCard(currentTierIndex, playerTrophies)
    local rewards = SeasonConfig.SEASON_REWARDS[currentTierIndex + 1]
    if not rewards then return nil end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 12, paddingBottom = 12,
        backgroundColor = "#1A1A2E",
        borderBottomWidth = 1,
        borderColor = COLORS.border,
        children = {
            UI.Label {
                text = "📋 本赛季结算预览",
                fontSize = 13,
                fontColor = COLORS.gold,
                fontWeight = "bold",
            },
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 8,
                children = {
                    UI.Label {
                        text = "最高段位达到: ",
                        fontSize = 11,
                        fontColor = COLORS.textDim,
                    },
                    UI.Label {
                        text = SeasonConfig.GetTierDisplayName(currentTierIndex, 1, playerTrophies),
                        fontSize = 11,
                        fontColor = TIER_VISUALS[currentTierIndex + 1] and TIER_VISUALS[currentTierIndex + 1].color or COLORS.text,
                        fontWeight = "bold",
                    },
                }
            },
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 4,
                children = {
                    UI.Label {
                        text = "结算可获: 🪙" .. rewards.gold .. "  ✨" .. rewards.xianyu,
                        fontSize = 11,
                        fontColor = COLORS.text,
                    },
                }
            },
            rewards.bonus and UI.Label {
                text = "🎁 " .. rewards.bonus,
                fontSize = 10,
                fontColor = COLORS.purple,
                marginTop = 4,
            } or nil,
        }
    }
end

-- ========== 公共 API ==========

--- 显示段位详情页
---@param opts table|nil { onNavigate: function }
function TierDetailUI.Show(opts)
    onBack_ = opts and opts.onNavigate
    return TierDetailUI.Refresh()
end

--- 刷新界面
---@return table rootPanel
function TierDetailUI.Refresh()
    local pd = PlayerDataManager.GetData()
    local playerTrophies = pd and pd.trophies or 0
    local currentTierIndex, currentSubTier, _ = SeasonConfig.GetTierByTrophies(playerTrophies)

    -- 构建段位列表（从高到低显示，让玩家看到目标在上方）
    local tierNodes = {}
    for i = #SeasonConfig.TIERS, 1, -1 do
        local tier = SeasonConfig.TIERS[i]
        local tierIndex = i - 1
        tierNodes[#tierNodes + 1] = createTierNode(tierIndex, tier, currentTierIndex, currentSubTier, playerTrophies)
    end

    -- 赛季结算预览
    local summaryCard = createSeasonSummaryCard(currentTierIndex, playerTrophies)

    -- 完整内容
    local scrollChildren = {}
    if summaryCard then scrollChildren[#scrollChildren + 1] = summaryCard end
    for _, node in ipairs(tierNodes) do
        scrollChildren[#scrollChildren + 1] = node
    end
    -- 底部留白
    scrollChildren[#scrollChildren + 1] = UI.Panel { height = 40 }

    rootPanel_ = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = COLORS.bgDark,
        children = {
            createHeader(),
            UI.ScrollView {
                width = "100%",
                flexGrow = 1,
                flexShrink = 1,
                children = scrollChildren,
            },
        }
    }
    return rootPanel_
end

--- 隐藏
function TierDetailUI.Hide()
    rootPanel_ = nil
end

--- 是否正在显示
---@return boolean
function TierDetailUI.IsShowing()
    return rootPanel_ ~= nil
end

return TierDetailUI
