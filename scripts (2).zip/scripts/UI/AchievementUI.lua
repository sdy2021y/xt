-- ============================================================================
-- AchievementUI.lua - 成就面板
-- 显示所有成就进度，分类浏览，领取奖励
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local AchievementManager = require("Systems.AchievementManager")
local AchievementConfig = require("Config.AchievementConfig")
local EventBus = require("Infrastructure.EventBus")

local AchievementUI = {}

-- ========== 颜色常量 ==========
local COLORS = {
    bgDark = "#0a0a1a",
    bgCard = "#1a1a3a",
    bgPanel = "#12122a",
    text = "#e8e0d4",
    textDim = "#8a7e72",
    gold = "#ffd700",
    green = "#27ae60",
    blue = "#5dade2",
    orange = "#e67e22",
    red = "#e74c3c",
    purple = "#9b59b6",
    border = "#2a2a4a",
    progressBg = "#1a1a2e",
    progressFill = "#5dade2",
    claimed = "#4a4a5a",
}

-- 分类颜色
local CATEGORY_COLORS = {
    battle = "#e74c3c",
    collect = "#f39c12",
    social = "#3498db",
    rank = "#9b59b6",
}

-- ========== 内部状态 ==========
local wrapper_ = nil
local onBack_ = nil
local activeCategory_ = "all"  -- "all" | "battle" | "collect" | "social" | "rank"

-- ========== 构建 UI ==========

--- 创建分类 Tab
local function buildCategoryTabs()
    local categories = {
        { key = "all", name = "全部", icon = "📋" },
        { key = "battle", name = "对战", icon = "⚔️" },
        { key = "collect", name = "收集", icon = "🃏" },
        { key = "social", name = "社交", icon = "👥" },
        { key = "rank", name = "段位", icon = "👑" },
    }

    local tabs = {}
    for _, cat in ipairs(categories) do
        local isActive = (activeCategory_ == cat.key)
        tabs[#tabs + 1] = UI.Button {
            text = cat.icon .. " " .. cat.name,
            fontSize = 12,
            backgroundColor = isActive and COLORS.blue or COLORS.bgDark,
            textColor = isActive and "#ffffff" or COLORS.textDim,
            borderRadius = 14, paddingLeft = 10, paddingRight = 10,
            height = 28, marginRight = 6,
            onClick = function()
                activeCategory_ = cat.key
                AchievementUI.Refresh()
            end,
        }
    end

    return UI.Panel {
        width = "100%", height = 44, flexDirection = "row",
        alignItems = "center", paddingLeft = 12, paddingRight = 12,
        backgroundColor = COLORS.bgDark,
        children = tabs,
    }
end

--- 构建单个成就条目
local function buildAchievementItem(ach)
    local progressPct = ach.target > 0 and (ach.progress / ach.target) or 0
    progressPct = math.min(1, progressPct)

    local statusColor = COLORS.textDim
    local statusText = ach.progress .. "/" .. ach.target
    if ach.claimed then
        statusColor = COLORS.claimed
        statusText = "已领取"
    elseif ach.completed then
        statusColor = COLORS.green
        statusText = "可领取！"
    end

    local catColor = CATEGORY_COLORS[ach.category] or COLORS.blue

    -- 奖励描述
    local rewardParts = {}
    if ach.rewards then
        if ach.rewards.xianyu then rewardParts[#rewardParts + 1] = "星钻×" .. ach.rewards.xianyu end
        if ach.rewards.gold then rewardParts[#rewardParts + 1] = "金币×" .. ach.rewards.gold end
        if ach.rewards.runes then rewardParts[#rewardParts + 1] = "符文×" .. ach.rewards.runes end
    end
    local rewardText = table.concat(rewardParts, "  ")

    return UI.Panel {
        width = "100%", paddingLeft = 12, paddingRight = 12,
        paddingTop = 10, paddingBottom = 10,
        backgroundColor = ach.claimed and "#0d0d1d" or COLORS.bgCard,
        borderBottom = 1, borderColor = COLORS.border,
        flexDirection = "row", alignItems = "center",
        children = {
            -- 图标
            UI.Label {
                text = ach.icon, fontSize = 28,
                width = 44, textAlign = "center",
                opacity = ach.claimed and 0.4 or 1,
            },
            -- 信息区
            UI.Panel {
                flexGrow = 1, flexShrink = 1, marginLeft = 8,
                children = {
                    -- 名称 + 分类标签
                    UI.Panel {
                        flexDirection = "row", alignItems = "center",
                        children = {
                            UI.Label {
                                text = ach.name, fontSize = 14,
                                color = ach.claimed and COLORS.textDim or COLORS.text,
                            },
                            UI.Panel {
                                marginLeft = 8, paddingLeft = 5, paddingRight = 5,
                                paddingTop = 1, paddingBottom = 1,
                                borderRadius = 6, backgroundColor = catColor .. "33",
                                children = {
                                    UI.Label {
                                        text = (AchievementConfig.CATEGORIES[ach.category] or {}).name or "",
                                        fontSize = 10, color = catColor,
                                    },
                                },
                            },
                        },
                    },
                    -- 描述
                    UI.Label {
                        text = ach.desc, fontSize = 11,
                        color = COLORS.textDim, marginTop = 2,
                    },
                    -- 进度条
                    UI.Panel {
                        width = "100%", height = 6, marginTop = 6,
                        borderRadius = 3, backgroundColor = COLORS.progressBg,
                        overflow = "hidden",
                        children = {
                            UI.Panel {
                                width = tostring(math.floor(progressPct * 100)) .. "%",
                                height = "100%", borderRadius = 3,
                                backgroundColor = ach.claimed and COLORS.claimed
                                    or (ach.completed and COLORS.green or COLORS.progressFill),
                            },
                        },
                    },
                    -- 奖励
                    UI.Label {
                        text = rewardText, fontSize = 10,
                        color = COLORS.gold, marginTop = 3,
                        opacity = ach.claimed and 0.4 or 1,
                    },
                },
            },
            -- 状态/按钮
            UI.Panel {
                width = 72, alignItems = "center", justifyContent = "center",
                marginLeft = 8,
                children = {
                    (ach.completed and not ach.claimed) and UI.Button {
                        text = "领取", fontSize = 12,
                        backgroundColor = COLORS.green, textColor = "#ffffff",
                        borderRadius = 12, paddingLeft = 12, paddingRight = 12, height = 28,
                        onClick = function()
                            local success, rewards = AchievementManager.ClaimReward(ach.id)
                            if success then
                                local parts = {}
                                if rewards.xianyu then parts[#parts + 1] = "星钻+" .. rewards.xianyu end
                                if rewards.gold then parts[#parts + 1] = "金币+" .. rewards.gold end
                                if rewards.runes then parts[#parts + 1] = "符文+" .. rewards.runes end
                                UI.Toast.Show(table.concat(parts, " "), "success")
                            else
                                UI.Toast.Show("领取失败", "error")
                            end
                            AchievementUI.Refresh()
                        end,
                    } or UI.Label {
                        text = statusText, fontSize = 11,
                        color = statusColor, textAlign = "center",
                    },
                },
            },
        },
    }
end

--- 构建成就列表
local function buildAchievementList()
    local achievements
    if activeCategory_ == "all" then
        achievements = AchievementManager.GetAllAchievements()
    else
        achievements = AchievementManager.GetByCategory(activeCategory_)
    end

    -- 排序：可领取 > 进行中 > 已领取
    table.sort(achievements, function(a, b)
        local sa = a.claimed and 3 or (a.completed and 1 or 2)
        local sb = b.claimed and 3 or (b.completed and 1 or 2)
        if sa ~= sb then return sa < sb end
        return (a.progress / math.max(1, a.target)) > (b.progress / math.max(1, b.target))
    end)

    local items = {}
    for _, ach in ipairs(achievements) do
        items[#items + 1] = buildAchievementItem(ach)
    end

    if #items == 0 then
        items[#items + 1] = UI.Label {
            text = "暂无此类成就", fontSize = 14,
            color = COLORS.textDim, textAlign = "center",
            marginTop = 40,
        }
    end

    return UI.ScrollView {
        width = "100%", flexGrow = 1, flexShrink = 1,
        children = items,
    }
end

-- ========== 公开接口 ==========

--- 显示成就面板
function AchievementUI.Show(onBackCb)
    onBack_ = onBackCb
    activeCategory_ = "all"
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    AchievementUI.Refresh()
    return wrapper_
end

--- 刷新界面
function AchievementUI.Refresh()
    local content = UI.Panel {
        width = "100%", height = "100%",
        backgroundColor = COLORS.bgDark,
        paddingTop = 12,
        children = {
            buildCategoryTabs(),
            buildAchievementList(),
        },
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 隐藏面板
function AchievementUI.Hide()
    wrapper_ = nil
end

return AchievementUI
