-- ══════════════════════════════════════════════
-- ============================================================================
-- ShopUI.lua - 商店界面
-- 只卖卡牌，4个窗口，品质概率：绿64.5%/蓝30%/紫5%/橙0.5%
-- 商品购买一次后灰色，12小时自动刷新或看广告刷新（每天3次）
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local UnitConfig = require("Config.UnitConfig")
local PlayerDataManager = require("Data.PlayerDataManager")
local AdManager = require("Systems.AdManager")
local EventBus = require("Infrastructure.EventBus")

local ShopUI = {}

-- 广告效果：免费抽卡
local freePullActive_ = false

-- 订阅广告效果
EventBus.On("AdEffectActivated", function(effectType, effectData)
    if effectType == "freePull" then
        freePullActive_ = effectData.active
    elseif effectType == "freeArtifact" then
        freePullActive_ = effectData.active
    end
end)

-- ========== 常量 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    headerBg = "#16162E",
    cardBg = "#1A1A3A",
    cardSoldOut = "#111122",
    gold = "#FFD700",
    text = "#FFFFFF",
    textDim = "#8888AA",
    textSoldOut = "#555566",
    border = "#2A2A4A",
    borderSoldOut = "#1A1A2A",
    green = "#4CAF50",
    blue = "#42A5F5",
    purple = "#AB47BC",
    orange = "#FF6D00",
    adBtn = "#1565C0",
    adBtnDisabled = "#333344",
}

local QUALITY_COLORS = {
    green = "#4CAF50",
    blue = "#42A5F5",
    purple = "#AB47BC",
    gold = "#FFD700",
}

local QUALITY_NAMES = {
    green = "普通",
    blue = "稀有",
    purple = "史诗",
    gold = "传说",
}

-- 卡牌价格（金币，已上调）
local CARD_PRICES = {
    green = 200,
    blue = 500,
    purple = 1500,
    gold = 5000,
}

-- 品质抽取概率（千分比）：绿645 蓝300 紫50 金5
local QUALITY_WEIGHTS = {
    { quality = "green",  weight = 645 },
    { quality = "blue",   weight = 300 },
    { quality = "purple", weight = 50 },
    { quality = "gold",   weight = 5 },
}
local TOTAL_WEIGHT = 1000

-- 每次刷新4张卡
local DEAL_COUNT = 4

-- 12小时刷新间隔（秒）
local REFRESH_INTERVAL = 12 * 3600

-- ========== 内部状态 ==========
local wrapper_ = nil
local dailyDeals_ = {}

-- ========== 商店数据管理 ==========

--- 获取商店持久化数据
local function getShopData()
    local data = PlayerDataManager.GetData()
    if not data.shopData then
        data.shopData = {
            lastRefreshTime = 0,
            purchasedItems = {},
            adRefreshCount = 0,
            adRefreshResetDay = 0,
            dealSeed = 0,
        }
    end
    return data.shopData
end

--- 检查是否需要自动刷新（12小时倒计时）
local function checkAutoRefresh()
    local shopData = getShopData()
    local now = os.time()

    -- 首次打开或超过12小时，自动刷新
    if shopData.lastRefreshTime == 0 or (now - shopData.lastRefreshTime) >= REFRESH_INTERVAL then
        ShopUI.ForceRefresh()
        return true
    end
    return false
end

--- 检查每日广告刷新次数重置
local function checkDailyAdReset()
    local shopData = getShopData()
    local now = os.time()
    local todayStart = os.date("*t", now)
    todayStart.hour = 0
    todayStart.min = 0
    todayStart.sec = 0
    local todayDay = math.floor(os.time(todayStart) / 86400)

    if shopData.adRefreshResetDay ~= todayDay then
        shopData.adRefreshCount = 0
        shopData.adRefreshResetDay = todayDay
    end
end

--- 获取距离下次自动刷新的剩余秒数
local function getRefreshRemaining()
    local shopData = getShopData()
    if shopData.lastRefreshTime == 0 then return 0 end
    local elapsed = os.time() - shopData.lastRefreshTime
    return math.max(0, REFRESH_INTERVAL - elapsed)
end

--- 格式化剩余时间为 HH:MM:SS
local function formatTime(seconds)
    local h = math.floor(seconds / 3600)
    local m = math.floor((seconds % 3600) / 60)
    local s = seconds % 60
    return string.format("%02d:%02d:%02d", h, m, s)
end

-- ========== 生成卡牌 ==========

--- 简易确定性 hash（不污染全局 math.random 状态）
---@param seed integer
---@return fun(): integer  返回一个伪随机生成器函数
local function createSeededRng(seed)
    local s = seed
    return function()
        -- xorshift32
        s = s ~ (s << 13)
        s = s ~ (s >> 17)
        s = s ~ (s << 5)
        s = s & 0x7FFFFFFF  -- 保持正数
        return s
    end
end

--- 按权重随机选品质
---@param rng fun(): integer
---@return string quality
local function rollQuality(rng)
    local roll = rng() % TOTAL_WEIGHT
    local cumulative = 0
    for _, qw in ipairs(QUALITY_WEIGHTS) do
        cumulative = cumulative + qw.weight
        if roll < cumulative then
            return qw.quality
        end
    end
    return "green"
end

--- 从指定品质中随机选一张 unit 卡
---@param quality string
---@param rng fun(): integer
---@return string|nil cardName
local function pickCardByQuality(quality, rng)
    local candidates = {}
    for cardName, cardDef in pairs(UnitConfig.CARDS) do
        if cardDef.quality == quality and cardDef.slotType == "unit" then
            candidates[#candidates + 1] = cardName
        end
    end
    if #candidates == 0 then return nil end
    -- 排序保证确定性
    table.sort(candidates)
    local idx = (rng() % #candidates) + 1
    return candidates[idx]
end

local function generateDailyDeals()
    local shopData = getShopData()
    local rng = createSeededRng(shopData.dealSeed)

    dailyDeals_ = {}
    local usedCards = {}

    for _ = 1, DEAL_COUNT do
        local quality = rollQuality(rng)
        local cardName = nil
        -- 重试避免重复卡牌
        local attempts = 0
        while attempts < 20 do
            local candidate = pickCardByQuality(quality, rng)
            if candidate and not usedCards[candidate] then
                cardName = candidate
                break
            end
            attempts = attempts + 1
        end

        -- 兜底：如果该品质没卡了，降级
        if not cardName then
            for _, qw in ipairs(QUALITY_WEIGHTS) do
                local fallback = pickCardByQuality(qw.quality, rng)
                if fallback and not usedCards[fallback] then
                    cardName = fallback
                    quality = qw.quality
                    break
                end
            end
        end

        if cardName then
            usedCards[cardName] = true
            local cardDef = UnitConfig.CARDS[cardName]
            dailyDeals_[#dailyDeals_ + 1] = {
                cardName = cardName,
                cardDef = cardDef,
                quality = quality,
                goldPrice = CARD_PRICES[quality] or 200,
            }
        end
    end
end

-- ========== UI 构建 ==========

--- 创建卡牌商品项
local function createDealItem(deal, index)
    local shopData = getShopData()
    local sold = shopData.purchasedItems[index] == true
    local qColor = sold and COLORS.borderSoldOut or (QUALITY_COLORS[deal.quality] or "#888888")
    local bgColor = sold and COLORS.cardSoldOut or COLORS.cardBg

    return UI.Button {
        width = "47%",
        height = 150,
        margin = 4,
        borderRadius = 12,
        backgroundColor = bgColor,
        borderWidth = sold and 1 or 2,
        borderColor = qColor,
        alignItems = "center",
        justifyContent = "center",
        paddingTop = 8,
        paddingBottom = 8,
        onClick = function()
            if not sold then
                ShopUI.BuyCard(index)
            end
        end,
        children = {
            -- 卡牌图标（已购买变暗）
            UI.Label {
                text = deal.cardDef.icon,
                fontSize = 32,
                fontColor = sold and COLORS.textSoldOut or COLORS.text,
            },
            -- 卡名
            UI.Label {
                text = deal.cardName,
                fontSize = 13,
                fontColor = sold and COLORS.textSoldOut or COLORS.text,
                fontWeight = "bold",
                marginTop = 4,
            },
            -- 品质标签
            UI.Label {
                text = (QUALITY_NAMES[deal.quality] or "") .. " · " .. deal.cardDef.race,
                fontSize = 9,
                fontColor = sold and COLORS.textSoldOut or qColor,
                marginTop = 2,
            },
            -- 价格或已购买标记
            sold and UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 8,
                height = 24,
                paddingLeft = 10,
                paddingRight = 10,
                borderRadius = 12,
                backgroundColor = "#1A1A1A",
                children = {
                    UI.Label {
                        text = "已购买",
                        fontSize = 12,
                        fontColor = COLORS.textSoldOut,
                    },
                }
            } or UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 8,
                height = 24,
                paddingLeft = 10,
                paddingRight = 10,
                borderRadius = 12,
                backgroundColor = "#2A1A00",
                children = {
                    UI.Label { text = "🪙", fontSize = 11 },
                    UI.Label {
                        text = " " .. deal.goldPrice,
                        fontSize = 12,
                        fontColor = COLORS.gold,
                        fontWeight = "bold",
                    },
                }
            },
        }
    }
end

--- 创建刷新按钮区域
local function createRefreshSection()
    checkDailyAdReset()
    local shopData = getShopData()
    local remaining = getRefreshRemaining()
    local adRefreshUsed = shopData.adRefreshCount or 0
    local adRefreshMax = 3
    local adRefreshLeft = adRefreshMax - adRefreshUsed
    local canAdRefresh = adRefreshLeft > 0

    return UI.Panel {
        width = "100%",
        paddingLeft = 8,
        paddingRight = 8,
        marginTop = 8,
        marginBottom = 4,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "space-between",
        children = {
            -- 倒计时
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "⏰ 刷新倒计时",
                        fontSize = 11,
                        fontColor = COLORS.textDim,
                    },
                    UI.Label {
                        text = " " .. formatTime(remaining),
                        fontSize = 12,
                        fontColor = COLORS.gold,
                        fontWeight = "bold",
                        marginLeft = 4,
                    },
                }
            },
            -- 广告刷新按钮
            UI.Button {
                height = 30,
                paddingLeft = 12,
                paddingRight = 12,
                borderRadius = 15,
                backgroundColor = canAdRefresh and COLORS.adBtn or COLORS.adBtnDisabled,
                borderWidth = 1,
                borderColor = canAdRefresh and "#42A5F5" or "#444466",
                alignItems = "center",
                justifyContent = "center",
                onClick = function()
                    if canAdRefresh then
                        ShopUI.AdRefresh()
                    else
                        UI.Toast.Show("今日广告刷新次数已用完", { type = "warning", duration = 2 })
                    end
                end,
                children = {
                    UI.Label {
                        text = canAdRefresh and ("📺 广告刷新 (" .. adRefreshLeft .. "/" .. adRefreshMax .. ")") or "📺 今日已用完",
                        fontSize = 11,
                        fontColor = canAdRefresh and "#FFFFFF" or "#666688",
                    },
                }
            },
        }
    }
end

--- 创建概率说明
local function createProbabilityInfo()
    return UI.Panel {
        width = "100%",
        paddingLeft = 12,
        paddingRight = 12,
        marginTop = 6,
        flexDirection = "row",
        justifyContent = "center",
        children = {
            UI.Label {
                text = "概率：",
                fontSize = 9,
                fontColor = COLORS.textDim,
            },
            UI.Label {
                text = "普通64.5% ",
                fontSize = 9,
                fontColor = QUALITY_COLORS.green,
            },
            UI.Label {
                text = "稀有30% ",
                fontSize = 9,
                fontColor = QUALITY_COLORS.blue,
            },
            UI.Label {
                text = "史诗5% ",
                fontSize = 9,
                fontColor = QUALITY_COLORS.purple,
            },
            UI.Label {
                text = "传说0.5%",
                fontSize = 9,
                fontColor = QUALITY_COLORS.gold,
            },
        }
    }
end

--- 创建卡牌商品区域
local function createCardShopSection()
    local dealWidgets = {}
    for i, deal in ipairs(dailyDeals_) do
        dealWidgets[#dealWidgets + 1] = createDealItem(deal, i)
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 8,
        paddingRight = 8,
        marginTop = 4,
        children = {
            -- 标题
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginBottom = 8,
                children = {
                    UI.Label {
                        text = "🎴 卡牌商店",
                        fontSize = 16,
                        fontColor = COLORS.orange,
                        fontWeight = "bold",
                    },
                    UI.Panel { flexGrow = 1 },
                    UI.Label {
                        text = "每12小时刷新",
                        fontSize = 10,
                        fontColor = COLORS.textDim,
                    },
                }
            },
            -- 刷新倒计时+广告刷新
            createRefreshSection(),
            -- 概率说明
            createProbabilityInfo(),
            -- 卡牌网格
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                flexWrap = "wrap",
                justifyContent = "center",
                marginTop = 8,
                children = dealWidgets,
            },
        }
    }
end

-- ========== 购买逻辑 ==========

--- 购买卡牌（只能买一次）
function ShopUI.BuyCard(index)
    local deal = dailyDeals_[index]
    if not deal then return end

    local shopData = getShopData()
    if shopData.purchasedItems[index] then
        UI.Toast.Show("已购买", { type = "warning", duration = 1.5 })
        return
    end

    if PlayerDataManager.SpendGold(deal.goldPrice) then
        shopData.purchasedItems[index] = true
        PlayerDataManager.AddCard(deal.cardName, 1)
        PlayerDataManager.Save()
        ShopUI.Refresh()
    else
        UI.Toast.Show("金币不足", { type = "warning", duration = 1.5 })
    end
end

-- ========== 刷新逻辑 ==========

--- 强制刷新商店（12小时倒计时到期或广告刷新）
function ShopUI.ForceRefresh()
    local shopData = getShopData()
    shopData.lastRefreshTime = os.time()
    shopData.purchasedItems = {}
    shopData.dealSeed = os.time() * 2654435761  -- 新种子=新卡牌
    PlayerDataManager.Save()
    generateDailyDeals()
end

--- 广告刷新商店
function ShopUI.AdRefresh()
    checkDailyAdReset()
    local shopData = getShopData()
    local adRefreshUsed = shopData.adRefreshCount or 0

    if adRefreshUsed >= 3 then
        UI.Toast.Show("今日广告刷新次数已用完", { type = "warning", duration = 2 })
        return
    end

    -- 播放广告
    local success, message = AdManager.PlayAd("shopRefresh")
    if success then
        shopData.adRefreshCount = adRefreshUsed + 1
        ShopUI.ForceRefresh()
        UI.Toast.Show("商店已刷新！", { type = "success", duration = 2 })
        ShopUI.Refresh()
    else
        UI.Toast.Show(message or "广告播放失败", { type = "warning", duration = 2 })
    end
end

-- ========== 公共 API ==========

--- 显示商店界面
function ShopUI.Show(callbacks)
    checkAutoRefresh()
    generateDailyDeals()
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    ShopUI.Refresh()
    return wrapper_
end

--- 刷新界面
function ShopUI.Refresh()
    local pdata = PlayerDataManager.GetData() or {}
    local content = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = COLORS.bgDark,
        paddingTop = 12,
        children = {
            -- 资源显示（右上角绝对定位）
            UI.Panel {
                position = "absolute",
                top = 8,
                right = 12,
                flexDirection = "row",
                alignItems = "center",
                backgroundColor = { 0, 0, 0, 0 },
                children = {
                    UI.Label {
                        text = "🪙" .. tostring(pdata.gold or 0),
                        fontSize = 12,
                        fontColor = COLORS.gold,
                        fontWeight = "bold",
                    },
                }
            },
            UI.ScrollView {
                width = "100%",
                flexGrow = 1,
                flexShrink = 1,
                children = {
                    createCardShopSection(),
                }
            },
        }
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 隐藏
function ShopUI.Hide()
    wrapper_ = nil
end

return ShopUI
