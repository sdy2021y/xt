-- ============================================================================
-- BattleHUD.lua - 战斗界面 HUD（完整布局版）
-- 布局：左上我方信息 / 右上敌方信息 / 顶部中间倒计时
--       左下晶核条 / 右下聊天按钮 / 右下角神器按钮
-- ============================================================================

local UI = require("urhox-libs/UI")
local GameConfig = require("Config.GameConfig")
local Shared = require("Network.Shared")
local ArtifactManager = require("Battle.ArtifactManager")
local ArtifactConfig = require("Config.ArtifactConfig")
local EventBus = require("Infrastructure.EventBus")
local PlayerDataManager = require("Data.PlayerDataManager")

local BattleHUD = {}

-- 快捷聊天是否展开
local chatPanelVisible_ = false

-- 当前模式 & 玩家信息（2v2 用）
local currentMode_ = "1v1"
local playersInfo_ = nil  -- { ally={name,trophies}, enemy1={name,trophies}, enemy2={name,trophies} }

-- ============================================================================
-- 主入口
-- ============================================================================

--- 创建战斗 HUD 根面板
---@param mode string|nil "1v1" 或 "2v2"（默认 "1v1"）
---@param playersInfo table|nil 2v2模式玩家信息 { ally={name,trophies}, enemy1={name,trophies}, enemy2={name,trophies} }
---@return table UI.Panel
function BattleHUD.Create(mode, playersInfo)
    currentMode_ = mode or "1v1"
    playersInfo_ = playersInfo

    local topChildren
    if currentMode_ == "2v2" then
        topChildren = {
            -- 顶部：2v2 紧凑双队伍横条
            BattleHUD.Create2v2TopBar(),
            -- 左下：人口显示
            BattleHUD.CreatePopulationPanel(),
            -- 左下偏右：晶核余额（无进度条，缩短版）
            BattleHUD.CreateSpiritBarCompact(),
            -- 右下偏上：聊天按钮
            BattleHUD.CreateChatButton(),
            -- 右下角：神器按钮
            BattleHUD.CreateArtifactButton(),
            -- 快捷聊天面板
            BattleHUD.CreateChatPanel(),
        }
    else
        topChildren = {
            -- 左上：我方信息面板
            BattleHUD.CreateMyInfoPanel(),
            -- 右上：敌方信息面板
            BattleHUD.CreateEnemyInfoPanel(),
            -- 顶部中间：倒计时
            BattleHUD.CreateTimerPanel(),
            -- 左下：晶核余额条
            BattleHUD.CreateSpiritBar(),
            -- 右下偏上：聊天按钮
            BattleHUD.CreateChatButton(),
            -- 右下角：神器按钮
            BattleHUD.CreateArtifactButton(),
            -- 快捷聊天面板
            BattleHUD.CreateChatPanel(),
        }
    end

    local hud = UI.Panel {
        id = "battleHUD",
        width = "100%",
        height = "100%",
        pointerEvents = "box-none",
        children = {
            UI.SafeAreaView {
                width = "100%",
                height = "100%",
                pointerEvents = "box-none",
                children = topChildren,
            }
        }
    }
    return hud
end

-- ============================================================================
-- 2v2 模式：顶部紧凑横条
-- ┌──────────────────────────────────────────────────────────────────────┐
-- │ [我][队友]  🟢12 👥23/100  │  ⏱1:49  │  🔴18 👥31/100  [敌1][敌2] │
-- └──────────────────────────────────────────────────────────────────────┘
-- ============================================================================

function BattleHUD.Create2v2TopBar()
    local pd = PlayerDataManager.GetData()
    local myName = (pd and pd.nickname) or "仙途弟子"
    local allyName = (playersInfo_ and playersInfo_.ally and playersInfo_.ally.name) or "队友"
    local enemy1Name = (playersInfo_ and playersInfo_.enemy1 and playersInfo_.enemy1.name) or "敌方1"
    local enemy2Name = (playersInfo_ and playersInfo_.enemy2 and playersInfo_.enemy2.name) or "敌方2"

    -- 截取名字前4个字符（避免太长）
    local function shortName(name, maxLen)
        maxLen = maxLen or 4
        if utf8 and utf8.len then
            local len = utf8.len(name) or 0
            if len > maxLen then
                local offset = utf8.offset(name, maxLen + 1)
                if offset then
                    return name:sub(1, offset - 1)
                end
            end
        elseif #name > maxLen * 3 then
            return name:sub(1, maxLen * 3)
        end
        return name
    end

    local myShort = shortName(myName)
    local allyShort = shortName(allyName)
    local e1Short = shortName(enemy1Name)
    local e2Short = shortName(enemy2Name)

    local BLUE = GameConfig.COLORS.PLAYER1
    local RED = GameConfig.COLORS.PLAYER2

    return UI.Panel {
        id = "topBar2v2",
        position = "absolute",
        top = 8,
        left = "50%",
        marginLeft = -220,
        width = 440,
        height = 44,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "space-between",
        backgroundColor = { 0, 0, 0, 160 },
        borderRadius = 10,
        paddingLeft = 8,
        paddingRight = 8,
        pointerEvents = "none",
        children = {
            -- === 左侧：我方队伍 ===
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                gap = 4,
                children = {
                    -- 玩家小头像
                    UI.Panel {
                        width = 24, height = 24, borderRadius = 5,
                        backgroundColor = BLUE,
                        justifyContent = "center", alignItems = "center",
                        children = {
                            UI.Label { text = myShort:sub(1, 3), fontSize = 10, fontColor = { 255, 255, 255, 255 } }
                        }
                    },
                    -- 队友小头像
                    UI.Panel {
                        width = 24, height = 24, borderRadius = 5,
                        backgroundColor = { 100, 160, 245, 255 },  -- 浅蓝
                        justifyContent = "center", alignItems = "center",
                        children = {
                            UI.Label { text = allyShort:sub(1, 3), fontSize = 10, fontColor = { 255, 255, 255, 255 } }
                        }
                    },
                    -- 我方领地
                    UI.Label {
                        id = "myTerritoryLabel",
                        text = "🟢 0",
                        fontSize = 12,
                        fontColor = { 200, 230, 255, 255 },
                        marginLeft = 4,
                    },
                }
            },
            -- === 中间：倒计时 ===
            UI.Panel {
                alignItems = "center",
                children = {
                    UI.Label {
                        id = "timerLabel",
                        text = "3:30",
                        fontSize = 20,
                        fontColor = GameConfig.COLORS.UI_TIMER,
                    },
                }
            },
            -- === 右侧：敌方队伍 ===
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                gap = 4,
                children = {
                    -- 敌方领地
                    UI.Label {
                        id = "enemyTerritoryLabel",
                        text = "🔴 0",
                        fontSize = 12,
                        fontColor = { 255, 200, 200, 255 },
                        marginRight = 4,
                    },
                    -- 敌方1小头像
                    UI.Panel {
                        width = 24, height = 24, borderRadius = 5,
                        backgroundColor = RED,
                        justifyContent = "center", alignItems = "center",
                        children = {
                            UI.Label { text = e1Short:sub(1, 3), fontSize = 10, fontColor = { 255, 255, 255, 255 } }
                        }
                    },
                    -- 敌方2小头像
                    UI.Panel {
                        width = 24, height = 24, borderRadius = 5,
                        backgroundColor = { 200, 100, 80, 255 },  -- 深红
                        justifyContent = "center", alignItems = "center",
                        children = {
                            UI.Label { text = e2Short:sub(1, 3), fontSize = 10, fontColor = { 255, 255, 255, 255 } }
                        }
                    },
                }
            },
        }
    }
end

-- ============================================================================
-- 左上：我方信息面板（1v1 模式）
-- ┌──┬──────────────┐
-- │  │ 昵称         │
-- │头│ 🏆 69        │
-- │  │ 🟢 86        │
-- │  │ 👥 12/100    │
-- └──┴──────────────┘
-- ============================================================================

function BattleHUD.CreateMyInfoPanel()
    local pd = PlayerDataManager.GetData()
    local nickname = (pd and pd.nickname) or "仙途弟子"
    local trophies = PlayerDataManager.Get("trophies") or 0

    return UI.Panel {
        id = "myInfoPanel",
        position = "absolute",
        left = 10,
        top = 10,
        flexDirection = "row",
        alignItems = "center",
        gap = 8,
        paddingLeft = 8,
        paddingRight = 10,
        paddingTop = 8,
        paddingBottom = 8,
        backgroundColor = { 0, 0, 0, 128 },
        borderRadius = 10,
        pointerEvents = "none",
        children = {
            -- 头像
            UI.Panel {
                width = 40,
                height = 40,
                borderRadius = 8,
                backgroundColor = GameConfig.COLORS.PLAYER1,
                justifyContent = "center",
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "仙",
                        fontSize = 18,
                        fontColor = { 255, 255, 255, 255 },
                    }
                }
            },
            -- 数据列
            UI.Panel {
                flexDirection = "column",
                gap = 2,
                children = {
                    UI.Label {
                        text = nickname,
                        fontSize = 13,
                        fontColor = { 255, 255, 255, 230 },
                    },
                    UI.Label {
                        text = "🏆 " .. trophies,
                        fontSize = 12,
                        fontColor = { 255, 210, 60, 255 },
                    },
                    UI.Label {
                        id = "myTerritoryLabel",
                        text = "🟢 0",
                        fontSize = 12,
                        fontColor = { 255, 255, 255, 220 },
                    },
                    UI.Label {
                        id = "myPopLabel",
                        text = "👥 0/" .. GameConfig.MAX_POPULATION,
                        fontSize = 12,
                        fontColor = { 200, 200, 210, 200 },
                    },
                }
            },
        }
    }
end

-- ============================================================================
-- 右上：敌方信息面板
-- ┌──────────────┬──┐
-- │   昵称       │  │
-- │      🏆 33   │头│
-- │      🔴 xx   │像│
-- │   👥 1/100   │  │
-- └──────────────┴──┘
-- ============================================================================

function BattleHUD.CreateEnemyInfoPanel()
    return UI.Panel {
        id = "enemyInfoPanel",
        position = "absolute",
        right = 10,
        top = 10,
        flexDirection = "row",
        alignItems = "center",
        gap = 8,
        paddingLeft = 10,
        paddingRight = 8,
        paddingTop = 8,
        paddingBottom = 8,
        backgroundColor = { 0, 0, 0, 128 },
        borderRadius = 10,
        pointerEvents = "none",
        children = {
            -- 数据列（右对齐）
            UI.Panel {
                flexDirection = "column",
                alignItems = "flex-end",
                gap = 2,
                children = {
                    UI.Label {
                        text = "对手",
                        fontSize = 13,
                        fontColor = { 255, 255, 255, 230 },
                    },
                    UI.Label {
                        text = "🏆 ?",
                        fontSize = 12,
                        fontColor = { 255, 210, 60, 255 },
                    },
                    UI.Label {
                        id = "enemyTerritoryLabel",
                        text = "🔴 0",
                        fontSize = 12,
                        fontColor = { 255, 255, 255, 220 },
                    },
                    UI.Label {
                        id = "enemyPopLabel",
                        text = "👥 0/" .. GameConfig.MAX_POPULATION,
                        fontSize = 12,
                        fontColor = { 200, 200, 210, 200 },
                    },
                }
            },
            -- 头像
            UI.Panel {
                width = 40,
                height = 40,
                borderRadius = 8,
                backgroundColor = GameConfig.COLORS.PLAYER2,
                justifyContent = "center",
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "敌",
                        fontSize = 18,
                        fontColor = { 255, 255, 255, 255 },
                    }
                }
            },
        }
    }
end

-- ============================================================================
-- 顶部中间：倒计时
-- ┌──────────────┐
-- │  时间剩余     │
-- │    1:49      │
-- └──────────────┘
-- ============================================================================

function BattleHUD.CreateTimerPanel()
    return UI.Panel {
        id = "timerPanel",
        position = "absolute",
        top = 10,
        left = "50%",
        marginLeft = -50,
        alignItems = "center",
        paddingLeft = 16,
        paddingRight = 16,
        paddingTop = 6,
        paddingBottom = 6,
        backgroundColor = { 30, 30, 50, 180 },
        borderRadius = 10,
        pointerEvents = "none",
        children = {
            UI.Label {
                text = "时间剩余",
                fontSize = 10,
                fontColor = { 160, 170, 190, 200 },
            },
            UI.Label {
                id = "timerLabel",
                text = "3:30",
                fontSize = 24,
                fontColor = GameConfig.COLORS.UI_TIMER,
            },
        }
    }
end

-- ============================================================================
-- 左下：晶核余额条
-- ┌─────────────────────────┐
-- │ ⭐ ██████████░░░░  56   │
-- └─────────────────────────┘
-- ============================================================================

function BattleHUD.CreateSpiritBar()
    return UI.Panel {
        id = "spiritBar",
        position = "absolute",
        left = 10,
        bottom = 10,
        width = 180,
        height = 36,
        flexDirection = "row",
        alignItems = "center",
        gap = 6,
        paddingLeft = 10,
        paddingRight = 10,
        backgroundColor = { 15, 18, 25, 220 },
        borderRadius = 18,
        borderWidth = 1,
        borderColor = { 60, 70, 90, 150 },
        pointerEvents = "none",
        children = {
            -- 星形图标
            UI.Label {
                text = "⭐",
                fontSize = 16,
            },
            -- 进度条背景
            UI.Panel {
                width = 90,
                height = 12,
                backgroundColor = { 40, 40, 50, 200 },
                borderRadius = 6,
                overflow = "hidden",
                children = {
                    -- 进度条前景
                    UI.Panel {
                        id = "spiritProgressBar",
                        width = "33%",
                        height = "100%",
                        backgroundColor = GameConfig.COLORS.UI_GOLD,
                        borderRadius = 6,
                    }
                }
            },
            -- 数字
            UI.Label {
                id = "spiritLabel",
                text = "100",
                fontSize = 14,
                fontColor = { 255, 255, 255, 255 },
            },
        }
    }
end

-- ============================================================================
-- ============================================================================
-- 左下：人口面板（2v2 模式专用）
-- ============================================================================

function BattleHUD.CreatePopulationPanel()
    return UI.Panel {
        id = "populationPanel",
        position = "absolute",
        left = 10,
        bottom = 50,
        height = 30,
        flexDirection = "row",
        alignItems = "center",
        gap = 4,
        paddingLeft = 10,
        paddingRight = 10,
        backgroundColor = { 15, 18, 25, 220 },
        borderRadius = 15,
        borderWidth = 1,
        borderColor = { 60, 70, 90, 150 },
        pointerEvents = "none",
        children = {
            UI.Label { text = "👥", fontSize = 13 },
            UI.Label {
                id = "myPopLabel",
                text = "0/" .. GameConfig.MAX_POPULATION,
                fontSize = 13,
                fontColor = { 200, 230, 255, 255 },
            },
        }
    }
end

-- ============================================================================
-- 左下偏右：晶核条紧凑版（2v2 模式，无进度条）
-- ============================================================================

function BattleHUD.CreateSpiritBarCompact()
    return UI.Panel {
        id = "spiritBar",
        position = "absolute",
        left = 10,
        bottom = 10,
        height = 30,
        flexDirection = "row",
        alignItems = "center",
        gap = 4,
        paddingLeft = 10,
        paddingRight = 10,
        backgroundColor = { 15, 18, 25, 220 },
        borderRadius = 15,
        borderWidth = 1,
        borderColor = { 60, 70, 90, 150 },
        pointerEvents = "none",
        children = {
            UI.Label { text = "⭐", fontSize = 14 },
            UI.Label {
                id = "spiritLabel",
                text = "100",
                fontSize = 14,
                fontColor = { 255, 255, 255, 255 },
            },
        }
    }
end

-- ============================================================================
-- 右下偏上：聊天按钮
-- ┌─────┐
-- │ 💬  │
-- └─────┘
-- ============================================================================

function BattleHUD.CreateChatButton()
    return UI.Button {
        id = "chatButton",
        position = "absolute",
        right = 16,
        bottom = 90,
        width = 48,
        height = 48,
        borderRadius = 24,
        backgroundColor = { 30, 30, 50, 180 },
        borderWidth = 1,
        borderColor = { 80, 90, 110, 150 },
        justifyContent = "center",
        alignItems = "center",
        pointerEvents = "auto",
        onPointerDown = function()
            chatPanelVisible_ = not chatPanelVisible_
            local panel = UI.FindById("chatPanel")
            if panel then
                panel.opacity = chatPanelVisible_ and 1 or 0
                panel.pointerEvents = chatPanelVisible_ and "auto" or "none"
            end
        end,
        children = {
            UI.Label {
                text = "💬",
                fontSize = 22,
            },
        }
    }
end

-- ============================================================================
-- 右下角：神器技能按钮
-- ┌─────┐
-- │ 🔮  │
-- └─────┘
-- ============================================================================

function BattleHUD.CreateArtifactButton()
    local hasArtifact = ArtifactManager.HasArtifact()
    local artifactIcon = ""
    local artifactName = ""

    if hasArtifact then
        local equipped = ArtifactManager.GetEquipped()
        local def = ArtifactConfig.ARTIFACTS[equipped and equipped.name or ""]
        if def then
            artifactIcon = def.icon or "⚡"
            artifactName = def.name or ""
        end
    end

    return UI.Button {
        id = "artifactButton",
        position = "absolute",
        right = 16,
        bottom = 20,
        width = 56,
        height = 56,
        borderRadius = 28,
        backgroundColor = hasArtifact and { 60, 45, 15, 220 } or { 40, 40, 50, 100 },
        borderWidth = 2,
        borderColor = hasArtifact and GameConfig.COLORS.UI_GOLD or { 80, 80, 90, 100 },
        justifyContent = "center",
        alignItems = "center",
        pointerEvents = hasArtifact and "auto" or "none",
        onPointerDown = function()
            if ArtifactManager.IsReady() then
                ArtifactManager.Release()
            end
        end,
        children = {
            UI.Label {
                id = "artifactIconLabel",
                text = hasArtifact and artifactIcon or "🔒",
                fontSize = 24,
                fontColor = hasArtifact and GameConfig.COLORS.UI_GOLD or { 120, 120, 130, 150 },
            },
        }
    }
end

-- ============================================================================
-- 快捷聊天面板
-- ============================================================================

function BattleHUD.CreateChatPanel()
    -- 表情行
    local emojis = { "😠", "😭", "😆", "🤔", "👍" }
    local emojiRow = UI.Panel {
        width = "100%",
        flexDirection = "row",
        justifyContent = "space-around",
        paddingTop = 8,
        paddingBottom = 8,
        children = (function()
            local items = {}
            for _, emoji in ipairs(emojis) do
                items[#items + 1] = UI.Button {
                    width = 44,
                    height = 44,
                    justifyContent = "center",
                    alignItems = "center",
                    onPointerDown = function()
                        BattleHUD.SendChatMessage(emoji)
                    end,
                    children = {
                        UI.Label {
                            text = emoji,
                            fontSize = 28,
                        }
                    }
                }
            end
            return items
        end)(),
    }

    -- 预设文字按钮
    local presets = { "漂亮！", "精彩对决！", "祝好运！", "哎呀..." }
    local textRows = UI.Panel {
        width = "100%",
        flexDirection = "column",
        gap = 6,
        paddingLeft = 8,
        paddingRight = 8,
        paddingBottom = 8,
        children = (function()
            local rows = {}
            for i = 1, #presets, 2 do
                local rowChildren = {
                    UI.Button {
                        width = "48%",
                        height = 32,
                        justifyContent = "center",
                        alignItems = "center",
                        backgroundColor = { 255, 255, 255, 255 },
                        borderWidth = 1,
                        borderColor = { 66, 135, 245, 255 },
                        borderRadius = 6,
                        onPointerDown = function()
                            BattleHUD.SendChatMessage(presets[i])
                        end,
                        children = {
                            UI.Label {
                                text = presets[i],
                                fontSize = 12,
                                fontColor = { 50, 50, 50, 255 },
                            }
                        }
                    }
                }
                if presets[i + 1] then
                    rowChildren[#rowChildren + 1] = UI.Button {
                        width = "48%",
                        height = 32,
                        justifyContent = "center",
                        alignItems = "center",
                        backgroundColor = { 255, 255, 255, 255 },
                        borderWidth = 1,
                        borderColor = { 66, 135, 245, 255 },
                        borderRadius = 6,
                        onPointerDown = function()
                            BattleHUD.SendChatMessage(presets[i + 1])
                        end,
                        children = {
                            UI.Label {
                                text = presets[i + 1],
                                fontSize = 12,
                                fontColor = { 50, 50, 50, 255 },
                            }
                        }
                    }
                end
                rows[#rows + 1] = UI.Panel {
                    width = "100%",
                    flexDirection = "row",
                    justifyContent = "space-between",
                    children = rowChildren,
                }
            end
            return rows
        end)(),
    }

    return UI.Panel {
        id = "chatPanel",
        position = "absolute",
        right = 16,
        bottom = 150,
        width = 220,
        backgroundColor = { 255, 255, 255, 245 },
        borderWidth = 2,
        borderColor = { 66, 135, 245, 255 },
        borderRadius = 12,
        opacity = 0,
        pointerEvents = "none",
        children = {
            emojiRow,
            textRows,
        }
    }
end

--- 发送快捷聊天消息
---@param message string
function BattleHUD.SendChatMessage(message)
    -- 关闭面板
    chatPanelVisible_ = false
    local panel = UI.FindById("chatPanel")
    if panel then
        panel.opacity = 0
        panel.pointerEvents = "none"
    end

    -- 显示本地气泡
    BattleHUD.ShowChatBubble(message)
end

--- 显示聊天气泡（屏幕中间弹出，1.5秒后消失）
---@param message string
function BattleHUD.ShowChatBubble(message)
    local bubble = UI.FindById("chatBubble")
    if bubble then
        bubble:SetText(message)
        bubble.opacity = 1
    else
        -- 动态创建气泡（如果不存在）
        local root = UI.FindById("battleHUD")
        if root then
            -- 气泡由渲染层处理，这里只触发事件
        end
    end

    -- 1.5秒后隐藏
    -- 简化实现：由 Update 循环管理
    chatBubbleTimer_ = 1.5
    chatBubbleText_ = message
end

-- ============================================================================
-- 更新函数
-- ============================================================================

--- 更新倒计时显示
---@param seconds number
function BattleHUD.UpdateTimer(seconds)
    local label = UI.FindById("timerLabel")
    if label then
        label:SetText(Shared.FormatTime(seconds))
        -- 最后30秒变红
        if seconds <= 30 then
            label.fontColor = { 255, 80, 80, 255 }
        end
    end
end

--- 更新玩家晶核显示
---@param stones number
function BattleHUD.UpdateSpiritStones(stones)
    -- 数字
    local label = UI.FindById("spiritLabel")
    if label then
        label:SetText(tostring(math.floor(stones)))
    end
    -- 进度条
    local bar = UI.FindById("spiritProgressBar")
    if bar then
        local maxDisplay = 300
        local pct = math.min(stones / maxDisplay * 100, 100)
        bar.width = tostring(math.floor(pct)) .. "%"
    end
end

--- 更新人口显示
---@param current number
---@param max number
function BattleHUD.UpdatePopulation(current, max)
    local label = UI.FindById("myPopLabel")
    if label then
        if currentMode_ == "2v2" then
            label:SetText(current .. "/" .. max)
        else
            label:SetText("👥 " .. current .. "/" .. max)
        end
    end
end

--- 更新领地数显示
---@param count number
function BattleHUD.UpdateTerritory(count)
    local label = UI.FindById("myTerritoryLabel")
    if label then
        label:SetText("🟢 " .. count)
    end
end

--- 更新敌方领地数显示
---@param count number
function BattleHUD.UpdateEnemyTerritory(count)
    local label = UI.FindById("enemyTerritoryLabel")
    if label then
        label:SetText("🔴 " .. count)
    end
end

--- 更新敌方人口显示
---@param current number
---@param max number
function BattleHUD.UpdateEnemyPopulation(current, max)
    local label = UI.FindById("enemyPopLabel")
    if label then
        label:SetText("👥 " .. current .. "/" .. max)
    end
end

--- 更新铸材显示（保留兼容）
---@param count number
function BattleHUD.UpdateMaterials(count)
    -- 铸材已移到信息面板，此函数保留兼容
end

--- 更新神器按钮状态
function BattleHUD.UpdateArtifactButton()
    local button = UI.FindById("artifactButton")
    if not button then return end

    local isReady = ArtifactManager.IsReady()
    local hasArtifact = ArtifactManager.HasArtifact()

    if isReady then
        button.backgroundColor = { 150, 120, 30, 240 }
        button.borderColor = { 255, 220, 100, 255 }
    elseif hasArtifact then
        button.backgroundColor = { 60, 45, 15, 220 }
        button.borderColor = GameConfig.COLORS.UI_GOLD
    end
end

--- 初始化事件监听（在战斗开始时调用）
function BattleHUD.InitEventListeners()
    EventBus.On("ArtifactCharged", function(stage, maxStage)
        BattleHUD.UpdateArtifactButton()
    end)

    EventBus.On("ArtifactReleased", function(data)
        BattleHUD.UpdateArtifactButton()
    end)
end

return BattleHUD
