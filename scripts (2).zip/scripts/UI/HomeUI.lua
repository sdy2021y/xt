-- ============================================================================
-- HomeUI.lua - 游戏主界面（斗法首页）
-- 纯函数模式：输入数据，输出 UI panel，不操作 Shell
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local SeasonConfig = require("Config.SeasonConfig")
local GameConfig = require("Config.GameConfig")
local ChestManager = require("Battle.ChestManager")
local PlayerDataManager = require("Data.PlayerDataManager")
local PowerCalculator = require("Config.PowerCalculator")

local TierDetailUI = require("UI.TierDetailUI")

local HomeUI = {}

-- ========== 玩家数据（从 PlayerDataManager 读取） ==========
local function getPlayerData()
    local d = PlayerDataManager.GetData()
    if not d then
        return {
            name = "浮空者", level = 1, trophies = 0,
            gold = 0, runes = 0, spiritStones = 0,
            power = 0, wins = 0, losses = 0,
        }
    end
    return {
        name = d.name or "浮空者",
        level = d.level or 1,
        trophies = d.trophies or 0,
        gold = d.gold or 0,
        runes = d.runes or 0,
        spiritStones = d.spiritStones or 0,
        power = PowerCalculator.Calculate(),
        wins = d.wins or 0,
        losses = d.losses or 0,
    }
end

-- ========== 内部状态 ==========
local wrapper_ = nil      -- 持久容器（由 Show() 创建，Refresh() 更新）
local onBattle_ = nil      -- 点击对战按钮回调
local onCards_ = nil       -- 点击卡牌Tab回调
local onNavigate_ = nil    -- 导航回调（替代 ShellUI.SwitchTab）

-- ========== 样式常量 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    bgPanel = "#12122A",
    bgCard = "#1A1A3A",
    headerBg = "#16162E",
    gold = "#FFD700",
    runes = "#AB47BC",
    spiritStone = "#64FFDA",
    text = "#FFFFFF",
    textDim = "#8888AA",
    border = "#2A2A4A",
    btnBattle = "#FF6D00",
    btnBattleGlow = "#FF9100",
    arenaTitle = "#FFD54F",
    progressBg = "#1A1A2E",
    progressFill = "#FFC107",
    blue = "#42A5F5",
}

-- ========== 顶部货币栏 ==========
local function createCurrencyBar()
    local pd = getPlayerData()
    return UI.Panel {
        width = "100%",
        height = 36,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "center",
        paddingLeft = 12,
        paddingRight = 12,
        backgroundColor = COLORS.headerBg,
        children = {
            -- 晶核
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginRight = 16,
                children = {
                    UI.Label { text = "💎", fontSize = 14 },
                    UI.Label {
                        text = tostring(pd.spiritStones),
                        fontSize = 12,
                        fontColor = COLORS.spiritStone,
                        marginLeft = 4,
                    },
                }
            },
            -- 金币
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginRight = 16,
                children = {
                    UI.Label { text = "🪙", fontSize = 14 },
                    UI.Label {
                        text = tostring(pd.gold),
                        fontSize = 12,
                        fontColor = COLORS.gold,
                        marginLeft = 4,
                    },
                }
            },
            -- 符文
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                children = {
                    UI.Label { text = "🔮", fontSize = 14 },
                    UI.Label {
                        text = tostring(pd.runes),
                        fontSize = 12,
                        fontColor = COLORS.runes,
                        marginLeft = 4,
                    },
                }
            },
        }
    }
end

-- ========== 玩家信息区 ==========
local function createPlayerInfo()
    local pd = getPlayerData()
    local tierIndex, subTier = SeasonConfig.GetTierByTrophies(pd.trophies)
    local visual = SeasonConfig.GetTierVisual(tierIndex)

    return UI.Panel {
        width = "100%",
        flexDirection = "row",
        alignItems = "center",
        paddingLeft = 12,
        paddingRight = 12,
        paddingTop = 8,
        paddingBottom = 8,
        children = {
            -- 头像框
            UI.Button {
                width = 56,
                height = 56,
                borderRadius = 28,
                backgroundColor = "#2A2A5A",
                borderWidth = 2,
                borderColor = visual.color,
                alignItems = "center",
                justifyContent = "center",
                onClick = function()
                    HomeUI.ShowProfilePopup()
                end,
                children = {
                    UI.Label { text = "🧙", fontSize = 28 },
                }
            },
            -- 玩家名称和段位
            UI.Panel {
                marginLeft = 10,
                flexGrow = 1,
                children = {
                    UI.Label {
                        text = pd.name,
                        fontSize = 15,
                        fontColor = COLORS.text,
                        fontWeight = "bold",
                    },
                    UI.Panel {
                        flexDirection = "row",
                        alignItems = "center",
                        marginTop = 2,
                        children = {
                            UI.Label {
                                text = SeasonConfig.GetTierIconName(tierIndex, subTier, pd.trophies),
                                fontSize = 11,
                                fontColor = visual.color,
                            },
                            UI.Label {
                                text = "  ⚔️ 战力 " .. pd.power,
                                fontSize = 11,
                                fontColor = COLORS.textDim,
                            },
                        }
                    },
                }
            },
            -- 设置按钮
            UI.Button {
                width = 36,
                height = 36,
                borderRadius = 18,
                backgroundColor = "#2A2A4A",
                alignItems = "center",
                justifyContent = "center",
                onClick = function() end,
                children = {
                    UI.Label { text = "⚙", fontSize = 16, fontColor = "#AAAACC" },
                }
            },
        }
    }
end

-- ========== 斗法段位展示区（核心区域） ==========
local function createArenaDisplay()
    local pd = getPlayerData()
    local tierIndex, subTier = SeasonConfig.GetTierByTrophies(pd.trophies)
    local progress = SeasonConfig.GetProgress(pd.trophies)
    local progressPercent = math.floor(progress * 100)

    -- 获取赛季段位信息
    local tierDisplay = SeasonConfig.GetTierDisplayName(tierIndex, subTier, pd.trophies)
    local winBonus, _ = SeasonConfig.GetTrophyBonus(pd.trophies)

    return UI.Panel {
        width = "100%",
        alignItems = "center",
        paddingTop = 20,
        paddingBottom = 16,
        children = {
            -- 段位名称横幅
            UI.Panel {
                width = 240,
                height = 40,
                borderRadius = 20,
                backgroundColor = "#B8860B",
                borderWidth = 2,
                borderColor = COLORS.gold,
                alignItems = "center",
                justifyContent = "center",
                children = {
                    UI.Label {
                        text = "⚔ " .. tierDisplay,
                        fontSize = 18,
                        fontColor = "#FFFFFF",
                        fontWeight = "bold",
                    },
                }
            },

            -- 斗法场景展示（六边形棋盘）
            UI.Panel {
                width = 220,
                height = 190,
                marginTop = 16,
                borderRadius = 16,
                backgroundColor = SeasonConfig.GetTierVisual(tierIndex).bgColor,
                borderWidth = 2,
                borderColor = SeasonConfig.GetTierVisual(tierIndex).color,
                alignItems = "center",
                justifyContent = "center",
                children = {
                    -- 场景图案
                    UI.Label { text = "⬡", fontSize = 52 },
                    UI.Label {
                        text = "斗法天梯",
                        fontSize = 14,
                        fontColor = "#DDDDEE",
                        fontWeight = "bold",
                        marginTop = 8,
                    },
                    UI.Label {
                        text = SeasonConfig.GetTierDisplayName(tierIndex, subTier, pd.trophies),
                        fontSize = 10,
                        fontColor = "#AAAACC",
                        marginTop = 4,
                    },
                }
            },

            -- 奖杯进度条
            UI.Panel {
                width = 260,
                marginTop = 16,
                alignItems = "center",
                children = {
                    -- 进度条容器
                    UI.Panel {
                        width = "100%",
                        height = 20,
                        borderRadius = 10,
                        backgroundColor = COLORS.progressBg,
                        borderWidth = 1,
                        borderColor = "#333355",
                        overflow = "hidden",
                        children = {
                            -- 填充
                            UI.Panel {
                                width = progressPercent .. "%",
                                height = "100%",
                                borderRadius = 10,
                                backgroundColor = COLORS.progressFill,
                            },
                        }
                    },
                    -- 进度文字
                    UI.Panel {
                        width = "100%",
                        flexDirection = "row",
                        justifyContent = "space-between",
                        marginTop = 4,
                        children = {
                            UI.Label {
                                text = "🏆 " .. pd.trophies,
                                fontSize = 11,
                                fontColor = COLORS.gold,
                            },
                            UI.Label {
                                text = "胜+" .. winBonus,
                                fontSize = 11,
                                fontColor = "#66BB6A",
                            },
                        }
                    },
                }
            },

            -- 段位信息按钮（点击进入段位详情页）
            UI.Button {
                width = 220,
                height = 32,
                marginTop = 14,
                borderRadius = 16,
                backgroundColor = "#1A2A3A",
                borderWidth = 1,
                borderColor = "#334466",
                flexDirection = "row",
                alignItems = "center",
                justifyContent = "center",
                onClick = function()
                    if onNavigate_ then onNavigate_("tierDetail") end
                end,
                children = {
                    UI.Label {
                        text = "📜 查看段位奖励",
                        fontSize = 12,
                        fontColor = COLORS.blue,
                    },
                }
            },
        }
    }
end

-- ========== 大对战按钮 ==========
local function createBattleButton()
    return UI.Panel {
        width = "100%",
        alignItems = "center",
        paddingTop = 16,
        paddingBottom = 12,
        children = {
            UI.Button {
                width = 260,
                height = 58,
                borderRadius = 29,
                backgroundColor = COLORS.btnBattle,
                borderWidth = 3,
                borderColor = COLORS.btnBattleGlow,
                alignItems = "center",
                justifyContent = "center",
                onClick = function()
                    local ModeSelectUI = require("UI.ModeSelectUI")
                    ModeSelectUI.Show(function(mode)
                        if onBattle_ then onBattle_(mode) end
                    end)
                end,
                children = {
                    UI.Label {
                        text = "⚔ 选择模式",
                        fontSize = 20,
                        fontColor = "#FFFFFF",
                        fontWeight = "bold",
                    },
                }
            },
        }
    }
end

-- ========== 宝箱槽位区（6个槽位，动态数据） ==========
local function createChestSlots()
    local slotsData = ChestManager.GetSlots()
    local slotWidgets = {}

    for i = 1, ChestManager.MAX_SLOTS do
        local slot = slotsData[i]
        local state = slot.state
        local chestDef = slot.chestType and ChestManager.TYPES[slot.chestType]

        local bgColor = "#1A1A3A"
        local borderColor = "#333355"
        local icon = "➕"
        local label = "空"
        local labelColor = "#444466"

        if state == "ready" then
            bgColor = "#2E3D1A"
            borderColor = "#4CAF50"
            icon = chestDef and chestDef.icon or "🎁"
            label = "开启!"
            labelColor = "#66BB6A"
        elseif state == "unlocking" then
            bgColor = "#1A2A3A"
            borderColor = "#42A5F5"
            icon = chestDef and chestDef.icon or "📦"
            local remain = ChestManager.GetRemainingTime(i)
            label = ChestManager.FormatTime(remain)
            labelColor = "#64B5F6"
        elseif state == "locked" then
            bgColor = "#2A1A1A"
            borderColor = "#FF8A65"
            icon = chestDef and chestDef.icon or "🔒"
            label = "解锁"
            labelColor = "#FF8A65"
        end

        local slotIndex = i
        slotWidgets[#slotWidgets + 1] = UI.Button {
            width = 60,
            height = 76,
            borderRadius = 12,
            backgroundColor = bgColor,
            borderWidth = 1,
            borderColor = borderColor,
            alignItems = "center",
            justifyContent = "center",
            marginRight = i < 6 and 6 or 0,
            onClick = function()
                HomeUI.OnChestSlotClick(slotIndex)
            end,
            children = {
                UI.Label { text = icon, fontSize = 26 },
                UI.Label {
                    text = label,
                    fontSize = 9,
                    fontColor = labelColor,
                    marginTop = 4,
                },
            }
        }
    end

    return UI.Panel {
        width = "100%",
        flexDirection = "row",
        justifyContent = "center",
        alignItems = "center",
        paddingTop = 12,
        paddingBottom = 16,
        children = slotWidgets,
    }
end

-- ========== 右侧悬浮任务按钮 ==========
local function createQuestFloatingBtn()
    return UI.Button {
        position = "absolute",
        right = 12,
        top = 280,
        width = 44,
        height = 44,
        borderRadius = 22,
        backgroundColor = "#2A1A4A",
        borderWidth = 2,
        borderColor = "#AB47BC",
        alignItems = "center",
        justifyContent = "center",
        onClick = function()
            if onNavigate_ then onNavigate_("quest") end
        end,
        children = {
            UI.Label { text = "📋", fontSize = 18 },
        }
    }
end

-- ========== 右侧悬浮按钮：成就 ==========
local function createAchievementFloatingBtn()
    return UI.Button {
        position = "absolute",
        right = 12,
        top = 335,
        width = 44,
        height = 44,
        borderRadius = 22,
        backgroundColor = "#1A2A1A",
        borderWidth = 2,
        borderColor = "#4CAF50",
        alignItems = "center",
        justifyContent = "center",
        onClick = function()
            if onNavigate_ then onNavigate_("achievement") end
        end,
        children = {
            UI.Label { text = "🏅", fontSize = 18 },
        }
    }
end

-- ========== 右侧悬浮按钮：好友 ==========
local function createFriendFloatingBtn()
    return UI.Button {
        position = "absolute",
        right = 12,
        top = 390,
        width = 44,
        height = 44,
        borderRadius = 22,
        backgroundColor = "#1A1A3A",
        borderWidth = 2,
        borderColor = "#42A5F5",
        alignItems = "center",
        justifyContent = "center",
        onClick = function()
            if onNavigate_ then onNavigate_("friend") end
        end,
        children = {
            UI.Label { text = "👥", fontSize = 18 },
        }
    }
end

-- ========== 右侧悬浮按钮：聊天 ==========
local function createChatFloatingBtn()
    return UI.Button {
        position = "absolute",
        right = 12,
        top = 445,
        width = 44,
        height = 44,
        borderRadius = 22,
        backgroundColor = "#2A2A1A",
        borderWidth = 2,
        borderColor = "#FFA726",
        alignItems = "center",
        justifyContent = "center",
        onClick = function()
            if onNavigate_ then onNavigate_("chat") end
        end,
        children = {
            UI.Label { text = "💬", fontSize = 18 },
        }
    }
end

-- ========== 宝箱交互逻辑 ==========

--- 宝箱槽位点击
---@param slotIndex integer
function HomeUI.OnChestSlotClick(slotIndex)
    local slot = ChestManager.GetSlot(slotIndex)
    if not slot then return end

    if slot.state == "empty" then
        return
    elseif slot.state == "locked" then
        -- 显示宝箱详情弹窗（含解锁按钮）
        HomeUI.ShowChestDetail(slotIndex)
    elseif slot.state == "unlocking" then
        -- 显示宝箱详情弹窗（含星钻秒开按钮）
        HomeUI.ShowChestDetail(slotIndex)
    elseif slot.state == "ready" then
        local rewards = ChestManager.OpenChest(slotIndex)
        if rewards then
            HomeUI.ShowChestRewards(rewards)
        end
    end
end

--- 显示宝箱详情弹窗（点击宝箱时弹出，含开启/秒开按钮+可能获得的卡牌）
---@param slotIndex integer
function HomeUI.ShowChestDetail(slotIndex)
    local slot = ChestManager.GetSlot(slotIndex)
    if not slot or not slot.chestType then return end

    local chestDef = ChestManager.TYPES[slot.chestType]
    if not chestDef then return end

    local chestName = chestDef.name or "宝箱"
    local chestColor = chestDef.color or "#FFD700"
    local chestIcon = chestDef.icon or "📦"

    -- 卡牌预览（不显示概率）
    local previewWidgets = {}
    if chestDef.cardPreview then
        for _, text in ipairs(chestDef.cardPreview) do
            previewWidgets[#previewWidgets + 1] = UI.Label {
                text = text,
                fontSize = 11,
                fontColor = "#CCCCEE",
                marginTop = 3,
            }
        end
    end

    -- 底部按钮
    local actionBtn = nil
    if slot.state == "locked" then
        local canStart = not ChestManager.HasUnlocking()
        actionBtn = UI.Button {
            width = "80%",
            height = 40,
            borderRadius = 10,
            backgroundColor = canStart and "#1565C0" or "#333355",
            borderWidth = 1,
            borderColor = canStart and "#42A5F5" or "#444466",
            alignItems = "center",
            justifyContent = "center",
            marginTop = 12,
            onClick = function()
                if canStart then
                    ChestManager.StartUnlock(slotIndex)
                    local ShellUI = require("UI.ShellUI")
                    ShellUI.HideOverlay()
                    HomeUI.Refresh()
                end
            end,
            children = {
                UI.Label {
                    text = canStart and "开始解锁" or "已有宝箱在解锁中",
                    fontSize = 14,
                    fontColor = canStart and "#FFFFFF" or "#666666",
                    fontWeight = "bold",
                },
            }
        }
    elseif slot.state == "unlocking" then
        local remain = ChestManager.GetRemainingTime(slotIndex)
        local instantCost = chestDef.instantCost or 0
        actionBtn = UI.Button {
            width = "80%",
            height = 40,
            borderRadius = 10,
            backgroundColor = "#6A1B9A",
            borderWidth = 1,
            borderColor = "#AB47BC",
            alignItems = "center",
            justifyContent = "center",
            marginTop = 12,
            onClick = function()
                local rewards, err = ChestManager.InstantOpen(slotIndex)
                if rewards then
                    local ShellUI = require("UI.ShellUI")
                    ShellUI.HideOverlay()
                    HomeUI.ShowChestRewards(rewards)
                else
                    HomeUI.ShowToast(err or "星钻不足")
                end
            end,
            children = {
                UI.Label {
                    text = "💎" .. instantCost .. " 立即开启",
                    fontSize = 14,
                    fontColor = "#FFFFFF",
                    fontWeight = "bold",
                },
            }
        }
    end

    local detailPopup = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = { 0, 0, 0, 180 },
        alignItems = "center",
        justifyContent = "center",
        onClick = function()
            local ShellUI = require("UI.ShellUI")
            ShellUI.HideOverlay()
        end,
        children = {
            UI.Panel {
                width = 280,
                borderRadius = 16,
                backgroundColor = "#121830",
                borderWidth = 2,
                borderColor = chestColor,
                overflow = "hidden",
                children = {
                    -- 顶部
                    UI.Panel {
                        width = "100%",
                        flexDirection = "row",
                        alignItems = "center",
                        paddingLeft = 14,
                        paddingRight = 10,
                        paddingTop = 12,
                        paddingBottom = 8,
                        backgroundColor = chestColor .. "22",
                        children = {
                            UI.Label { text = chestIcon, fontSize = 28, marginRight = 10 },
                            UI.Label {
                                text = chestName,
                                fontSize = 18,
                                fontColor = chestColor,
                                fontWeight = "bold",
                                flexGrow = 1,
                            },
                            UI.Button {
                                width = 28,
                                height = 28,
                                borderRadius = 14,
                                backgroundColor = "#CC2222",
                                alignItems = "center",
                                justifyContent = "center",
                                onClick = function()
                                    local ShellUI = require("UI.ShellUI")
                                    ShellUI.HideOverlay()
                                end,
                                children = {
                                    UI.Label { text = "✕", fontSize = 12, fontColor = "#FFFFFF", fontWeight = "bold" },
                                }
                            },
                        }
                    },
                    -- 奖励信息
                    UI.Panel {
                        width = "100%",
                        paddingLeft = 16,
                        paddingRight = 16,
                        paddingTop = 12,
                        paddingBottom = 12,
                        children = {
                            -- 固定奖励
                            UI.Label {
                                text = "固定奖励",
                                fontSize = 12,
                                fontColor = "#8888AA",
                                marginBottom = 4,
                            },
                            UI.Panel {
                                flexDirection = "row",
                                flexWrap = "wrap",
                                children = {
                                    UI.Label { text = "🪙" .. (chestDef.gold or 0), fontSize = 13, fontColor = COLORS.gold, marginRight = 12 },
                                    UI.Label { text = "⛏️" .. (chestDef.materials or 0), fontSize = 13, fontColor = "#8D6E63", marginRight = 12 },
                                    (chestDef.xianyu or 0) > 0 and UI.Label { text = "💎" .. (chestDef.xianyu or 0), fontSize = 13, fontColor = "#B9F2FF" } or nil,
                                }
                            },
                            -- 可能获得的卡牌
                            UI.Label {
                                text = "可能获得",
                                fontSize = 12,
                                fontColor = "#8888AA",
                                marginTop = 10,
                                marginBottom = 4,
                            },
                            UI.Panel {
                                flexDirection = "column",
                                children = previewWidgets,
                            },
                            -- 倒计时/秒开
                            slot.state == "unlocking" and UI.Panel {
                                marginTop = 10,
                                alignItems = "center",
                                children = {
                                    UI.Label {
                                        text = "剩余: " .. ChestManager.FormatTime(ChestManager.GetRemainingTime(slotIndex)),
                                        fontSize = 12,
                                        fontColor = "#64B5F6",
                                    },
                                }
                            } or nil,
                            -- 操作按钮
                            actionBtn,
                        }
                    },
                }
            },
        }
    }

    local ShellUI = require("UI.ShellUI")
    ShellUI.ShowOverlay(detailPopup)
end

--- 显示开箱奖励弹窗
---@param rewards table
function HomeUI.ShowChestRewards(rewards)
    local chestDef = ChestManager.TYPES[rewards.chestType]
    local chestName = chestDef and chestDef.name or "宝箱"

    -- 卡牌奖励列表
    local cardWidgets = {}
    for _, card in ipairs(rewards.cards) do
        local qualityColors = {
            green = "#4CAF50",
            blue = "#42A5F5",
            purple = "#AB47BC",
            gold = "#FFD700",
        }
        cardWidgets[#cardWidgets + 1] = UI.Panel {
            width = 70,
            height = 80,
            borderRadius = 8,
            backgroundColor = "#1A1A3A",
            borderWidth = 1,
            borderColor = qualityColors[card.quality] or "#555555",
            alignItems = "center",
            justifyContent = "center",
            margin = 4,
            children = {
                UI.Label { text = card.icon, fontSize = 24 },
                UI.Label {
                    text = card.name,
                    fontSize = 8,
                    fontColor = "#CCCCEE",
                    marginTop = 4,
                },
                UI.Label {
                    text = card.race,
                    fontSize = 7,
                    fontColor = qualityColors[card.quality] or "#888888",
                    marginTop = 2,
                },
            }
        }
    end

    local popup = UI.Panel {
        width = 300,
        borderRadius = 16,
        backgroundColor = "#1A1A3A",
        borderWidth = 2,
        borderColor = chestDef and chestDef.color or "#FFD700",
        alignItems = "center",
        paddingTop = 20,
        paddingBottom = 20,
        paddingLeft = 16,
        paddingRight = 16,
        children = {
            -- 标题
            UI.Label {
                text = chestName .. " 开启!",
                fontSize = 18,
                fontColor = chestDef and chestDef.color or "#FFD700",
                fontWeight = "bold",
            },
            -- 金币奖励
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 12,
                children = {
                    UI.Label { text = "🪙", fontSize = 20 },
                    UI.Label {
                        text = " +" .. rewards.gold,
                        fontSize = 16,
                        fontColor = COLORS.gold,
                        fontWeight = "bold",
                    },
                }
            },
            -- 铸材奖励
            (rewards.materials and rewards.materials > 0) and UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 6,
                children = {
                    UI.Label { text = "⛏️", fontSize = 20 },
                    UI.Label {
                        text = " +" .. rewards.materials,
                        fontSize = 16,
                        fontColor = "#8D6E63",
                        fontWeight = "bold",
                    },
                }
            } or nil,
            -- 星钻奖励
            (rewards.xianyu and rewards.xianyu > 0) and UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 6,
                children = {
                    UI.Label { text = "💎", fontSize = 20 },
                    UI.Label {
                        text = " +" .. rewards.xianyu,
                        fontSize = 16,
                        fontColor = "#E040FB",
                        fontWeight = "bold",
                    },
                }
            } or nil,
            -- 卡牌分隔
            UI.Panel {
                width = "80%",
                height = 1,
                backgroundColor = "#333355",
                marginTop = 12,
                marginBottom = 12,
            },
            -- 获得卡牌标签
            UI.Label {
                text = "获得卡牌 x" .. #rewards.cards,
                fontSize = 12,
                fontColor = COLORS.textDim,
            },
            -- 卡牌列表（横向滚动）
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                flexWrap = "wrap",
                justifyContent = "center",
                marginTop = 8,
                children = cardWidgets,
            },
            -- 确认按钮（奖励已在 ChestManager 中发放，此处仅关闭弹窗）
            UI.Button {
                width = 160,
                height = 40,
                borderRadius = 20,
                backgroundColor = "#4CAF50",
                alignItems = "center",
                justifyContent = "center",
                marginTop = 16,
                onClick = function()
                    local ShellUI = require("UI.ShellUI")
                    ShellUI.HideOverlay()
                    HomeUI.Refresh()
                end,
                children = {
                    UI.Label {
                        text = "收下奖励",
                        fontSize = 14,
                        fontColor = "#FFFFFF",
                        fontWeight = "bold",
                    },
                }
            },
        }
    }
    local ShellUI = require("UI.ShellUI")
    ShellUI.ShowOverlay(popup)
end

--- 显示个人信息弹窗
function HomeUI.ShowProfilePopup()
    local pd = getPlayerData()
    local tierIndex, subTier, tierName = SeasonConfig.GetTierByTrophies(pd.trophies)
    local tierDisplay = SeasonConfig.GetTierDisplayName(tierIndex, subTier, pd.trophies)
    local visual = SeasonConfig.GetTierVisual(tierIndex)
    local totalGames = pd.wins + pd.losses
    local winRate = totalGames > 0 and math.floor(pd.wins / totalGames * 100) or 0

    local popup = UI.Panel {
        width = 280,
        borderRadius = 16,
        backgroundColor = "#1A1A3A",
        borderWidth = 2,
        borderColor = visual.color,
        alignItems = "center",
        paddingTop = 24,
        paddingBottom = 24,
        paddingLeft = 20,
        paddingRight = 20,
        children = {
            -- 头像
            UI.Panel {
                width = 64,
                height = 64,
                borderRadius = 32,
                backgroundColor = "#2A2A5A",
                borderWidth = 2,
                borderColor = visual.color,
                alignItems = "center",
                justifyContent = "center",
                children = {
                    UI.Label { text = "🧙", fontSize = 32 },
                }
            },
            -- 名字
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                marginTop = 12,
                children = {
                    UI.Label {
                        text = pd.name,
                        fontSize = 18,
                        fontColor = COLORS.text,
                        fontWeight = "bold",
                    },
                    UI.Label {
                        text = " ✏️",
                        fontSize = 14,
                        fontColor = COLORS.textDim,
                        marginLeft = 6,
                    },
                }
            },
            -- 分割线
            UI.Panel {
                width = "80%",
                height = 1,
                backgroundColor = "#333355",
                marginTop = 16,
                marginBottom = 16,
            },
            -- 当前段位
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                children = {
                    UI.Label {
                        text = visual.icon,
                        fontSize = 20,
                    },
                    UI.Label {
                        text = " " .. tierDisplay,
                        fontSize = 14,
                        fontColor = visual.color,
                        fontWeight = "bold",
                        marginLeft = 6,
                    },
                }
            },
            -- 奖杯数
            UI.Label {
                text = "🏆 " .. pd.trophies .. " 奖杯",
                fontSize = 13,
                fontColor = COLORS.gold,
                marginTop = 6,
            },
            -- 战力
            UI.Label {
                text = "⚔ 战力 " .. pd.power,
                fontSize = 13,
                fontColor = "#64FFDA",
                marginTop = 4,
            },
            -- 分割线
            UI.Panel {
                width = "80%",
                height = 1,
                backgroundColor = "#333355",
                marginTop = 16,
                marginBottom = 12,
            },
            -- 赛季数据
            UI.Label {
                text = "赛季数据",
                fontSize = 14,
                fontColor = COLORS.textDim,
                fontWeight = "bold",
            },
            -- 胜场
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                justifyContent = "space-around",
                marginTop = 12,
                children = {
                    UI.Panel {
                        alignItems = "center",
                        children = {
                            UI.Label {
                                text = tostring(pd.wins),
                                fontSize = 22,
                                fontColor = "#4CAF50",
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = "胜利",
                                fontSize = 11,
                                fontColor = COLORS.textDim,
                                marginTop = 2,
                            },
                        }
                    },
                    UI.Panel {
                        alignItems = "center",
                        children = {
                            UI.Label {
                                text = tostring(pd.losses),
                                fontSize = 22,
                                fontColor = "#EF5350",
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = "失败",
                                fontSize = 11,
                                fontColor = COLORS.textDim,
                                marginTop = 2,
                            },
                        }
                    },
                    UI.Panel {
                        alignItems = "center",
                        children = {
                            UI.Label {
                                text = winRate .. "%",
                                fontSize = 22,
                                fontColor = "#42A5F5",
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = "胜率",
                                fontSize = 11,
                                fontColor = COLORS.textDim,
                                marginTop = 2,
                            },
                        }
                    },
                }
            },
            -- 预留空位
            UI.Panel {
                width = "100%",
                height = 20,
                marginTop = 16,
                borderRadius = 8,
                backgroundColor = "#12122A",
                borderWidth = 1,
                borderColor = "#2A2A4A",
                alignItems = "center",
                justifyContent = "center",
                children = {
                    UI.Label {
                        text = "—— 更多数据敬请期待 ——",
                        fontSize = 10,
                        fontColor = "#444466",
                    },
                }
            },
            -- 关闭按钮
            UI.Button {
                width = 120,
                height = 36,
                borderRadius = 18,
                backgroundColor = "#333355",
                alignItems = "center",
                justifyContent = "center",
                marginTop = 16,
                onClick = function()
                    local ShellUI = require("UI.ShellUI")
                    ShellUI.HideOverlay()
                end,
                children = {
                    UI.Label {
                        text = "关闭",
                        fontSize = 14,
                        fontColor = "#AAAACC",
                    },
                }
            },
        }
    }
    local ShellUI = require("UI.ShellUI")
    ShellUI.ShowOverlay(popup)
end

--- 显示提示信息
---@param msg string
---@param variant string|nil "info"|"success"|"warning"|"error" 默认 "info"
function HomeUI.ShowToast(msg, variant)
    UI.Toast.Show(msg, { type = variant or "info", duration = 2.5 })
end

-- ========== 公共 API ==========

--- 显示主界面
---@param callbacks table { onBattle: function, onCards: function, onNavigate: function }
function HomeUI.Show(callbacks)
    onBattle_ = callbacks and callbacks.onBattle
    onCards_ = callbacks and callbacks.onCards
    onNavigate_ = callbacks and callbacks.onNavigate

    -- 初始化玩家数据和宝箱系统
    PlayerDataManager.Init()
    ChestManager.Init()
    local QuestManager = require("Data.QuestManager")
    QuestManager.Init()
    local SeasonManager = require("Systems.SeasonManager")
    SeasonManager.Init()
    local AchievementManager = require("Systems.AchievementManager")
    AchievementManager.Init()
    local FriendManager = require("Systems.FriendManager")
    FriendManager.Init()
    local ChatManager = require("Systems.ChatManager")
    ChatManager.Init()

    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    HomeUI.Refresh()
    return wrapper_
end

--- 刷新UI
function HomeUI.Refresh()
    local content = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = COLORS.bgDark,
        children = {
            createCurrencyBar(),
            createPlayerInfo(),
            UI.ScrollView {
                width = "100%",
                flexGrow = 1,
                flexShrink = 1,
                children = {
                    createArenaDisplay(),
                    createBattleButton(),
                    createChestSlots(),
                }
            },
            createQuestFloatingBtn(),
            createAchievementFloatingBtn(),
            createFriendFloatingBtn(),
            createChatFloatingBtn(),
        }
    }

    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

return HomeUI
