-- ══════════════════════════════════════════════
-- ============================================================================
-- MatchTransitionUI.lua - 匹配过渡页（VS展示）
-- 参考"占城大师"匹配成功页：双方信息 + VS特效 + 提示语
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local SeasonConfig = require("Config.SeasonConfig")
local DeckManager = require("Battle.DeckManager")
local SynergyManager = require("Battle.SynergyManager")
local UnitConfig = require("Config.UnitConfig")
local PowerCalculator = require("Config.PowerCalculator")

local MatchTransitionUI = {}

local rootPanel_ = nil
local timer_ = 0
local duration_ = 3.5  -- 过渡展示时长（秒）
local onComplete_ = nil

-- 匹配等待状态
local waitingPanel_ = nil
local waitingTimer_ = 0
local waitingDots_ = ""
local waitingMode_ = "1v1"

-- ========== 样式常量 ==========
local COLORS = {
    bg = "#1A0A2E",
    playerPanel = "#0D3B66",
    opponentPanel = "#5C1010",
    text = "#FFFFFF",
    textDim = "#AAAACC",
    gold = "#FFD700",
    trophy = "#FFC107",
    vsGlow = "#FF6D00",
    border = "#333366",
}

-- ========== 计算战力 ==========
local function calculatePower(deck)
    return PowerCalculator.DeckPower(deck)
end

-- ========== 获取羁绊图标摘要 ==========
local function getSynergyIcons(deck)
    -- 统计种族和职业
    local races = {}
    local classes = {}
    for _, cardName in ipairs(deck) do
        local card = UnitConfig.CARDS[cardName]
        if card and card.slotType == "unit" and card.race then
            races[card.race] = (races[card.race] or 0) + 1
            local cls = card.range == "melee" and "近战" or "远程"
            classes[cls] = (classes[cls] or 0) + 1
        end
    end

    local icons = {}
    local raceIcons = { human = "⚔️", demon = "👹", dark = "💀", spirit = "✨" }
    local raceNames = { human = "人", demon = "妖", dark = "魔", spirit = "灵" }
    for race, count in pairs(races) do
        if count >= 2 then
            icons[#icons + 1] = (raceIcons[race] or "?") .. count
        end
    end
    for cls, count in pairs(classes) do
        if count >= 2 then
            local icon = cls == "近战" and "🗡️" or "🏹"
            icons[#icons + 1] = icon .. count
        end
    end
    return table.concat(icons, " ")
end

-- ========== 创建玩家信息面板 ==========
---@param data table
---@param isPlayer boolean
---@param compact boolean|nil 紧凑模式(2v2并排时使用)
local function createPlayerPanel(data, isPlayer, compact)
    local bgColor = isPlayer and COLORS.playerPanel or COLORS.opponentPanel
    local borderColor = isPlayer and "#1E6091" or "#8B1A1A"
    local panelWidth = compact and "48%" or "90%"
    local panelHeight = compact and 90 or 100
    local avatarSize = compact and 40 or 56
    local nameFontSize = compact and 14 or 16
    local powerFontSize = compact and 14 or 18

    return UI.Panel {
        width = panelWidth,
        height = panelHeight,
        flexDirection = "row",
        alignItems = "center",
        backgroundColor = bgColor,
        borderRadius = 12,
        borderWidth = 2,
        borderColor = borderColor,
        paddingLeft = 12, paddingRight = 12,
        children = {
            -- 头像
            UI.Panel {
                width = avatarSize, height = avatarSize,
                borderRadius = math.floor(avatarSize / 2),
                backgroundColor = "#2A2A5A",
                borderWidth = 2,
                borderColor = COLORS.gold,
                alignItems = "center",
                justifyContent = "center",
                children = {
                    UI.Label { text = data.avatar or "👤", fontSize = compact and 20 or 28 },
                }
            },
            -- 信息区
            UI.Panel {
                flexGrow = 1,
                flexShrink = 1,
                marginLeft = compact and 8 or 12,
                children = {
                    -- 名字
                    UI.Label {
                        text = data.name,
                        fontSize = nameFontSize,
                        fontWeight = "bold",
                        fontColor = COLORS.text,
                    },
                    -- 段位 + 奖杯
                    UI.Panel {
                        flexDirection = "row",
                        alignItems = "center",
                        marginTop = 4,
                        children = {
                            UI.Label {
                                text = "🏅" .. data.rank,
                                fontSize = compact and 10 or 12,
                                fontColor = COLORS.trophy,
                            },
                            UI.Label {
                                text = "  🏆" .. data.trophies,
                                fontSize = compact and 10 or 12,
                                fontColor = COLORS.trophy,
                                marginLeft = 8,
                            },
                        }
                    },
                    -- 羁绊图标（紧凑模式隐藏）
                    compact and nil or UI.Panel {
                        flexDirection = "row",
                        marginTop = 4,
                        children = {
                            UI.Label {
                                text = data.synergies or "",
                                fontSize = 11,
                                fontColor = COLORS.textDim,
                            },
                        }
                    },
                }
            },
            -- 战力
            UI.Panel {
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "战力",
                        fontSize = compact and 9 or 10,
                        fontColor = COLORS.textDim,
                    },
                    UI.Label {
                        text = tostring(data.power),
                        fontSize = powerFontSize,
                        fontWeight = "bold",
                        fontColor = COLORS.gold,
                    },
                }
            },
        }
    }
end

-- ========== 公共 API ==========

--- 显示匹配等待页（模式选择后立即调用）
---@param mode string "1v1" or "2v2"
---@param onCancel function|nil 取消匹配回调
function MatchTransitionUI.ShowWaiting(mode, onCancel)
    waitingMode_ = mode or "1v1"
    waitingTimer_ = 0
    waitingDots_ = ""

    -- 隐藏之前的面板
    if rootPanel_ then
        UI.SetRoot(nil, true)
        rootPanel_ = nil
    end

    local modeLabel = waitingMode_ == "2v2" and "2v2 对战" or "1v1 对战"

    local dotsLabel = UI.Label {
        id = "waiting_dots",
        text = "匹配中...",
        fontSize = 20,
        fontColor = COLORS.text,
        marginTop = 16,
    }

    local timerLabel = UI.Label {
        id = "waiting_timer",
        text = "00:00",
        fontSize = 14,
        fontColor = COLORS.textDim,
        marginTop = 8,
    }

    waitingPanel_ = UI.Panel {
        width = "100%", height = "100%",
        position = "absolute",
        top = 0, left = 0,
        backgroundColor = COLORS.bg,
        alignItems = "center",
        justifyContent = "center",
        children = {
            -- 模式标题
            UI.Label {
                text = modeLabel,
                fontSize = 14,
                fontColor = COLORS.textDim,
                marginBottom = 4,
            },
            -- 搜索图标
            UI.Label {
                text = "🔍",
                fontSize = 48,
            },
            -- 匹配中动画文字
            dotsLabel,
            -- 计时器
            timerLabel,
            -- 提示
            UI.Label {
                text = "正在寻找实力相当的对手",
                fontSize = 12,
                fontColor = COLORS.textDim,
                marginTop = 24,
            },
            -- 取消按钮
            UI.Button {
                text = "取消",
                width = 120, height = 36,
                marginTop = 30,
                variant = "outline",
                onClick = function()
                    MatchTransitionUI.CancelWaiting()
                    if onCancel then onCancel() end
                end,
            },
        }
    }
    UI.SetRoot(waitingPanel_)
end

--- 更新匹配等待动画（需要外部每帧调用）
---@param dt number
function MatchTransitionUI.UpdateWaiting(dt)
    if not waitingPanel_ then return end
    waitingTimer_ = waitingTimer_ + dt

    -- 更新动画点
    local dotCount = math.floor(waitingTimer_ * 2) % 4
    local dots = string.rep(".", dotCount)
    local dotsNode = waitingPanel_:FindById("waiting_dots")
    if dotsNode then
        dotsNode:SetText("匹配中" .. dots)
    end

    -- 更新计时器
    local secs = math.floor(waitingTimer_)
    local mins = math.floor(secs / 60)
    secs = secs % 60
    local timerNode = waitingPanel_:FindById("waiting_timer")
    if timerNode then
        timerNode:SetText(string.format("%02d:%02d", mins, secs))
    end
end

--- 取消匹配等待
function MatchTransitionUI.CancelWaiting()
    if waitingPanel_ then
        UI.SetRoot(nil, true)
        waitingPanel_ = nil
    end
end

--- 匹配等待是否正在显示
function MatchTransitionUI.IsWaiting()
    return waitingPanel_ ~= nil
end

--- 显示匹配过渡页
---@param playerData table { name, trophies, deck }
---@param opponentData table { name, trophies, deck }
---@param onCompleteCallback function 过渡结束后回调
---@param mode string|nil "1v1" or "2v2"
---@param allyData table|nil 队友数据（2v2模式）
---@param opponent2Data table|nil 敌方2号数据（2v2模式）
function MatchTransitionUI.Show(playerData, opponentData, onCompleteCallback, mode, allyData, opponent2Data)
    onComplete_ = onCompleteCallback
    timer_ = 0
    mode = mode or "1v1"

    local playerDeck = playerData.deck or DeckManager.DEFAULT_PLAYER_DECK
    local opponentDeck = opponentData.deck or DeckManager.DEFAULT_AI_DECK

    local pTierIdx, pSubTier = SeasonConfig.GetTierByTrophies(playerData.trophies or 0)
    local oTierIdx, oSubTier = SeasonConfig.GetTierByTrophies(opponentData.trophies or 0)

    local pInfo = {
        name = playerData.name or "浮空者",
        avatar = "🧙",
        rank = SeasonConfig.GetTierDisplayName(pTierIdx, pSubTier, playerData.trophies or 0),
        trophies = playerData.trophies or 0,
        power = calculatePower(playerDeck),
        synergies = getSynergyIcons(playerDeck),
    }

    local oInfo = {
        name = opponentData.name or "对手",
        avatar = "👹",
        rank = SeasonConfig.GetTierDisplayName(oTierIdx, oSubTier, opponentData.trophies or 0),
        trophies = opponentData.trophies or 0,
        power = calculatePower(opponentDeck),
        synergies = getSynergyIcons(opponentDeck),
    }

    -- 2v2模式：队友和敌方2号
    local aInfo = nil
    local o2Info = nil
    if mode == "2v2" then
        local allyDeck = (allyData and allyData.deck) or DeckManager.DEFAULT_AI_DECK
        local opp2Deck = (opponent2Data and opponent2Data.deck) or DeckManager.DEFAULT_AI_DECK
        local aTrophies = (allyData and allyData.trophies) or math.random(80, 180)
        local o2Trophies = (opponent2Data and opponent2Data.trophies) or math.random(80, 180)
        local aTierIdx, aSubTier = SeasonConfig.GetTierByTrophies(aTrophies)
        local o2TierIdx, o2SubTier = SeasonConfig.GetTierByTrophies(o2Trophies)
        aInfo = {
            name = (allyData and allyData.name) or "浮空盟友",
            avatar = "🧝",
            rank = SeasonConfig.GetTierDisplayName(aTierIdx, aSubTier, aTrophies),
            trophies = aTrophies,
            power = calculatePower(allyDeck),
            synergies = getSynergyIcons(allyDeck),
        }
        o2Info = {
            name = (opponent2Data and opponent2Data.name) or "敌方副将",
            avatar = "👺",
            rank = SeasonConfig.GetTierDisplayName(o2TierIdx, o2SubTier, o2Trophies),
            trophies = o2Trophies,
            power = calculatePower(opp2Deck),
            synergies = getSynergyIcons(opp2Deck),
        }
    end

    -- 提示语
    local tips = {
        "合理搭配羁绊可大幅提升战力",
        "每消灭一个敌方单位获得5金币",
        "矿脉是晶核收入的核心来源",
        "城墙可以减缓敌方进攻速度",
        "优先翻开靠近前线的格子",
    }
    local tipText = tips[math.random(1, #tips)]

    -- 标题
    local titleText = mode == "2v2" and "2v2 匹配成功！" or "匹配成功！"

    -- 构建子元素
    ---@type table[]
    local children = {
        -- 标题
        UI.Label {
            text = titleText,
            fontSize = 26,
            fontWeight = "bold",
            fontColor = COLORS.text,
            marginBottom = 15,
        },
    }

    if mode == "2v2" and aInfo and o2Info then
        -- 2v2：4人布局，上方敌方2人，下方我方2人
        -- 敌方区域
        children[#children + 1] = UI.Panel {
            width = "94%",
            flexDirection = "row",
            justifyContent = "space-between",
            children = {
                createPlayerPanel(oInfo, false, true),
                createPlayerPanel(o2Info, false, true),
            }
        }
        -- VS
        children[#children + 1] = UI.Panel {
            marginTop = 10, marginBottom = 10,
            alignItems = "center",
            children = {
                UI.Label {
                    text = "⚡ VS ⚡",
                    fontSize = 28,
                    fontWeight = "bold",
                    fontColor = COLORS.vsGlow,
                },
            }
        }
        -- 我方区域
        children[#children + 1] = UI.Panel {
            width = "94%",
            flexDirection = "row",
            justifyContent = "space-between",
            children = {
                createPlayerPanel(pInfo, true, true),
                createPlayerPanel(aInfo, true, true),
            }
        }
    else
        -- 1v1：原布局
        children[#children + 1] = createPlayerPanel(oInfo, false)
        children[#children + 1] = UI.Panel {
            marginTop = 20, marginBottom = 20,
            alignItems = "center",
            children = {
                UI.Label {
                    text = "⚡ VS ⚡",
                    fontSize = 32,
                    fontWeight = "bold",
                    fontColor = COLORS.vsGlow,
                },
            }
        }
        children[#children + 1] = createPlayerPanel(pInfo, true)
    end

    -- 底部提示
    children[#children + 1] = UI.Panel {
        width = "85%",
        marginTop = 30,
        borderRadius = 8,
        backgroundColor = "#16162E",
        borderWidth = 1,
        borderColor = COLORS.border,
        paddingTop = 10, paddingBottom = 10,
        paddingLeft = 16, paddingRight = 16,
        alignItems = "center",
        children = {
            UI.Label {
                text = "提示",
                fontSize = 12,
                fontWeight = "bold",
                fontColor = COLORS.gold,
            },
            UI.Label {
                text = tipText,
                fontSize = 12,
                fontColor = COLORS.textDim,
                marginTop = 4,
            },
        }
    }

    rootPanel_ = UI.Panel {
        width = "100%", height = "100%",
        position = "absolute",
        top = 0, left = 0,
        backgroundColor = COLORS.bg,
        alignItems = "center",
        justifyContent = "center",
        children = children,
    }

    UI.SetRoot(rootPanel_)
end

--- 每帧更新（需要外部调用）
---@param dt number
function MatchTransitionUI.Update(dt)
    if not rootPanel_ then return end
    timer_ = timer_ + dt
    if timer_ >= duration_ then
        MatchTransitionUI.Hide()
        if onComplete_ then
            onComplete_()
        end
    end
end

--- 隐藏
function MatchTransitionUI.Hide()
    if rootPanel_ then
        UI.SetRoot(nil, true)
        rootPanel_ = nil
    end
end

--- 是否正在显示
function MatchTransitionUI.IsShowing()
    return rootPanel_ ~= nil
end

return MatchTransitionUI


-- ══════════════════════════════════════════════
