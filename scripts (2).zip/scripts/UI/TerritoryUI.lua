-- ============================================================================
-- TerritoryUI.lua - 据点界面（声明式 UI 重写）
-- 4建筑升级/产出收集 + 灵田种植 + 小偷入侵 + 离线收益
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local EventBus = require("Infrastructure.EventBus")
local TerritoryManager = require("Battle.TerritoryManager")
local TerritoryConfig = require("Config.TerritoryConfig")
local PlayerDataManager = require("Data.PlayerDataManager")
local ArtifactUI = require("UI.ArtifactUI")

local TerritoryUI = {}

-- ========== 内部状态 ==========
local wrapper_ = nil
local showCropPicker_ = false
local cropPickerSlot_ = nil

-- ========== 样式常量 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    bgPanel = "#12122A",
    bgCard = "#1A1A3A",
    headerBg = "#16162E",
    gold = "#FFD700",
    text = "#FFFFFF",
    textDim = "#8888AA",
    border = "#2A2A4A",
    green = "#4CAF50",
    blue = "#42A5F5",
    orange = "#FF8A65",
    red = "#FF5252",
    purple = "#AB47BC",
}

-- ========== 单个建筑卡片 ==========
local function createBuildingCard(buildingId, buildingDef)
    local building = TerritoryManager.GetBuilding(buildingId)
    if not building then return UI.Panel {} end

    local level = building.level or 1
    local output = TerritoryManager.GetPendingOutput(buildingId)
    local isMaxLevel = level >= buildingDef.maxLevel
    local upgradeCost = not isMaxLevel and TerritoryConfig.GetUpgradeCost(buildingId, level) or 0

    -- 产出描述
    local outputDesc = ""
    if buildingId == "lingField" then
        local slots = TerritoryManager.GetCropSlots()
        outputDesc = "种植位: " .. slots .. "/" .. buildingDef.maxSlots
    else
        local hourly = TerritoryConfig.GetBuildingOutput(buildingId, level)
        outputDesc = string.format("%.0f %s/时", hourly, buildingDef.resourceName)
    end

    -- 按钮组
    local buttons = {}

    -- 收集按钮（灵田无产出收集）
    if buildingId ~= "lingField" and output > 0 then
        buttons[#buttons + 1] = UI.Button {
            height = 28,
            paddingLeft = 10, paddingRight = 10,
            borderRadius = 14,
            backgroundColor = COLORS.green,
            alignItems = "center",
            justifyContent = "center",
            marginRight = 6,
            onClick = function()
                TerritoryManager.CollectBuildingOutput(buildingId)
                TerritoryUI.Refresh()
            end,
            children = {
                UI.Label { text = "收集 +" .. output, fontSize = 10, fontColor = "#FFFFFF" },
            }
        }
    end

    -- 升级按钮
    if not isMaxLevel then
        buttons[#buttons + 1] = UI.Button {
            height = 28,
            paddingLeft = 10, paddingRight = 10,
            borderRadius = 14,
            backgroundColor = "#3A5A8A",
            alignItems = "center",
            justifyContent = "center",
            onClick = function()
                TerritoryManager.UpgradeBuilding(buildingId)
                TerritoryUI.Refresh()
            end,
            children = {
                UI.Label { text = "升级 🔮" .. upgradeCost, fontSize = 10, fontColor = "#FFFFFF" },
            }
        }
    else
        buttons[#buttons + 1] = UI.Label {
            text = "已满级",
            fontSize = 10,
            fontColor = COLORS.textDim,
        }
    end

    return UI.Panel {
        width = "100%",
        flexDirection = "row",
        alignItems = "center",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 10, paddingBottom = 10,
        marginBottom = 6,
        borderRadius = 10,
        backgroundColor = COLORS.bgCard,
        borderWidth = 1,
        borderColor = COLORS.border,
        children = {
            -- 图标
            UI.Label { text = buildingDef.icon, fontSize = 28 },
            -- 信息列
            UI.Panel {
                marginLeft = 10,
                flexGrow = 1,
                children = {
                    UI.Panel {
                        flexDirection = "row",
                        alignItems = "center",
                        children = {
                            UI.Label {
                                text = buildingDef.name,
                                fontSize = 14,
                                fontColor = COLORS.text,
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = "  Lv." .. level,
                                fontSize = 11,
                                fontColor = COLORS.gold,
                            },
                        }
                    },
                    UI.Label {
                        text = outputDesc,
                        fontSize = 10,
                        fontColor = COLORS.textDim,
                        marginTop = 2,
                    },
                }
            },
            -- 按钮区
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                children = buttons,
            },
        }
    }
end

-- ========== 灵田种植区 ==========
local function createCropSection()
    local slots = TerritoryManager.GetCropSlots()
    local slotWidgets = {}

    for i = 1, slots do
        local cropStatus = TerritoryManager.GetCropStatus(i)
        local slotIndex = i

        if cropStatus then
            -- 有作物
            local cropDef = TerritoryConfig.CROPS[cropStatus.cropId]
            local progressPct = math.floor(cropStatus.progress * 100)
            local statusText = cropStatus.isReady and "可收获!" or (progressPct .. "%")
            local statusColor = cropStatus.isReady and COLORS.gold or COLORS.blue

            slotWidgets[#slotWidgets + 1] = UI.Button {
                width = 72, height = 88,
                borderRadius = 10,
                backgroundColor = cropStatus.isReady and "#2E3D1A" or "#1A1A3A",
                borderWidth = 1,
                borderColor = cropStatus.isReady and COLORS.green or COLORS.border,
                alignItems = "center",
                justifyContent = "center",
                marginRight = 8,
                onClick = function()
                    if cropStatus.isReady then
                        TerritoryManager.HarvestCrop(slotIndex)
                        TerritoryUI.Refresh()
                    end
                end,
                children = {
                    UI.Label { text = cropDef and cropDef.icon or "🌱", fontSize = 24 },
                    UI.Label {
                        text = cropDef and cropDef.name or "",
                        fontSize = 8,
                        fontColor = COLORS.textDim,
                        marginTop = 2,
                    },
                    -- 进度条
                    UI.Panel {
                        width = 52, height = 6,
                        borderRadius = 3,
                        backgroundColor = "#111122",
                        marginTop = 4,
                        overflow = "hidden",
                        children = {
                            UI.Panel {
                                width = progressPct .. "%",
                                height = "100%",
                                borderRadius = 3,
                                backgroundColor = cropStatus.isReady and COLORS.gold or COLORS.green,
                            },
                        }
                    },
                    UI.Label {
                        text = statusText,
                        fontSize = 8,
                        fontColor = statusColor,
                        marginTop = 2,
                    },
                }
            }
        else
            -- 空种植位 — 点击打开种植选择器
            slotWidgets[#slotWidgets + 1] = UI.Button {
                width = 72, height = 88,
                borderRadius = 10,
                backgroundColor = "#1A1A2A",
                borderWidth = 1,
                borderColor = COLORS.border,
                alignItems = "center",
                justifyContent = "center",
                marginRight = 8,
                onClick = function()
                    showCropPicker_ = true
                    cropPickerSlot_ = slotIndex
                    TerritoryUI.Refresh()
                end,
                children = {
                    UI.Label { text = "+", fontSize = 28, fontColor = "#555577" },
                    UI.Label { text = "种植", fontSize = 9, fontColor = "#555577", marginTop = 4 },
                }
            }
        end
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 12, paddingBottom = 8,
        children = {
            UI.Label {
                text = "🌱 灵田种植",
                fontSize = 14,
                fontColor = COLORS.gold,
                fontWeight = "bold",
                marginBottom = 8,
            },
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                flexWrap = "wrap",
                children = slotWidgets,
            },
        }
    }
end

-- ========== 种植选择器弹窗 ==========
local function createCropPicker()
    if not showCropPicker_ then return nil end

    local crops = TerritoryManager.GetAvailableCrops()
    local cropButtons = {}

    for _, crop in ipairs(crops) do
        local cropId = crop.id
        local growMinutes = math.floor(crop.growTime / 60)
        local growText = growMinutes >= 60
            and string.format("%dh", math.floor(growMinutes / 60))
            or string.format("%dm", growMinutes)

        cropButtons[#cropButtons + 1] = UI.Button {
            width = 100, height = 80,
            borderRadius = 10,
            backgroundColor = "#2A2A4A",
            borderWidth = 1,
            borderColor = COLORS.border,
            alignItems = "center",
            justifyContent = "center",
            margin = 6,
            onClick = function()
                TerritoryManager.PlantCrop(cropPickerSlot_, cropId)
                showCropPicker_ = false
                cropPickerSlot_ = nil
                TerritoryUI.Refresh()
            end,
            children = {
                UI.Label { text = crop.icon, fontSize = 24 },
                UI.Label { text = crop.name, fontSize = 10, fontColor = COLORS.text, marginTop = 4 },
                UI.Label { text = growText .. " → " .. crop.reward .. "✨", fontSize = 8, fontColor = COLORS.textDim, marginTop = 2 },
            }
        }
    end

    -- 取消按钮
    cropButtons[#cropButtons + 1] = UI.Button {
        width = 100, height = 80,
        borderRadius = 10,
        backgroundColor = "#3A2A2A",
        borderWidth = 1,
        borderColor = COLORS.red,
        alignItems = "center",
        justifyContent = "center",
        margin = 6,
        onClick = function()
            showCropPicker_ = false
            cropPickerSlot_ = nil
            TerritoryUI.Refresh()
        end,
        children = {
            UI.Label { text = "✕", fontSize = 20, fontColor = COLORS.red },
            UI.Label { text = "取消", fontSize = 10, fontColor = COLORS.red, marginTop = 4 },
        }
    }

    return UI.Panel {
        width = "100%",
        height = "100%",
        position = "absolute",
        left = 0, top = 0,
        backgroundColor = { 0, 0, 0, 180 },
        alignItems = "center",
        justifyContent = "center",
        children = {
            UI.Panel {
                width = 280,
                borderRadius = 16,
                backgroundColor = COLORS.bgPanel,
                borderWidth = 2,
                borderColor = COLORS.gold,
                paddingTop = 16, paddingBottom = 16,
                paddingLeft = 12, paddingRight = 12,
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "选择种植作物",
                        fontSize = 16,
                        fontColor = COLORS.gold,
                        fontWeight = "bold",
                        marginBottom = 12,
                    },
                    UI.Panel {
                        width = "100%",
                        flexDirection = "row",
                        flexWrap = "wrap",
                        justifyContent = "center",
                        children = cropButtons,
                    },
                }
            },
        }
    }
end

-- ========== 小偷入侵警告 ==========
local function createThiefWarning()
    local thiefState = TerritoryManager.GetThiefState()
    if not thiefState.isThiefActive then return nil end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 8, paddingBottom = 8,
        children = {
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                alignItems = "center",
                borderRadius = 10,
                backgroundColor = "#3A1A1A",
                borderWidth = 1,
                borderColor = COLORS.red,
                paddingLeft = 12, paddingRight = 12,
                paddingTop = 10, paddingBottom = 10,
                children = {
                    UI.Label { text = "⚠️", fontSize = 20 },
                    UI.Panel {
                        marginLeft = 10,
                        flexGrow = 1,
                        children = {
                            UI.Label {
                                text = "小偷入侵！",
                                fontSize = 14,
                                fontColor = COLORS.red,
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = "快去击退小偷保护矿脉！",
                                fontSize = 10,
                                fontColor = COLORS.orange,
                                marginTop = 2,
                            },
                        }
                    },
                    UI.Button {
                        height = 32,
                        paddingLeft = 14, paddingRight = 14,
                        borderRadius = 16,
                        backgroundColor = COLORS.red,
                        alignItems = "center",
                        justifyContent = "center",
                        onClick = function()
                            TerritoryManager.DefeatThief()
                            TerritoryUI.Refresh()
                        end,
                        children = {
                            UI.Label { text = "击退!", fontSize = 12, fontColor = "#FFFFFF", fontWeight = "bold" },
                        }
                    },
                }
            },
        }
    }
end

-- ========== 离线奖励提示 ==========
local function createOfflineRewardsBanner()
    local offRewards = TerritoryManager.GetOfflineRewards()
    if not offRewards then return nil end
    local hasRewards = (offRewards.materials or 0) > 0
        or (offRewards.runes or 0) > 0
        or (offRewards.spiritStones or 0) > 0
    if not hasRewards then return nil end

    local rewardText = ""
    if (offRewards.materials or 0) > 0 then
        rewardText = rewardText .. "🔮铸材×" .. offRewards.materials .. "  "
    end
    if (offRewards.spiritStones or 0) > 0 then
        rewardText = rewardText .. "💎晶核×" .. offRewards.spiritStones .. "  "
    end
    if (offRewards.runes or 0) > 0 then
        rewardText = rewardText .. "🔮符文×" .. offRewards.runes
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 8, paddingBottom = 4,
        children = {
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                alignItems = "center",
                borderRadius = 10,
                backgroundColor = "#1A2A1A",
                borderWidth = 1,
                borderColor = COLORS.green,
                paddingLeft = 12, paddingRight = 12,
                paddingTop = 8, paddingBottom = 8,
                children = {
                    UI.Label { text = "🎁", fontSize = 18 },
                    UI.Panel {
                        marginLeft = 8,
                        flexGrow = 1,
                        children = {
                            UI.Label {
                                text = "离线奖励: " .. rewardText,
                                fontSize = 12,
                                fontColor = COLORS.green,
                            },
                        }
                    },
                    UI.Button {
                        height = 28,
                        paddingLeft = 12, paddingRight = 12,
                        borderRadius = 14,
                        backgroundColor = COLORS.green,
                        alignItems = "center",
                        justifyContent = "center",
                        onClick = function()
                            TerritoryManager.ClaimOfflineRewards(false)
                            TerritoryUI.Refresh()
                        end,
                        children = {
                            UI.Label { text = "领取", fontSize = 11, fontColor = "#FFFFFF" },
                        }
                    },
                }
            },
        }
    }
end

-- ========== 神器入口卡片 ==========
local function createArtifactEntry()
    local pd = PlayerDataManager.GetData() or {}
    local artifacts = pd.artifacts or {}
    local equippedCount = 0
    for _, art in pairs(artifacts) do
        if art.equipped then equippedCount = equippedCount + 1 end
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 10, paddingBottom = 4,
        children = {
            UI.Label {
                text = "⚗️ 神器",
                fontSize = 14,
                fontColor = COLORS.gold,
                fontWeight = "bold",
                marginBottom = 8,
            },
            UI.Button {
                width = "100%",
                flexDirection = "row",
                alignItems = "center",
                paddingLeft = 12, paddingRight = 12,
                paddingTop = 12, paddingBottom = 12,
                borderRadius = 10,
                backgroundColor = COLORS.bgCard,
                borderWidth = 1,
                borderColor = COLORS.purple,
                onClick = function()
                    local ShellUI = require("UI.ShellUI")
                    ShellUI.SwitchTab("artifact")
                end,
                children = {
                    UI.Label { text = "🔮", fontSize = 28 },
                    UI.Panel {
                        marginLeft = 10,
                        flexGrow = 1,
                        children = {
                            UI.Label {
                                text = "炼器阁",
                                fontSize = 14,
                                fontColor = COLORS.text,
                                fontWeight = "bold",
                            },
                            UI.Label {
                                text = equippedCount > 0
                                    and ("已装备 " .. equippedCount .. " 件神器")
                                    or "召唤并装备强力神器",
                                fontSize = 10,
                                fontColor = COLORS.textDim,
                                marginTop = 2,
                            },
                        }
                    },
                    UI.Panel {
                        alignItems = "center",
                        justifyContent = "center",
                        children = {
                            UI.Label {
                                text = "进入 →",
                                fontSize = 12,
                                fontColor = COLORS.purple,
                            },
                        }
                    },
                }
            },
        }
    }
end

-- ========== 建筑列表 ==========
local function createBuildingList()
    -- 保证顺序一致
    local orderedIds = { "lingMine", "pillFurnace", "library", "lingField" }
    local cards = {}
    for _, buildingId in ipairs(orderedIds) do
        local buildingDef = TerritoryConfig.BUILDINGS[buildingId]
        if buildingDef then
            cards[#cards + 1] = createBuildingCard(buildingId, buildingDef)
        end
    end

    return UI.Panel {
        width = "100%",
        paddingLeft = 12, paddingRight = 12,
        paddingTop = 8,
        children = {
            UI.Label {
                text = "🏗️ 建筑",
                fontSize = 14,
                fontColor = COLORS.gold,
                fontWeight = "bold",
                marginBottom = 8,
            },
            table.unpack(cards),
        }
    }
end

-- ========== 公共 API ==========

--- 显示据点界面
---@param opts table|nil { onBack: function }
---@return table rootPanel
function TerritoryUI.Show(opts)
    onBack_ = opts and opts.onBack
    showCropPicker_ = false
    cropPickerSlot_ = nil
    TerritoryManager.Init()
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    TerritoryUI.Refresh()
    return wrapper_
end

--- 刷新界面
---@return table rootPanel
function TerritoryUI.Refresh()
    local pd = PlayerDataManager.GetData() or {}
    local materials = pd.materials or 0
    local runes = pd.runes or 0
    local lordLevel = pd.level or 1
    local realm = TerritoryManager.GetLordRealm()

    -- 主内容列表
    local contentChildren = {}

    -- 星阶信息（界面中间上方）
    contentChildren[#contentChildren + 1] = UI.Panel {
        width = "100%",
        height = 44,
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "center",
        alignSelf = "center",
        marginBottom = 12,
        paddingTop = 8, paddingBottom = 4,
        children = {
            UI.Label {
                text = realm.title .. " Lv." .. lordLevel,
                fontSize = 16,
                fontWeight = "bold",
                fontColor = COLORS.gold,
            },
            UI.Label {
                text = "  🔮 " .. tostring(materials),
                fontSize = 14,
                fontColor = "#88FF88",
                marginLeft = 16,
            },
            UI.Label {
                text = "  🔮符文 " .. tostring(runes),
                fontSize = 12,
                fontColor = COLORS.purple,
                marginLeft = 12,
            },
        }
    }

    -- 离线奖励
    local offBanner = createOfflineRewardsBanner()
    if offBanner then contentChildren[#contentChildren + 1] = offBanner end

    -- 小偷警告
    local thiefW = createThiefWarning()
    if thiefW then contentChildren[#contentChildren + 1] = thiefW end

    -- 建筑列表
    contentChildren[#contentChildren + 1] = createBuildingList()

    -- 神器入口
    contentChildren[#contentChildren + 1] = createArtifactEntry()

    -- 灵田
    contentChildren[#contentChildren + 1] = createCropSection()

    -- 底部间距
    contentChildren[#contentChildren + 1] = UI.Panel { height = 20 }

    -- 种植选择器浮层
    local picker = createCropPicker()

    -- 主面板
    local mainChildren = {
        UI.ScrollView {
            width = "100%",
            flexGrow = 1,
            flexShrink = 1,
            children = contentChildren,
        },
    }

    if picker then
        mainChildren[#mainChildren + 1] = picker
    end

    local content = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = COLORS.bgDark,
        paddingTop = 12,
        children = mainChildren,
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 隐藏据点界面
function TerritoryUI.Hide()
    wrapper_ = nil
end

--- 是否正在显示
---@return boolean
function TerritoryUI.IsShowing()
    return wrapper_ ~= nil
end

return TerritoryUI
