-- ══════════════════════════════════════════════
-- ============================================================================
-- RankUI.lua - 排行榜界面
-- 显示全服奖杯排行 + 玩家自身排名
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local PlayerDataManager = require("Data.PlayerDataManager")
local SeasonConfig = require("Config.SeasonConfig")
local PowerCalculator = require("Config.PowerCalculator")

local RankUI = {}

-- ========== 常量 ==========
local COLORS = {
    bgDark = "#0A0A1E",
    headerBg = "#16162E",
    cardBg = "#1A1A3A",
    gold = "#FFD700",
    silver = "#C0C0C0",
    bronze = "#CD7F32",
    text = "#FFFFFF",
    textDim = "#8888AA",
    border = "#2A2A4A",
    highlight = "#2A3A5A",
}

-- 排行榜数据（从云端加载）
local leaderboardData_ = {}
local loadingState_ = "idle"  -- "idle"|"loading"|"loaded"|"error"

-- ========== 内部状态 ==========
local wrapper_ = nil

-- ========== UI 构建 ==========

--- 创建玩家自身排名卡片
local function createMyRankCard()
    local pdata = PlayerDataManager.GetData()
    local myTrophies = pdata and pdata.trophies or 0
    local myPower = PowerCalculator.Calculate()

    -- 计算玩家排名（从已加载的排行榜中计算）
    local myRank = 1
    for _, p in ipairs(leaderboardData_) do
        if p.trophies > myTrophies then
            myRank = myRank + 1
        end
    end

    local tierIndex, subTier = SeasonConfig.GetTierByTrophies(myTrophies)

    return UI.Panel {
        width = "92%",
        height = 70,
        marginTop = 12,
        marginBottom = 12,
        borderRadius = 12,
        backgroundColor = COLORS.highlight,
        borderWidth = 2,
        borderColor = COLORS.gold,
        flexDirection = "row",
        alignItems = "center",
        paddingLeft = 12,
        paddingRight = 12,
        alignSelf = "center",
        children = {
            -- 排名
            UI.Panel {
                width = 36,
                height = 36,
                borderRadius = 18,
                backgroundColor = "#3A3A5A",
                alignItems = "center",
                justifyContent = "center",
                children = {
                    UI.Label {
                        text = "#" .. myRank,
                        fontSize = 12,
                        fontColor = COLORS.gold,
                        fontWeight = "bold",
                    },
                }
            },
            -- 头像
            UI.Panel {
                width = 40,
                height = 40,
                borderRadius = 20,
                backgroundColor = "#2A2A5A",
                borderWidth = 2,
                borderColor = SeasonConfig.GetTierVisual(tierIndex).color,
                alignItems = "center",
                justifyContent = "center",
                marginLeft = 8,
                children = {
                    UI.Label { text = "🧙", fontSize = 20 },
                }
            },
            -- 信息
            UI.Panel {
                marginLeft = 10,
                flexGrow = 1,
                children = {
                    UI.Label {
                        text = pdata and pdata.name or "浮空者",
                        fontSize = 14,
                        fontColor = COLORS.text,
                        fontWeight = "bold",
                    },
                    UI.Panel {
                        flexDirection = "row",
                        alignItems = "center",
                        marginTop = 2,
                        children = {
                            UI.Label {
                                text = SeasonConfig.GetTierIconName(tierIndex, subTier, myTrophies),
                                fontSize = 10,
                                fontColor = SeasonConfig.GetTierVisual(tierIndex).color,
                            },
                            UI.Label {
                                text = "  ⚔" .. myPower,
                                fontSize = 10,
                                fontColor = COLORS.textDim,
                            },
                        }
                    },
                }
            },
            -- 奖杯
            UI.Panel {
                alignItems = "center",
                children = {
                    UI.Label {
                        text = "🏆 " .. myTrophies,
                        fontSize = 14,
                        fontColor = COLORS.gold,
                        fontWeight = "bold",
                    },
                }
            },
        }
    }
end

--- 创建排行榜列表项
local function createRankItem(rank, player)
    local rankColors = {
        [1] = COLORS.gold,
        [2] = COLORS.silver,
        [3] = COLORS.bronze,
    }
    local rankColor = rankColors[rank] or COLORS.textDim
    local bgColor = rank <= 3 and "#1A1A3A" or "#12122A"

    local rTierIdx, rSubTier = SeasonConfig.GetTierByTrophies(player.trophies)

    return UI.Panel {
        width = "100%",
        height = 56,
        flexDirection = "row",
        alignItems = "center",
        backgroundColor = bgColor,
        paddingLeft = 12,
        paddingRight = 12,
        borderBottomWidth = 1,
        borderColor = "#1A1A2E",
        children = {
            -- 排名数字
            UI.Panel {
                width = 30,
                alignItems = "center",
                children = {
                    UI.Label {
                        text = rank <= 3 and ({ "🥇", "🥈", "🥉" })[rank] or tostring(rank),
                        fontSize = rank <= 3 and 18 or 13,
                        fontColor = rankColor,
                        fontWeight = "bold",
                    },
                }
            },
            -- 头像
            UI.Panel {
                width = 36,
                height = 36,
                borderRadius = 18,
                backgroundColor = "#2A2A4A",
                alignItems = "center",
                justifyContent = "center",
                marginLeft = 8,
                children = {
                    UI.Label { text = "👤", fontSize = 16 },
                }
            },
            -- 名称和段位
            UI.Panel {
                marginLeft = 10,
                flexGrow = 1,
                children = {
                    UI.Label {
                        text = player.name,
                        fontSize = 12,
                        fontColor = COLORS.text,
                    },
                    UI.Panel {
                        flexDirection = "row",
                        alignItems = "center",
                        marginTop = 2,
                        children = {
                            UI.Label {
                                text = SeasonConfig.GetTierIconName(rTierIdx, rSubTier, player.trophies) .. " Lv." .. player.level,
                                fontSize = 9,
                                fontColor = COLORS.textDim,
                            },
                            UI.Label {
                                text = "  ⚔" .. (player.power or 0),
                                fontSize = 9,
                                fontColor = COLORS.textDim,
                            },
                        }
                    },
                }
            },
            -- 奖杯
            UI.Label {
                text = "🏆 " .. player.trophies,
                fontSize = 12,
                fontColor = COLORS.gold,
            },
        }
    }
end

--- 创建排行列表
local function createRankList()
    if loadingState_ == "loading" then
        return UI.Panel {
            width = "100%",
            height = 100,
            alignItems = "center",
            justifyContent = "center",
            children = {
                UI.Label { text = "加载中...", fontSize = 14, fontColor = COLORS.textDim },
            }
        }
    end

    if loadingState_ == "error" or #leaderboardData_ == 0 then
        return UI.Panel {
            width = "100%",
            height = 100,
            alignItems = "center",
            justifyContent = "center",
            children = {
                UI.Label {
                    text = loadingState_ == "error" and "加载失败，请稍后重试" or "暂无排行数据",
                    fontSize = 13,
                    fontColor = COLORS.textDim,
                },
            }
        }
    end

    local items = {}
    for i, player in ipairs(leaderboardData_) do
        items[#items + 1] = createRankItem(i, player)
    end

    return UI.Panel {
        width = "100%",
        children = items,
    }
end

--- 从云端加载排行榜数据
local function loadLeaderboard()
    if not clientCloud then
        loadingState_ = "loaded"
        return
    end

    loadingState_ = "loading"
    RankUI.Refresh()

    clientCloud:GetRankList("trophies", 0, 20, {
        ok = function(rankList)
            leaderboardData_ = {}
            local userIds = {}
            for i, item in ipairs(rankList) do
                leaderboardData_[i] = {
                    name = "浮空者#" .. i,
                    trophies = item.iscore and item.iscore.trophies or 0,
                    level = item.iscore and item.iscore.level or 1,
                    power = item.iscore and item.iscore.power or 0,
                    userId = item.userId,
                    isMe = item.userId == clientCloud.userId,
                }
                userIds[#userIds + 1] = item.userId
            end

            -- 查询昵称
            if #userIds > 0 then
                GetUserNickname({
                    userIds = userIds,
                    onSuccess = function(nicknames)
                        local map = {}
                        for _, info in ipairs(nicknames) do
                            map[info.userId] = info.nickname or ""
                        end
                        for _, entry in ipairs(leaderboardData_) do
                            if map[entry.userId] and map[entry.userId] ~= "" then
                                entry.name = map[entry.userId]
                            end
                        end
                        loadingState_ = "loaded"
                        RankUI.Refresh()
                    end,
                    onError = function()
                        loadingState_ = "loaded"
                        RankUI.Refresh()
                    end
                })
            else
                loadingState_ = "loaded"
                RankUI.Refresh()
            end
        end
    }, "level")
end

-- ========== 公共 API ==========

--- 显示排行榜
---@param callbacks table|nil { onBack: function }
function RankUI.Show(callbacks)
    RankUI.UploadScore()
    loadLeaderboard()
    wrapper_ = UI.Panel { width = "100%", height = "100%" }
    RankUI.Refresh()
    return wrapper_
end

--- 刷新排行榜界面
function RankUI.Refresh()
    local content = UI.Panel {
        width = "100%",
        height = "100%",
        backgroundColor = COLORS.bgDark,
        paddingTop = 12,
        children = {
            UI.ScrollView {
                width = "100%",
                flexGrow = 1,
                flexShrink = 1,
                children = {
                    -- 居中标题
                    UI.Panel {
                        width = "100%",
                        height = 40,
                        flexDirection = "row",
                        alignItems = "center",
                        justifyContent = "center",
                        paddingTop = 8,
                        children = {
                            UI.Label {
                                text = "🏆 排行榜",
                                fontSize = 18,
                                fontWeight = "bold",
                                fontColor = COLORS.text,
                            },
                        }
                    },
                    createMyRankCard(),
                    createRankList(),
                }
            },
        }
    }
    if wrapper_ then
        wrapper_:RemoveAllChildren()
        wrapper_:AddChild(content)
    end
end

--- 上报玩家分数到排行榜
function RankUI.UploadScore()
    if not clientCloud then return end
    local pd = PlayerDataManager.GetData()
    if not pd then return end
    clientCloud:Set("trophies", pd.trophies or 0, {
        ok = function() end,
        error = function() end,
    })
    clientCloud:Set("level", pd.level or 1, {
        ok = function() end,
        error = function() end,
    })
    clientCloud:Set("power", PowerCalculator.Calculate(), {
        ok = function() end,
        error = function() end,
    })
    -- 上传当前活跃卡组（供 AI 对手使用）
    local DeckManager = require("Battle.DeckManager")
    local deck = DeckManager.GetPlayerDeckOrDefault()
    local cjson = require("cjson")
    clientCloud:Set("deck", cjson.encode(deck), {
        ok = function() end,
        error = function() end,
    })
end

--- 隐藏
function RankUI.Hide()
    wrapper_ = nil
end

return RankUI


-- ══════════════════════════════════════════════
