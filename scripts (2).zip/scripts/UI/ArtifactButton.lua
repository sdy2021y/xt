-- ============================================================================
-- ArtifactButton.lua - 神器按钮UI（战斗界面右下角）
-- 显示充能进度条 + 神器图标 + 释放按钮
-- ============================================================================
---@diagnostic disable: undefined-global

local EventBus = require("Infrastructure.EventBus")
local ArtifactManager = require("Battle.ArtifactManager")
local ArtifactConfig = require("Config.ArtifactConfig")

local ArtifactButton = {}

-- ========== 内部状态 ==========
local isVisible_ = true
local chargeProgress_ = 0
local isReady_ = false
local chargeStage_ = 0
local cooldownRemaining_ = 0
local artifactName_ = ""
local artifactIcon_ = ""

-- ========== 初始化 ==========

--- 初始化神器按钮
function ArtifactButton.Init()
    -- 注册事件监听
    EventBus.On("ArtifactCharged", ArtifactButton.OnCharged)
    EventBus.On("ArtifactChargeProgress", ArtifactButton.OnProgress)
    EventBus.On("ArtifactReleased", ArtifactButton.OnReleased)

    -- 检查是否装备神器
    if ArtifactManager.HasArtifact() then
        local artifact = ArtifactManager.GetEquipped()
        local def = ArtifactConfig.ARTIFACTS[artifact.name]
        if def then
            artifactName_ = artifact.name
            artifactIcon_ = def.icon
        end
        isVisible_ = true
    else
        isVisible_ = false
        artifactName_ = ""
        artifactIcon_ = ""
    end
end

-- ========== 事件处理 ==========

function ArtifactButton.OnCharged(stage, maxStage)
    chargeStage_ = maxStage
    isReady_ = true
end

function ArtifactButton.OnProgress(progress, tilesFlipped)
    chargeProgress_ = progress
end

function ArtifactButton.OnReleased(data)
    isReady_ = false
    chargeProgress_ = 0
    chargeStage_ = 0
end

-- ========== 渲染 ==========

--- 绘制神器按钮（战斗界面右下角）
---@param x number 按钮中心X
---@param y number 按钮中心Y
---@param size number 按钮尺寸
function ArtifactButton.Render(x, y, size)
    if not isVisible_ then return end

    local radius = size / 2

    -- 背景圆
    local bgColor = isReady_ and 0xFFD700 or 0x444444
    RenderCircle(x, y, radius, bgColor, 0x333333, 2)

    -- 充能进度条（圆弧）
    if not isReady_ and chargeProgress_ > 0 then
        local progressColor = chargeProgress_ >= 1 and 0xFFD700 or 0x00FF88
        RenderArcSegment(x, y, radius + 4, -90, -90 + chargeProgress_ * 360, progressColor, 3)
    end

    -- 神器图标
    if artifactIcon_ ~= "" then
        RenderText(x, y - 4, artifactIcon_, 24, 0xFFFFFF, "center")
    end

    -- 神器名称
    if artifactName_ ~= "" then
        RenderText(x, y + radius + 10, artifactName_, 10, 0xCCCCCC, "center")
    end

    -- 充能阶段指示器
    local stage = ArtifactManager.GetChargeStage()
    if stage > 0 then
        local stageText = ""
        for i = 1, stage do
            stageText = stageText .. "●"
        end
        RenderText(x, y - radius - 8, stageText, 8, 0xFFD700, "center")
    end

    -- 可释放时高亮边框
    if isReady_ then
        local pulse = 0.5 + 0.5 * math.sin(os.clock() * 4)
        local alpha = math.floor(pulse * 255)
        RenderCircle(x, y, radius + 6, 0, alpha << 24 | 0xFFD700, 3)
    end
end

-- ========== 点击检测 ==========

--- 检测点击是否在按钮范围内
---@param px number 点击X
---@param py number 点击Y
---@param bx number 按钮X
---@param by number 按钮Y
---@param bsize number 按钮尺寸
---@return boolean
function ArtifactButton.HitTest(px, py, bx, by, bsize)
    if not isVisible_ then return false end
    local dx = px - bx
    local dy = py - by
    return dx * dx + dy * dy <= (bsize / 2) * (bsize / 2)
end

--- 点击神器按钮
---@return boolean success
function ArtifactButton.OnClick()
    if not isReady_ then return false end
    return ArtifactManager.Release()
end

-- ========== 辅助 ==========

--- 重置状态（新一局战斗）
function ArtifactButton.Reset()
    chargeProgress_ = 0
    isReady_ = false
    chargeStage_ = 0
    cooldownRemaining_ = 0

    if ArtifactManager.HasArtifact() then
        local artifact = ArtifactManager.GetEquipped()
        local def = ArtifactConfig.ARTIFACTS[artifact.name]
        if def then
            artifactName_ = artifact.name
            artifactIcon_ = def.icon
        end
        isVisible_ = true
    else
        isVisible_ = false
    end
end

--- 是否显示神器按钮
---@return boolean
function ArtifactButton.IsVisible()
    return isVisible_
end

return ArtifactButton