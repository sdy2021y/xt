-- ============================================================================
-- ModeSelectUI.lua - 模式选择弹窗
-- 暗色仙侠风，2x2网格布局
-- ============================================================================
---@diagnostic disable: param-type-mismatch

local UI = require("urhox-libs/UI")
local GameConfig = require("Config.GameConfig")

local ModeSelectUI = {}

local COLORS = {
    bgDark = "#0A0A1E",
    bgPanel = "#12122A",
    bgCard = "#1A1A3A",
    gold = "#FFD700",
    text = "#FFFFFF",
    textDim = "#8888AA",
    border = "#2A2A4A",
    btn1v1 = "#FF6D00",
    btn2v2 = "#1565C0",
    btnLocked = "#333344",
}

function ModeSelectUI.Show(onSelect)
    -- onSelect(mode) 回调，mode = "1v1" / "2v2"
    local popup = UI.Panel {
        width = 300,
        borderRadius = 16,
        backgroundColor = COLORS.bgPanel,
        borderWidth = 2,
        borderColor = COLORS.gold,
        alignItems = "center",
        paddingTop = 24,
        paddingBottom = 24,
        paddingLeft = 20,
        paddingRight = 20,
        children = {
            -- 标题
            UI.Label {
                text = "选择模式",
                fontSize = 20,
                fontColor = COLORS.gold,
                fontWeight = "bold",
                marginBottom = 20,
            },
            -- 2x2 网格
            UI.Panel {
                width = "100%",
                flexDirection = "row",
                flexWrap = "wrap",
                justifyContent = "space-between",
                children = {
                    -- 1v1
                    UI.Button {
                        width = "47%",
                        height = 90,
                        borderRadius = 12,
                        backgroundColor = COLORS.btn1v1,
                        borderWidth = 2,
                        borderColor = "#FF9100",
                        alignItems = "center",
                        justifyContent = "center",
                        marginBottom = 10,
                        onClick = function()
                            local ShellUI = require("UI.ShellUI")
                            ShellUI.HideOverlay()
                            if onSelect then onSelect("1v1") end
                        end,
                        children = {
                            UI.Label { text = "⚔️", fontSize = 28 },
                            UI.Label { text = "1v1 斗法", fontSize = 14, fontColor = "#FFFFFF", fontWeight = "bold", marginTop = 4 },
                            UI.Label { text = "180秒", fontSize = 10, fontColor = "#FFE0B2", marginTop = 2 },
                        }
                    },
                    -- 2v2
                    UI.Button {
                        width = "47%",
                        height = 90,
                        borderRadius = 12,
                        backgroundColor = COLORS.btn2v2,
                        borderWidth = 2,
                        borderColor = "#42A5F5",
                        alignItems = "center",
                        justifyContent = "center",
                        marginBottom = 10,
                        onClick = function()
                            local ShellUI = require("UI.ShellUI")
                            ShellUI.HideOverlay()
                            if onSelect then onSelect("2v2") end
                        end,
                        children = {
                            UI.Label { text = "🤝", fontSize = 28 },
                            UI.Label { text = "2v2 组队", fontSize = 14, fontColor = "#FFFFFF", fontWeight = "bold", marginTop = 4 },
                            UI.Label { text = "240秒", fontSize = 10, fontColor = "#BBDEFB", marginTop = 2 },
                        }
                    },
                    -- 3v3 锁定
                    UI.Button {
                        width = "47%",
                        height = 90,
                        borderRadius = 12,
                        backgroundColor = COLORS.btnLocked,
                        borderWidth = 1,
                        borderColor = "#444466",
                        alignItems = "center",
                        justifyContent = "center",
                        onClick = function()
                            UI.Toast.Show("即将开放，敬请期待", { type = "warning", duration = 2 })
                        end,
                        children = {
                            UI.Label { text = "🔒", fontSize = 28 },
                            UI.Label { text = "3v3 乱斗", fontSize = 14, fontColor = "#666688", fontWeight = "bold", marginTop = 4 },
                            UI.Label { text = "即将开放", fontSize = 10, fontColor = "#555577", marginTop = 2 },
                        }
                    },
                    -- Boss 锁定
                    UI.Button {
                        width = "47%",
                        height = 90,
                        borderRadius = 12,
                        backgroundColor = COLORS.btnLocked,
                        borderWidth = 1,
                        borderColor = "#444466",
                        alignItems = "center",
                        justifyContent = "center",
                        onClick = function()
                            UI.Toast.Show("即将开放，敬请期待", { type = "warning", duration = 2 })
                        end,
                        children = {
                            UI.Label { text = "🔒", fontSize = 28 },
                            UI.Label { text = "打BOSS", fontSize = 14, fontColor = "#666688", fontWeight = "bold", marginTop = 4 },
                            UI.Label { text = "即将开放", fontSize = 10, fontColor = "#555577", marginTop = 2 },
                        }
                    },
                }
            },
            -- 关闭按钮
            UI.Button {
                width = 120,
                height = 36,
                borderRadius = 18,
                backgroundColor = "#333355",
                alignItems = "center",
                justifyContent = "center",
                marginTop = 16,
                onClick = function()
                    local ShellUI = require("UI.ShellUI")
                    ShellUI.HideOverlay()
                end,
                children = {
                    UI.Label { text = "取消", fontSize = 14, fontColor = "#AAAACC" },
                }
            },
        }
    }
    local ShellUI = require("UI.ShellUI")
    ShellUI.ShowOverlay(popup)
end

return ModeSelectUI
