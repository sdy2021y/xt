-- ══════════════════════════════════════════════
-- ============================================================================
-- TutorialManager.lua - 新手引导系统
-- 分步骤引导玩家了解核心玩法
-- ============================================================================
---@diagnostic disable: missing-parameter

local UI = require("urhox-libs/UI")
local GameConfig = require("Config.GameConfig")

local TutorialManager = {}

-- 教程步骤定义
local STEPS = {
    {
        id = "welcome",
        title = "欢迎来到仙途",
        text = "占领格子、建造建筑、派兵攻打对方主城！\n率先摧毁敌方主城即可获胜。",
        position = "center",   -- center / top / bottom
        waitAction = "tap",    -- tap = 点击任意处继续
    },
    {
        id = "flip_tile",
        title = "翻开格子",
        text = "点击靠近己方领地的暗色格子，\n花费晶核翻开它，扩张你的领地！",
        position = "center",
        waitAction = "flip",   -- 等待玩家翻开一个格子
    },
    {
        id = "buildings",
        title = "随机建筑",
        text = "翻开格子可能出现矿脉（产晶核）、\n兵营（产兵）或炮台（防守）。",
        position = "center",
        waitAction = "tap",
    },
    {
        id = "units",
        title = "自动出兵",
        text = "兵营会自动生产士兵向敌方推进，\n士兵遇敌自动战斗。",
        position = "center",
        waitAction = "tap",
    },
    {
        id = "goal",
        title = "胜利条件",
        text = "摧毁敌方主城 或 时间结束时\n占领更多领地即可获胜。开战吧！",
        position = "center",
        waitAction = "tap",
    },
}

-- 状态
local currentStep_ = 0        -- 0 = 教程未开始或已完成
local isActive_ = false
local overlay_ = nil          -- UI overlay 引用
local onComplete_ = nil       -- 完成回调

-- 存档 key（是否已看过教程）
local SAVE_KEY = "tutorial_done"

--- 检查是否需要显示教程（第一次游戏时显示）
---@return boolean
function TutorialManager.ShouldShow()
    if not clientCloud then return true end
    local done = clientCloud:Get(SAVE_KEY)
    return done ~= "1"
end

--- 开始教程
---@param completeCallback function|nil 教程完成时的回调
function TutorialManager.Start(completeCallback)
    onComplete_ = completeCallback
    isActive_ = true
    currentStep_ = 1
    TutorialManager.ShowStep()
end

--- 跳过教程
function TutorialManager.Skip()
    isActive_ = false
    currentStep_ = 0
    if clientCloud then
        clientCloud:Set(SAVE_KEY, "1", {
            ok = function() end,
            error = function(err) print("[Tutorial] Save error: " .. tostring(err)) end
        })
    end
    if overlay_ then
        overlay_:SetVisible(false)
    end
    if onComplete_ then
        onComplete_()
    end
end

--- 是否正在进行教程
---@return boolean
function TutorialManager.IsActive()
    return isActive_
end

--- 获取当前步骤ID（供外部判断）
---@return string|nil
function TutorialManager.GetCurrentStepId()
    if not isActive_ or currentStep_ < 1 or currentStep_ > #STEPS then
        return nil
    end
    return STEPS[currentStep_].id
end

--- 通知教程系统：玩家完成了某个动作
---@param action string 动作类型 "flip" / "tap" / "skill"
function TutorialManager.NotifyAction(action)
    if not isActive_ then return end
    if currentStep_ < 1 or currentStep_ > #STEPS then return end

    local step = STEPS[currentStep_]
    if step.waitAction == action or (step.waitAction == "tap" and action == "tap") then
        TutorialManager.NextStep()
    end
end

--- 前进到下一步
function TutorialManager.NextStep()
    currentStep_ = currentStep_ + 1
    if currentStep_ > #STEPS then
        -- 教程完成
        TutorialManager.Complete()
    else
        TutorialManager.ShowStep()
    end
end

--- 完成教程
function TutorialManager.Complete()
    isActive_ = false
    currentStep_ = 0
    if clientCloud then
        clientCloud:Set(SAVE_KEY, "1", {
            ok = function() end,
            error = function(err) print("[Tutorial] Save error: " .. tostring(err)) end
        })
    end
    if overlay_ then
        overlay_:SetVisible(false)
    end
    if onComplete_ then
        onComplete_()
    end
end

--- 显示当前步骤的 UI
function TutorialManager.ShowStep()
    if currentStep_ < 1 or currentStep_ > #STEPS then return end
    local step = STEPS[currentStep_]

    if overlay_ then
        -- 更新已有 overlay 内容
        local titleLabel = overlay_:FindById("tutTitle")
        local textLabel = overlay_:FindById("tutText")
        local hintLabel = overlay_:FindById("tutHint")
        local stepLabel = overlay_:FindById("tutStep")

        if titleLabel then titleLabel:SetText(step.title) end
        if textLabel then textLabel:SetText(step.text) end
        if stepLabel then stepLabel:SetText(currentStep_ .. "/" .. #STEPS) end

        -- 更新提示文字
        if hintLabel then
            if step.waitAction == "flip" then
                hintLabel:SetText("请翻开一个格子继续")
            else
                hintLabel:SetText("点击任意处继续")
            end
        end

        overlay_:SetVisible(true)
    end
end

--- 创建教程 UI overlay（在 CreateUI 时调用一次）
---@return table UI.Panel
function TutorialManager.CreateOverlay()
    local step = STEPS[1] or { title = "", text = "" }

    overlay_ = UI.Panel {
        id = "tutorialOverlay",
        width = "100%",
        height = "100%",
        position = "absolute",
        top = 0, left = 0,
        justifyContent = "center",
        alignItems = "center",
        backgroundColor = "#00000088",
        children = {
            -- 教程卡片
            UI.Panel {
                id = "tutCard",
                width = 300,
                minHeight = 180,
                backgroundColor = "#1a1e2eF0",
                borderRadius = 16,
                borderWidth = 2,
                borderColor = "#6688ccAA",
                paddingTop = 20,
                paddingBottom = 20,
                paddingLeft = 24,
                paddingRight = 24,
                alignItems = "center",
                justifyContent = "center",
                children = {
                    -- 步骤指示器
                    UI.Label {
                        id = "tutStep",
                        text = "1/" .. #STEPS,
                        fontSize = 12,
                        fontColor = { 136, 170, 204, 255 },
                        marginBottom = 8,
                    },
                    -- 标题
                    UI.Label {
                        id = "tutTitle",
                        text = step.title,
                        fontSize = 20,
                        fontWeight = "bold",
                        fontColor = { 255, 216, 102, 255 },
                        marginBottom = 12,
                        textAlign = "center",
                    },
                    -- 正文
                    UI.Label {
                        id = "tutText",
                        text = step.text,
                        fontSize = 14,
                        fontColor = { 221, 238, 255, 255 },
                        textAlign = "center",
                        marginBottom = 16,
                        lineHeight = 1.5,
                    },
                    -- 操作提示
                    UI.Label {
                        id = "tutHint",
                        text = "点击任意处继续",
                        fontSize = 12,
                        fontColor = { 136, 204, 170, 255 },
                        marginBottom = 8,
                    },
                    -- 跳过按钮
                    UI.Button {
                        text = "跳过教程",
                        variant = "text",
                        fontSize = 12,
                        fontColor = { 102, 102, 136, 255 },
                        marginTop = 4,
                        onClick = function()
                            TutorialManager.Skip()
                        end,
                    },
                }
            }
        }
    }

    return overlay_
end

--- 处理教程 overlay 点击（在 tap 时调用）
---@return boolean true 如果教程消费了这次点击
function TutorialManager.HandleTap()
    if not isActive_ then return false end
    if currentStep_ < 1 or currentStep_ > #STEPS then return false end

    local step = STEPS[currentStep_]
    if step.waitAction == "tap" then
        TutorialManager.NextStep()
        return true  -- 消费点击
    end

    -- waitAction 是 "flip"，不消费点击（让玩家翻格子）
    -- 但隐藏 overlay 让玩家能看到格子
    if overlay_ then
        overlay_:SetVisible(false)
    end
    return false
end

return TutorialManager
