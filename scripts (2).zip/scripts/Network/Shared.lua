-- ============================================================================
-- Shared.lua - 共享常量、事件名、序列化工具
-- 服务端和客户端共用
-- 格子模型：team(归属) + flipped(已翻) + ruins(残骸)，无 state 枚举
-- ============================================================================

local Shared = {}

local HexGrid = require("Battle.HexGrid")
local GameConfig = require("Config.GameConfig")

-- 战斗阶段
Shared.BATTLE_PHASE = {
    WAITING = 0,     -- 等待开始
    PLAYING = 1,     -- 战斗中
    ENDED = 2,       -- 已结束
}

--- 检查某格子是否相邻己方至少一个已翻格（用于判断可翻/标签显示，空地也算）
---@param q integer
---@param r integer
---@param team integer
---@param tileStates table
---@return boolean
function Shared.IsAdjacentToFlipped(q, r, team, tileStates)
    local neighbors = HexGrid.Neighbors({ q = q, r = r })
    for _, nh in ipairs(neighbors) do
        local nKey = HexGrid.Key(nh.q, nh.r)
        local nTile = tileStates[nKey]
        -- 己方 + 已翻开即可作为扩展源（空地也允许继续翻）
        if nTile and nTile.team == team and nTile.flipped then
            return true
        end
    end
    return false
end

--- 2v2模式：检查是否相邻自己slot的已翻格子（排除盟友的，空地也算）
---@param q integer
---@param r integer
---@param team integer
---@param slot integer
---@param tileStates table
---@return boolean
function Shared.IsAdjacentToFlippedWithSlot(q, r, team, slot, tileStates)
    local neighbors = HexGrid.Neighbors({ q = q, r = r })
    for _, nh in ipairs(neighbors) do
        local nKey = HexGrid.Key(nh.q, nh.r)
        local nTile = tileStates[nKey]
        -- 己方 + 已翻开 + 同slot即可作为扩展源
        if nTile and nTile.team == team and nTile.flipped then
            local tileSlot = nTile.slot or ((team == 1) and 1 or 3)
            if tileSlot == slot then
                return true
            end
        end
    end
    return false
end

-- ============================================================================
-- 事件名定义（Server→Client 下行 + Client→Server 上行）
-- ============================================================================

-- 下行：玩家加入时 — Server→单个Client
Shared.EVENT = {
    -- 玩家分配到 slot/team
    PLAYER_ASSIGNED = "PlayerAssigned",

    -- 地图初始化 — Server→所有Client（仅战斗开始时发1次）
    MAP_INIT = "MapInit",

    -- 战斗状态增量同步 — Server→所有Client（每100ms）
    BATTLE_SYNC = "BattleSync",

    -- 翻格结果 — Server→所有Client（事件驱动）
    TILE_FLIPPED = "TileFlipped",

    -- 翻格请求 — Client→Server
    FLIP_TILE = "FlipTile",

    -- 格子被攻击/摧毁
    TILE_DAMAGED = "TileDamaged",
    TILE_DESTROYED = "TileDestroyed",

    -- 战斗结束
    BATTLE_OVER = "BattleEnd",

    -- 单位生成
    UNIT_SPAWNED = "UnitSpawned",

    -- 单位死亡
    UNIT_DIED = "UnitDied",
}

-- ============================================================================
-- 序列化/反序列化工具
-- ============================================================================

--- 序列化 tileStates 的全量数据（用于 MapInit）
---@param tileStates table
---@return string JSON
function Shared.SerializeMap(tileStates)
    local data = {}
    for key, tile in pairs(tileStates) do
        data[key] = {
            team = tile.team or 0,
            building = tile.building or 0,
            tileType = tile.tileType or "empty",
            price = tile.price or 0,
            flipped = tile.flipped or false,
            ruins = tile.ruins or false,
            slot = tile.slot,
        }
    end
    return require("cjson").encode(data)
end

--- 反序列化 MapInit 数据
---@param jsonStr string
---@return table
function Shared.DeserializeMap(jsonStr)
    return require("cjson").decode(jsonStr)
end

--- 序列化出生点数据
---@param spawns table
---@return string JSON
function Shared.SerializeSpawns(spawns)
    return require("cjson").encode(spawns)
end

--- 反序列化出生点数据
---@param jsonStr string
---@return table
function Shared.DeserializeSpawns(jsonStr)
    return require("cjson").decode(jsonStr)
end

--- 序列化单位状态
---@param units table
---@return string JSON
function Shared.SerializeUnits(units)
    local data = {}
    for i, unit in ipairs(units) do
        data[i] = {
            id = unit.id,
            owner = unit.owner,
            team = unit.team or unit.owner,
            slot = unit.slot,
            q = unit.q,
            r = unit.r,
            hp = unit.hp,
            maxHp = unit.maxHp,
            state = unit.state,
            cardName = unit.cardName,
            cardLevel = unit.cardLevel,
            quality = unit.quality,
            baseAtk = unit.baseAtk,
            baseSpd = unit.baseSpd,
            attack = unit.attack,
            range = unit.range,
            moveSpeed = unit.moveSpeed,
            spawnQ = unit.spawnQ,
            spawnR = unit.spawnR,
        }
    end
    return require("cjson").encode(data)
end

--- 序列化建筑状态
---@param buildings table
---@return string JSON
function Shared.SerializeBuildings(buildings)
    local data = {}
    for key, b in pairs(buildings) do
        data[key] = {
            type = b.building,
            owner = b.owner,
            team = b.team or b.owner,
            slot = b.slot,
            hp = b.hp,
            maxHp = b.maxHp,
            spiritTimer = b.spiritTimer,
            spawnTimer = b.spawnTimer,
            attackTimer = b.attackTimer,
            barracksPrice = b.barracksPrice,
            fixedQuality = b.fixedQuality,
        }
    end
    return require("cjson").encode(data)
end

--- 序列化资源状态
---@param resources table
---@return string JSON
function Shared.SerializeResources(resources)
    return require("cjson").encode(resources)
end

--- 注册远程事件（客户端需要监听的事件）
function Shared.RegisterRemoteEvents()
    network:RegisterRemoteEvent(Shared.EVENT.PLAYER_ASSIGNED)
    network:RegisterRemoteEvent(Shared.EVENT.MAP_INIT)
    network:RegisterRemoteEvent(Shared.EVENT.BATTLE_SYNC)
    network:RegisterRemoteEvent(Shared.EVENT.TILE_FLIPPED)
    network:RegisterRemoteEvent(Shared.EVENT.BATTLE_OVER)

    SubscribeToEvent(Shared.EVENT.PLAYER_ASSIGNED, "ClientHandlePlayerAssigned")
    SubscribeToEvent(Shared.EVENT.MAP_INIT, "ClientHandleMapInit")
    SubscribeToEvent(Shared.EVENT.BATTLE_SYNC, "ClientHandleBattleSync")
    SubscribeToEvent(Shared.EVENT.TILE_FLIPPED, "ClientHandleTileFlipped")
    SubscribeToEvent(Shared.EVENT.BATTLE_OVER, "ClientHandleBattleOver")
end

--- 格式化秒数为 m:ss
---@param seconds number
---@return string
function Shared.FormatTime(seconds)
    local m = math.floor(seconds / 60)
    local s = math.floor(seconds % 60)
    return string.format("%d:%02d", m, s)
end

return Shared
