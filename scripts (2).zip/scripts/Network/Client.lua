-- ══════════════════════════════════════════════
-- ============================================================================
-- Client.lua - 客户端游戏逻辑
-- 核心玩法：翻格子→消耗晶核→随机获得建筑→自动出兵→占地
-- ============================================================================

local UI = require("urhox-libs/UI")
local GameConfig = require("Config.GameConfig")
local TileConfig = require("Config.TileConfig")
local Shared = require("Network.Shared")
local HexGrid = require("Battle.HexGrid")
local HexRenderer = require("Render.HexRenderer")
local BattleHUD = require("UI.BattleHUD")
local BuildingManager = require("Battle.BuildingManager")
local UnitManager = require("Battle.UnitManager")
local UnitConfig = require("Config.UnitConfig")
local DeckManager = require("Battle.DeckManager")
local SynergyManager = require("Battle.SynergyManager")
local AIOpponent = require("Battle.AIOpponent")
local WallManager = require("Battle.WallManager")
local SoundManager = require("Audio.SoundManager")
local TutorialManager = require("UI.TutorialManager")
local DeckBuilderUI = require("UI.DeckBuilderUI")
local ShellUI = require("UI.ShellUI")
local MatchTransitionUI = require("UI.MatchTransitionUI")
local BattleResultUI = require("UI.BattleResultUI")
local ChestManager = require("Battle.ChestManager")
local PlayerDataManager = require("Data.PlayerDataManager")
local QuestManager = require("Data.QuestManager")
local SeasonConfig = require("Config.SeasonConfig")
local ArtifactManager = require("Battle.ArtifactManager")
local SeasonManager = require("Systems.SeasonManager")
local AdManager = require("Systems.AdManager")
local EventBus = require("Infrastructure.EventBus")
local SkillEngine = require("Battle.SkillEngine")
local ViewTransform = require("Render.ViewTransform")

local Client = {}

-- 游戏阶段：home → deck_building → match_transition → battle → result
local gamePhase_ = "home"

-- 客户端状态
local screenW_ = 0
local screenH_ = 0
local dpr_ = 1.0

-- 战斗状态
local battleTimer_ = GameConfig.BATTLE_DURATION_DEFAULT or 180
local battlePhase_ = Shared.BATTLE_PHASE.WAITING  -- 战斗还没开始，等 StartBattle 后切换
local spiritStones_ = GameConfig.STARTING_SPIRIT_STONES
local population_ = 0
local territoryP1_ = 1
local territoryP2_ = 1
local materials_ = 0     -- 铸材（摧毁敌方建筑获得，战后带出）

-- 格子数据
local gridHexes_ = {}    -- 所有 hex 坐标
local minQ_, maxQ_, minR_, maxR_ = 0, 0, 0, 0  -- 地图实际范围缓存
local tileStates_ = {}   -- { [key] = { team, building, tileType, price, flipped, ruins } }
local highlightHex_ = nil

-- 战斗系统
local buildings_ = {}    -- { [hexKey] = buildingInstance }
local units_ = {}        -- { unit, unit, ... }
local targetHexes_ = {}  -- { [owner] = {q, r} } 各方核心坐标

-- 残骸系统：{ [hexKey] = { ruinTimer = number, owner = number } }
local ruins_ = {}
local RUIN_DURATION = 8.0  -- 8秒残骸期

-- 游戏画布 NanoVG 上下文
---@type userdata
local vg_ = nil
local logicalW_ = 0
local logicalH_ = 0

-- 结算状态
local resultShown_ = false

-- 提示消息
local toastMsg_ = ""
local toastTimer_ = 0

-- 视觉特效队列
local effects_ = {}  -- { {type, x, y, timer, duration, ...}, ... }
-- 缓存hex半径（用于特效渲染）
local hexRadius_ = GameConfig.HEX.RADIUS

-- 音频场景（模块级变量防止 GC 回收）
local audioScene_ = nil

-- 拖动平移状态
local dragActive_ = false         -- 是否正在拖动
local dragStartX_ = 0             -- 拖动起始位置
local dragStartY_ = 0
local dragTotalDist_ = 0          -- 总移动距离（用于区分点击和拖动）
local DRAG_THRESHOLD = 8          -- 拖动阈值（超过则不触发点击）

-- AI 对手卡组缓存（从云端获取的同段位玩家卡组，nil 则用默认卡组）
local aiOpponentDeck_ = nil

-- 本地队伍编号（单机模式默认1，联机由 PlayerAssigned 设置）
local localTeam_ = 1
-- 本地槽位编号（2v2区分同队玩家：玩家=1，盟友AI=2，敌方AI=3/4）
local localSlot_ = 1

-- 当前对战模式
local currentMode_ = "1v1"

-- 2v2 模式玩家信息（传给 HUD 显示）
local playersInfo2v2_ = nil  -- { ally={name,trophies}, enemy1={name,trophies}, enemy2={name,trophies} }

-- 联机模式标记（true=联机，由Server权威运行战斗逻辑；false=单机，本地运行Server）
local isOnlineMode_ = false

-- 匹配倒计时
local matchCountdownTimer_ = 0
local matchCountdownActive_ = false
local matchCountdownCallback_ = nil

-- ============================================================================
-- 生命周期
-- ============================================================================

function Client.Start()
    screenW_ = graphics:GetWidth()
    screenH_ = graphics:GetHeight()
    dpr_ = graphics:GetDPR()
    logicalW_ = screenW_ / dpr_
    logicalH_ = screenH_ / dpr_

    -- 1. 创建游戏画布 NanoVG 上下文
    vg_ = nvgCreate(1)
    nvgSetRenderOrder(vg_, 100)
    nvgCreateFont(vg_, "sans", "Fonts/MiSans-Regular.ttf")

    -- 2. 初始化 UI 系统
    UI.Init({
        fonts = {
            { family = "sans", weights = {
                normal = "Fonts/MiSans-Regular.ttf",
            } }
        },
        scale = UI.Scale.DEFAULT,
    })

    -- 注册远程事件
    Shared.RegisterRemoteEvents()

    -- 初始化音频系统（模块级变量防止 GC）
    if not audioScene_ then
        audioScene_ = Scene()
        SoundManager.Init(audioScene_)
    end

    -- 订阅事件（始终注册，按阶段分发）
    SubscribeToEvent("Update", "ClientHandleUpdate")
    SubscribeToEvent(vg_, "NanoVGRender", "ClientHandleNanoVGRender")
    SubscribeToEvent("MouseButtonDown", "ClientHandleMouseDown")
    SubscribeToEvent("MouseMove", "ClientHandleMouseMove")
    SubscribeToEvent("MouseButtonUp", "ClientHandleMouseUp")
    SubscribeToEvent("TouchBegin", "ClientHandleTouchBegin")
    SubscribeToEvent("TouchMove", "ClientHandleTouchMove")
    SubscribeToEvent("TouchEnd", "ClientHandleTouchEnd")
    SubscribeToEvent("MultiGesture", "ClientHandleMultiGesture")

    -- 新玩家首次进入：自动绑定默认卡组（仅首次，不覆盖已保存配置）
    if not DeckManager.GetSavedDeck() then
        print("[Client] First-time player, auto-binding default deck")
        DeckManager.SavePlayerDeck(DeckManager.DEFAULT_PLAYER_DECK, 1)
    end

    -- 显示主界面
    gamePhase_ = "home"
    Client.ShowHome()
end

function Client.Stop()
    UI.Shutdown()
    if vg_ then
        nvgDelete(vg_)
        vg_ = nil
    end
end

-- ============================================================================
-- 主界面
-- ============================================================================

--- 显示主界面（竞技场首页，含常驻底部导航栏）
function Client.ShowHome()
    gamePhase_ = "home"
    ShellUI.Init({
        onBattle = function(mode)
            -- 开战前校验卡组
            local deck = DeckManager.GetSavedDeck()
            if not deck then
                UI.Toast.Show("请先配置卡组", { type = "warning", duration = 2.5 })
                ShellUI.SwitchTab("cards")
                return
            end
            local valid, err = DeckManager.ValidateDeck(deck)
            if not valid then
                UI.Toast.Show(err or "卡组不合法", { type = "warning", duration = 2.5 })
                ShellUI.SwitchTab("cards")
                return
            end
            Client.ShowMatchTransition(deck, mode)
        end,
        onCards = function()
            ShellUI.SwitchTab("cards")
        end,
    })
end

--- 显示匹配过渡页（VS展示），结束后自动开始战斗
--- 匹配流程：
---   1. 8秒内尝试匹配在线真实玩家（实时对战）
---   2. 提前匹配到 → 立即进入VS页面，标记为真实玩家
---   3. 8秒超时 → 第9秒用同段位玩家卡组的AI替代
---   1v1/2v2 皆适用，2v2可能是4位真实玩家，也可能是1玩家+3AI
---@param deck table 玩家卡组
---@param mode string 游戏模式 "1v1"/"2v2"
function Client.ShowMatchTransition(deck, mode)
    gamePhase_ = "match_transition"
    aiOpponentDeck_ = nil  -- 重置缓存

    -- 立即显示匹配等待界面
    MatchTransitionUI.ShowWaiting(mode, function()
        -- 取消匹配 → 回到首页
        matchCountdownActive_ = false
        matchCountdownCallback_ = nil
        Client.ShowHome()
    end)

    local pd = PlayerDataManager.GetData() or {}
    local playerTrophies = pd.trophies or 0
    local playerData = {
        name = pd.playerName or "修炼者",
        trophies = playerTrophies,
        deck = deck,
    }

    -- 匹配结果缓存（isRealPlayer 标记是否为真实在线玩家）
    local matchResult = {
        -- 对手1
        opponentName = nil,
        opponentTrophies = nil,
        opponentDeck = nil,
        opponentIsReal = false,
        -- 队友（2v2）
        allyName = nil,
        allyTrophies = nil,
        allyDeck = nil,
        allyIsReal = false,
        -- 敌方2号（2v2）
        opp2Name = nil,
        opp2Trophies = nil,
        opp2Deck = nil,
        opp2IsReal = false,
        -- 是否已收到云端响应
        cloudResponded = false,
    }

    --- 尝试从云端匹配正在匹配中的同段位在线玩家
    --- 匹配到的是真实玩家，将进行实时对战（非AI代打）
    local function tryMatchOnlinePlayers()
        if not clientCloud then
            matchResult.cloudResponded = true
            return
        end
        pcall(function()
            clientCloud:GetRankList("trophies", 0, 50, {
                ok = function(rankList)
                    matchResult.cloudResponded = true
                    if not rankList or #rankList == 0 then return end

                    -- 筛选同段位范围内的在线玩家（奖杯 ±300）
                    local candidates = {}
                    for _, item in ipairs(rankList) do
                        local t = item.iscore and item.iscore.trophies or 0
                        if math.abs(t - playerTrophies) <= 300
                            and item.userId ~= clientCloud.userId then
                            candidates[#candidates + 1] = item
                        end
                    end

                    if #candidates == 0 then return end

                    -- 1v1：选1个对手；2v2：选3个（1队友+2敌人）
                    local needed = (mode == "2v2") and 3 or 1
                    local chosen = {}
                    local indices = {}
                    for i = 1, #candidates do indices[i] = i end
                    -- Fisher-Yates 洗牌
                    for i = #indices, 2, -1 do
                        local j = math.random(1, i)
                        indices[i], indices[j] = indices[j], indices[i]
                    end
                    for i = 1, math.min(needed, #indices) do
                        chosen[#chosen + 1] = candidates[indices[i]]
                    end

                    -- 解析对手1（真实在线玩家）
                    if chosen[1] then
                        matchResult.opponentIsReal = true
                        local deckJson = chosen[1].iscore and chosen[1].iscore.deck
                        if deckJson and type(deckJson) == "string" and deckJson ~= "" then
                            local cjson = require("cjson")
                            local ok, parsed = pcall(cjson.decode, deckJson)
                            if ok and parsed and type(parsed) == "table" and #parsed >= 8 then
                                matchResult.opponentDeck = parsed
                            end
                        end
                        matchResult.opponentTrophies = chosen[1].iscore and chosen[1].iscore.trophies
                        if chosen[1].userId then
                            pcall(function()
                                GetUserNickname({
                                    userIds = { chosen[1].userId },
                                    onSuccess = function(nicknames)
                                        if nicknames and nicknames[1] and nicknames[1].nickname ~= "" then
                                            matchResult.opponentName = nicknames[1].nickname
                                        end
                                    end,
                                    onError = function() end,
                                })
                            end)
                        end
                    end

                    -- 2v2：解析队友和敌方2号（真实在线玩家）
                    if mode == "2v2" then
                        if chosen[2] then
                            matchResult.allyIsReal = true
                            local deckJson = chosen[2].iscore and chosen[2].iscore.deck
                            if deckJson and type(deckJson) == "string" and deckJson ~= "" then
                                local cjson = require("cjson")
                                local ok, parsed = pcall(cjson.decode, deckJson)
                                if ok and parsed and type(parsed) == "table" and #parsed >= 8 then
                                    matchResult.allyDeck = parsed
                                end
                            end
                            matchResult.allyTrophies = chosen[2].iscore and chosen[2].iscore.trophies
                            if chosen[2].userId then
                                pcall(function()
                                    GetUserNickname({
                                        userIds = { chosen[2].userId },
                                        onSuccess = function(nicknames)
                                            if nicknames and nicknames[1] and nicknames[1].nickname ~= "" then
                                                matchResult.allyName = nicknames[1].nickname
                                            end
                                        end,
                                        onError = function() end,
                                    })
                                end)
                            end
                        end
                        if chosen[3] then
                            matchResult.opp2IsReal = true
                            local deckJson = chosen[3].iscore and chosen[3].iscore.deck
                            if deckJson and type(deckJson) == "string" and deckJson ~= "" then
                                local cjson = require("cjson")
                                local ok, parsed = pcall(cjson.decode, deckJson)
                                if ok and parsed and type(parsed) == "table" and #parsed >= 8 then
                                    matchResult.opp2Deck = parsed
                                end
                            end
                            matchResult.opp2Trophies = chosen[3].iscore and chosen[3].iscore.trophies
                            if chosen[3].userId then
                                pcall(function()
                                    GetUserNickname({
                                        userIds = { chosen[3].userId },
                                        onSuccess = function(nicknames)
                                            if nicknames and nicknames[1] and nicknames[1].nickname ~= "" then
                                                matchResult.opp2Name = nicknames[1].nickname
                                            end
                                        end,
                                        onError = function() end,
                                    })
                                end)
                            end
                        end
                    end
                end,
            }, "deck")
        end)
    end

    -- 发起匹配请求
    tryMatchOnlinePlayers()

    --- 生成同段位AI数据（8秒超时后使用，AI使用同段位随机玩家卡组）
    local function makeAIFallback(roleName)
        local trophies = math.max(0, playerTrophies + math.random(-200, 200))
        return {
            name = roleName,
            trophies = trophies,
            deck = DeckManager.DEFAULT_AI_DECK,
            isRealPlayer = false,
        }
    end

    --- 8秒匹配结束或提前匹配到 → 显示VS页面并开始战斗
    local function showVSAndStart()
        -- 关闭匹配等待界面
        MatchTransitionUI.CancelWaiting()

        -- 对手1：在线玩家 or 同段位AI
        local opponentData
        if matchResult.opponentIsReal and matchResult.opponentDeck then
            opponentData = {
                name = matchResult.opponentName or "在线玩家",
                trophies = matchResult.opponentTrophies or playerTrophies,
                deck = matchResult.opponentDeck,
                isRealPlayer = true,
            }
        else
            opponentData = makeAIFallback("浮空散人")
        end

        -- 缓存对手卡组给战斗用
        aiOpponentDeck_ = opponentData.deck

        local allyData = nil
        local opponent2Data = nil
        if mode == "2v2" then
            -- 队友：在线玩家 or 同段位AI
            if matchResult.allyIsReal and matchResult.allyDeck then
                allyData = {
                    name = matchResult.allyName or "在线队友",
                    trophies = matchResult.allyTrophies or playerTrophies,
                    deck = matchResult.allyDeck,
                    isRealPlayer = true,
                }
            else
                allyData = makeAIFallback("浮空盟友")
            end
            -- 敌方2号：在线玩家 or 同段位AI
            if matchResult.opp2IsReal and matchResult.opp2Deck then
                opponent2Data = {
                    name = matchResult.opp2Name or "在线对手",
                    trophies = matchResult.opp2Trophies or playerTrophies,
                    deck = matchResult.opp2Deck,
                    isRealPlayer = true,
                }
            else
                opponent2Data = makeAIFallback("敌方副将")
            end
        end

        MatchTransitionUI.Show(playerData, opponentData, function()
            if opponentData.isRealPlayer then
                -- 在线玩家：走联机流程（Server等待对方连接后自动开始）
                Client.StartOnlineBattle(deck, mode, opponentData, allyData, opponent2Data)
            else
                -- AI对手：走单机流程
                Client.StartBattle(deck, mode)
            end
        end, mode, allyData, opponent2Data)
    end

    -- 匹配等待（无倒计时UI，直接等匹配结果后进入VS页面）
    local matchDuration = 8
    matchCountdownTimer_ = 0
    matchCountdownActive_ = true
    matchCountdownCallback_ = function(dt)
        matchCountdownTimer_ = matchCountdownTimer_ + dt

        -- 提前匹配到在线玩家 → 立即进入
        if matchResult.opponentIsReal and matchResult.cloudResponded then
            matchCountdownActive_ = false
            showVSAndStart()
            return true
        end

        -- 超时 → 用同段位AI
        if matchCountdownTimer_ >= matchDuration then
            matchCountdownActive_ = false
            showVSAndStart()
            return true
        end
        return false
    end
end

-- ============================================================================
-- 战斗启动（卡组确认后调用）
-- ============================================================================

function Client.StartBattle(playerDeck, mode)
    mode = mode or "1v1"
    gamePhase_ = "battle"
    currentMode_ = mode
    isOnlineMode_ = false  -- 确保单机模式不走联机分支（BUG-7修复）
    localSlot_ = 1
    localTeam_ = 1
    HexRenderer.SetLocalInfo(localSlot_, currentMode_)

    -- 保存 2v2 玩家信息（单机模式全是AI名）
    if mode == "2v2" then
        playersInfo2v2_ = {
            ally = { name = "浮空盟友", trophies = 0 },
            enemy1 = { name = "浮空散人", trophies = 0 },
            enemy2 = { name = "敌方副将", trophies = 0 },
        }
    else
        playersInfo2v2_ = nil
    end

    -- 设置玩家卡组
    DeckManager.SetDeck(1, playerDeck)
    -- AI 使用同段位玩家卡组（云端获取），无则用默认卡组
    local aiDeck = aiOpponentDeck_ or DeckManager.DEFAULT_AI_DECK
    if mode == "2v2" then
        DeckManager.SetDeck(2, aiDeck)
        DeckManager.SetDeck(3, aiDeck)
        DeckManager.SetDeck(4, aiDeck)
    else
        DeckManager.SetDeck(2, aiDeck)
    end

    -- 任务：羁绊触发检测
    local activeEffects = SynergyManager.GetActiveEffects(1)
    if activeEffects and #activeEffects > 0 then
        QuestManager.ReportEvent("synergy_trigger", #activeEffects)
    end

    -- 初始化神器系统
    local pd = PlayerDataManager.GetData()
    local equippedArtifact = pd and pd.equippedArtifact or nil
    ArtifactManager.Init(equippedArtifact)
    EventBus.On("ArtifactReleased", Client.OnArtifactReleased)

    -- 初始化格子骨架（空地图）
    Client.InitLocalGrid(logicalW_, logicalH_)

    -- 单机模式：本地运行 Server 逻辑，共享内存
    local Server = require("Network.Server")
    Server.SetMode(mode)
    Server.InitGrid(mode == "2v2" and 4 or 2, 2)
    -- 将 Server 的地图数据直接应用到 Client
    Client.ApplyMapData(Server.GetTileStates(), Server.GetSpawns(), Server.GetBuildings())
    ViewTransform.SetLocalTeam(1)  -- 单机永远是 team1
    localTeam_ = 1

    AIOpponent.Reset()
    AIOpponent.SetMode(mode)

    -- 根据玩家段位设置 AI 强度
    local SeasonConfig = require("Config.SeasonConfig")
    local trophies = PlayerDataManager.Get("trophies") or 0
    local tierIndex = SeasonConfig.GetTierByTrophies(trophies)
    AIOpponent.SetStrength(tierIndex)

    -- 创建战斗 UI
    Client.CreateUI()

    BattleHUD.InitEventListeners()
    BattleHUD.UpdateArtifactButton()

    battlePhase_ = Shared.BATTLE_PHASE.PLAYING
    -- 按模式设置战斗时长（currentMode_ 已在函数开头设置）
    battleTimer_ = GameConfig.BATTLE_DURATION[currentMode_] or GameConfig.BATTLE_DURATION_DEFAULT
end

-- ============================================================================
-- 联机战斗启动（匹配到真实在线玩家时调用）
-- 利用现有 Server.lua 联机基础设施：ClientConnected → TryStartBattle → MapInit → BattleSync
-- ============================================================================

--- 启动联机战斗（真实在线玩家对战）
--- 流程：本函数初始化客户端 → 连接Server → Server收到双方连接后自动TryStartBattle
--- → Server下发MapInit → Server每100ms推送BattleSync → 客户端只渲染+发送翻格请求
---@param playerDeck table 玩家卡组
---@param mode string "1v1"/"2v2"
---@param opponentData table 对手数据 { name, trophies, deck, isRealPlayer }
---@param allyData table|nil 队友数据（2v2）
---@param opponent2Data table|nil 敌方2号数据（2v2）
function Client.StartOnlineBattle(playerDeck, mode, opponentData, allyData, opponent2Data)
    mode = mode or "1v1"
    gamePhase_ = "battle"
    currentMode_ = mode
    isOnlineMode_ = true
    HexRenderer.SetLocalInfo(localSlot_, currentMode_)

    -- 保存 2v2 玩家信息（用于 HUD 显示）
    if mode == "2v2" then
        playersInfo2v2_ = {
            ally = { name = (allyData and allyData.name) or "队友", trophies = (allyData and allyData.trophies) or 0 },
            enemy1 = { name = (opponentData and opponentData.name) or "敌方1", trophies = (opponentData and opponentData.trophies) or 0 },
            enemy2 = { name = (opponent2Data and opponent2Data.name) or "敌方2", trophies = (opponent2Data and opponent2Data.trophies) or 0 },
        }
    else
        playersInfo2v2_ = nil
    end

    -- 设置玩家卡组
    DeckManager.SetDeck(1, playerDeck)
    -- 对手/队友卡组（联机模式由服务端权威使用，这里保留给本地显示/预判）
    if mode == "2v2" and allyData and allyData.deck then
        DeckManager.SetDeck(2, allyData.deck)
    end
    if opponentData and opponentData.deck then
        DeckManager.SetDeck(mode == "2v2" and 3 or 2, opponentData.deck)
    end
    if mode == "2v2" and opponent2Data and opponent2Data.deck then
        DeckManager.SetDeck(4, opponent2Data.deck)
    end

    -- 任务：羁绊触发检测
    local activeEffects = SynergyManager.GetActiveEffects(1)
    if activeEffects and #activeEffects > 0 then
        QuestManager.ReportEvent("synergy_trigger", #activeEffects)
    end

    -- 初始化神器系统
    local pd = PlayerDataManager.GetData()
    local equippedArtifact = pd and pd.equippedArtifact or nil
    ArtifactManager.Init(equippedArtifact)
    EventBus.On("ArtifactReleased", Client.OnArtifactReleased)

    -- 初始化格子骨架（空地图，等待Server下发MapInit填充）
    Client.InitLocalGrid(logicalW_, logicalH_)

    -- 联机模式：不运行本地Server，等待远程Server下发数据
    -- Server端会在双方连接后自动调用 TryStartBattle → SendMapInit
    -- 客户端通过 ClientHandleMapInit 接收地图，通过 ClientHandleBattleSync 接收增量同步

    -- 设置本地队伍（联机模式下由 Server 的 PlayerAssigned 事件设置，默认1）
    localTeam_ = 1
    ViewTransform.SetLocalTeam(1)

    -- 联机模式不需要AI对手（对手是真实玩家，由Server控制）
    AIOpponent.Reset()

    -- 2v2联机：如果队友是AI，需要启用盟友AI
    if mode == "2v2" then
        if allyData and not allyData.isRealPlayer then
            -- 队友是AI：启用盟友AI（但翻格请求仍需发到Server）
            AIOpponent.SetAllyEnabled(true)
        end
        -- 如果队友是真实玩家，不需要盟友AI，队友自己操作
    end

    -- 创建战斗 UI
    Client.CreateUI()

    BattleHUD.InitEventListeners()
    BattleHUD.UpdateArtifactButton()

    -- 战斗阶段设为 WAITING，等收到 Server 的 MapInit 后切换到 PLAYING
    battlePhase_ = Shared.BATTLE_PHASE.WAITING
    battleTimer_ = GameConfig.BATTLE_DURATION[mode] or GameConfig.BATTLE_DURATION_DEFAULT

    -- 发送 PlayerReady 事件通知 Server 本客户端已准备好
    local readyData = VariantMap()
    readyData["PlayerIdx"] = Variant(1)  -- 临时，Server会重新分配
    readyData["Deck"] = Variant(require("cjson").encode(playerDeck))
    readyData["Mode"] = Variant(mode)
    network:SendRemoteEvent("PlayerReady", readyData)

    Client.ShowToast("连接服务器中...")
end

-- ============================================================================
-- 神器效果处理
-- ============================================================================

--- 处理神器释放事件
---@param artifactData table { artifactName, artifactDef, level, star, releaseCount, chargeStage }
function Client.OnArtifactReleased(artifactData)
    local artifactName = artifactData.artifactName
    local artifactDef = artifactData.artifactDef
    local level = artifactData.level or 0
    local chargeStage = artifactData.chargeStage
    
    if not artifactDef or not artifactDef.skill then
        return
    end
    
    local skill = artifactDef.skill
    
    -- 播放音效
    SoundManager.Play("thunder", 0.7)
    
    -- 根据神器名称执行对应效果
    if artifactName == "天鼓雷音" then
        -- 天鼓雷音：全体移速+100%持续5秒
        local speedBonus = skill.value or 1.0  -- 100%
        local duration = skill.duration or 5
        SkillEngine.AddSpeedBuffToAllies(units_, 1, speedBonus, duration)
        Client.ShowToast("天鼓雷音！全军移速提升！")
        
    elseif artifactName == "虚空遁符" then
        -- 虚空遁符：传送3个最强单位到敌后
        local teleportCount = skill.count or 3
        if level >= 30 then
            -- 30级被动：传送数量+2
            teleportCount = teleportCount + 2
        end
        
        -- 选择最强的己方单位
        local playerUnits = {}
        for _, unit in ipairs(units_) do
            if unit.owner == 1 and unit.state ~= "dead" then
                table.insert(playerUnits, unit)
            end
        end
        
        -- 按攻击力排序（最强的在前面）
        table.sort(playerUnits, function(a, b)
            return (a.baseAtk or a.attack or 0) > (b.baseAtk or b.attack or 0)
        end)
        
        -- 获取敌方核心位置（敌后）
        local enemyTargetHex = targetHexes_[2]
        if enemyTargetHex then
            -- 找到附近的空位
            local teleportPositions = Client.FindNearbyEmptyPositions(enemyTargetHex, teleportCount)
            
            -- 传送单位
            for i = 1, math.min(teleportCount, #playerUnits, #teleportPositions) do
                local unit = playerUnits[i]
                local pos = teleportPositions[i]
                unit.q = pos.q
                unit.r = pos.r
                -- 给传送的单位添加攻速buff
                local atkSpdBonus = (level >= 30) and 0.2 or 0.1  -- 10%或20%
                SkillEngine.AddAttackSpeedBuffToUnit(unit, atkSpdBonus, skill.duration or 5)
                -- 10级被动：无敌4秒（暂略，需要更多状态支持）
            end
            
            Client.ShowToast("虚空遁符！精锐突进敌后！")
        end
        
    elseif artifactName == "诛仙弑神枪" then
        -- 诛仙弑神枪：斩杀传奇+范围伤害
        local qualities = { "legendary" }
        if level >= 30 then
            -- 30级被动：也可以斩杀史诗
            qualities = { "epic", "legendary" }
        end
        
        -- 斩杀
        local executeCount = SkillEngine.ExecuteUnitsByQuality(units_, 1, qualities)
        
        -- AOE伤害
        local damage = (level >= 30) and 400 or 250
        local radius = skill.radius or 3
        if level >= 20 then
            -- 20级被动：更大范围和更多伤害
            damage = damage + 100
            radius = math.max(radius, 5)
        end
        
        -- 在战场中央造成AOE伤害（从实际地图范围动态计算中心）
        local midCol = math.floor((maxQ_ + minQ_) / 2 + 0.5)
        local midRow = math.floor((maxR_ + minR_) / 2 + 0.5)
        SkillEngine.DoAoeDamageAtPos(nil, midCol, midRow, units_, radius, damage)
        
        if executeCount > 0 then
            Client.ShowToast("诛仙弑神枪！斩杀 " .. executeCount .. " 个敌方精英！")
        else
            Client.ShowToast("诛仙弑神枪！横扫敌军！")
        end
    end
end

--- 找到目标位置附近的空位
---@param targetHex table { q, r }
---@param count number 需要的位置数量
---@return table[] 位置列表
function Client.FindNearbyEmptyPositions(targetHex, count)
    local positions = {}
    -- 简单实现：在目标周围一定范围内寻找
    for dq = -3, 3 do
        for dr = -3, 3 do
            if math.abs(dq) + math.abs(dr) <= 3 then  -- 曼哈顿距离
                local hex = { q = targetHex.q + dq, r = targetHex.r + dr }
                local key = HexGrid.Key(hex.q, hex.r)
                if tileStates_[key] then
                    -- 检查是否有建筑或单位占用
                    local hasBuilding = buildings_[key] ~= nil
                    local hasUnit = false
                    for _, unit in ipairs(units_) do
                        if unit.q == hex.q and unit.r == hex.r and unit.state ~= "dead" then
                            hasUnit = true
                            break
                        end
                    end
                    if not hasBuilding and not hasUnit then
                        table.insert(positions, hex)
                        if #positions >= count then
                            return positions
                        end
                    end
                end
            end
        end
    end
    return positions
end

-- ============================================================================
-- 初始化
-- ============================================================================

--- 初始化本地网格（仅建空骨架，地图数据由 Server 下发）
---@param logicalW number
---@param logicalH number
function Client.InitLocalGrid(logicalW, logicalH)
    -- 不再生成 gridHexes_ 和调用 SetupLayout，等 ApplyMapData 根据实际地图填充
    gridHexes_ = {}
    tileStates_ = {}
end

function Client.CreateUI()
    local root = UI.Panel {
        id = "clientRoot",
        width = "100%",
        height = "100%",
        pointerEvents = "box-none",
        children = {
            BattleHUD.Create(currentMode_, playersInfo2v2_),
            TutorialManager.CreateOverlay(),
        }
    }
    UI.SetRoot(root)

    -- 首次游戏启动教程
    if TutorialManager.ShouldShow() then
        TutorialManager.Start()
    end
end

-- ============================================================================
-- 每帧更新
-- ============================================================================

---@param eventType string
---@param eventData UpdateEventData
function ClientHandleUpdate(eventType, eventData)
    local dt = eventData["TimeStep"]:GetFloat()

    -- 匹配过渡阶段：更新匹配倒计时和过渡计时器
    if gamePhase_ == "match_transition" then
        -- 驱动匹配等待动画
        MatchTransitionUI.UpdateWaiting(dt)

        if matchCountdownActive_ and matchCountdownCallback_ then
            local done = matchCountdownCallback_(dt)
            if done then
                matchCountdownCallback_ = nil
            end
        end
        MatchTransitionUI.Update(dt)
        return
    end

    -- 非战斗阶段不更新战斗逻辑
    if gamePhase_ ~= "battle" then return end

    -- 提示消息衰减
    if toastTimer_ > 0 then
        toastTimer_ = toastTimer_ - dt
    end

    -- 更新视觉特效（不管战斗是否结束都更新）
    Client.UpdateEffects(dt)
    -- 更新HexRenderer动画
    HexRenderer.UpdateAnimations(dt)

    if battlePhase_ ~= Shared.BATTLE_PHASE.PLAYING then
        return
    end

    -- ====== 联机模式：Server权威运行战斗，客户端只渲染+发翻格请求 ======
    if isOnlineMode_ then
        -- 倒计时由 Server 的 BattleSync 下发，客户端不自行扣减
        -- 但为避免网络延迟导致UI卡顿，客户端也做本地倒计时（会被Server同步覆盖）
        battleTimer_ = battleTimer_ - dt

        -- 盟友AI翻格（2v2联机且队友是AI时，仅处理team1的盟友slot）
        if AIOpponent.IsAllyEnabled() then
            local _, allyKey, _ = AIOpponent.Update(tileStates_, gridHexes_, dt, units_)
            if allyKey then
                local aq, ar = HexGrid.FromKey(allyKey)
                local flipData = VariantMap()
                flipData["Q"] = Variant(aq)
                flipData["R"] = Variant(ar)
                flipData["PlayerIdx"] = Variant(2)  -- 盟友是 slot 2
                network:SendRemoteEvent("FlipTile", flipData)
            end
        end

        -- 更新统计
        Client.UpdateStats()

        -- 更新 HUD
        BattleHUD.UpdateTimer(battleTimer_)
        BattleHUD.UpdateSpiritStones(spiritStones_)
        BattleHUD.UpdatePopulation(UnitManager.CountUnitsBySlot(units_, localSlot_), GameConfig.MAX_POPULATION)
        BattleHUD.UpdateTerritory(territoryP1_)
        BattleHUD.UpdateEnemyTerritory(territoryP2_)
        local enemyMaxPop = (currentMode_ == "2v2") and GameConfig.MAX_POPULATION or (GameConfig.AI_MAX_POPULATION or 60)
        BattleHUD.UpdateEnemyPopulation(UnitManager.CountUnits(units_, 2), enemyMaxPop)
        BattleHUD.UpdateMaterials(materials_)
        return
    end

    -- ====== 单机模式：本地运行完整战斗逻辑 ======

    -- 倒计时
    battleTimer_ = battleTimer_ - dt
    if battleTimer_ <= 0 then
        battleTimer_ = 0
        Client.EndBattle()
        return
    end

    -- 1. AI 对手行动（翻格子）—— 多实例独立返回
    local _, _, flippedKeys = AIOpponent.Update(tileStates_, gridHexes_, dt, units_)
    local anyFlipped = false
    for slot, hexKey in pairs(flippedKeys) do
        HexRenderer.StartFlipAnimation(hexKey)
        local tile = tileStates_[hexKey]
        if tile and tile.building and tile.building > 0 then
            buildings_[hexKey] = BuildingManager.CreateInstance(tile)
            anyFlipped = true
        end
    end
    if anyFlipped then
        WallManager.RebuildAll(buildings_, tileStates_)
    end

    -- 2. 建筑产出（晶核 + 出兵）
    BuildingManager.Update(buildings_, tileStates_, dt,
        function(owner, amount, slot)
            if owner == 1 then
                if slot and slot == 2 then
                    -- 盟友AI (slot 2) 的建筑产出归盟友AI
                    AIOpponent.AddSpiritToSlot(2, amount)
                else
                    -- 玩家自己 (slot 1) 的建筑产出
                    spiritStones_ = spiritStones_ + amount
                end
            else
                -- 敌方建筑：精确分配给对应 slot 的 AI
                if slot then
                    AIOpponent.AddSpiritToSlot(slot, amount)
                else
                    AIOpponent.AddSpirit(amount, 2)
                end
            end
        end,
        function(owner, hexKey, barracksPrice, fixedQuality)
            ---@diagnostic disable-next-line: assign-type-mismatch
            local building = buildings_[hexKey]
            local slot = building and building.slot or owner
            local maxPop = (currentMode_ == "2v2") and GameConfig.MAX_POPULATION
                or ((owner == 2) and (GameConfig.AI_MAX_POPULATION or 20) or GameConfig.MAX_POPULATION)
            local currentPop = UnitManager.CountPopulationBySlot(units_, slot)
            if currentPop >= maxPop then return end

            local cardName, cardLevel

            if building and building.boundCard then
                -- 使用绑定的卡牌
                cardName = building.boundCard.cardName
                cardLevel = building.boundCard.cardLevel
            else
                -- 兜底：如果没有绑定卡牌，回退到旧的随机抽卡
                cardName, cardLevel = DeckManager.RollCard(slot, barracksPrice, fixedQuality)
            end

            if not cardName then return end

            -- AI 卡牌等级加成（段位绑定，仅兜底路径需要，boundCard 已包含加成）
            if slot ~= 1 and not (building and building.boundCard) then
                cardLevel = (cardLevel or 0) + AIOpponent.GetCardLevelBonus()
            end

            -- 检查人口是否溢出
            local card = UnitConfig.CARDS[cardName]
            if card and (currentPop + (card.pop or 1)) > maxPop then return end

            local q, r = HexGrid.FromKey(hexKey)
            local unit = UnitManager.CreateUnit(owner, q, r, cardName, cardLevel, slot)
            if unit then
                units_[#units_ + 1] = unit
            end
        end,
        units_
    )

    -- 3. 单位更新（移动、战斗）
    local wallDirty = false
    
    local function onSpiritGain(owner, amount)
        if owner == 1 then
            spiritStones_ = spiritStones_ + amount
        else
            AIOpponent.AddSpirit(amount, owner)
        end
    end
    
    local function summonCallback(owner, q, r, cardName, cardLevel)
        local params = type(cardName) == "table" and cardName or { cardName = cardName, cardLevel = cardLevel }
        local summonId = params.cardName or params.unitId
        local fallbackCards = {
            ["_幼翼"] = "翼族斥候",
            ["_分身"] = "翼族斥候",
            ["_自爆机"] = "自爆机",
            ["_机甲兵"] = "蒸汽战犬",
            ["_revived"] = "风帆新兵",
        }
        local resolvedCard = UnitConfig.CARDS[summonId] and summonId or fallbackCards[summonId] or "风帆新兵"
        local count = math.max(1, params.count or 1)

        for _ = 1, count do
            local unit = UnitManager.CreateUnit(owner, q, r, resolvedCard, params.cardLevel or cardLevel or 0, params.slot or owner)
            if unit then
                if params.hp then
                    unit.maxHp = params.hp
                    unit.hp = params.hp
                elseif params.hpPercent then
                    unit.maxHp = math.max(1, math.floor(unit.maxHp * params.hpPercent))
                    unit.hp = unit.maxHp
                end
                if params.atk then
                    unit.baseAtk = params.atk
                    unit.attack = params.atk
                elseif params.atkPercent then
                    unit.baseAtk = math.max(1, math.floor(unit.baseAtk * params.atkPercent))
                    unit.attack = unit.baseAtk
                end
                unit._summonDuration = params.duration
                units_[#units_ + 1] = unit
            end
        end
    end
    
    UnitManager.Update(units_, tileStates_, buildings_, dt, targetHexes_,
        function(owner, hexKey, slot)
            -- 占领回调：仅染色（改team），不设置flipped
            -- 兵经过格子只改变领地颜色，不等于"翻开"格子
            local tile = tileStates_[hexKey]
            if tile then
                -- 兵占领≠翻开，只有玩家手动翻格子才算翻开
                -- 不清除 tileType，保留格子内容让玩家可以翻开获得建筑
                tile.team = owner
                tile.slot = slot or tile.slot
                tile.ruins = false
                wallDirty = true
                -- 占领闪光特效
                local cq, cr = HexGrid.FromKey(hexKey)
                local ox, oy = HexRenderer.GetOrigin()
                local cx, cy = HexGrid.ToPixel({ q = cq, r = cr }, HexRenderer.GetRadius(), ox, oy)
                Client.SpawnEffect("capture", cx, cy, owner)
            end
        end,
        onSpiritGain,
        summonCallback
    )
    if wallDirty then
        WallManager.RebuildAll(buildings_, tileStates_)
    end

    -- 3.5 处理攻击事件 → 生成攻击火花特效 + 音效
    local atkEvents = UnitManager.PopAttackEvents()
    for i, evt in ipairs(atkEvents) do
        local ox, oy = HexRenderer.GetOrigin()
        local tx, ty = HexGrid.ToPixel({ q = evt.targetQ, r = evt.targetR }, HexRenderer.GetRadius(), ox, oy)
        Client.SpawnEffect("attack", tx, ty, 0)
        -- 每3个攻击事件播放一次音效，避免同帧过多音效叠加
        if i % 3 == 1 then
            SoundManager.Play("attack", 0.35)
        end
    end

    -- 4. 检查胜负
    Client.CheckVictory()
    
    -- 5. 更新残骸计时器
    local ruinChanged = false
    for hexKey, ruin in pairs(ruins_) do
        ruin.ruinTimer = ruin.ruinTimer - dt
        if ruin.ruinTimer <= 0 then
            -- 残骸过期：重置 tile 状态
            local tile = tileStates_[hexKey]
            if tile then
                tile.ruins = false
            end
            ruins_[hexKey] = nil
            ruinChanged = true
        end
    end
    
    -- 残骸完全清除后重建城墙
    if ruinChanged then
        WallManager.RebuildAll(buildings_, tileStates_)
    end

    -- 6. 更新统计
    Client.UpdateStats()

    -- 7. 更新 HUD
    BattleHUD.UpdateTimer(battleTimer_)
    BattleHUD.UpdateSpiritStones(spiritStones_)
    BattleHUD.UpdatePopulation(UnitManager.CountUnitsBySlot(units_, localSlot_), GameConfig.MAX_POPULATION)
    BattleHUD.UpdateTerritory(territoryP1_)
    BattleHUD.UpdateEnemyTerritory(territoryP2_)
    local enemyMaxPop = (currentMode_ == "2v2") and GameConfig.MAX_POPULATION or (GameConfig.AI_MAX_POPULATION or 60)
    BattleHUD.UpdateEnemyPopulation(UnitManager.CountUnits(units_, 2), enemyMaxPop)
    BattleHUD.UpdateMaterials(materials_)
end

-- ============================================================================
-- 翻格子核心逻辑
-- ============================================================================

--- 判断某格子是否可以被某队伍翻开（客户端预判，与 Server.CanFlip 同步）
--- 规则：相邻有己方已翻开的格子即可翻（空地也算扩展源）
--- 目标格子的领地归属检查在 TryFlipTile 中进行
---@param hex table {q, r}
---@param team integer
---@return boolean
function Client.CanFlip(hex, team, slot)
    local neighbors = HexGrid.Neighbors(hex)
    for _, nh in ipairs(neighbors) do
        local key = HexGrid.Key(nh.q, nh.r)
        local tile = tileStates_[key]
        -- 相邻格子必须：己方 + 已翻开（空地也可作为扩展源）
        if tile and tile.team == team and tile.flipped then
            if not slot then
                return true
            end
            -- 2v2模式：检查 slot 归属（tile.slot 必须精确匹配，无 fallback）
            if tile.slot == slot then
                return true
            end
        end
    end
    return false
end

--- 尝试翻开一个格子
---@param hexKey string
---@return boolean success
---@return string message
function Client.TryFlipTile(hexKey)
    local tile = tileStates_[hexKey]
    if not tile then
        return false, ""
    end

    -- 检查：必须未翻开
    if tile.flipped then
        return false, ""
    end

    -- 检查：必须是我方领地才能翻（全局规则，所有模式通用）
    if tile.team ~= localTeam_ then
        return false, ""
    end

    -- 检查：残骸需先占领
    if tile.ruins then
        return false, "残骸需先占领"
    end

    -- 检查：必须相邻我方已翻开的格子
    local fq, br = HexGrid.FromKey(hexKey)
    -- 2v2模式传入 localSlot_ 限制只能从自己 slot 的格子扩展
    local slotCheck = (currentMode_ == "2v2") and localSlot_ or nil
    if not Client.CanFlip({ q = fq, r = br }, localTeam_, slotCheck) then
        return false, "必须相邻我方已翻开的格子"
    end

    -- 联机模式：客户端只做预判，发送翻格请求到Server，由Server权威判定
    if isOnlineMode_ then
        -- 检查：格子必须有类型（非空地）
        if tile.tileType == TileConfig.TILE_TYPE.EMPTY then
            return false, ""
        end

        -- 检查：已有建筑的格子不能翻
        if tile.building ~= GameConfig.BUILDING.NONE then
            return false, "该格子已有建筑"
        end

        -- 检查：晶核是否足够
        local price = tile.price
        if spiritStones_ < price then
            return false, "晶核不足（需要" .. price .. "）"
        end

        -- 发送翻格请求到Server
        local flipData = VariantMap()
        flipData["Q"] = Variant(fq)
        flipData["R"] = Variant(br)
        flipData["PlayerIdx"] = Variant(localSlot_)
        network:SendRemoteEvent("FlipTile", flipData)
        return true, ""
    end

    -- 以下为单机模式的完整翻格逻辑
    -- 检查：格子必须有类型（非空地）
    if tile.tileType == TileConfig.TILE_TYPE.EMPTY then
        return false, ""
    end

    -- 检查：已有建筑的格子不能翻
    if tile.building ~= GameConfig.BUILDING.NONE then
        return false, "该格子已有建筑"
    end

    -- 检查：晶核是否足够
    local price = tile.price
    if spiritStones_ < price then
        return false, "晶核不足（需要" .. price .. "）"
    end

    -- 扣除晶核
    spiritStones_ = spiritStones_ - price

    -- 触发翻牌动画
    HexRenderer.StartFlipAnimation(hexKey)

    -- 翻开格子，获得建筑
    local buildingType, buildingName, barracksPrice, fixedQuality = TileConfig.GetFlipResult(tile.tileType)
    tile.flipped = true
    tile.team = localTeam_  -- 翻格 = 占领
    tile.slot = localSlot_  -- 标记归属槽位（2v2区分同队玩家）

    -- 计算格子屏幕坐标（用于特效）
    local fq, fr = HexGrid.FromKey(hexKey)
    local fox, foy = HexRenderer.GetOrigin()
    local fcx, fcy = HexGrid.ToPixel({ q = fq, r = fr }, HexRenderer.GetRadius(), fox, foy)

    if buildingType ~= GameConfig.BUILDING.NONE then
        tile.building = buildingType
        tile.barracksPrice = barracksPrice or 0  -- 建筑价格（用于品质概率查询）
        tile.fixedQuality = fixedQuality          -- 问号格子的固定品质
        
        -- 所有建筑统一流程：先 ROLL 品质，再从卡组匹配该品质的卡，绑定
        if buildingType == GameConfig.BUILDING.BARRACKS then
            local quality = fixedQuality or DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(1, "unit", quality)
            if cardName then
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        elseif buildingType == GameConfig.BUILDING.SPIRIT_MINE then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(1, "mine", quality)
            if cardName then
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        elseif buildingType == GameConfig.BUILDING.TOWER or buildingType == GameConfig.BUILDING.ELITE_TOWER then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(1, "tower", quality)
            if cardName then
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        end
        
        buildings_[hexKey] = BuildingManager.CreateInstance(tile)

        -- 建筑变动后重建城墙（Server 已处理相邻格子生成）
        WallManager.RebuildAll(buildings_, tileStates_)

        -- 翻格特效（建造成功）
        Client.SpawnEffect("build", fcx, fcy, 1)
        SoundManager.Play("flip")
        SoundManager.Play("build")

        TutorialManager.NotifyAction("flip")
        QuestManager.ReportEvent("tile_flip", 1)
        ArtifactManager.OnTileRevealed(hexKey) ---@diagnostic disable-line: param-type-mismatch
        return true, buildingName .. "！"
    else
        -- 问号格子翻到空 —— 标记为永久空地，不可再刷新
        tile.tileType = TileConfig.TILE_TYPE.EMPTY
        tile.revealedEmpty = true

        -- 翻格特效（空地）
        Client.SpawnEffect("flip_empty", fcx, fcy, 1)
        SoundManager.Play("flip")

        TutorialManager.NotifyAction("flip")
        QuestManager.ReportEvent("tile_flip", 1)
        ArtifactManager.OnTileRevealed(hexKey) ---@diagnostic disable-line: param-type-mismatch
        return true, "什么都没有..."
    end
end

-- ============================================================================
-- 战斗逻辑
-- ============================================================================

function Client.UpdateStats()
    local p1 = 0
    local p2 = 0
    for _, tile in pairs(tileStates_) do
        if tile.team == 1 then p1 = p1 + 1 end
        if tile.team == 2 then p2 = p2 + 1 end
    end
    territoryP1_ = p1
    territoryP2_ = p2
end

--- 获取指定队伍的领地数量
---@param team integer
---@return integer
function Client.GetTerritoryCount(team)
    local count = 0
    for _, hex in ipairs(gridHexes_) do
        local key = HexGrid.Key(hex.q, hex.r)
        local tile = tileStates_[key]
        if tile and tile.team == team then
            count = count + 1
        end
    end
    return count
end

function Client.CheckVictory()
    -- 检查建筑 HP <= 0 并转换为残骸状态
    for hexKey, inst in pairs(buildings_) do
        if inst.hp <= 0 then
            -- 玩家摧毁敌方建筑获得铸材
            if inst.owner == 2 then
                local reward = GameConfig.BUILDING_MATERIAL_REWARD[inst.building] or 0
                materials_ = materials_ + reward
                QuestManager.ReportEvent("building_destroy", 1)
            end
            -- 爆炸特效
            local bq, br = HexGrid.FromKey(hexKey)
            local box, boy = HexRenderer.GetOrigin()
            local bcx, bcy = HexGrid.ToPixel({ q = bq, r = br }, HexRenderer.GetRadius(), box, boy)
            Client.SpawnEffect("destroy", bcx, bcy, inst.owner)
            SoundManager.Play("destroy", 0.6)
            
            -- 转换为残骸状态
            local tile = tileStates_[hexKey]
            if tile then
                -- 摧毁者获得领地归属
                local destroyer = inst.lastAttackerTeam or ((inst.owner == 1) and 2 or 1)
                tile.team = destroyer
                tile.slot = inst.lastAttackerSlot or tile.slot
                tile.flipped = true  -- 保持翻开状态，残骸用 ruins 标记
                tile.building = GameConfig.BUILDING.NONE
                tile.ruins = true
            end
            ruins_[hexKey] = {
                ruinTimer = RUIN_DURATION,
                owner = inst.owner,
                building = inst.building
            }
            buildings_[hexKey] = nil
        end
    end

    -- 2v2模式：检测已覆灭的 slot，清除其残余单位（释放人口）
    if currentMode_ == "2v2" then
        -- 收集仍有建筑存活的 slot 集合
        local aliveSlots = {}
        for _, inst in pairs(buildings_) do
            if inst.slot then
                aliveSlots[inst.slot] = true
            end
        end
        -- 杀死已覆灭 slot 的残余单位（势力覆灭→部队溃散）
        for _, unit in ipairs(units_) do
            if unit.slot and not aliveSlots[unit.slot] and unit.state ~= "dead" then
                unit.hp = 0
                unit.state = "dead"
            end
        end
    end

    -- 胜利条件：敌方所有建筑全灭（只看 buildings_ 表，不含残骸）
    local p1HasBuilding = false
    local p2HasBuilding = false
    for _, inst in pairs(buildings_) do
        if inst.owner == 1 then p1HasBuilding = true end
        if inst.owner == 2 then p2HasBuilding = true end
    end

    if not p2HasBuilding then
        Client.EndBattle("victory")
        return
    end
    if not p1HasBuilding then
        Client.EndBattle("defeat")
        return
    end
end

---@param result string|nil
function Client.EndBattle(result)
    if battlePhase_ == Shared.BATTLE_PHASE.ENDED then return end
    battlePhase_ = Shared.BATTLE_PHASE.ENDED

    -- 确保领地数据最新（最后一帧可能有变化未同步）
    Client.UpdateStats()

    if not result then
        if territoryP1_ > territoryP2_ then
            result = "victory"
        elseif territoryP1_ < territoryP2_ then
            result = "defeat"
        else
            result = "draw"
        end
    end

    Client.ShowResult(result)
end

---@param result string
function Client.ShowResult(result)
    if resultShown_ then return end
    resultShown_ = true
    gamePhase_ = "result"

    -- 通过赛季管理器计算奖杯变化（含段位晋升/掉段/保段判定）
    local trophies, trophyChange, tierChanged = SeasonManager.UpdateTrophies(result, currentMode_)

    -- 计算其他奖励
    -- 注意：UpdateTrophies 已修改 pd.trophies，需用返回值反推更新前的值
    local trophiesBefore = math.max(0, trophies - trophyChange)
    local pd = PlayerDataManager.GetData()
    local tierIndex, _ = SeasonConfig.GetTierByTrophies(trophiesBefore)

    local goldReward = 0
    local materialReward = materials_   -- 战斗中摧毁建筑获得的铸材
    local expReward = 0
    local chestReward = nil

    if result == "victory" then
        local tierGold, _ = SeasonConfig.GetTierRewards(tierIndex)
        goldReward = tierGold + math.min(materials_, 50)  -- 铸材奖励上限50
        goldReward = math.min(goldReward, 300)  -- 总金币上限300
        
        -- 检查是否有金币翻倍效果
        if AdManager and AdManager.IsEffectActive and AdManager.IsEffectActive("goldDouble") then
            goldReward = goldReward * (AdManager.GetEffectValue("goldDouble") or 2)
        end
        
        expReward = math.min(20 + math.floor(territoryP1_ * 0.5), 80)  -- 经验上限80
        -- 胜利且有空槽位时获得宝箱
        if ChestManager.HasEmptySlot() then
            local awardedType = ChestManager.AwardChest()
            if awardedType then
                local chestDef = ChestManager.TYPES[awardedType]
                chestReward = chestDef and chestDef.name or awardedType
            end
        end
    elseif result == "defeat" or result == "draw" then
        -- 平局按失败奖励结算
        goldReward = math.min(10 + math.floor(materials_ * 0.3), 100)  -- 失败金币上限100
        materialReward = math.min(materialReward + 30, 100)  -- 铸材上限100
        expReward = math.min(5 + math.floor(territoryP1_ * 0.3), 30)  -- 经验上限30
    end

    -- 持久化对战奖励（奖杯和战斗记录已由 SeasonManager 处理）
    PlayerDataManager.AddGold(goldReward)
    PlayerDataManager.AddMaterials(materialReward)
    PlayerDataManager.AddExp(expReward)
    PlayerDataManager.Save()

    -- 任务事件上报
    QuestManager.ReportEvent("battle_complete", 1)
    if result == "victory" then
        QuestManager.ReportEvent("battle_win", 1)
        -- 种族胜利统计：检查卡组中主要种族
        local deck = DeckManager.GetDeck(1)
        if deck then
            local raceCounts = {}
            for _, cardName in ipairs(deck) do
                local cardDef = UnitConfig.CARDS[cardName]
                if cardDef and cardDef.race then
                    raceCounts[cardDef.race] = (raceCounts[cardDef.race] or 0) + 1
                end
            end
            -- 含有至少2张的种族都算用该种族胜利
            for race, cnt in pairs(raceCounts) do
                if cnt >= 2 then
                    QuestManager.ReportEvent("win_with_race", 1, { race = race })
                end
            end
        end
    end

    -- 获取 MVP 数据
    local mvp = UnitManager.GetMVP(units_, 1)

    -- 广告礼包剩余次数
    local adBonusLeft = 8 - (pd and pd.adBonusUsedToday or 0)
    if adBonusLeft < 0 then adBonusLeft = 0 end

    local stats = {
        territory1 = territoryP1_,
        territory2 = territoryP2_,
        spiritStones = math.floor(spiritStones_),
        trophiesBefore = trophiesBefore,
        trophyChange = trophyChange,
        goldReward = goldReward,
        materialReward = materialReward,
        expReward = expReward,
        chestReward = chestReward,
        mvp = mvp,
        adBonusLeft = adBonusLeft,
    }

    -- 清除战斗 UI，显示结算界面
    UI.SetRoot(nil, true)
    BattleResultUI.Show(result, stats, function()
        Client.Restart()
    end)
end

function Client.Restart()
    battleTimer_ = GameConfig.BATTLE_DURATION_DEFAULT or 180
    battlePhase_ = Shared.BATTLE_PHASE.PLAYING
    spiritStones_ = GameConfig.STARTING_SPIRIT_STONES
    population_ = 0
    territoryP1_ = 1
    territoryP2_ = 1
    materials_ = 0
    playersInfo2v2_ = nil
    gridHexes_ = {}
    tileStates_ = {}
    buildings_ = {}
    units_ = {}
    targetHexes_ = {}
    highlightHex_ = nil
    resultShown_ = false
    toastMsg_ = ""
    toastTimer_ = 0
    effects_ = {}
    ruins_ = {}  -- 重置残骸状态
    aiOpponentDeck_ = nil
    isOnlineMode_ = false  -- 重置联机模式标记

    WallManager.Reset()

    -- 销毁 Shell UI（防止黑屏）
    local ShellUI = require("UI.ShellUI")
    ShellUI.Destroy()

    -- 返回主界面
    UI.SetRoot(nil, true)
    Client.ShowHome()
end

--- 显示短暂提示消息
---@param msg string
function Client.ShowToast(msg)
    toastMsg_ = msg
    toastTimer_ = 2.0
end

-- ============================================================================
-- 视觉特效系统
-- ============================================================================

--- 生成一个特效
---@param effectType string "capture"|"build"|"flip_empty"|"destroy"|"attack"
---@param x number 屏幕坐标X
---@param y number 屏幕坐标Y
---@param owner integer|nil 所属方（影响颜色）
function Client.SpawnEffect(effectType, x, y, owner)
    local duration = 0.5
    if effectType == "build" then duration = 0.7
    elseif effectType == "destroy" then duration = 0.9
    elseif effectType == "attack" then duration = 0.3
    end

    effects_[#effects_ + 1] = {
        type = effectType,
        x = x, y = y,
        timer = 0,
        duration = duration,
        owner = owner or 1,
    }
end

--- 更新所有特效（在 Update 循环中调用）
---@param dt number
function Client.UpdateEffects(dt)
    for i = #effects_, 1, -1 do
        local fx = effects_[i]
        fx.timer = fx.timer + dt
        if fx.timer >= fx.duration then
            table.remove(effects_, i)
        end
    end
end

--- 渲染所有特效
---@param vg userdata
function Client.RenderEffects(vg)
    for _, fx in ipairs(effects_) do
        local progress = fx.timer / fx.duration  -- 0→1
        if fx.type == "capture" then
            Client.RenderCaptureEffect(vg, fx, progress)
        elseif fx.type == "build" then
            Client.RenderBuildEffect(vg, fx, progress)
        elseif fx.type == "flip_empty" then
            Client.RenderFlipEmptyEffect(vg, fx, progress)
        elseif fx.type == "destroy" then
            Client.RenderDestroyEffect(vg, fx, progress)
        elseif fx.type == "attack" then
            Client.RenderAttackEffect(vg, fx, progress)
        end
    end
end

--- 占领闪光：扩散环
function Client.RenderCaptureEffect(vg, fx, progress)
    local radius = hexRadius_ * (0.5 + progress * 1.2)
    local alpha = math.floor((1.0 - progress) * 200)
    local color
    if fx.owner == 1 then
        color = { 100, 180, 255 }
    else
        color = { 255, 120, 100 }
    end

    nvgBeginPath(vg)
    nvgCircle(vg, fx.x, fx.y, radius)
    nvgStrokeColor(vg, nvgRGBA(color[1], color[2], color[3], alpha))
    nvgStrokeWidth(vg, 2.5 * (1.0 - progress))
    nvgStroke(vg)
end

--- 建造成功：上升光环 + 缩放闪烁
function Client.RenderBuildEffect(vg, fx, progress)
    -- 中心闪光
    local scale = 1.0 + progress * 0.5
    local alpha = math.floor((1.0 - progress) * 255)
    local radius = hexRadius_ * 0.8 * scale

    nvgBeginPath(vg)
    nvgCircle(vg, fx.x, fx.y, radius)
    nvgFillColor(vg, nvgRGBA(255, 220, 100, math.floor(alpha * 0.3)))
    nvgFill(vg)

    -- 边框
    nvgBeginPath(vg)
    nvgCircle(vg, fx.x, fx.y, radius)
    nvgStrokeColor(vg, nvgRGBA(255, 240, 150, alpha))
    nvgStrokeWidth(vg, 2.0)
    nvgStroke(vg)

    -- 上升粒子（用小矩形模拟）
    for i = 1, 4 do
        local angle = (i / 4) * math.pi * 2 + progress * 3
        local dist = hexRadius_ * progress * 1.2
        local px = fx.x + math.cos(angle) * dist
        local py = fx.y - progress * hexRadius_ * 1.5 + math.sin(angle) * dist * 0.3
        local pAlpha = math.floor((1.0 - progress) * 200)
        local pSize = 2.5 * (1.0 - progress)

        nvgBeginPath(vg)
        nvgRect(vg, px - pSize, py - pSize, pSize * 2, pSize * 2)
        nvgFillColor(vg, nvgRGBA(255, 220, 100, pAlpha))
        nvgFill(vg)
    end
end

--- 翻到空地：淡灰色收缩
function Client.RenderFlipEmptyEffect(vg, fx, progress)
    local radius = hexRadius_ * (1.0 - progress * 0.5)
    local alpha = math.floor((1.0 - progress) * 120)

    nvgBeginPath(vg)
    nvgCircle(vg, fx.x, fx.y, radius)
    nvgStrokeColor(vg, nvgRGBA(180, 180, 180, alpha))
    nvgStrokeWidth(vg, 1.5)
    nvgStroke(vg)
end

--- 建筑摧毁：爆炸粒子四散
function Client.RenderDestroyEffect(vg, fx, progress)
    -- 中心爆炸闪光
    local flashAlpha = 0
    if progress < 0.3 then
        flashAlpha = math.floor((1.0 - progress / 0.3) * 255)
    end
    if flashAlpha > 0 then
        nvgBeginPath(vg)
        nvgCircle(vg, fx.x, fx.y, hexRadius_ * (0.5 + progress))
        nvgFillColor(vg, nvgRGBA(255, 180, 50, flashAlpha))
        nvgFill(vg)
    end

    -- 四散碎片
    local numParticles = 8
    for i = 1, numParticles do
        local angle = (i / numParticles) * math.pi * 2 + fx.x * 0.1
        local speed = hexRadius_ * (1.0 + (i % 3) * 0.5)
        local dist = speed * progress
        local px = fx.x + math.cos(angle) * dist
        local py = fx.y + math.sin(angle) * dist + progress * progress * 20  -- 重力
        local pAlpha = math.floor((1.0 - progress) * 220)
        local pSize = 3.0 * (1.0 - progress * 0.6)

        -- 碎片颜色：橙→红渐变
        local r = math.min(255, 200 + math.floor(progress * 55))
        local g = math.max(0, math.floor(150 * (1.0 - progress)))

        nvgBeginPath(vg)
        nvgRect(vg, px - pSize / 2, py - pSize / 2, pSize, pSize)
        nvgFillColor(vg, nvgRGBA(r, g, 30, pAlpha))
        nvgFill(vg)
    end
end

--- 攻击火花：小闪光
function Client.RenderAttackEffect(vg, fx, progress)
    local alpha = math.floor((1.0 - progress) * 255)
    local radius = 4 * (1.0 - progress * 0.5)

    -- 十字闪光
    nvgBeginPath(vg)
    nvgMoveTo(vg, fx.x - radius * 2, fx.y)
    nvgLineTo(vg, fx.x + radius * 2, fx.y)
    nvgMoveTo(vg, fx.x, fx.y - radius * 2)
    nvgLineTo(vg, fx.x, fx.y + radius * 2)
    nvgStrokeColor(vg, nvgRGBA(255, 255, 200, alpha))
    nvgStrokeWidth(vg, 1.5 * (1.0 - progress))
    nvgStroke(vg)

    -- 中心点
    nvgBeginPath(vg)
    nvgCircle(vg, fx.x, fx.y, radius)
    nvgFillColor(vg, nvgRGBA(255, 255, 220, alpha))
    nvgFill(vg)
end

-- ============================================================================
-- 渲染
-- ============================================================================

function ClientHandleNanoVGRender(eventType, eventData)
    if not vg_ then return end

    -- 非战斗阶段不渲染战斗画面
    if gamePhase_ ~= "battle" then
        nvgBeginFrame(vg_, logicalW_, logicalH_, dpr_)
        nvgEndFrame(vg_)
        return
    end

    nvgBeginFrame(vg_, logicalW_, logicalH_, dpr_)

    -- 应用视口变换（缩放 + 平移）
    nvgSave(vg_)
    local vs = HexRenderer.GetViewScale()
    local fx, fy = HexRenderer.GetViewFocus()
    nvgTranslate(vg_, logicalW_ / 2, logicalH_ / 2)
    nvgScale(vg_, vs, vs)
    nvgTranslate(vg_, -fx, -fy)

    -- 0. 绘制背景（海洋渐变 + 浮空岛效果）
    HexRenderer.DrawBackground(vg_)

    -- 1. 绘制格子地图（含价格和类型图标）
    HexRenderer.DrawGrid(vg_, tileStates_, gridHexes_, highlightHex_, buildings_)

    -- 2. 绘制建筑血条
    HexRenderer.DrawBuildingHealthBars(vg_, buildings_)

    -- 3. 绘制城墙
    HexRenderer.DrawWalls(vg_, WallManager.GetSegments(1))
    HexRenderer.DrawWalls(vg_, WallManager.GetSegments(2))

    -- 4. 绘制单位
    HexRenderer.DrawUnits(vg_, units_)

    -- 5. 绘制视觉特效
    Client.RenderEffects(vg_)

    nvgRestore(vg_)  -- 恢复视口变换

    -- 6. 绘制提示消息
    if toastTimer_ > 0 and toastMsg_ ~= "" then
        local alpha = math.min(1.0, toastTimer_) * 255
        nvgFontFace(vg_, "sans")
        nvgFontSize(vg_, 16)
        nvgTextAlign(vg_, NVG_ALIGN_CENTER + NVG_ALIGN_MIDDLE)

        -- 背景
        nvgBeginPath(vg_)
        nvgRoundedRect(vg_, logicalW_ / 2 - 120, logicalH_ * 0.4 - 18, 240, 36, 10)
        nvgFillColor(vg_, nvgRGBA(20, 25, 40, math.floor(alpha * 0.9)))
        nvgFill(vg_)

        nvgFillColor(vg_, nvgRGBA(255, 240, 200, math.floor(alpha)))
        nvgText(vg_, logicalW_ / 2, logicalH_ * 0.4, toastMsg_)
    end

    nvgEndFrame(vg_)
end

-- ============================================================================
-- 输入
-- ============================================================================

---@param eventType string
---@param eventData MouseButtonDownEventData
function ClientHandleMouseDown(eventType, eventData)
    if gamePhase_ ~= "battle" then return end
    local button = eventData["Button"]:GetInt()
    if button ~= MOUSEB_LEFT then return end

    local x = eventData["X"]:GetInt() / dpr_
    local y = eventData["Y"]:GetInt() / dpr_
    dragActive_ = true
    dragStartX_ = x
    dragStartY_ = y
    dragTotalDist_ = 0
end

---@param eventType string
---@param eventData VariantMap
function ClientHandleMouseMove(eventType, eventData)
    if not dragActive_ then return end
    if gamePhase_ ~= "battle" then return end
    local dx = eventData["DX"]:GetInt() / dpr_
    local dy = eventData["DY"]:GetInt() / dpr_
    dragTotalDist_ = dragTotalDist_ + math.abs(dx) + math.abs(dy)
    if dragTotalDist_ > DRAG_THRESHOLD then
        HexRenderer.PanView(dx, dy)
    end
end

---@param eventType string
---@param eventData VariantMap
function ClientHandleMouseUp(eventType, eventData)
    if gamePhase_ ~= "battle" then
        dragActive_ = false
        return
    end
    if dragActive_ and dragTotalDist_ <= DRAG_THRESHOLD then
        -- 距离没超阈值 → 当作点击处理
        Client.HandleTapAt(dragStartX_, dragStartY_)
    end
    dragActive_ = false
end

---@param eventType string
---@param eventData TouchBeginEventData
function ClientHandleTouchBegin(eventType, eventData)
    if gamePhase_ ~= "battle" then return end
    local x = eventData["X"]:GetInt() / dpr_
    local y = eventData["Y"]:GetInt() / dpr_
    dragActive_ = true
    dragStartX_ = x
    dragStartY_ = y
    dragTotalDist_ = 0
end

---@param eventType string
---@param eventData VariantMap
function ClientHandleTouchMove(eventType, eventData)
    if not dragActive_ then return end
    if gamePhase_ ~= "battle" then return end
    local dx = eventData["DX"]:GetInt() / dpr_
    local dy = eventData["DY"]:GetInt() / dpr_
    dragTotalDist_ = dragTotalDist_ + math.abs(dx) + math.abs(dy)
    if dragTotalDist_ > DRAG_THRESHOLD then
        HexRenderer.PanView(dx, dy)
    end
end

---@param eventType string
---@param eventData VariantMap
function ClientHandleTouchEnd(eventType, eventData)
    if gamePhase_ ~= "battle" then
        dragActive_ = false
        return
    end
    if dragActive_ and dragTotalDist_ <= DRAG_THRESHOLD then
        Client.HandleTapAt(dragStartX_, dragStartY_)
    end
    dragActive_ = false
end

--- 双指缩放手势
---@param eventType string
---@param eventData VariantMap
function ClientHandleMultiGesture(eventType, eventData)
    if gamePhase_ ~= "battle" then return end
    local dDist = eventData["DDist"]:GetFloat()
    if math.abs(dDist) > 0.001 then
        local curScale = HexRenderer.GetViewScale()
        local newScale = curScale + dDist * 5.0
        HexRenderer.SetViewScale(newScale)
    end
end

--- 处理点击/触摸 —— 翻格子核心交互
---@param logicalX number
---@param logicalY number
function Client.HandleTapAt(logicalX, logicalY)
    if battlePhase_ ~= Shared.BATTLE_PHASE.PLAYING then return end

    -- 教程拦截：如果教程 overlay 消费了点击则返回
    if TutorialManager.HandleTap() then return end

    -- 检测格子点击
    local hex = HexRenderer.ScreenToHex(logicalX, logicalY)
    if not hex then
        highlightHex_ = nil
        return
    end

    local key = HexGrid.Key(hex.q, hex.r)
    local tile = tileStates_[key]
    if not tile then
        highlightHex_ = nil
        return
    end

    highlightHex_ = hex

    -- 翻格子！
    local success, msg = Client.TryFlipTile(key)
    if msg and msg ~= "" then
        Client.ShowToast(msg)
    end
end

-- ============================================================================
-- 单机模式：Server→Client 数据应用 + 新协议 Handler
-- ============================================================================

--- 将 Server 生成的地图数据直接应用到 Client（单机模式，共享内存）
---@param serverTiles table
---@param serverSpawns table
---@param serverBuildings table
function Client.ApplyMapData(serverTiles, serverSpawns, serverBuildings)
    -- 填充 tileStates
    for key, tile in pairs(serverTiles) do
        tileStates_[key] = {
            team = tile.team or 0,
            building = tile.building or 0,
            tileType = tile.tileType or "empty",
            price = tile.price or 0,
            flipped = tile.flipped or false,
            ruins = tile.ruins or false,
            barracksPrice = tile.barracksPrice or 0,
            fixedQuality = tile.fixedQuality or nil,
            boundCard = tile.boundCard or nil,
            slot = tile.slot or nil,  -- 2v2模式区分同队玩家归属
        }
    end

    -- 从 serverTiles 的所有 key 构建 gridHexes_ 列表
    gridHexes_ = {}
    local minQ, maxQ, minR, maxR = 0, 0, 0, 0
    for key, tile in pairs(serverTiles) do
        local q, r = HexGrid.FromKey(key)
        gridHexes_[#gridHexes_ + 1] = { q = q, r = r }
        if q < minQ then minQ = q end
        if q > maxQ then maxQ = q end
        if r < minR then minR = r end
        if r > maxR then maxR = r end
    end

    -- 缓存地图范围供其他模块使用
    minQ_, maxQ_, minR_, maxR_ = minQ, maxQ, minR, maxR

    -- 根据 gridHexes_ 的实际范围计算 cols/rows，调用 HexRenderer.SetupLayout
    local cols = maxQ - minQ + 1
    local rows = maxR - minR + 1
    HexRenderer.SetupLayout(logicalW_, logicalH_, cols, rows)

    -- 填充 targetHexes
    for _, spawn in ipairs(serverSpawns) do
        targetHexes_[spawn.slot] = { q = spawn.q, r = spawn.r, team = spawn.team }
    end

    -- 填充 buildings
    for key, b in pairs(serverBuildings) do
        buildings_[key] = b
    end

    -- 初始视口：居中到玩家主城位置
    local myBase = targetHexes_[localSlot_] or targetHexes_[1]
    if myBase then
        local radius = HexRenderer.GetRadius()
        local ox, oy = HexRenderer.GetOrigin()
        local baseX, baseY = HexGrid.ToPixel(myBase, radius, ox, oy)
        -- 应用 ViewTransform（team2 时翻转）
        baseX, baseY = ViewTransform.Apply(baseX, baseY, HexRenderer.GetMapSize())
        HexRenderer.CenterOnMapPoint(baseX, baseY)
    end
end

--- Server→Client: 接收 MapInit 全量地图数据（联机模式）
---@param eventType string
---@param eventData VariantMap
function ClientHandleMapInit(eventType, eventData)
    local mapJSON = eventData["MapJSON"]:GetString()
    local spawnsJSON = eventData["SpawnsJSON"]:GetString()
    battleTimer_ = eventData["Timer"]:GetFloat()

    local mapData = Shared.DeserializeMap(mapJSON)
    local spawns = Shared.DeserializeSpawns(spawnsJSON)

    Client.ApplyMapData(mapData, spawns, {})

    -- 联机模式：收到 MapInit 表示战斗正式开始
    if isOnlineMode_ then
        battlePhase_ = Shared.BATTLE_PHASE.PLAYING
        Client.ShowToast("战斗开始！")
    end
end

--- Server→Client: 接收 PlayerAssigned（联机模式）
---@param eventType string
---@param eventData VariantMap
function ClientHandlePlayerAssigned(eventType, eventData)
    local slot = eventData["Slot"]:GetInt()
    local team = eventData["Team"]:GetInt()
    localSlot_ = slot
    localTeam_ = team
    ViewTransform.SetLocalTeam(team)
    HexRenderer.SetLocalInfo(localSlot_, currentMode_)
end

--- Server→Client: 接收 BattleSync 增量同步
---@param eventType string
---@param eventData VariantMap
function ClientHandleBattleSync(eventType, eventData)
    battleTimer_ = eventData["Timer"]:GetFloat()

    -- 晶核同步：联机模式按本地 slot 取自己的独立资源
    if isOnlineMode_ then
        local slotSpiritsJSON = eventData["SlotSpiritsJSON"] and eventData["SlotSpiritsJSON"]:GetString() or ""
        if slotSpiritsJSON ~= "" then
            local ok, slotSpirits = pcall(require("cjson").decode, slotSpiritsJSON)
            if ok and slotSpirits then
                spiritStones_ = slotSpirits[tostring(localSlot_)] or slotSpirits[localSlot_] or spiritStones_
            end
        else
            local p1Spirit = eventData["P1Spirit"]:GetInt()
            local p2Spirit = eventData["P2Spirit"] and eventData["P2Spirit"]:GetInt() or 0
            spiritStones_ = (localTeam_ == 1) and p1Spirit or p2Spirit
        end
    else
        spiritStones_ = eventData["P1Spirit"]:GetInt()
    end

    -- 增量更新单位（联机模式下全量替换，单机模式下增量合并）
    local unitsJSON = eventData["UnitsJSON"]:GetString()
    if unitsJSON and unitsJSON ~= "" then
        local unitData = require("cjson").decode(unitsJSON)
        if isOnlineMode_ then
            -- 联机模式：Server权威，全量替换单位列表
            units_ = {}
            for _, uData in ipairs(unitData or {}) do
                local unit = UnitManager.CreateUnit(uData.owner or uData.team, uData.q, uData.r, uData.cardName or "风帆新兵", uData.cardLevel or 0, uData.slot)
                if unit then
                    unit.id = uData.id
                    unit.hp = uData.hp
                    unit.maxHp = uData.maxHp or unit.maxHp
                    unit.baseAtk = uData.baseAtk or unit.baseAtk
                    unit.baseSpd = uData.baseSpd or unit.baseSpd
                    unit.attack = uData.attack or unit.attack
                    unit.moveSpeed = uData.moveSpeed or unit.moveSpeed
                    unit.state = uData.state
                    unit.slot = uData.slot
                    units_[#units_ + 1] = unit
                end
            end
        else
            -- 单机模式：增量合并
            for _, uData in ipairs(unitData or {}) do
                for _, unit in ipairs(units_) do
                    if unit.id == uData.id then
                        unit.hp = uData.hp
                        unit.q = uData.q
                        unit.r = uData.r
                        unit.state = uData.state
                        break
                    end
                end
            end
        end
    end

    -- 建筑同步（联机模式下同步建筑HP等状态）
    local buildingsJSON = eventData["BuildingsJSON"]
    if buildingsJSON and isOnlineMode_ then
        local bData = require("cjson").decode(buildingsJSON:GetString())
        for key, bInfo in pairs(bData or {}) do
            local b = buildings_[key]
            if b then
                b.hp = bInfo.hp
                b.maxHp = bInfo.maxHp
            end
        end
    end

    -- 领地染色变更
    local territoryJSON = eventData["TerritoryChangesJSON"]
    if territoryJSON then
        local changes = require("cjson").decode(territoryJSON:GetString())
        for _, change in ipairs(changes or {}) do
            local tile = tileStates_[change.key]
            if tile then
                tile.team = change.team
                tile.slot = change.slot or tile.slot
            end
        end
    end
end

--- Server→Client: 接收 TileFlipped 翻格事件
---@param eventType string
---@param eventData VariantMap
function ClientHandleTileFlipped(eventType, eventData)
    local q = eventData["Q"]:GetInt()
    local r = eventData["R"]:GetInt()
    local team = eventData["Team"]:GetInt()
    local building = eventData["Building"]:GetInt()
    local slot = eventData["Slot"] and eventData["Slot"]:GetInt() or nil
    local tileType = eventData["TileType"]
    if type(tileType) == "userdata" then
        tileType = tileType:GetInt()
    elseif type(tileType) ~= "number" then
        ---@diagnostic disable-next-line: assign-type-mismatch
        tileType = 0
    end
    local newTilesJSON = eventData["NewTilesJSON"]:GetString()

    local key = HexGrid.Key(q, r)

    -- 根据 tileType 获取完整建筑信息（barracksPrice、fixedQuality）
    ---@diagnostic disable-next-line: param-type-mismatch
    local buildingType, buildingName, barracksPrice, fixedQuality = TileConfig.GetFlipResult(tileType)
    -- 如果 Server 下发了 building 类型，优先使用
    if building and building ~= GameConfig.BUILDING.NONE then
        buildingType = building
    end
    local revealedEmpty = (buildingType == GameConfig.BUILDING.NONE)
    if revealedEmpty then
        tileType = TileConfig.TILE_TYPE.EMPTY
        barracksPrice = 0
        fixedQuality = nil
    end

    tileStates_[key] = {
        team = team,
        building = buildingType,
        tileType = tileType,
        price = 0,
        flipped = true,
        ruins = false,
        slot = slot,
        revealedEmpty = revealedEmpty,
        barracksPrice = barracksPrice or 0,
        fixedQuality = fixedQuality,
    }

    if buildingType ~= GameConfig.BUILDING.NONE then
        buildings_[key] = BuildingManager.CreateInstance(tileStates_[key])
        WallManager.RebuildAll(buildings_, tileStates_)
    end

    -- 接收 Server 下发的新生成格子
    if newTilesJSON and newTilesJSON ~= "" then
        local newTiles = require("cjson").decode(newTilesJSON)
        for _, nt in ipairs(newTiles or {}) do
            local nkey = HexGrid.Key(nt.q, nt.r)
            if not tileStates_[nkey] then
                tileStates_[nkey] = {
                    team = team,
                    building = GameConfig.BUILDING.NONE,
                    tileType = nt.tileType,
                    price = nt.price,
                    flipped = false,
                    ruins = false,
                }
            end
        end
    end

    -- 刷新领地统计
    Client.UpdateStats()
end

--- Server→Client: 接收 BattleOver
---@param eventType string
---@param eventData VariantMap
function ClientHandleBattleOver(eventType, eventData)
    local winner = eventData["Winner"]:GetInt()
    local isDraw = eventData["IsDraw"] and eventData["IsDraw"]:GetBool() or false

    if isOnlineMode_ then
        -- 联机模式：根据 Server 判定的胜负结果结束战斗
        local result
        if isDraw then
            result = "draw"
        elseif winner == localTeam_ then
            result = "victory"
        else
            result = "defeat"
        end
        Client.EndBattle(result)
    else
        -- 单机模式：根据 winner 判定
        local result
        if winner == 0 then
            result = "draw"
        elseif winner == localTeam_ then
            result = "victory"
        else
            result = "defeat"
        end
        Client.EndBattle(result)
    end
end

return Client


-- ══════════════════════════════════════════════
