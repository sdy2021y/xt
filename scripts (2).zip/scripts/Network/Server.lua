-- ============================================================================
-- Server.lua - 服务端游戏逻辑（完整版）
-- 权威服务器：运行完整战斗模拟，包括建筑生产、单位出兵、战斗结算
-- 格子模型：team(归属) + flipped(已翻) + ruins(残骸)，无 state 枚举
-- ============================================================================

-- 服务端框架注入的全局变量（LSP 类型声明）
---@type integer
SERVER_MAX_PLAYERS = SERVER_MAX_PLAYERS or 2
---@type integer
SERVER_REGISTERED_PLAYERS = SERVER_REGISTERED_PLAYERS or 2
---@type integer
SERVER_TICK_RATE = SERVER_TICK_RATE or 30
SERVER_AI_DECKS = SERVER_AI_DECKS or {}

local GameConfig = require("Config.GameConfig")
local Shared = require("Network.Shared")
local HexGrid = require("Battle.HexGrid")
local BuildingManager = require("Battle.BuildingManager")
local UnitManager = require("Battle.UnitManager")
local UnitConfig = require("Config.UnitConfig")
local SynergyManager = require("Battle.SynergyManager")
local SkillEngine = require("Battle.SkillEngine")
local TileConfig = require("Config.TileConfig")
local DeckManager = require("Battle.DeckManager")
local MapConfig = require("Config.MapConfig")

local SpawnConfig = require("Config.SpawnConfig")

local Server = {}

-- 服务器状态
local battlePhase_ = Shared.BATTLE_PHASE.WAITING
local battleTimer_ = 0
local currentMode_ = (SERVER_MAX_PLAYERS == 4) and "2v2" or "1v1"  -- 当前对战模式
local maxPlayers_ = SERVER_MAX_PLAYERS or 2       -- 当前模式最大玩家数（1v1=2, 2v2=4）
local players_ = {}  -- { [connectionIdx] = playerData }
local tileStates_ = {}  -- { [key] = { team, building, tileType, price, flipped, ruins } }
local gridHexes_ = {}   -- 所有格子坐标列表

-- 战斗系统实例（服务端权威）
local buildings_ = {}    -- { [hexKey] = buildingInstance }
local units_ = {}        -- { unit, unit, ... }
local targetHexes_ = {}  -- { [slot] = {q, r, team} } 各方核心坐标

-- 出生点数据
local spawnData_ = {}  -- { {slot, team, q, r}, ... }
local mapInitSent_ = false  -- MapInit 是否已发送

-- 地图边界集合（异形地图防止越界生长）
local hexSet_ = {}  -- { [key] = true } 所有合法格子集合

-- 当前使用的地图模板ID
local currentTemplateId_ = "rect_classic"

-- 领地染色变更队列（下次 sync 时批量下发）
local territoryChanges_ = {}  -- { {key, team}, ... }

-- 同步累计器（减少网络包）
local syncAccumulator_ = 0
local SYNC_INTERVAL = 0.1  -- 100ms 同步一次

-- 残骸计时器：{ [hexKey] = { timer = number, owner = integer } }
local ruins_ = {}
local RUIN_DURATION = 8.0  -- 8秒残骸期
local aiSlotState_ = {} -- { [slot] = { timer, startDelay } }
local AI_ACTION_COOLDOWN = 3.0

-- ============================================================================
-- 生命周期
-- ============================================================================

function Server.Start()
    -- 注册远程事件
    network:RegisterRemoteEvent("FlipTile")
    network:RegisterRemoteEvent("PlayerReady")
    network:RegisterRemoteEvent("PlayerAssigned")

    -- 初始化格子地图
    Server.InitGrid(maxPlayers_, 2)

    -- 订阅事件
    SubscribeToEvent("Update", "ServerHandleUpdate")
    SubscribeToEvent("ClientConnected", "ServerHandleClientConnected")
    SubscribeToEvent("ClientDisconnected", "ServerHandleClientDisconnected")
    SubscribeToEvent("FlipTile", "ServerHandleFlipTile")
    SubscribeToEvent("PlayerReady", "ServerHandlePlayerReady")
end

function Server.Stop()
    buildings_ = {}
    units_ = {}
    tileStates_ = {}
    players_ = {}
    targetHexes_ = {}
    spawnData_ = {}
    territoryChanges_ = {}
    ruins_ = {}
    aiSlotState_ = {}
    mapInitSent_ = false
    maxPlayers_ = SERVER_MAX_PLAYERS or 2
    currentMode_ = (maxPlayers_ == 4) and "2v2" or "1v1"
end

-- ============================================================================
-- 地图生成（Server 唯一权威）
-- ============================================================================

--- 初始化格子地图（服务端唯一权威生成）
---@param playerCount? integer 玩家总数（默认2）
---@param teamCount? integer 队伍数（默认2）
---@param templateId? string 地图模板ID（nil=随机）
function Server.InitGrid(playerCount, teamCount, templateId)
    playerCount = playerCount or 2
    teamCount = teamCount or 2
    buildings_ = {}
    units_ = {}
    tileStates_ = {}
    targetHexes_ = {}
    ruins_ = {}
    aiSlotState_ = {}
    territoryChanges_ = {}

    -- 选择地图模板
    templateId = templateId or MapConfig.RandomTemplate(playerCount)
    currentTemplateId_ = templateId
    print("[Server] Using map template: " .. templateId)

    -- 生成地图数据
    local mapData = MapConfig.Generate(templateId, playerCount, teamCount)
    gridHexes_ = mapData.hexes
    spawnData_ = mapData.spawns
    local bounds = mapData.bounds

    -- 构建合法格子集合（异形地图边界控制）
    hexSet_ = {}
    for _, hex in ipairs(gridHexes_) do
        hexSet_[HexGrid.Key(hex.q, hex.r)] = true
    end

    -- 初始化所有格子（随机 tileType + 领地归属）
    for _, hex in ipairs(gridHexes_) do
        local key = HexGrid.Key(hex.q, hex.r)

        -- 确定所属队伍
        local team = 0
        if bounds[1] and bounds[1].startRow ~= nil then
            -- 矩形类模板：按行索引判断
            local rOffset = -math.floor(hex.q / 2)
            local rowIndex = hex.r - rOffset
            for t, bound in pairs(bounds) do
                if rowIndex >= bound.startRow and rowIndex <= bound.endRow then
                    team = t
                    break
                end
            end
        else
            -- 菱形等特殊模板：按 r 坐标正负判断
            if hex.r > 0 then team = 1
            elseif hex.r < 0 then team = 2
            end
        end

        -- 随机格子类型
        local tileType = TileConfig.RandomTileTypeByWeight(nil)

        tileStates_[key] = {
            team = team,
            building = GameConfig.BUILDING.NONE,
            tileType = tileType,
            price = TileConfig.GetPrice(tileType),
            flipped = false,
            ruins = false,
        }
    end

    -- 放置核心
    for _, spawn in ipairs(spawnData_) do
        local key = HexGrid.Key(spawn.q, spawn.r)
        tileStates_[key] = {
            team = spawn.team,
            building = GameConfig.BUILDING.MAIN_BASE,
            tileType = "main_base",
            price = 0,
            flipped = true,
            ruins = false,
            slot = spawn.slot,
        }
        targetHexes_[spawn.slot] = { q = spawn.q, r = spawn.r, team = spawn.team }
        buildings_[key] = BuildingManager.CreateInstance(tileStates_[key])
    end

    -- 核心周围生成初始 tile（GDD规则：必有矿脉+兵营）
    for _, spawn in ipairs(spawnData_) do
        Server.SpawnInitialTiles(spawn.slot, spawn.team, { q = spawn.q, r = spawn.r })
    end
end

--- 核心周围生成初始 tile（每方必含1矿脉+1兵营，邻居不翻开，让玩家/AI自己翻）
---@param slot integer
---@param team integer
---@param baseHex table {q, r}
function Server.SpawnInitialTiles(slot, team, baseHex)
    local neighbors = HexGrid.Neighbors(baseHex)
    local placed = {}

    for _, nh in ipairs(neighbors) do
        local key = HexGrid.Key(nh.q, nh.r)
        if tileStates_[key] and not tileStates_[key].flipped then
            placed[#placed + 1] = { q = nh.q, r = nh.r, key = key }
        end
    end

    -- 确保至少1矿脉+1兵营，邻居格子不翻开，不放建筑，不设 team
    local minePlaced, barracksPlaced = false, false
    for _, p in ipairs(placed) do
        if not minePlaced then
            tileStates_[p.key].tileType = TileConfig.TILE_TYPE.SPIRIT_MINE
            tileStates_[p.key].price = TileConfig.GetPrice(TileConfig.TILE_TYPE.SPIRIT_MINE)
            minePlaced = true
        elseif not barracksPlaced then
            tileStates_[p.key].tileType = TileConfig.TILE_TYPE.BARRACKS_50
            tileStates_[p.key].price = TileConfig.GetPrice(TileConfig.TILE_TYPE.BARRACKS_50)
            barracksPlaced = true
        end
        -- 其余邻居保持随机类型，不翻开，不放建筑，不设 team
    end
end

--- 翻格后生成周围新格子（Server 权威，事件驱动下发）
--- 异形地图：只在 hexSet_ 边界内生成，防止越界生长
--- 注意：当前 InitGrid 已为所有模板 hex 创建了 tileStates_，因此此函数为空操作。
--- 未来如需迷雾逐步展开机制，可改为增量生成（InitGrid 只创建核心周围1格）。
---@param q integer
---@param r integer
---@param team integer
---@return table[] newTiles
function Server.SpawnAdjacentTiles(q, r, team)
    local neighbors = HexGrid.Neighbors({ q = q, r = r })
    local newTiles = {}

    for _, nh in ipairs(neighbors) do
        local key = HexGrid.Key(nh.q, nh.r)
        -- 只在地图边界内且尚未生成的格子才创建
        if not tileStates_[key] and hexSet_[key] then
            local tileType = TileConfig.RandomTileTypeByWeight(nil)
            tileStates_[key] = {
                team = team,
                building = GameConfig.BUILDING.NONE,
                tileType = tileType,
                price = TileConfig.GetPrice(tileType),
                flipped = false,
                ruins = false,
            }
            newTiles[#newTiles + 1] = {
                q = nh.q, r = nh.r,
                key = key,
                tileType = tileType,
                price = TileConfig.GetPrice(tileType),
            }
        end
    end

    return newTiles
end

-- ============================================================================
-- 翻格条件（相邻我方建筑即可翻，不再限制领地）
-- ============================================================================

--- 判断某格子是否可以被某队伍翻开
--- 规则：相邻己方已翻开的格子即可翻（空地也算扩展源）
--- 兵经过染色不算！只有已翻开的领地格才是扩展源
--- 2v2模式：slot 不为 nil 时，只能从自己 slot 的格子扩展
---@param hex table {q, r}
---@param team integer
---@param slot integer|nil 2v2模式传入玩家slot
---@return boolean
function Server.CanFlip(hex, team, slot)
    local neighbors = HexGrid.Neighbors(hex)
    for _, nh in ipairs(neighbors) do
        local key = HexGrid.Key(nh.q, nh.r)
        local tile = tileStates_[key]
        -- 相邻格子必须：己方 + 已翻开（空地也可作为扩展源）
        if tile and tile.team == team and tile.flipped then
            if not slot then
                return true
            end
            -- 2v2模式：检查 slot 归属（tile.slot 必须精确匹配，无 fallback）
            if tile.slot == slot then
                return true
            end
        end
    end
    return false
end

-- ============================================================================
-- 领地染色（单位经过改变格子颜色）
-- ============================================================================

--- 单位移动到新格子时调用
---@param unit table 单位实例
---@param newHex table {q, r} 新位置
function Server.OnUnitEnterHex(unit, newHex)
    local key = HexGrid.Key(newHex.q, newHex.r)
    local tile = tileStates_[key]
    if tile then
        local oldTeam = tile.team
        if oldTeam ~= unit.team then
            -- 不改变有敌方建筑的格子颜色（敌方建筑必须摧毁）
            if tile.building and tile.building ~= GameConfig.BUILDING.NONE and tile.team ~= unit.team then
                return
            end
            tile.team = unit.team
            territoryChanges_[#territoryChanges_ + 1] = { key = key, team = unit.team }
        end
    end
end

--- 领地染色变更入队
---@param key string
---@param team integer
function Server.QueueTerritoryChange(key, team, slot)
    territoryChanges_[#territoryChanges_ + 1] = { key = key, team = team, slot = slot }
end

-- ============================================================================
-- 胜利条件（1v1 / 2v2 统一）
-- ============================================================================

--- 检查即时胜利：敌方队伍所有建筑全灭
---@return integer|nil winnerTeam 1或2，nil表示未决出
function Server.CheckVictory()
    local teamBuildings = { [1] = 0, [2] = 0 }
    for key, _ in pairs(buildings_) do
        local tile = tileStates_[key]
        if tile and tile.team and tile.team > 0 then
            teamBuildings[tile.team] = (teamBuildings[tile.team] or 0) + 1
        end
    end

    if teamBuildings[2] == 0 then return 1 end  -- 队伍2全灭 → 队伍1赢
    if teamBuildings[1] == 0 then return 2 end  -- 队伍1全灭 → 队伍2赢
    return nil
end

--- 倒计时结束：按领地格数判定胜负
---@return integer winnerTeam 1或2，0=平局
function Server.CheckTerritoryWinner()
    local teamTiles = { [1] = 0, [2] = 0 }
    for _, tile in pairs(tileStates_) do
        if tile.team and tile.team > 0 then
            teamTiles[tile.team] = (teamTiles[tile.team] or 0) + 1
        end
    end

    if teamTiles[1] > teamTiles[2] then return 1
    elseif teamTiles[2] > teamTiles[1] then return 2
    else return 0 end  -- 0 = 平局
end

-- ============================================================================
-- 寻敌（动态最近敌方建筑 + 优先级）
-- ============================================================================

--- 找最近的敌方建筑（同距离按优先级）
---@param hex table {q, r} 当前位置
---@param ownerTeam integer 己方队伍
---@return table|nil target {q, r, key, buildingType}
function Server.FindNearestEnemyBuilding(hex, ownerTeam)
    local bestTarget = nil
    local bestDist = math.huge
    local bestPriority = math.huge

    for key, building in pairs(buildings_) do
        local tile = tileStates_[key]
        if tile and tile.team ~= ownerTeam and tile.team > 0 then
            local bq, br = HexGrid.FromKey(key)
            local dist = HexGrid.Distance({ q = hex.q, r = hex.r }, { q = bq, r = br })
            local priority = GameConfig.ATTACK_PRIORITY[tile.building] or 99

            if dist < bestDist or (dist == bestDist and priority < bestPriority) then
                bestDist = dist
                bestPriority = priority
                bestTarget = { q = bq, r = br, key = key, buildingType = tile.building }
            end
        end
    end

    return bestTarget
end

-- ============================================================================
-- 事件处理
-- ============================================================================

---@param eventType string
---@param eventData UpdateEventData
function ServerHandleUpdate(eventType, eventData)
    if battlePhase_ ~= Shared.BATTLE_PHASE.PLAYING then
        return
    end

    local dt = eventData["TimeStep"]:GetFloat()
    battleTimer_ = battleTimer_ - dt

    -- ====== 完整战斗模拟 ======
    Server.UpdateAISlots(dt)

    -- 定义回调函数
    local function onSpiritGain(owner, amount, slot)
        local player = players_[slot or owner]
        if player then
            player.spiritStones = player.spiritStones + amount
        end
    end

    local function onUnitSpawn(owner, hexKey, barracksPrice, fixedQuality)
        -- 服务端产兵逻辑
        local maxPop = GameConfig.MAX_POPULATION
        local building = buildings_[hexKey]
        local slot = building and building.slot or owner
        local currentPop = UnitManager.CountPopulationBySlot(units_, slot)
        if currentPop >= maxPop then return end

        local bq, br = HexGrid.FromKey(hexKey)
        local cardName, cardLevel

        if building and building.boundCard then
            -- 使用绑定的卡牌
            cardName = building.boundCard.cardName
            cardLevel = building.boundCard.cardLevel
        else
            -- 兜底：随机抽卡
            cardName, cardLevel = DeckManager.RollCard(slot, barracksPrice, fixedQuality)
        end

        if not cardName then return end

        local card = UnitConfig.CARDS[cardName]
        if card and (currentPop + (card.pop or 1)) > maxPop then return end

        local unit = UnitManager.CreateUnit(owner, bq, br, cardName, cardLevel or 0, slot)
        if unit then
            units_[#units_ + 1] = unit
        end
    end

    local function summonCallback(owner, q, r, cardName, cardLevel)
        local params = type(cardName) == "table" and cardName or { cardName = cardName, cardLevel = cardLevel }
        local summonId = params.cardName or params.unitId
        local fallbackCards = {
            ["_幼翼"] = "翼族斥候",
            ["_分身"] = "翼族斥候",
            ["_自爆机"] = "自爆机",
            ["_机甲兵"] = "蒸汽战犬",
            ["_revived"] = "风帆新兵",
        }
        local resolvedCard = UnitConfig.CARDS[summonId] and summonId or fallbackCards[summonId] or "风帆新兵"
        local count = math.max(1, params.count or 1)

        for _ = 1, count do
            local unit = UnitManager.CreateUnit(owner, q, r, resolvedCard, params.cardLevel or cardLevel or 0, params.slot or owner)
            if unit then
                if params.hp then
                    unit.maxHp = params.hp
                    unit.hp = params.hp
                elseif params.hpPercent then
                    unit.maxHp = math.max(1, math.floor(unit.maxHp * params.hpPercent))
                    unit.hp = unit.maxHp
                end
                if params.atk then
                    unit.baseAtk = params.atk
                    unit.attack = params.atk
                elseif params.atkPercent then
                    unit.baseAtk = math.max(1, math.floor(unit.baseAtk * params.atkPercent))
                    unit.attack = unit.baseAtk
                end
                unit._summonDuration = params.duration
                units_[#units_ + 1] = unit
            end
        end
    end

    local function onTileCapture(owner, hexKey, slot)
        local tile = tileStates_[hexKey]
        if tile then
            tile.team = owner
            tile.slot = slot or tile.slot
            tile.ruins = false
        end
        -- 领地染色同步
        Server.QueueTerritoryChange(hexKey, owner, slot)
    end

    -- 1. 建筑更新：矿脉产晶核、兵营产兵、炮台攻击
    BuildingManager.Update(buildings_, tileStates_, dt, onSpiritGain, onUnitSpawn, units_)

    -- 2. 单位更新：移动、寻敌、攻击、死亡
    UnitManager.Update(units_, tileStates_, buildings_, dt, targetHexes_, onTileCapture, onSpiritGain, summonCallback)

    -- 3. 处理被摧毁的建筑（HP <= 0）
    for hexKey, inst in pairs(buildings_) do
        if inst.hp <= 0 then
            local tile = tileStates_[hexKey]
            if tile then
                local destroyer = inst.lastAttackerTeam or ((inst.owner == 1) and 2 or 1)
                tile.team = destroyer
                tile.slot = inst.lastAttackerSlot or tile.slot
                tile.flipped = true
                tile.building = GameConfig.BUILDING.NONE
                tile.ruins = true
                -- 启动残骸计时器
                ruins_[hexKey] = { timer = RUIN_DURATION, owner = destroyer }
            end
            Server.QueueTerritoryChange(hexKey, inst.lastAttackerTeam or ((inst.owner == 1) and 2 or 1), inst.lastAttackerSlot)
            buildings_[hexKey] = nil
        end
    end

    -- 3.5 更新残骸计时器
    local ruinChanged = false
    for hexKey, ruin in pairs(ruins_) do
        ruin.timer = ruin.timer - dt
        if ruin.timer <= 0 then
            local tile = tileStates_[hexKey]
            if tile then
                tile.ruins = false
            end
            ruins_[hexKey] = nil
            ruinChanged = true
        end
    end

    -- 4. 同步状态到客户端
    if not mapInitSent_ then
        Server.SendMapInit()
        mapInitSent_ = true
    end

    syncAccumulator_ = syncAccumulator_ + dt
    if syncAccumulator_ >= SYNC_INTERVAL then
        syncAccumulator_ = 0
        Server.SyncBattleState()
    end

    -- 5. 检查胜负
    if battleTimer_ <= 0 then
        battleTimer_ = 0
        Server.EndBattle()
    else
        Server.CheckWinCondition()
    end
end

function Server.EnsureAISlots()
    local registered = math.min(SERVER_REGISTERED_PLAYERS or maxPlayers_, maxPlayers_)
    for slot = registered + 1, maxPlayers_ do
        if not players_[slot] then
            local team = (slot <= maxPlayers_ / 2) and 1 or 2
            players_[slot] = {
                connection = nil,
                playerIndex = slot,
                team = team,
                spiritStones = GameConfig.STARTING_SPIRIT_STONES,
                population = 0,
                materials = 0,
                ready = true,
                isAI = true,
                deck = SERVER_AI_DECKS[slot] or DeckManager.DEFAULT_AI_DECK,
            }
            aiSlotState_[slot] = { timer = 0, startDelay = 1.0 + slot * 0.5 }
            print("[Server] AI filled slot " .. slot .. " team " .. team)
        end
    end
end

function Server.ServerFlipTileForPlayer(playerIdx, q, r)
    local player = players_[playerIdx]
    if not player then return false end

    local key = HexGrid.Key(q, r)
    local tile = tileStates_[key]
    if not tile or tile.flipped or tile.ruins then return false end
    if tile.team ~= player.team then return false end
    if tile.tileType == TileConfig.TILE_TYPE.EMPTY then return false end
    if tile.building ~= GameConfig.BUILDING.NONE then return false end

    local slotCheck = (currentMode_ == "2v2") and player.playerIndex or nil
    if not Server.CanFlip({ q = q, r = r }, player.team, slotCheck) then return false end
    if player.spiritStones < tile.price then return false end

    player.spiritStones = player.spiritStones - tile.price
    tile.flipped = true
    tile.team = player.team
    tile.slot = player.playerIndex

    local buildingType, buildingName, barracksPrice, fixedQuality = TileConfig.GetFlipResult(tile.tileType)
    tile.building = buildingType
    tile.barracksPrice = barracksPrice or 0
    tile.fixedQuality = fixedQuality
    if buildingType == GameConfig.BUILDING.NONE then
        tile.tileType = TileConfig.TILE_TYPE.EMPTY
        tile.revealedEmpty = true
        tile.barracksPrice = 0
        tile.fixedQuality = nil
    end

    if buildingType ~= GameConfig.BUILDING.NONE then
        if buildingType == GameConfig.BUILDING.BARRACKS then
            local quality = fixedQuality or DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(player.playerIndex, "unit", quality)
            if cardName then tile.boundCard = { cardName = cardName, cardLevel = cardLevel } end
        elseif buildingType == GameConfig.BUILDING.SPIRIT_MINE then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(player.playerIndex, "mine", quality)
            if cardName then tile.boundCard = { cardName = cardName, cardLevel = cardLevel } end
        elseif buildingType == GameConfig.BUILDING.TOWER or buildingType == GameConfig.BUILDING.ELITE_TOWER then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(player.playerIndex, "tower", quality)
            if cardName then tile.boundCard = { cardName = cardName, cardLevel = cardLevel } end
        end

        buildings_[key] = BuildingManager.CreateInstance(tile)
    end

    if tile.building == GameConfig.BUILDING.SPIRIT_MINE then
        player.spiritStones = player.spiritStones + GameConfig.TILE_MINE_BONUS
    end

    local newTiles = Server.SpawnAdjacentTiles(q, r, player.team)
    local syncData = VariantMap()
    syncData["Q"] = Variant(q)
    syncData["R"] = Variant(r)
    syncData["PlayerIdx"] = Variant(playerIdx)
    syncData["Team"] = Variant(tile.team)
    syncData["Slot"] = Variant(tile.slot or 0)
    syncData["Building"] = Variant(tile.building)
    syncData["TileType"] = Variant(tile.tileType or "")
    syncData["BuildingName"] = Variant(buildingName or "")
    syncData["SpiritStones"] = Variant(player.spiritStones)
    syncData["NewTilesJSON"] = Variant(require("cjson").encode(newTiles))
    network:BroadcastRemoteEvent("TileFlipped", true, syncData)
    return true
end

function Server.UpdateAISlots(dt)
    for slot, player in pairs(players_) do
        if player.isAI and battlePhase_ == Shared.BATTLE_PHASE.PLAYING then
            local state = aiSlotState_[slot] or { timer = 0, startDelay = 1.0 }
            aiSlotState_[slot] = state
            state.timer = state.timer + dt
            if state.timer >= (state.startDelay or 0) + AI_ACTION_COOLDOWN then
                local choices = {}
                for _, hex in ipairs(gridHexes_) do
                    local key = HexGrid.Key(hex.q, hex.r)
                    local tile = tileStates_[key]
                    if tile
                        and not tile.flipped
                        and not tile.ruins
                        and tile.team == player.team
                        and tile.tileType ~= TileConfig.TILE_TYPE.EMPTY
                        and tile.building == GameConfig.BUILDING.NONE
                        and tile.price <= player.spiritStones
                        and Server.CanFlip(hex, player.team, (currentMode_ == "2v2") and slot or nil) then
                        choices[#choices + 1] = hex
                    end
                end
                if #choices > 0 then
                    local chosen = choices[math.random(1, #choices)]
                    if Server.ServerFlipTileForPlayer(slot, chosen.q, chosen.r) then
                        state.timer = state.startDelay or 0
                    end
                end
            end
        end
    end
end

function ServerHandleClientConnected(eventType, eventData)
    local connection = eventData["Connection"]:GetPtr("Connection")
    if not connection then return end

    local idx = 0
    for i = 1, maxPlayers_ do
        if not players_[i] then
            idx = i
            break
        end
    end

    if idx == 0 then return end  -- 已满

    -- 2v2队伍分配：1,2号→team1，3,4号→team2
    local team = (idx <= maxPlayers_ / 2) and 1 or 2

    players_[idx] = {
        connection = connection,
        playerIndex = idx,
        team = team,
        spiritStones = GameConfig.STARTING_SPIRIT_STONES,
        population = 0,
        materials = 0,
        ready = false,
        deck = {},
    }

    -- 通知客户端分配的 slot 和 team
    local assignData = VariantMap()
    assignData["Slot"] = Variant(idx)
    assignData["Team"] = Variant(team)
    connection:SendRemoteEvent("PlayerAssigned", true, assignData)

    -- 只分配座位；战斗启动统一由 PlayerReady 触发，确保卡组已上传
end

function ServerHandleClientDisconnected(eventType, eventData)
    local connection = eventData["Connection"]:GetPtr("Connection")
    if not connection then return end

    local disconnectedIdx = 0
    for idx, player in pairs(players_) do
        if player.connection == connection then
            disconnectedIdx = idx
            break
        end
    end

    if disconnectedIdx == 0 then return end

    print("[Server] Player " .. disconnectedIdx .. " disconnected")

    if battlePhase_ == Shared.BATTLE_PHASE.PLAYING then
        -- 断线方的队友判定为输，对方队伍赢
        local disconnectedTeam = players_[disconnectedIdx].team
        local winnerTeam = (disconnectedTeam == 1) and 2 or 1

        battlePhase_ = Shared.BATTLE_PHASE.ENDED

        local endData = VariantMap()
        endData["Winner"] = Variant(winnerTeam)
        endData["P1Count"] = Variant(0)
        endData["P2Count"] = Variant(0)
        endData["DisconnectWin"] = Variant(true)
        endData["Mode"] = Variant(currentMode_)
        network:BroadcastRemoteEvent("BattleEnd", true, endData)
    end

    players_[disconnectedIdx] = nil
end

function ServerHandleFlipTile(eventType, eventData)
    local q = eventData["Q"]:GetInt()
    local r = eventData["R"]:GetInt()
    local connection = eventData["Connection"]
    if not connection then
        print("[Server] FlipTile: missing connection")
        return
    end

    local conn = type(connection) == "userdata" and connection:GetPtr("Connection") or connection
    local playerIdx = nil
    for idx, player in pairs(players_) do
        if player.connection == conn then
            playerIdx = idx
            break
        end
    end
    if not playerIdx then
        print("[Server] FlipTile: unknown connection")
        return
    end

    local key = HexGrid.Key(q, r)
    local tile = tileStates_[key]

    if not tile then
        print("[Server] Invalid tile: " .. key)
        return
    end

    if tile.flipped then
        print("[Server] Tile already revealed: " .. key)
        return
    end

    local player = players_[playerIdx]
    if not player then return end

    -- 检查：目标格子必须是该玩家所属队伍的领地（全局规则，所有模式通用）
    if tile.team ~= player.team then
        print("[Server] Not your territory: " .. key)
        return
    end

    -- 翻格条件：相邻我方建筑即可翻（2v2需检查slot归属）
    local slotCheck = (currentMode_ == "2v2") and player.playerIndex or nil
    if not Server.CanFlip({ q = q, r = r }, player.team, slotCheck) then
        print("[Server] Must be adjacent to your revealed tile")
        return
    end

    if player.spiritStones < tile.price then
        print("[Server] Not enough spirit stones")
        return
    end

    -- 扣除本 slot 晶核，翻开格子
    player.spiritStones = player.spiritStones - tile.price
    tile.flipped = true
    tile.team = player.team  -- 翻格 = 占领（即使原来是敌方领地）
    tile.slot = player.playerIndex  -- 标记归属槽位（2v2区分同队玩家）

    -- 使用 TileConfig 的翻格逻辑获取建筑类型
    local buildingType, buildingName, barracksPrice, fixedQuality = TileConfig.GetFlipResult(tile.tileType)
    tile.building = buildingType
    tile.barracksPrice = barracksPrice or 0
    tile.fixedQuality = fixedQuality
    if buildingType == GameConfig.BUILDING.NONE then
        tile.tileType = TileConfig.TILE_TYPE.EMPTY
        tile.revealedEmpty = true
        tile.barracksPrice = 0
        tile.fixedQuality = nil
    end

    -- 所有建筑统一流程：先 ROLL 品质，再从卡组匹配该品质的卡，绑定
    if buildingType ~= GameConfig.BUILDING.NONE then
        local owner = player.team
        if buildingType == GameConfig.BUILDING.BARRACKS then
            local quality = fixedQuality or DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(player.playerIndex, "unit", quality)
            if cardName then
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        elseif buildingType == GameConfig.BUILDING.SPIRIT_MINE then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(player.playerIndex, "mine", quality)
            if cardName then
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        elseif buildingType == GameConfig.BUILDING.TOWER or buildingType == GameConfig.BUILDING.ELITE_TOWER then
            local quality = DeckManager.RollQuality(barracksPrice or 50)
            local cardName, cardLevel = DeckManager.SelectRandomCardWithFallback(player.playerIndex, "tower", quality)
            if cardName then
                tile.boundCard = { cardName = cardName, cardLevel = cardLevel }
            end
        end

        buildings_[key] = BuildingManager.CreateInstance(tile)
    end

    -- 如果是矿脉，给当前 slot 回馈晶核加成
    if tile.building == GameConfig.BUILDING.SPIRIT_MINE then
        player.spiritStones = player.spiritStones + GameConfig.TILE_MINE_BONUS
    end

    -- 广播翻格结果给所有客户端（含新生成的周围格子）
    local newTiles = Server.SpawnAdjacentTiles(q, r, player.team)

    local syncData = VariantMap()
    syncData["Q"] = Variant(q)
    syncData["R"] = Variant(r)
    syncData["PlayerIdx"] = Variant(playerIdx)
    syncData["Team"] = Variant(tile.team)
    syncData["Slot"] = Variant(tile.slot or 0)
    syncData["Building"] = Variant(tile.building)
    syncData["TileType"] = Variant(tile.tileType or "")
    syncData["BuildingName"] = Variant(buildingName or "")
    syncData["SpiritStones"] = Variant(player.spiritStones)
    syncData["NewTilesJSON"] = Variant(require("cjson").encode(newTiles))
    network:BroadcastRemoteEvent("TileFlipped", true, syncData)
end

function ServerHandlePlayerReady(eventType, eventData)
    -- 接收客户端发送的模式信息
    local mode = eventData["Mode"]
    if mode and type(mode) == "userdata" then
        mode = mode:GetString()
    end
    if mode and (mode == "1v1" or mode == "2v2") then
        Server.SetMode(mode)
    end

    -- 接收客户端发送的卡组（通过连接匹配玩家，而非PlayerIdx）
    local deckJSON = eventData["Deck"]
    if deckJSON and type(deckJSON) == "userdata" then
        deckJSON = deckJSON:GetString()
    end
    if deckJSON and deckJSON ~= "" then
        local ok, deck = pcall(require("cjson").decode, deckJSON)
        if ok and deck then
            -- 找到发送此事件的玩家（通过连接对象匹配）
            local connection = eventData["Connection"]
            if connection then
                local conn = type(connection) == "userdata" and connection:GetPtr("Connection") or connection
                for idx, player in pairs(players_) do
                    if player.connection == conn then
                        player.deck = deck
                        player.ready = true
                        break
                    end
                end
            else
                -- 兜底：如果无法获取连接，用 PlayerIdx
                local playerIdx = eventData["PlayerIdx"]
                if playerIdx and type(playerIdx) == "userdata" then
                    playerIdx = playerIdx:GetInt()
                end
                if playerIdx and players_[playerIdx] then
                    players_[playerIdx].deck = deck
                    players_[playerIdx].ready = true
                end
            end
        end
    end

    Server.TryStartBattle()
end

-- ============================================================================
-- 战斗流程
-- ============================================================================

function Server.TryStartBattle()
    if battlePhase_ ~= Shared.BATTLE_PHASE.WAITING then return end

    Server.EnsureAISlots()

    -- 检查所有必需玩家是否已连接并准备
    for i = 1, maxPlayers_ do
        if not players_[i] or not players_[i].ready then return end
    end

    for i = 1, maxPlayers_ do
        local player = players_[i]
        if player and player.deck then
            DeckManager.SetDeck(player.playerIndex, player.deck)
        end
    end

    battlePhase_ = Shared.BATTLE_PHASE.PLAYING
    battleTimer_ = GameConfig.BATTLE_DURATION[currentMode_] or GameConfig.BATTLE_DURATION_DEFAULT
    syncAccumulator_ = 0
    mapInitSent_ = false

    Server.InitGrid(maxPlayers_, 2)

    print("[Server] Battle started! Mode: " .. currentMode_ .. " Duration: " .. battleTimer_ .. "s")

    local startData = VariantMap()
    startData["Duration"] = Variant(battleTimer_)
    network:BroadcastRemoteEvent("BattleStart", true, startData)

    Server.SendMapInit()
    mapInitSent_ = true
end

function Server.EndBattle()
    battlePhase_ = Shared.BATTLE_PHASE.ENDED

    -- 倒计时结束：按领地格数判定胜负
    local winner = Server.CheckTerritoryWinner()  -- 1, 2, 或 0(平局)

    local p1Count = 0
    local p2Count = 0
    for _, tile in pairs(tileStates_) do
        if tile.team == 1 then p1Count = p1Count + 1 end
        if tile.team == 2 then p2Count = p2Count + 1 end
    end

    local endData = VariantMap()
    endData["Winner"] = Variant(winner)
    endData["P1Count"] = Variant(p1Count)
    endData["P2Count"] = Variant(p2Count)
    endData["IsDraw"] = Variant(winner == 0)
    endData["Mode"] = Variant(currentMode_)
    network:BroadcastRemoteEvent("BattleEnd", true, endData)

    print("[Server] Battle ended (timer). Winner: " .. winner .. " P1: " .. p1Count .. " P2: " .. p2Count)
end

--- 检查即时胜利条件：敌方队伍所有建筑全灭
function Server.CheckWinCondition()
    if currentMode_ == "2v2" then
        local aliveSlots = {}
        for _, inst in pairs(buildings_) do
            if inst.slot then
                aliveSlots[inst.slot] = true
            end
        end
        for _, unit in ipairs(units_) do
            if unit.slot and not aliveSlots[unit.slot] and unit.state ~= "dead" then
                unit.hp = 0
                unit.state = "dead"
            end
        end
    end

    local winner = Server.CheckVictory()
    if winner then
        battlePhase_ = Shared.BATTLE_PHASE.ENDED

        local p1Count = 0
        local p2Count = 0
        for _, tile in pairs(tileStates_) do
            if tile.team == 1 then p1Count = p1Count + 1 end
            if tile.team == 2 then p2Count = p2Count + 1 end
        end

        local endData = VariantMap()
        endData["Winner"] = Variant(winner)
        endData["P1Count"] = Variant(p1Count)
        endData["P2Count"] = Variant(p2Count)
        endData["AllDestroyed"] = Variant(true)
        endData["Mode"] = Variant(currentMode_)
        network:BroadcastRemoteEvent("BattleEnd", true, endData)

        print("[Server] Enemy team eliminated! Winner: " .. winner)
    end
end

-- ============================================================================
-- 状态同步（新协议：MapInit 一次 + BattleSync 增量 + TileFlipped 事件）
-- ============================================================================

--- 首次全量地图同步（仅战斗开始时发1次）
function Server.SendMapInit()
    local syncData = VariantMap()
    syncData["MapJSON"] = Variant(Shared.SerializeMap(tileStates_))
    syncData["SpawnsJSON"] = Variant(Shared.SerializeSpawns(spawnData_))
    syncData["Timer"] = Variant(battleTimer_)
    network:BroadcastRemoteEvent("MapInit", true, syncData)
end

--- 增量战斗状态同步（每100ms）
function Server.SyncBattleState()
    local slotSpirits = {}
    for i = 1, maxPlayers_ do
        slotSpirits[i] = players_[i] and players_[i].spiritStones or 0
    end

    -- 兼容旧客户端：1v1 使用 slot1/slot2，2v2 新客户端使用 SlotSpiritsJSON
    local p1Spirit = players_[1] and players_[1].spiritStones or 0
    local p2Spirit = players_[2] and players_[2].spiritStones or 0

    local syncData = VariantMap()
    syncData["Timer"] = Variant(battleTimer_)
    syncData["P1Spirit"] = Variant(p1Spirit)
    syncData["P2Spirit"] = Variant(p2Spirit)
    syncData["SlotSpiritsJSON"] = Variant(require("cjson").encode(slotSpirits))
    syncData["UnitsJSON"] = Variant(Shared.SerializeUnits(units_))
    syncData["BuildingsJSON"] = Variant(Shared.SerializeBuildings(buildings_))

    -- 领地染色变更（批量下发后清空队列）
    if #territoryChanges_ > 0 then
        syncData["TerritoryChangesJSON"] = Variant(require("cjson").encode(territoryChanges_))
        territoryChanges_ = {}
    end

    network:BroadcastRemoteEvent("BattleSync", true, syncData)
end

-- ============================================================================
-- 供单机模式 Client 直接读取的 getter 方法
-- ============================================================================

function Server.GetTileStates()
    return tileStates_
end

function Server.GetSpawns()
    return spawnData_
end

function Server.GetBuildings()
    return buildings_
end

function Server.GetGridHexes()
    return gridHexes_
end

--- 获取当前地图模板ID
---@return string
function Server.GetTemplateId()
    return currentTemplateId_
end

--- 获取当前对战模式
---@return string
function Server.GetCurrentMode()
    return currentMode_
end

--- 设置对战模式
---@param mode string
function Server.SetMode(mode)
    currentMode_ = mode
    maxPlayers_ = (mode == "2v2") and 4 or 2
end

return Server
